# Entwicklung 04 — Native Mutterhalter und gestufte Lageraufnahmen

## Abgearbeiteter nächster Konstruktionsschritt

Entwicklung 03 konnte Motorträger, Distanzhülsen und einfache Flanschplatten mit
Durchgangsbohrungen bauen. Für Muttergehäuse und Lageraufnahmen fehlten Stufenbohrungen,
Schultern und Kopfversenkungen. Diese Bauteilfamilie ist nun implementiert und in dieselbe
native Erzeugungs- und Achsmodulstruktur eingebunden. Es handelt sich um einen Software- und
Konstruktionsbaustein, nicht um fertig an die SX3.5Z angepasste Halter.

## 1. Datenherkunft: drei Ebenen strikt getrennt

**Nutzerunterlage:** BF20_neu.zip / BF20_neu/BF20_neu.pdf, Seite 16, Zeichnung BF20-17,
Christoph Selig, 06.09.2008. Nennmaße 43×20×19,5; Lochabstand 30; zwei Durchgänge Ø6,6 und
Zylindersenkungen Ø11×6,4. Die symmetrische Lage der Bohrungen bei x=±15/y=0 ist die
explizite Auslegung der symmetrischen Ansicht. Die markierten Eckfasen 2,8 werden nicht
als Schenkelmaß interpretiert und sind **nicht modelliert**. Stahl ist angegeben,
eine genauere Werkstoffsorte wird nicht erfunden. Nutzerquelle bleibt unverändert.

**Eigenentwürfe:** Mutter-Flanschträger 66×66×18, Lageraufnahme 80×60×24 und Deckel 80×60×6.
Deren Anschlussdurchmesser/-abstände sind reine, zentral änderbare Entwurfswerte. Sie
repräsentieren keine ausgewählte Kaufteilvariante und keine gemessenen SX-Interfaces.
Kein fiktives Kugelmuttern-/Lager-Kaufteil ist in der Demonstrationsbaugruppe enthalten.

**Herstellerrecherche:** isel-Produktseite und THK-Support-Unit-Seiten wurden geöffnet.
Ein verwendbarer, zu einer gewählten Mutter-/Lagerpaarung gehörender Zeichnungs-/CAD-Satz
war nicht erhältlich. isel-Katalogabruf und direkter Download scheiterten; THK nennt
Mitgliedschaft für CAD. Das berechtigt NICHT dazu, vermutete Herstellermaße einzusetzen.
Ergebnisse/Links stehen in `reference/Quellen_04.json`.

## 2. Geometrievertrag

Alle neuen Bohrungen sind parallel zu lokal +Z; das Grundteil ist ein Quader.
Jede Bohrung besitzt x/y, Durchgangsdurchmesser und optional Front-/Rückstufe mit Tiefe.
Die Stufen müssen größer als der Durchgang sein. Vorder- und Rückstufe dürfen sich nicht
axial überschneiden; eine positive Restschulter bleibt bestehen. Maximalradien verschiedener
Bohrungen müssen sich im XY-Querschnitt mit der angegebenen Mindestwand trennen.
Diese konservative Bedingung kann manche real herstellbaren gestaffelten Taschen ablehnen;
es wird nicht versucht, beliebige überlappende Taschen zu behaupten.

Exaktes analytisches Abtragsvolumen pro Bohrung unter diesen Einschränkungen:

`V = pi/4 * [d²*T + (D_front²-d²)*t_front + (D_rear²-d²)*t_rear]`

Nur vorhandene Stufen gehen ein. Die zentrale Durchgangsfläche wird somit **nicht doppelt**
subtrahiert. Die Zwischenvolumina ergeben sich in der Reihenfolge Rohteil → Durchgang →
Frontstufe → Rückstufe → nächste Bohrung. Die Volumenprüfung ist eine Eingabe-/Referenzprüfung,
kein anderer CAD-Kern. Reale Solids werden ausschließlich mit NX erzeugt.

Alle Maße sind benannte NX-Ausdrücke (`width`, `thickness`, `hole_seat_front_depth` usw.).
Die Rohteil- und Schnittkonturen beziehen sich auf diese Ausdrücke. Gegenläufige Rückstufen
werden als +Z-Zylinder ab `thickness-rear_depth` aufgebaut; keine geratenen ReverseDirection-
Varianten werden benötigt. Die Sitz-/Schultergeometrie bleibt beim Ändern der Dicke abhängig.

## 3. Tatsächlich implementierte NX-Prüfschritte

Für jeden der 46 Rohteil-/Abzugsschritte des Standardkatalogs wird im Code ein reales
NX-Volumen gemessen und mit dem analytischen Zwischenwert verglichen. Hinzu kommen die
Endbegrenzungen und ein einzelner Solid als erwartetes Ergebnis.

Je Teil folgen zwei Parameterproben: Dicke + 1 mm und Änderung einer vorhandenen Stufentiefe
bis 0,5 mm. Die Sollvolumina werden neu berechnet, nicht als `Volumen/Dicke` angenähert;
dieser frühere Ansatz wäre bei Sackstufen falsch. An einer Grenzschulter wird eine
zulässige Verringerung der Tiefe verwendet. Ursprüngliche Ausdrücke werden auch bei
Fehlern wiederhergestellt und erneut geprüft. Insgesamt acht Probeänderungen im Standardfall.

Die Komponentenmatrix wird wie in 03 am asymmetrischen NX-Testkörper kalibriert. Nach
Einsetzen jedes der vier Vorkommnisse werden dessen NX-Körpergrenzen gegen die vorgesehenen
Darstellungspositionen geprüft. Die Formelprüfung des Deckels kontrolliert gemeinsame Achse,
Anlagefläche, Außenkontur und vier Bohrungspositionen. Das ist **kein** überprüfter
Lager-Axialstapel, Vorspannungsnachweis oder exakter Flächen-Kontakttest.

Diese Absätze beschreiben den implementierten Code. Ein NX-Ergebnisprotokoll liegt hier
nicht vor. Offline wird kein native_execution=True-Prüfbericht erzeugt.

## 4. Integration statt Parallelprojekt

`construction/housing04.py`: Schema, Formeln, Bohrungstabelle, analytische Stufenprüfung.
`construction/library04.py`: Katalog, Deckel-/Gehäusekonsistenz, Berichte und Darstellungspositionen.
`construction/recipes03.py`: neue Klasse wird in die gemeinsame Rezeptprüfung delegiert.
`cnc_nx/build03.py`: derselbe native Builder, zusätzliche Zwischenvolumen- und Stufentiefenprüfungen.
`cnc_nx/housings04.py`: tatsächlicher NX-Aufbau und Speichern der Bibliotheksbaugruppe.
`NX_14_Mutterhalter_Lageraufnahmen.py`: neuer Journal-Einstieg.
`Projekt04_Halterbericht.py`: ausschließlich Offline-Berichte.

Bestehende X/Y/Z-Module können neue Halterrezepte in `custom_parts` erhalten. Sie brauchen
weiter geprüfte Rahmen und Einbaulagen. Kein Journal trägt erfundene SX-Maschinenlagen ein.
Der Übernahme-/Ausschlussplan vorhandener Parts und alle Originaldateischutzprüfungen bleiben.

## 5. Nicht enthalten / nächste datengebundene Arbeit

Keine reale Kugelmutter-/Lagerauswahl, keine Hersteller-CAD-Imports, keine fertigen
Wellenenden, keine Threads/Präzisionssitztoleranzen, keine Befestigungsmittel, keine
Fertigungszeichnungen. CSV-Bohrungstabellen sind Modellberichte, keine Zeichnungen.
Keine aktualisierte vollständige CNC-Maschinenbaugruppe oder neuer Maschinen-STEP.

Mit bestätigten Kaufteil- und Maschinenanschlussdaten können genau diese Rezepte verwendet
werden, statt neue Halterprogramme zu schreiben. Dazu sind insbesondere Sitzdurchmesser,
Schulterlage, Lagerpaket, Montageflächen/Lochbilder und Freigang an der realen Maschine zu
belegen. Die fehlenden Daten verhindern nicht den eigenständigen Lauf von Journal 14.

## 6. Originalschutz, Versionsstand und Paket

Eigene Laufordner unter Projekt04, eigene eindeutige Partnamen, keine Originaländerungen.
Die bisherige v4.8-Bestandsrekonstruktion wird nicht gepatcht. Vorhandene Journale 01–13 bleiben.
Das ZIP enthält alte Referenzberichte zur Nachvollziehbarkeit; der aktuelle Bericht ist
`reports/Pruefbericht_Entwicklung_04.json`. Dateiprüfsummen gelten für die tatsächlich
beigelegten Dateien, nicht für ungespeicherte, auf Nutzerrechnern vorhandene NX-Geometrie.
