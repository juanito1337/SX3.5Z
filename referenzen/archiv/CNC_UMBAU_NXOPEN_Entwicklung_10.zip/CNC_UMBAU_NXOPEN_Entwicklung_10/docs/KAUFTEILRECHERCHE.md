> Historischer Stand Analyse 01, unveränderte Grundlage. Für Konzept 02 gelten KONZEPT_02.md und QUELLEN_02.md; keine neuen Freigaben aus diesem Dokument ableiten.

# Herstellerrecherche – Kandidaten, keine Bestellfreigabe

Recherche: 26.10.2026. Herstellerangaben und Datei-/CAD-Verfügbarkeit sind getrennte
Nachweise. Eine aktuell erreichbare Produktseite ist keine Lagerbestands- oder
Lieferzeitzusage. Keine Preise, Händlerlagerstände oder verbindlichen Angebote geprüft.

## 1. Mesa 7i95T – vom Nutzer festgelegte Steuerung

Quelle M01: Mesa, 7i95T Manual V1.2, PDF-Seite 6 (Druckseite 1):
https://www.mesanet.com/pdf/parallel/7i95tman.pdf

Sechs Step/Dir-Achsen, sechs Encoderkanäle, 24 isolierte Eingänge und sechs isolierte
Ausgänge; Ethernet-Anbindung. Step/Dir-Ausgänge: differenzielle 5-V-Signale. Die
Kartenversorgung ist 5 V; die 4–36-V-Angabe der isolierten Eingänge ist **nicht**
die Versorgungsspannung der Logik. Mechanischer Einbau und Versorgung/EMV bleiben
zu planen. Ein vorhandener 24-V-Trafo ist kein nachgewiesenes passendes CNC-Netzteil.

Kein dedizierter 0–10-V-Spindelausgang wird aus dieser Funktionsliste abgeleitet.
Eine Anbindung des originalen W92-/XMT-Spindelantriebs braucht dessen nachgewiesene
Schnittstelle. Die Hall-Sensorklemmen SA/SB/SC werden nicht als Sollwerteingang benutzt.
Die Karte ist eine Schnittstellenkarte, kein Motor-Leistungstreiber.

LinuxCNC-Quelle M02:
https://linuxcnc.org/docs/stable/html/man/man9/hm2_eth.9.html
Der hm2_eth-Treiber dokumentiert HostMot2-Ethernet und eine dedizierte Ethernet-
Verbindung. Die genaue 7i95T-Firmware, Pinbelegung und lokale LinuxCNC-Version
müssen vor einer INI/HAL-Freigabe festgelegt werden. Kein getestetes INI/HAL in dieser Stufe.

## 2. Kugelgewindetriebe

M03: isel Ø16 mm:
https://www.isel.com/produkte/kugelgewindespindel-oe16-mm

Hersteller nennt Ø16 mit 2,5/4/5/10/20 mm Steigungen, kundenspezifische Endenbearbeitung
und CAD-Zugang über Traceparts. Damit ist **16×4** aus der historischen BF20-Liste
als aktuell geführte Produktfamilienvariante belegbar. Nicht belegt sind eine bereits
ausgewählte Mutter, deren Vorspannung und endgültige Längen/Enden für die SX3.5Z.

M04: isel Ø20 mm:
https://www.isel.com/produkte/kugelgewindespindel-oe20-mm
Hersteller führt 5/10/20 mm Steigungen. Ø20×5 ist ein separater Kandidat, nicht aus
den BF20-Zeichnungen übernommenes Originalmaß und keine festgelegte Z-Spindel.

CAD-Weg laut Hersteller:
https://www.traceparts.com/els/isel/de/search/isel-germany-gmbh?CatalogPath=ISEL%3AISEL.1
**Keine konkrete Hersteller-STEP-Datei wurde in dieser Sitzung heruntergeladen.**
Ein angegebener Portalzugang ist nicht gleichbedeutend mit einem verifizierten Modell.
Die aus Zeichnungen stammenden BF20-Mutternformen werden nicht als heutige,
identisch verfügbare isel-Artikel ausgegeben.

## 3. Motor-/Treiberkandidaten für die Auslegung

M05: Leadshine CS-M22326:
https://www.leadshine.com/product-detail/closed-loop-stepper-drive/closed-loop-stepper/CS-M22326.html

Herstellerdaten: 2-phasig, NEMA23, Länge104 mm, Welle8 mm, Zentrierung38,1 mm,
5 A Phasenstrom, 2,6 Nm **Haltemoment**, 1.000 Linien/4.000 Zählschritte pro Umdrehung
am inkrementellen Geber. Das Haltemoment ist keine dynamische Drehmomentfreigabe.
Kein Nachweis, dass dieser Motor X, Y oder Z ausreichend antreibt. Montagefläche,
Bohrbild, Last-/Drehzahlkurve und thermische Randbedingungen bleiben zu prüfen.

M06: Leadshine CS-D508:
https://www.leadshine.com/product-detail/CS-D508.html

Hersteller nennt Step/Dir bzw. CW/CCW, 20–50 VDC und maximal8 A. Die Produktseite
führt CS-M22326 als zugeordneten Motorkandidaten. Gehäuse116×69,2×26,5 mm. Der
Regelkreis zwischen Treiber und Motor ist nicht automatisch ein geschlossener
Linearpositionsregelkreis in LinuxCNC. Eine zusätzliche Encoderaufschaltung an Mesa
wird nicht ungeprüft verdrahtet. Weder Netzteilauswahl noch Mikroschritte sind final.

Hersteller-CAD-Portal:
https://www.leadshine.com/download/3D%20Modelings.html
Keine konkrete STEP-Datei erhalten; CAD-Revision und Vollständigkeit daher offen.
Kein beliebiges NEMA23-Modell als Originaldatei ausgegeben.

## 4. Lagerungen und Kupplung

M07: THK Support Unit:
https://www.thk.com/eu/en/products/ball_screw/support_unit/
https://www.thk.com/eu/en/products/ball_screw/support_unit/ek_bk_fk/
https://www.thk.com/eu/en/products/ball_screw/support_unit/ef_bf_ff/

THK dokumentiert BK/EK/FK als Festlagerfamilien und BF/EF/FF als Abstützungsfamilien;
Festseite mit vorgespannten Schrägkugellagern, Abstützungsseite mit Rillenkugellager.
Das ist eine überprüfbare Alternative zur historischen Einzel-Lagerlösung, aber
**keine gewählte Größe BK12/BF12**. Wellensitze, Achshöhe, Schulter-/Sicherungskonzept
und Lasten müssen gemeinsam festgelegt werden. Kein automatischer Schluss von
16-mm-Spindelaußendurchmesser auf 12-mm-Lagerzapfen.
CAD-Link führt zum THK-Anmeldebereich; kein Modell heruntergeladen.

M08: KTR, spielfreie Servokupplungen:
https://www.ktr.com/de/de/produkte/spielfreie-servokupplungen-wellenkupplungen/

Reale Familien: ROTEX GS und TOOLFLEX. Nur Familienkandidaten für Direktantrieb,
keine freigegebene Baugröße/Bohrung/Zahnkranzhärte. Ein Riemenantrieb nach BF20-Prinzip
ist eine getrennte Alternative. Die orange Originalkupplung ist nicht allein anhand
der Farbe als passender spielfreier Servotyp identifiziert.

## 5. Noch nicht ausgewählt

Kugelmuttern samt exakter Artikelnummer, Lagergrößen, Endenbearbeitung, Kupplungs-
oder Riemenausführung, Z-Antrieb und Halteeinrichtung, Referenz-/Endschalter,
Netzteile, Schütze/Sicherheitsbauteile, Kabel, Schaltschrank und Spindelschnittstelle.
Diese Positionen bleiben ausdrücklich offen. Der finale BOM-Datensatz ist deshalb
nicht erstellt. `config/component_database.json` ist ein **Recherche-/Nachweisregister**,
nicht eine vollständige, bestellbare Stückliste.

## Nächster Nachweis je Kaufteil

Bestellcode und Variante → Herstellerzeichnung und Revisionsstand → Original-CAD
oder belegte Ersatzgeometrie → Anschlussabgleich in Original-NX-Baugruppe →
Last-/Dynamikprüfung → Endlagen/Kollisionen → Fertigungs-/Bestellfreigabe.
Ein Portal-Link oder ein nominaler Durchmesser überspringt keinen dieser Schritte.
