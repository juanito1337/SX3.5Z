# Abnahmematrix – Konzept 02 / 27.10.2026

Maßstab ist `reference/NUTZERANFORDERUNGEN.txt`, nicht die Anzahl der Dateien.

| Promptbereich | Bearbeitet | Noch nicht erreicht |
|---|---|---|
| 1 NX/NXOpen | alle neuen CAD-Generatoren verwenden NXOpen, keine Ersatz-CAD-Konstruktion | echte Ausführung hier nicht möglich |
| 2 Originalbestand | lesender Audit, Referenzcontainer, Hash-/Eigentumsschutz | tatsächliche native Originaldateien und Audit fehlen hier |
| 3 API | Laufzeitbefund, bekannte Aufrufmuster, Fehlerprotokoll | offizielle NX2406-Webreferenz nicht zugänglich, neue Journale nicht runtime-verifiziert |
| 4 Parametrik | drei native Entwurfsmuster mit benannten Ausdrücken, vorgesehenem Änderungstest | keine anschlussmaßlich freigegebenen Halter |
| 5 Kaufteil-CAD | Herstellerfamilien und Quellenregister, Statuskennzeichnung | keine passende Hersteller-STEP-Datei heruntergeladen und validiert |
| 6 CNC-Montage | Bewegungskonzept, getrennte Zielhierarchie, Schutzstrategie | finale native Montage nicht implementiert/erzeugt |
| 7 Achsmodule | getrennte X/Y/Z-Datenplanmodule und Rahmenvalidator | kein automatischer kompletter Achsaufbau |
| 8 Prüfungen | lokale Mathematik-/Datenprüfungen, 125 normierte Prüfposen | echte NX-Kollision, kontinuierlicher Hub, Festigkeit, Maschine nicht geprüft |
| 9 Zeichnungen | Inhalts- und Freigabeplan | keine NX-Fertigungszeichnungen, PDF-Zeichnungen oder DXF |
| 10 Quellcode | vollständiger Quellcode des implementierten Umfangs | keine Behauptung vollständiger Endautomation |
| 11 Dateien A/B | Generatoren für Teilumfang | keine hier erzeugten nativen `.prt` |
| 11 Datei C | Python-Quellcode vorhanden | nicht in NX ausgeführt |
| 11 Dateien D/E | Export-/Zeichnungsplan | keine CNC-STEP-/Zeichnungsexporte |
| 11 Datei F | Konzept-BOM mit Quellen, Blockern, Konzeptmengen | nicht bestellfertig |
| 11 Datei G | Offline-Prüfbericht | kein vollständiges geometrisches NX-Protokoll |
| 12 Endabnahme | überprüfbare nächste Meilensteine beschrieben | **NICHT ERFÜLLT / PROJEKT NICHT ABGESCHLOSSEN** |

Alle Resultate mit `manufacturing_released=False` / `order_released=False` bleiben
Entwurfsdaten. Das Eintragen von „CONFIRMED“ in eine JSON-Datei ist kein technischer
Prüfnachweis. Eine normale 24-V-I/O-Rückmeldung ist keine Sicherheitsfunktion.
