# Analyse der bereitgestellten BF20-Archive

Stand: 26.10.2026. Alle Seitenangaben sind **PDF-Seiten, ab 1 gezählt**.
Die hier ausgewerteten Zeichnungen sind Fremdmaschinen-Referenzen, kein
vermessener Anschlussdatensatz der fotografierten SIEG SX3.5Z.

## 1. Tatsächlicher Inhalt

| Datei / Dokument | BF20_neu.zip | BF20_alt.zip | Befund |
|---|---:|---:|---|
| Hauptzeichnungssatz | BF20_neu.pdf, 30 S. | BF20alt_Paulimot_HBM.pdf, 34 S. | Unterschiedliche Konstruktionsstände; nicht mischen. |
| Umbauanleitung.pdf | 31 S. | 31 S. | Datei-SHA256 identisch. |
| Einbau Kugelgewindemuttern.pdf | 4 S. | 4 S. | Datei-SHA256 identisch. |
| Montage der Z-Spindel.pdf | 1 S. | 1 S. | Datei-SHA256 identisch. |
| Stückliste Kaufteile BF20.pdf | 1 S. | 1 S. | Datei-SHA256 identisch. |
| Stückliste anzufertigende Teile.pdf | 1 S. | 1 S. | Datei-SHA256 identisch; Überschrift nennt ausdrücklich BF20 alt. |
| Explosionszeichnung_alt.pdf | – | 8 S. | Modellbezeichnung Grizzly G0704; nicht die SX3.5Z. |
| Modifikationen Basismaschine.txt | – | vorhanden | Lager-/Passscheibenänderungen und Positionsnummern. |
| P1050054.jpg / P1050055.jpg | – | vorhanden | Zwei ergänzende Fotos. |
| Filament_Monitor_Idler_V2.gcode | – | vorhanden | Fremder 3D-Druck-G-Code; nicht Bestandteil des Fräsenumbaus. Nicht ausgeführt. |

Neu: 6 Dateien / 6 PDFs. Alt: 11 Dateien / 7 PDFs. Zusammen 17 Dateien,
13 PDF-Dateien und 148 PDF-Seiten einschließlich Duplikaten. Acht unterschiedliche
PDF-Dokumente nach SHA256. **Keine .prt, .step/.stp, .x_t oder sonstige 3D-CAD-Datei
in diesen beiden Archiven.**

Das vollständige Dateiinventar mit Bytegrößen, Hashes und PDF-Seitenzahlen liegt
in `reference/Archivmanifest.json`. `analysis/inspect_archives.py` reproduziert die
Archivlisten und SHA256, ohne Dateien zu entpacken oder Inhalte auszuführen.
Die PDF-Seitenzahlen und Zeichnungsauswertung sind zusätzliche Ergebnisse dieser
Analyse und werden vom reinen Standardbibliotheks-ZIP-Skript nicht neu ermittelt.

## 2. Nachgewiesene Zeichnungsunterschiede

Die folgenden sechs Nenngeometrien wurden in den Zeichnungen visuell abgelesen.
Nicht aus der gemeinsamen Stückliste abgeleitet. Durchmesser und Länge in mm.

| Zeichnung | PDF-Seite | Neu: außen / innen / Länge | Alt: außen / innen / Länge |
|---|---:|---:|---:|
| BF20-09, Abstandshülse X | 8 | 16 / 10 H7 / 15,0 | 13,4 / 10 H7 / 11,3 |
| BF20-11, Abstandshülse Y | 10 | 16 / 10 H7 / 22,0 | 13,4 / 10 H7 / 15,0 |
| BF20-14, Abstandshülse Z | 13 | 20 / 10 H7 / 11,5 | 20 / 17 / 11,3 |

Beim Alt-Z-Innendurchmesser ist in der betrachteten Zeichnung kein H7 eingetragen.
Ein numerisches Toleranzfeld wird nicht hinzugedichtet. Die NX-Referenzteile bilden
nur diese Nennzylinder ab und dokumentieren den Zeichnungsbezug.

Weitere beobachtete Unterschiede:
- Endbearbeitungen der X-/Y-Spindeln in den Hauptzeichnungen, PDF-Seiten 19 und 20.
- Sattelbearbeitung in PDF-Seite 27: Alt enthält zusätzliche Freistellungen;
  nicht pauschal auf den Neu-Satz oder den SX3.5Z-Guss übertragbar.
- Alt enthält auf PDF-Seiten 31–34 weitere Lagerungsteile: BF20-35 Lagerplatte Z,
  BF20-36 Zwischenring, BF20-38 Scheibe, BF20-39 Lagerflansch Y. Es gibt keinen
  gleichlautenden vollständigen Satz dieser Zusatzseiten im Neu-Archiv.
- Ähnliche Titel und Zeichnungsnummern bedeuten nicht identische Passflächen.
  Auch die Z-Spindelseite im Alt-Archiv enthält die Bezeichnung „neu“; der
  Archivname allein entscheidet deshalb keinen gültigen Montagezustand.

## 3. Was das dokumentierte BF20-Konzept tatsächlich vorsieht

Quelle: `Stückliste anzufertigende Teile.pdf`, Seite 1 in beiden Archiven;
Konstruktion durch Christoph Selig, zugehörige Hauptzeichnungen überwiegend 2008.

| Achse | Gewindetrieb in der Liste | Rohteil-Längenangabe | Separate Verlängerung | Historische Lagerangabe |
|---|---|---:|---:|---|
| X | 16 × 4, eckige Mutter | 683 | 85 × D16 | 3000-2RSR sowie 6000-2RSR |
| Y | 16 × 4, eckige Mutter | 287 | 90 × D16 | 3000-2RSR |
| Z | 16 × 4 mit separatem Mutterngehäuse | 410 | 100 × D24 | 3003-2RSR |

**Das sind Rohteil-/Halbzeugangaben, keine drei bestellfertigen SX-Spindellängen.**
Die im alten Gespräch erwogenen 1605/2005 stimmen nicht automatisch mit dieser
16×4-Konstruktion überein; sie bleiben unterschiedliche Auslegungsoptionen.

Die Stückliste nennt pro Achse eine Riemenscheibe **HTD 5×9, 30 Z** und ein
Motorritzel **HTD 5×9, 15 Z**. Rechnerische Folgerung (kein weiterer Quellenwert):
Motorumdrehungen/Spindelumdrehung = 30/15 = 2. Bei 4 mm Spindelvorschub je
Umdrehung ergeben sich 2 mm Achsweg pro Motorumdrehung. Dies ist keine freigegebene
LinuxCNC-Skalierung der tatsächlichen Maschine.

Beispiel nur zum Rechenweg: 200 Vollschritte × 16 Mikroschritte × 2 / 4 mm =
1.600 Impulse/mm. Motor, Treiber, Mikroschrittwahl und Übersetzung deiner SX sind
noch nicht endgültig festgelegt. Kein HAL-/INI-Produktionsdatensatz daraus erzeugt.

## 4. Quellenkonflikte und nicht übertragbare Angaben

- Beide Archive teilen die gleiche Fertigungsliste mit Überschrift **„BF20 alt“**.
  Beispiel X-Hülse: Rohteil 12 × D16 in dieser Liste, während die Neu-Zeichnung
  15 mm Fertiglänge zeigt. Eine 12-mm-Rohlänge kann kein 15-mm-Fertigteil liefern.
  Deshalb keine gemeinsame, ungeprüfte Einkaufs-/Zuschnittliste erzeugen.
- Materialien unterscheiden sich teilweise zwischen Liste und Zeichnungen
  (beispielsweise Al Cu Mg 1 gegenüber Al Cu Mg Pb). Keine stillschweigende
  Werkstoffsubstitution oder neue Normgleichsetzung vorgenommen.
- `Modifikationen Basismaschine.txt` nennt für 6000 „10×26×12“. Diese Angabe
  wurde **nicht als Herstellermaß verifiziert** und wird nicht in eine Lageraufnahme
  übernommen. Die Datei selbst bleibt unverändert; keine verdeckte Korrektur.
- Die Kaufteilliste nennt historische einfach-cnc-Kits MX010/MX010A, SN002,
  SN006 usw. Heutige Lieferbarkeit und vollständige Ausführung sind nicht belegt.
- Montagehinweise zum Entfernen von Kegelrädern, Abfräsen von Originalteilen,
  Weglassen einer vierten Schraube oder Schmierintervallen betreffen den jeweiligen
  BF20-Umbausatz. Sie sind **keine SX3.5Z-Freigabe und keine allgemeine Sicherheits-
  oder Festigkeitsbewertung**.
- Vier historische induktive Schalter aus einem Umbausatz sind kein vollständiger
  Nachweis eines CNC-Referenz-, Endlagen- und Not-Halt-Konzepts.

## 5. Abgrenzung zur vorhandenen SX3.5Z

Im verfügbaren Dateibestand liegt die frühere Python-Modelldefinition v4.8 vor,
aber keine vom Nutzer tatsächlich gespeicherte native Hauptbaugruppe mit ihren
referenzierten .prt-Dateien. Deren Features, Änderungen, absoluten Koordinaten,
Referenzsets und unter Umständen verschobenen Komponenten wurden hier daher
**nicht in NX gelesen**.

Die Rezeptanalyse zeigt 179 Teile, 10 Gruppen, 887 Operationen, 215 Eingabeparameter
und 49 abgeleitete Ausdrücke. Von den Eingabeparametern sind 191 als Fotoannahmen
markiert, 18 als Dokumentdaten, 5 als Stellungen und 1 als Normreferenz. Auch
Dokumentdaten sind nicht automatisch Messwerte des konkreten Exemplars.

Das Rezept benennt X/Y/Z und neutrale Positionen, enthält aber keine Abnahme der
realen Anschlussstellen. `reference/Vorheriges_Rezept_Analyse.json` ist deshalb
mit `PYTHON_RECIPE_NOT_NX_RUNTIME` gekennzeichnet. Der neue lesende NX-Audit muss
auf der tatsächlich vorhandenen Baugruppe laufen, bevor daraus neue Halterpositionen
abgeleitet werden.
