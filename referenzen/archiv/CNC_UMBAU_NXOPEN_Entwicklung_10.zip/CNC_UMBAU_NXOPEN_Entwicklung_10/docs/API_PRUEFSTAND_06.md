# API-Prüfstand Entwicklung06

**Ziel:** NX2406 / eingebettetes Python3.10. **Autor-NX-Ausführung:** keine.
Neue Methoden sind nicht durch Offline-Mocks als native Funktionsnachweise bestätigt.

## Recherche und Beleggrenzen

Abrufversuche der offiziellen Siemens-Webreferenzen am 27.10.2026:
- https://docs.sw.siemens.com/en-US/doc/209349590/PL20240624518972719.nxopen_net
- https://docs.plm.automation.siemens.com/data_services/resources/nx/1926/nx_api/custom/en_US/nxopen_python_ref/NXOpen.Drawings.DrawingSheetCollection.html

Beide Adressen waren über den Recherchezugang nicht zugänglich. Daraus folgt weder,
dass die Funktionen in NX fehlen, noch eine Bestätigung ihrer Python-Signaturen.
Als Deklarationshilfe wurden die NX-generierten .NET-2022.1-Referenzseiten unter
`https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/` eingesehen.
Dies ist **ein Spiegel älterer .NET-Referenzen, keine offizielle NX2406-Python-Prüfung**.
Entsprechende Methoden sind im Code implementierte Kandidaten mit Laufzeitdiagnose.

## Verwendete neue Methoden und Kontrollen

| Methoden / Eigenschaften | Herkunft / Kontrolle | Offen |
|---|---|---|
| `View.Orient(Matrix3x3)`, `ViewCollection.SaveAs(View, name, bool, bool)` | .NET-Referenz; gespeicherte Matrix wird verglichen | tatsächliche Python-Bindung, Anzeigeverhalten |
| `DrawingSheetCollection.InsertSheet(...)`, `DrawingSheet.Open()` | vorhandener dokumentierter Legacy-API-Weg, Präsenzprüfung | NX2406-Überladung/Enum-Werte, Lizenzen, Drafting-Kontext |
| `UF.Draw.InitializeViewInfo`, `ImportView` | live Python-Docstring muss 0 bzw. 4 Eingaben ausweisen | tatsächlicher Rückgabewert-/Struct-Typ |
| `SetViewScale`, `UpdateOneView`, `MoveView`, `AskViewBorders` | Präsenz; AskViewBorders prüft live 1-/2-Eingabesignatur; Blattabmessung/-lage wird gemessen | Ansichtsränder, ausgeblendete Hilfsobjekte, Repräsentation |
| `Annotations.CreateDraftingNoteBuilder`, Origin/Style/Text | .NET-Referenz; Commit muss Objekt liefern; Builder wird freigegeben | Schrift, Zeilenabstand, Blattbindung, visuelle Anordnung |
| `PlotManager.CreatePrintPdfbuilder`, `SourceBuilder.SetSheets`, `Commit` | .NET-Referenz; Dateiname, Nicht-Anhängen, Wassertext; reale Dateiprüfung nach Commit | Übersetzer/Lizenz, PDF-Seitenlayout, visuelle Kontrolle |

Referenzseiten: `NXOpen.View.html`, `NXOpen.ViewCollection.html`,
`NXOpen.Drawings.DrawingSheetCollection.html`, `NXOpen.UF.UFDraw.html`,
`NXOpen.Annotations.DraftingNoteBuilder.html`, `NXOpen.Annotations.OriginBuilder.html`,
`NXOpen.PlotManager.html`, `NXOpen.PrintPDFBuilder.html` unter obiger Spiegeladresse.

`NX_API_Befund.json` enthält die tatsächlich erreichbaren Python-Methodendokumentationen
und nennt nur Laufzeitpräsenz. Eine Methodenpräsenz allein ist kein Erfolgsnachweis.
Eine fehlende Funktion stoppt den betreffenden nativen Ablauf; es wird nicht ein
Bild/PDF aus einem anderen Programm als erfolgreicher NX-Export ausgegeben.

Die vorhandenen nativen Solid-/Mess-/Speicheradapter werden unverändert genutzt.
Auch deren Tests auf dieser Plattform sind keine aktuellen Zielrechner-Nachweise.
`NewParts` speichert nur eigene neue Teile, mit `SaveComponents=False`.

## Zu prüfen in der Zielinstallation

Journal17 vollständig ausführen. Für jedes Teil müssen Native-View-Extentkontrolle,
Ausdruckssnapshot und Solid-Nachkontrolle bestehen. Die PDFs und `.prt`-Blätter
anschließend visuell öffnen. Erst danach ist die betreffende Drafting-Funktion für
diesen konkreten Lauf nachgewiesen, weiterhin ohne Fertigungsfreigabe.
