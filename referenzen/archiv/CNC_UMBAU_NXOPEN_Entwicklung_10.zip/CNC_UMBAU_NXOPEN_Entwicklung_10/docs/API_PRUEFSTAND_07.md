# API-Prüfstand Entwicklung07
Ziel NX2406, Python3.10. **Nicht in NX vom Autor ausgeführt.**

Keine neue Modellierungs- oder NX-Teilelistenfunktion. Der lesende Pfad verwendet
bereits im Projekt vorhandene Zugriffe:
- Session.Parts.Display; Part.ComponentAssembly.RootComponent
- Component.GetChildren(), Prototype, IsSuppressed, ReferenceSet, Name, Tag
- Part.FullPath, Name, IsFullyLoaded, IsModified, Bodies; Body.IsSolidBody

Keine Setter, Open/Load, Save, SaveAs, Suppress oder Positionierung in Journal18.
Journal19 benutzt zusätzlich unverändert den Generator von Journal07; seine
Modellierungs-, Speicher- und Kalibrierungsgrenzen aus Entwicklung03 gelten weiter.

Rückgaben werden geprüft: unbekannte Booleans werden nicht in wahr/falsch umgedeutet,
GetChildren-Fehler nicht als leere Unterbaugruppe ausgelegt. Nicht erreichbare Dateien
oder Änderungen werden als unvollständig bzw. Integritätsfehler ausgewiesen.
Die Daten-/Dateilogik wurde lokal getestet, NX-Randobjekte simuliert. Daraus folgt
keine bestätigte NX-Laufzeitkompatibilität.

Die offizielle Siemens-NX2406-Webreferenz wurde für diesen Schritt versucht:
https://docs.sw.siemens.com/documentation/external/PL20240624903789847/en-US/nx_api/nxopen_python_ref/NXOpen.Assemblies.Component.html
https://docs.sw.siemens.com/documentation/external/PL20240624903789847/en-US/nx_api/nxopen_python_ref/NXOpen.BasePart.html
Beide Adressen waren über den Webzugriff nicht zugänglich; kein Quelleninhalt daraus
als verifiziert ausgegeben. Laufzeitverfügbarkeit und Fehler werden protokolliert.
