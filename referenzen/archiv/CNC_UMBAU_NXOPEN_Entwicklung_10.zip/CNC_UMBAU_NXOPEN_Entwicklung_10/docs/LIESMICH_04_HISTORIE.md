# SX3.5Z CNC-Projekt — Entwicklung 04

## Neuer Schritt: Mutterträger und gestufte Lageraufnahmen

Vollständige Fortsetzung von Entwicklung 03. Kein Patch für die alte v4.x-Maschinenrekonstruktion.
Die native Teilefamilie unterstützt axiale Durchgangsbohrungen mit vorderen und hinteren
Zylinderstufen, verbleibenden Schultern und Schraubenkopfsenkungen. Keine andere CAD-Software.

**Hier keine NX-Ausführung; keine erzeugten .prt-Dateien im ZIP.** Diese entstehen erst bei
erfolgreichem Journallauf in Siemens NX 2406. Die Lieferteile sind Entwurfs-/Referenzteile,
keine passenden SX-Maschinenhalter, keine freigegebenen Festlager oder Kaufteilnachbauten.

## Sofort nutzbarer Einstieg in NX

1. Vollständig in einen neuen Ordner entpacken; keine Dateien zwischen Projektständen mischen.
2. In NX 2406 über Journal wiedergeben / Play Journal `NX_14_Mutterhalter_Lageraufnahmen.py` starten.
3. Versionsmeldung `SX3.5Z CNC-Projekt 4.0 / Modus housings04` beachten.
4. Der Lauf liest alle Eingaben vor der Erzeugung, prüft die NX-Komponentenmatrix an realer
   Testgeometrie und erzeugt danach vier native Einzelteile sowie eine neue Dateibaugruppe.
5. Standardausgabe: `%LOCALAPPDATA%\SX35Z_CNC\Projekt04\<Zeitstempel>_housings04_<Kennung>\`.
   Alternativ einen absoluten lokalen Pfad in `config/project.json` unter `output_root` eintragen.
   Alte erzeugte oder originale Parts werden nicht gespeichert oder überschrieben.

Ergebnis bei erfolgreicher NX-Ausführung:

```
NX_PARTS/
  D04_MUTTERTRAEGER__<Kennung>.prt
  D04_LAGERAUFNAHME__<Kennung>.prt
  D04_LAGERDECKEL__<Kennung>.prt
  R04_BF20_17_Y__<Kennung>.prt
NX_ASSEMBLY/
  HALTERBIBLIOTHEK_04_NICHT_MASCHINENPASSEND__<Kennung>.prt
NX_Halterbibliothek_04.json
NX_Bohrungstabelle_04.csv
Halter_Eingaben_Snapshot.json
NX_Protokoll.txt
NX_API_Befund.json
LAUFSTATUS.json
```

Bei Abbruch entsteht `LAUF_FEHLER.json`; vorhandene Teilausgaben sind keine fertige Bibliothek.

## Umfang und Herkunft der vier Teile

| ID | Nennmaße (mm) | Einordnung |
|---|---|---|
| D04_MUTTERTRAEGER | 66×66×18; Durchgang Ø28,2 / Frontstufe Ø36,2×4; zwei Vierlochbilder | Eigenentwurf; kein gewählter Kugelmuttern-Typ |
| D04_LAGERAUFNAHME | 80×60×24; Durchgang Ø22 / Frontsitz Ø32×16 / Rückstufe Ø26×3 | Eigenentwurf; keine ausgewählte Lagerpassung |
| D04_LAGERDECKEL | 80×60×6; Durchgang Ø26; vier gesenkte Schraubendurchgänge | Eigenentwurf; zum Demonstrations-Lochbild der Lageraufnahme |
| R04_BF20_17_Y | 43×20×19,5; 2×6,6 / Senkung Ø11×6,4; Abstand 30 | Nenngeometrie der Nutzerzeichnung BF20_neu.pdf Seite 16; OHNE Eckfasen |

Die ersten drei Tabellenzeilen sind **nicht aus Herstellerzeichnungen abgeleitet**.
Die BF20-Zeichnung ist ausdrücklich keine SX3.5Z-Anschlusszeichnung. Der Deckel liegt an der
Demo-Lageraufnahme; die übrigen Teile stehen nur nebeneinander. Kein Maschinenkoordinatensystem,
keine montierte Achse, keine Lager-/Kugelmuttern-Kaufteile oder Befestigungsschrauben enthalten.

## Parameter ändern

`config/housings04.json` ist die Eingabequelle für Journal 14. Zahlen sind Millimeter;
`front_depth` ist die Tiefe von lokal z=0, `rear_depth` die Tiefe vom gegenüberliegenden Ende.
Die Wandgrenze ist eine geometrische Plausibilitätsgrenze, kein Festigkeitsnachweis.
Bei ungültigen Kombinationen stoppt das Journal vor dem ersten neuen Teil.
Die Native-Teile besitzen benannte Ausdrücke. Für koordinierte Änderungen im Prüfaufbau
JSON ändern und neu erzeugen. Keine automatische Interpart-Kopplung/Montagezwangsbedingungen.

Alle Rohteile, Durchgänge und Stufen werden nativ aufgebaut. Der implementierte NX-Prüfweg
misst Zwischenvolumina, Endabmessungen und je Teil eine Dicken- sowie eine Stufentiefenänderung.
Ein fehlender oder fehlgeschlagener Test ist nie eine Freigabe.

## Berichte ohne NX

`python Projekt04_Halterbericht.py` erzeugt einen neuen Berichtordner unter `output/`.
Enthalten: Eingaberezept, nominale Volumenrechnung, Bohrungstabelle und Bibliotheksstückliste.
Dies erzeugt **keine CAD-Dateien und keine Fertigungszeichnungen**.
Vorgerechnete Daten liegen unter `reports/04_Halterbibliothek/`.

## Bestehende Funktionen

Journale 01–13 bleiben vorhanden. Die X/Y/Z-Module akzeptieren die neue Rezeptklasse
`stepped_housing04`. Die echten Achskonfigurationen und Maschinenlagen bleiben unbestätigt;
Journal 14 braucht sie nicht. Der vorhandene Bestandsaudit ist weiterhin read-only.
Elektrik, LinuxCNC/Mesa-Auslegung, Originalmaschine und v4.8-Modelldefinition sind nicht geändert.

## Prüfung und Grenzen

Siehe `reports/Pruefbericht_Entwicklung_04.json` und `docs/REVIEW_04.md`.
Offline-Tests prüfen Mathematik, Eingaben, Dispatch und einzelne simulierte NX-Prüfabläufe.
Sie beweisen keine NX-Kompatibilität oder Solidvalidität. Alle Geometrie muss in NX laufen.
Keine neue Hersteller-CAD-Datei wurde heruntergeladen; Recherchegrenzen sind dokumentiert.
Keine Passungstoleranzen, Gewinde, Tragfähigkeit, Schmierung, Z-Absturzsicherung oder
Verfahrwegkollisionen freigegeben. Die finale `FRAESMASCHINE_CNC_UMBAU.prt` bleibt offen.
