# Entwicklung08 — Prüfprotokoll und gemessene Referenz-Schnittstellen

## Einordnung in den Nutzerprompt

Nach 11F (Stückliste) wird 11G (Dokumentation geometrischer Prüfungen) zusammen mit
Teilen von Abschnitt8 umgesetzt. Primärziel bleibt native NX-CAD-Konstruktion.
Das ist kein Abschluss von Abschnitt12 und keine neue physisch eingepasste CNC-Achse.

## Komponenten und Bezugssysteme

Die Prüfreferenz ist unverändert `construction.recipes03.reference_carrier()`.
Z ist dort die Motorwellen-/Hülsenachse. Alle sieben Referenzvorkommen haben in diesem
Rezept Identitätsdrehungen. Der neue native Flächenadapter akzeptiert ausschließlich
solche Drehungen; beliebige Maschinen-/Parent-Transformationen werden nicht geraten.

Er liest die Prototypflächen über den vorhandenen GetFaces/AskFaceData-Pfad und
überträgt sie mit dem tatsächlich gelesenen Translationsvektor. Zuvor werden die
Vorkommniskörpergrenzen über den vorhandenen Messweg geprüft. Die eigentliche Prüfung
vergleicht anschließend unabhängige tatsächliche Zylinderachsen bzw. Planflächen.
Die allgemeine numerische Auswertung ist rotationsfähig, der native Referenzadapter
absichtlich enger. Vermessene Radius-/Punktwerte werden im Ergebnis erhalten.

Die Zuordnung verwendet explizite Nominalschnittstellen, nicht irgendeine erste
gefundenen Zylinderfläche. Bei keiner oder mehreren passenden Flächen entsteht ein
Fehler. Der Suchbereich beträgt 0,5 mm / 1 Grad, die eigentlichen numerischen
Prüfgrenzen sind wesentlich enger. Eine Suchzuordnung ist keine bestandene Prüfung.

## 23 Einzelprüfungen

| Gruppe | Anzahl | Umfang |
|---|---:|---|
| Motorbund/Plattenöffnung koaxial | 1 | Radius-/Achsvergleich |
| Nominaler Durchmesserspalt | 1 | 38,3 minus 38,1 mm aus bestehender Referenz |
| Motorlochbild/Plattenlochbild | 4 | Zylinderachsen, nominale Durchmesser |
| Motorflansch/Plattenoberseite | 1 | Abstand und Parallelität der Ebenen |
| Distanzhülsen/Bohrungen in beiden Platten | 8 | Vier Hülsen, jeweils zwei Gegenseiten |
| Distanzhülsen/Anlageebenen | 8 | Je zwei Stirnseiten pro Hülse |

Die Restmaschine, Lager, Kupplung, Schrauben, Leitungen und dynamische Bewegung sind
nicht Bestandteil dieser Referenz. Die nominellen Durchgangsbohrungen sind keine
fertig ausgelegten Positionier-/Zentrierpassungen. Eine Schraube wird dadurch noch
nicht geometrisch oder festigkeitsseitig nachgewiesen.

## Berichtsbündelung und Bindung

`subject_from_snapshot` verlangt gespeicherte, vollständig geladene, unveränderte
Millimeterteile. Es bindet Rootdatei, alle gelesenen Prototypdateien, Vorkommen,
Unterdrückungs-/Reference-Set-Zustände und Rohpositionen in einen SHA256-Fingerabdruck.
Dateihashes werden bei Auswertung erneut gegen die tatsächlichen Bytes geprüft.

Folgende Nachweise werden getrennt behandelt:

- `native_geometry`: explizit unterstützte Berichte03/04 mit gebundenen Teilehashes,
  endlichem positivem Volumen, plausiblen Grenzen und bestandenem Parameterstatus.
  Aussage bleibt auf die berichteten Teile begrenzt.
- `interfaces`: neuer Bericht08, gleicher Gesamtfingerabdruck, aktuelle Teilpfade,
  gleiche Vorkommnisnamen und -positionen; Messdaten werden erneut ausgewertet.
- `bom`: Bericht07 wird gegen aktuelle aktive Mengen verglichen; verknüpfte
  Dokumentdateien und deren Modellbindung werden frisch geprüft.
- `drawings`: gebundene06-Nennmaßblätter/PDFs sind weiterhin keine freigegebenen
  Fertigungszeichnungen. Sie können andere neu erzeugte Part-Dateien betreffen.
- `step`: aktuelle Modelldatei + Exportdatei vorhanden und hashgebunden. Kein
  Rücklesen/Geometrievergleich allein aus der vorhandenen Exportmeldung.
- `collision_selftest`: nur Prüfung der NX-Schnittstelle; nie Zielmaschinenfreigabe.
- `travel`: ältere05-Auswertung als ungebundener Altbericht gekennzeichnet, da deren
  vollständiger Root-/Unterbaugruppenstand nicht aus dem Bericht bewiesen werden kann.

Unterstützt wird eine bewusst enge Liste von Berichtsschemata. Ein beliebiger JSON-
Text mit „PASS“ ist keine Evidenz. Doppelte JSON-Schlüssel, NaN, falsche Hashes,
Doppelzuordnungen, fehlende Quellen und erkannte Änderungen führen nicht zu Erfolg.
SHA256 dient nicht als digitale Signatur; manipulierte, neu gehashte Berichte lassen
sich damit nicht authentifizieren. Fachliche Prüfung bleibt erforderlich.

## Quellschutz und Fehlerfälle

Vor, nach den NX-Leseoperationen und nach dem Export wird erneut gelesen. Datei-/
Konfigurationsänderungen oder Dirty-Flags verhindern die abschließende Ergebnisdatei.
Nur neue Referenzteile aus dem bestehenden Generator werden gespeichert; keine
Originale laden, reparieren, umpositionieren oder speichern. Bei Fehlschlag bleiben
explizite Diagnose-Zwischenstände erhalten. Keine vollständig publizierte Abschluss-
JSON ohne finalen Guard. Externe gleichzeitige Änderungen können ohne exklusive
Dateisperren nie transaktional ausgeschlossen werden; erkannte Änderungen blockieren.

## Status und Lücken

`INCOMPLETE_NO_RELEASE`: Bericht erstellt, aber keine Gesamtfreigabe. Dies ist der
normale Referenzzustand, selbst bei 23 grünen Schnittstellenchecks.
`BLOCKED`: mindestens ein explizit zugeordneter Nachweis fehlerhaft, veraltet oder
nicht lesbar. `NOT_RUN`: keine entsprechende Prüfung vorgelegt/ausgeführt.
`SCOPE_UNBOUND_LEGACY`/`DIAGNOSTIC_ONLY`: dokumentiert, nicht aufwerten.

Native geometrische Prüfungen sind beim Autor NICHT ausgeführt. Vorhandene
Offline-Tests prüfen Rechen-/Schema-/Dateischutzlogik und simulierbare API-Grenzen.
Maschineneinpassung, Festigkeit, Antriebsauslegung, Sicherheit und finale
CNC-`.prt` bleiben offen. Die vorangegangenen Kaufteil-/Maßannahmen sind unverändert.
