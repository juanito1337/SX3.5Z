> Historischer Stand Analyse 01, unveränderte Grundlage. Für Konzept 02 gelten KONZEPT_02.md und QUELLEN_02.md; keine neuen Freigaben aus diesem Dokument ableiten.

# Konstruktion: Entscheidungen und offene Freigaben

## Zielmaschine und Baugruppenbasis

Ziel bleibt die im Gespräch fotografierte SX3.5Z. Die BF20-Dokumente dienen als
Funktions-/Konstruktionsreferenz. Der erste neue Container referenziert die bereits
vorhandene SX-Baugruppe vollständig; sie wird nicht durch eine neue Fotoannäherung
ersetzt. Noch keine Handantriebe löschen oder unterdrücken: Das geschieht erst im
späteren separaten Montagezweig nach eindeutiger Komponenten-Zuordnung.

## Ausgangsvarianten

**Variante A: BF20-Zahnriemenprinzip übertragen, neu auslegen.** Vorteil für die
Untersuchung: dokumentierte 2:1-Anordnung und getrennte Mutter-/Lagerhalter.
Zu prüfen: zusätzliche Riemenquerkräfte, Spannweg, Zahnzahl, Bauraum, Schutzgehäuse,
Wellenabstände und dynamisches Motormoment. Die historischen Zeichnungsmaße werden
nicht transplantiert.

**Variante B: koaxialer Direktantrieb, neu auslegen.** Eigenständige Alternative;
Motorposition, Kupplung, Wellenende und Lagerung benötigen andere Schnittstellen.
Keine Entscheidung allein anhand eines NEMA-Flanschmaßes.

**Noch keine Achse endgültig auf A/B festgelegt.** Ein gemischter Aufbau ist nicht
verboten, muss aber je Achse begründet und geprüft werden. Die Entscheidung soll
von realem Bauraum und Dynamik abhängen, nicht von einer einheitlichen Optik.

## X

Anschlussrollen des bisherigen Rezepts: Arbeitstisch_Foto, Kreuzschlitten_Guss_Detail,
X_Original_Spindelmutter_Geteilt, X_Lagerflansch_rechts, X_Lagerabschluss_links.
Namen sind Kandidaten, keine aus der tatsächlichen NX-Baugruppe bestätigten IDs.

Benötigt: Achslinie im Maschinenbezug; Achshöhe relativ zu bearbeiteten Führungsflächen;
Tischstirn-Lochbild; Fest-/Loslagerabstand; Wellenabsätze; Mutteraufnahme und freier
Querschnitt bei beiden Endlagen; Schmierzugang; Kabel-/Messsystemfreiraum.
Die Mutter bewegt sich relativ zum Tisch. Die tatsächliche Einbaubewegung muss
an der Baugruppe geprüft werden, nicht aus einer Einzelteilansicht angenommen.

## Y

Anschlussrollen: Basis_Guss_Foto, Kreuzschlitten_Guss_Detail, Y_Lagerflansch_vorn,
Y_Original_Spindelmutter_Platzhalter. Letztere heißt bereits ausdrücklich Platzhalter.

Benötigt: vorderes Lagerflansch-Lochbild und Achshöhe; Mutteranschluss am Sattel;
Spindel-/Mutterfreiraum nach hinten zur Säule; Endlagen mit Faltenbalg/Messsystem;
Erhalt der Führungslänge und Tragwirkung. Keine Gussrippe ohne konstruktiven Nachweis
bearbeiten. Aus einem Hüllmodell darf keine Freifräsung freigegeben werden.

## Z

Anschlussrollen: Saeule_Guss_Foto, Spindelkopf_Guss_Detail, Z_Mutterhalter_Original,
Z_Lagerbock_Original, Z_Motor_Adapterplatte. Original-Hubmotor und spätere CNC-Achse
sind funktional verschieden. Für die CNC-Positionierung ist der gesamte Kopf die
bewegte Masse, nicht nur die Pinole.

Benötigt: obere Lager-/Motoranschlüsse; Kopf-Mutteranschluss; Achslinie und Durchgang
an den Säulenrippen; vollständige bewegte Masse einschließlich Spindelmotor und
verbleibender Anbauteile; Reibung; Beschleunigung; Bearbeitungskräfte; gewünschter
Eilgang; eigenes Halte-/Absturzschutzkonzept. Ein ungetesteter Motorbremsenausgang
ist kein Nachweis einer geeigneten Sicherheitseinrichtung.

## Berechnung vor Motor-/Spindelbestellung

Offene Eingangsgrößen bewusst nicht durch plausible Standardwerte ersetzen:
- Kräfte, Massen, Reibung, Zielgeschwindigkeit/-beschleunigung.
- Spindelsteigung, Wirkungsgrad, Auflagerbedingungen, kritische Drehzahl,
  Knickung, Tragzahlen, Vorspannung und Lebensdauer.
- Drehmomentbedarf einschließlich rotierender Trägheiten und Übersetzung;
  Vergleich mit der dynamischen Herstellerkennlinie bei passender Spannung,
  nicht nur mit Haltemoment.
- Lager-/Kupplungs-/Riemenbelastung, Montage- und Schmierfreiraum.

`cnc_nx/core.py` enthält nur grundlegende Größenprüfungen und die mathematische
Skalierung. Es behauptet keine durchgerechnete Auslegung dieser Maschine.

## Geometrische Prüfplanung nach Zuordnung der Schnittstellen

Vorgesehene Prüfpunkte (noch NICHT ausgeführt): X/Y jeweils Endlage–Mitte–Endlage;
Z oben–Mitte–unten und zusätzliche kritische Zwischenlagen; kombinierte Ecklagen,
wo Motorhalter, Kopf, Bälge oder Leitungen einander näherkommen. Eine reine
3-Punkt-Prüfung genügt nicht automatisch für alle Zwischenlagen.

Zu protokollieren: tatsächliche Komponententransformationen; kleinster Abstand;
absichtliche Kontakte vs. unzulässige Durchdringung; Achswinkel und radialer Versatz;
Schrauben-/Werkzeugzugang; mechanische und Software-Endlagen; geschützter Kabelweg.
Kein statischer Screenshot und kein bestandener Rohkörpertest ersetzt dies.

## Native Sonderteile und Zeichnungen

Nach bestätigten Schnittstellen: zuerst Mutterhalter, dann Lageradapter, dann
Motorhalter/Spannelemente, Schalterhalter und Schutzteile; separate .prt mit sprechenden
Ausdrücken. Einfache BF20-Referenzhülsen werden in dieser Stufe bereits separat
nativ vorbereitet, jedoch nicht als SX-Sonderteile ausgegeben.

Fertigungszeichnungen, Passungen, Gewindeangaben und Werkstoffe werden erst mit
freigegebenen Komponenten und Last-/Montagekonzept erstellt. Es werden derzeit
keine scheinbar fertigen PDFs/DXFs geliefert, die auf unbestätigten Maßen beruhen.
