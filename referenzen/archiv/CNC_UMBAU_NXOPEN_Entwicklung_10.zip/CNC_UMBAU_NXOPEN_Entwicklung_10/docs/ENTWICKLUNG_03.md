# Entwicklung 03 – native Teile, Achsaufbau und kontrollierte Integration

## 1. Auftrag und Grenze dieser Lieferung

Fortsetzung des freigegebenen Konzepts 02 unter `reference/NUTZERANFORDERUNGEN.txt`.
CAD wird ausschließlich durch Siemens NX / NX Open Python erstellt. Der vorliegende
Quellcode ist ein Konstruktions- und Integrationswerkzeug, nicht die bereits gebaute
CNC-Maschine. Der echte NX-Bestandsaudit und bestätigte Maschinenanschlussmaße liegen
hier weiterhin nicht vor. Keine unbekannte Maschinenposition wurde ergänzt.

Die Elektrik-/LinuxCNC-Planung aus Konzept 02 ist unverändert enthalten. Es gibt keine
neu freigegebene Verdrahtung, keine Inbetriebnahmedatei und keine neue Motorfreigabe.

## 2. Was gegenüber Konzept 02 wirklich hinzugekommen ist

### 2.1 Ein unabhängig vom Bestandsaudit ausführbarer NX-Aufbau

`NX_07_Motortraeger_Referenz.py` erzeugt bei erfolgreichem NX-Lauf die folgenden
**vier Prototypdateien mit sieben Komponentenvorkommen**:

| ID | Menge | Nominale Ausführung | Herkunft |
|---|---:|---|---|
| M03_CS_M22326_CATALOG2022 | 1 | Motor-Hüllkörper 56,4 × 56,4 × 103 mm; Welle Ø8 × 21; Zentrierung Ø38,1 × 1,6 | Leadshine CS-M-Datenblatt, Seite 4 |
| D03_MOTOR_PLATE | 1 | Platte 90 × 90 × 12; Zentraldurchgang Ø38,3; Motorlochbild 47,14 quadratisch, Bohrungen Ø5,5; vier Distanzsäulenlöcher Ø6,6 bei x/y ±35 | eigener Entwurf, Motorschnittstelle aus vorgenannter Zeichnung |
| D03_SPACER | 4 | Hülse Ø14 / Ø6,6 × 50 | eigener Entwurf |
| D03_INTERFACE_BLANK | 1 | Platte 90 × 90 × 12; Zentraldurchgang Ø26; vier Durchgänge Ø6,6 bei x/y ±35 | eigener Rohplattenentwurf, keine Maschinenanbindung |

**CAT2022 ist eine interne Quellenkennung, keine zusätzliche Herstellerbestellnummer.**
Für den Typ CS-M22326 nennt die Produktseite 104 mm, das ausgewertete Datenblatt 103 mm.
Es ist nicht nachgewiesen, ob Revision, Messbezug oder Dokumentationsfehler die Abweichung
verursacht. Vor Bestellung muss der Lieferant die konkrete Maßzeichnung bestätigen.

Der Motor ist **kein originaler Hersteller-CAD-Import**: Gehäusekontur, Frontflansch,
Zentrierbund, Welle, Wellenabflachung und vier Flanschbohrungen sind nominal rekonstruiert.
Steckverbinder, Leitungen, Rundungen und Motorinnenleben fehlen. Die Bauteilhülle ist
folglich **keine vollständige Einbauhülle mit Kabeln**.

Die Stirnfläche des Motors liegt bei lokalem z=0; der Körper bei z=0…103, die Welle
ragt nach −Z. In der Referenzbaugruppe liegt die Motorfläche bei z=12, die Motorplatte
bei z=0…12, die Hülsen bei z=−50…0 und die Schnittstellen-Rohplatte bei z=−62…−50.
Das stellt einen prüfbaren konstruktiven Aufbau dar, aber weder eine bestätigte
Kupplungslänge noch den notwendigen Werkzeug-/Schraubenzugang.

Nicht enthalten: Befestigungsschrauben, Kupplung, Lagerbock, Kugelspindel, Mutter,
Maschinenlochbild, Festigkeitsberechnung, Abdeckung und Haltesystem.

### 2.2 Parametrische Bauvorschriften statt neuer Platzhalterdateien

`construction/recipes03.py` beschreibt drei unterstützte Bauteilklassen:
Motorreferenz, Distanzhülse und Flansch-/Halterplatte mit Zentraldurchgang und freiem
Lochbild. `cnc_nx/build03.py` setzt sie in native NX-Features um:
benannte Maßausdrücke, assoziative Ursprungspunkte, Blöcke, Zylinder und getrennte
Vereinigungs-/Abzugsschritte. Es wird **kein STEP-Körper anstelle der Sonderteilparametrik** verwendet.

Eine Halterplatte kann als Ausgangspunkt für Motor-, Mutter- oder Lagerflansche dienen.
Sie ist aber **kein spezifiziertes Muttergehäuse und kein passungsbemaßter Lagersitz**.
Taschen, Radien, Gewinde, gestufte Sitze oder Blechabwicklungen sind in dieser neuen
Bauvorschriftenfamilie noch nicht implementiert.

Die Vorprüfung prüft Formeln, Dimensionen, Bauteilklassen und erforderliche Probeparameter.
In NX sind anschließend folgende tatsächliche Prüfungen implementiert:

- ein einzelner Volumenkörper;
- erwartetes Volumen und Körperbegrenzungen;
- messbarer Materialzuwachs beim Vereinigen bzw. Materialabtrag beim Schneiden;
- Änderung eines Maßausdrucks um 1 mm mit erwarteter Volumenänderung und Wiederherstellung.

Diese Aussagen beschreiben den **Codepfad**. Ohne NX-Ausführung liegen dafür noch keine
NX-Ergebnisprotokolle vor. Offline wird weder Solidvalidität noch Topologie bewiesen.

### 2.3 X, Y und Z: jetzt mit nativer Bau-/Montageroutine

Die Module `construction/create_x_axis.py`, `create_y_axis.py`, `create_z_axis.py`
behalten ihre Planfunktionen und erhalten `build_native(...)`.
`construction/axis_native03.py` übernimmt:

1. Prüfung der ausdrücklich geprüften Achsdefinition;
2. native Erzeugung aller definierten Sonderteile;
3. Verwendung vorhandener nativer Kaufteilmodelle mit Dateihash und Quellenzuordnung;
4. Umrechnung achslokaler Bauteilpositionen in Maschinenkoordinaten;
5. Aufbau und Speichern einer separaten nativen Achs-Entwurfsbaugruppe.

Dies ist **keine automatische Auswahl von Motor, Kugelmutter oder Festlager**.
Die Achskonfiguration wird erst ausgefüllt, wenn Kaufteildaten und Schnittstellen
vorliegen. Z meldet einen fehlenden Haltenachweis ausdrücklich; auch ein gespeicherter
Z-Entwurf besitzt niemals eine Betriebs- oder Fertigungsfreigabe.

### 2.4 Neue Maschinenstruktur ohne Änderungen am Original

`NX_10_Montagebaugruppe_erzeugen.py` kann Original-Einzelteile, importierte Kaufteile
und erzeugte Sonderteile in einer **neuen Dateibaugruppe** kombinieren. Das Original
wird nicht unterdrückt, ersetzt oder gespeichert. Ein nicht benötigtes Handrad wird
nur aus der neuen Komponentenliste ausgeschlossen.

Für jeden aktiven, vollständig gelesenen Original-Volumenkörperträger ist eine
REUSE-/EXCLUDE-Entscheidung erforderlich. Ausschlüsse benötigen einen Grund.
Mehrfach verwendete Prototypen behalten unterschiedliche Vorkommnisse. Unvollständige
Ladezustände, unbekannte Kindanzahlen, unbekannter Körperstatus, reine Flächenteile
oder gemischte Körper-plus-Unterbaugruppen werden nicht stillschweigend ausgelassen,
sondern im derzeit unterstützten Importweg zurückgewiesen.

Die neue Struktur enthält native Komponenten, **aber keine Montagezwangsbedingungen,
keine WAVE-Verknüpfungen und kein mechanisches Bewegungsmodell**. Alle Untergruppen
werden an der Wurzel mit Identitätstransformation eingefügt; Einzelteilpositionen
innerhalb dieser Gruppen sind ausdrücklich in Maschinenkoordinaten angegeben.

Der aktuelle Ergebnisname ist absichtlich
`FRAESMASCHINE_CNC_MONTAGEENTWURF_NICHT_FREIGEGEBEN__<Kennung>.prt`.
Er ist nicht die endgültige Abnahmedatei `FRAESMASCHINE_CNC_UMBAU.prt`.

## 3. Koordinaten und Herkunft von Maßen

### 3.1 Vereinbarung

Für alle neuen Datendateien gilt:

`p_Maschine = R × p_lokal + t`

Dabei ist p ein Spaltenvektor, R eine orthonormale rechtshändige 3×3-Matrix, t ein
3-Vektor in Millimetern. Spiegelungen, Nullrichtungen und nichtendliche Zahlen sind
unzulässig. Achslokales Z ist die jeweilige Antriebs-/Spindelrichtung.

Die NX-Matrixfeldkonvention wird **nicht aus dem Namen Xx/Xy/... geraten**:
Ein asymmetrischer realer 1×2×3-mm-Probekörper wird mit einer bekannten 90°-Drehung
und Verschiebung als Komponente eingesetzt. Seine gemessenen Vorkommnisgrenzen müssen
genau eine der überprüften Zeilen-/Spaltenzuordnungen bestätigen. Sonst stoppt die Montage.

### 3.2 Geometrische Bezugsermittlung

`NX_08_Achsbezuege_auslesen.py` wertet den JSON-Bericht des vorhandenen NX-Audits aus.
Die Auswahl von Prototyp, Zylinderfläche, Bezugsplanfläche, Achsvorzeichen und Rollrichtung
ist **explizit**, nicht nach Bauteilnamen geraten. Der Schnitt zwischen Zylinderachse
und Bezugsebene liefert den lokalen Ursprung. Der exportierte Radius liefert einen
CAD-Durchmesser.

**Das Ergebnis liegt im absoluten Koordinatensystem des Prototypteils, nicht automatisch
im Maschinenkoordinatensystem.** Die Vorkommnistransformation und die Übereinstimmung mit
der realen Maschine müssen getrennt nachgewiesen werden. Der Audit vorhandener
Foto-Rekonstruktionen macht angenommene Maße nicht zu real vermessenen Anschlussmaßen.

### 3.3 Einrichten der Dateien

`Projekt03_Eingaben_vorbereiten.py` erzeugt aus einem echten Audit neue Entwurfsdateien.
Es übernimmt ausschließlich IDs und Quelldateien; `origin_mm` und `rotation` bleiben
zunächst null. Die Beispiele in `config/examples` sind nicht für den Maschinenbau
freigegeben und enthalten keine versteckten Standardlagen.

Ein geprüfter Original-Komponenteneintrag benötigt: eindeutige id, group,
kind ORIGINAL, absoluten .prt-Pfad, SHA256, Quelle, Maßstatus, occurrence_path aus dem
Audit sowie geprüfte origin_mm/rotation. Die vollständige inclusion/exclusion-Liste
liegt unter source_inventory.decisions. Status MODEL_LAYOUT_REVIEWED bedeutet nur,
dass der CAD-Aufbau geprüft beschrieben wurde, **nicht** dass Fertigung oder Sicherheit
freigegeben sind.

## 4. Hersteller-CAD: Importweg implementiert, Dateien noch offen

`NX_11_Kaufteile_STEP_importieren.py` prüft vor dem Import: STEP-Datei, vollständige
Austauschdateikennung, SHA256, Hersteller, Bestell-/Typnummer und Quellenadresse.
Ein vereinbarter nomineller Hüllquader kann zusätzlich geprüft werden.

Der Import wird ausdrücklich in das neue Arbeitsteil gerichtet. Auch die
Übersetzer-Ausgabedatei wird auf den vom Lauf erzeugten .prt-Pfad begrenzt; es bleibt
kein Übersetzer-Standardziel neben der Lieferantendatei offen. Nur an dieser eigenen
Datei darf ein erfolgreicher Übersetzeraufruf neue Bytes erzeugen. Die originale STEP-Datei
wird vor und nach dem Aufruf auf identischen Hash geprüft.

Nach Import müssen reale NX-Volumenkörper, positive Körpervolumina und messbare
Begrenzungen vorliegen. Die Richtung der Herstellerkoordinaten ist dennoch gesondert
zu registrieren. Ein Größenvergleich ersetzt keine genaue Geometrie-/Passungsprüfung.

**Es wurden in dieser Lieferung keine originalen Kaufteil-STEPs heruntergeladen oder
beigelegt.** Auch wurden keine STEP-Dateien selbst in einem anderen CAD-System erzeugt.
Das Motorreferenzteil ist ein separat gekennzeichnetes, zeichnungsbasiertes Ersatzmodell.

## 5. Export und Vorprüfung

`NX_12_STEP_exportieren.py` verwendet einen gespeicherten nativen Quellteilstand.
Es speichert die Originalteile nicht und fordert einen neuen Exportpfad an. Ergebnisdatei,
STEP-Kennung und Quellenhash werden geprüft. **Ein geometrischer Reimportvergleich ist
noch nicht implementiert.** Ein vorhandener Export ist somit kein Rundlaufnachweis.

`NX_13_AABB_Vorpruefung.py` arbeitet mit den tatsächlich aus NX gemessenen Körpergrenzen
von Journal 10. Ein positiver Hüllquaderabstand liefert eine konservative untere
Abstandsschranke. Überschneidung oder Berührung bedeutet lediglich
POTENTIAL_CONTACT_OR_INTERFERENCE: beabsichtigter Kontakt und echte Kollision sind noch
nicht getrennt. Es werden keine fraglichen Paarungen automatisch ausgeschlossen.

Der Python-Baustein sweep_bounds kann Hüllen an vorgegebenen Verschiebungen berechnen;
das ist keine in NX ausgeführte Bewegung. Der 125-Punkte-Prüfplan aus Konzept 02 bleibt
ein Plan. Eine exakte NX-Kollisionsprüfung über bestätigte reale Verfahrwege ist offen.

## 6. Schutz-, Wiederholungs- und Fehlerverhalten

Jeder Lauf verwendet einen neuen lokalen Ausgabeordner und eindeutige Dateinamen.
Neue Teile sind über eine Eigentümerliste geschützt; gespeichert werden nur diese Teile,
mit SaveComponents=False. Neue Ausgaben überschreiben keine Bestandsdateien.
Vorhandene native Dateien werden anhand von Pfad, Hash, Einheit, Lade- und Änderungszustand
geprüft. Der Bestand wird nicht per SaveAll gespeichert. Kein Teamcenter/PDM-Modus.

Bei Abbruch können bereits erzeugte **unvollständige neue Dateien** im Laufordner bleiben.
Diese werden nicht als vollständige Baugruppe behauptet. Error- und Statusberichte sind
getrennt. Wiederholte Journalstarts laden projektzugehörige Python-Module aus dem neuen
Projektordner neu; fremde Python-Module werden nicht pauschal gelöscht.

## 7. Noch nicht abgeschlossen

Nicht geliefert sind die maschinengenau eingepassten X/Y/Z-Triebe, festgelegte
Wellenenden und Lagerpassungen, vollständige Schutz-/Halteauslegung, belastbare
Motorfreigabe, Hersteller-CAD-Paket, Fertigungszeichnungen und endgültige native Maschine.
Die zusätzlichen Journale sind hier **nicht in Siemens NX ausgeführt** worden.

Der nächste unmittelbar nutzbare Schritt ist Journal 07. Der nächste datenabhängige
Schritt zur echten Maschinenintegration ist Journal 01 auf der tatsächlichen
Bestandsbaugruppe, danach die explizite Referenz- und Teilezuordnung. Diese Abhängigkeit
ist eine Folge fehlender Eingabedaten, keine Ausführungssperre für die Referenzbaugruppe.
