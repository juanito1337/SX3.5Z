# NX-Open-Schnittstellen – Prüfstand Entwicklung 03

## Vorhandene Nachweise

Die früher hochgeladenen NX-Protokolle belegen NX 2406/Python 3.10 sowie tatsächlich
benutzte Aufrufe für NewDisplay, Millimetereinheiten, Ausdruckserzeugung, Grundfeatures,
Speichern und AddComponent. Das ist **kein** Nachweis der Ausführung dieses neuen Pakets.

Der native Bauteiladapter baut auf den bestehenden Projektadaptern auf. Methodenverfügbarkeit
und Python-Docstrings werden im Zielsystem durch ApiEvidence protokolliert. Verfügbarkeit
ist nicht gleich funktionaler Erfolg; der Bericht nennt RUNTIME_PRESENCE_ONLY.

## Neue Pfade, lokal nicht in NX geprüft

| API-Pfad | Zweck | Laufzeitnachweis im implementierten Code |
|---|---|---|
| BooleanBuilder Unite / Subtract | native CSG-Sonderteile | Materialwirkung, eine Ergebnisgeometrie, Volumen |
| Component.FindOccurrence + UF AskBoundingBoxExact | Komponentenkoordinaten | asymmetrischer Kalibrierkörper, gemessene Soll-/Ist-Grenzen |
| ComponentAssembly.AddComponent / GetPosition | Montage | Ladezustand, zurückgemeldete Position/Orientierung |
| DexManager.CreateStep214Importer | Hersteller-STEP nach neuem nativen Teil | vorhandene Factory/Enums, kontrolliertes WorkPart/OutputFile, reale Körper nach Commit |
| DexManager.CreateStep214Creator | neutraler Export | vorhandene Factory/Enums, neue Datei, STEP-Kennung und Quellhash |
| MeasureManager.NewMassProperties | Körpervolumen | explizite mm³-Einheit, positive endliche Ergebnisse |

Die offiziellen Referenzzugriffe auf docs.sw.siemens.com und
docs.plm.automation.siemens.com waren in dieser Sitzung nicht nutzbar. Neue Aufrufpfade
sind daher **nicht als vollständig gegen die NX-2406-Online-Referenz verifiziert** ausgewiesen.
Insbesondere STEP-Translator-/Vorkommnis-Messpfade müssen in der Zielinstallation bestehen.
Nicht verfügbare Methoden werden nicht durch erfundene Geometrie oder Erfolgsstatus ersetzt.

Ziel ist die native Offline-Dateiverwaltung; Teamcenter, Zeichnungsexport, interpart WAVE,
Montagezwangsbedingungen und dynamische Mechanismen sind nicht implementiert.
Es ist kein alternatives CAD-System als Ersatz verwendet worden.
