# API-Prüfstand Entwicklung04

Ziel: NX2406 / eingebettetes Python3.10. Kein NX-Lauf beim Autor.

Die neue Halterfamilie benutzt KEINEN neuen NX-Featuretyp. Wiederverwendet werden aus03:
CreateNumberExpression, assoziative Punkte/Skalare/Achsen, CreateBlockFeatureBuilder,
CreateCylinderBuilder, CreateBooleanBuilder(Subtract), NewMassProperties, AskBoundingBoxExact,
GetBodies, UpdateManager.DoUpdate, AddComponent, FindOccurrence und Save.

Das bedeutet Code-Wiederverwendung, NICHT einen neuen Kompatibilitätsnachweis. Die früheren
Nutzerprotokolle belegen einzelne ursprüngliche Ausdrucks-/Featureaufrufe, nicht den
vollständigen neuen Halterablauf. Insbesondere Messung, Ausdrückerücknahme und Positionierung
müssen im echten NX-Lauf bestehen. `NX_API_Befund.json` protokolliert verfügbare Bindungen.

Die neuen Schritte verändern geometrische Rezepte und prüfen konkrete Zwischenvolumina;
kein STEP-Surrogat und kein externer CAD-Kern ersetzen native Sonderteil-Features.
Offline können Standardbibliothekstests laufen; sie sind nicht als NX-Ausführung zu lesen.

Neu recherchierte Herstellerportale sind in Quellen_04.json erfasst. Originale Kaufteil-CAD-
Dateien liegen nach wie vor nicht vor. Offizielle API-Referenzpfade wurden gegenüber03 nicht
als neu verifiziert ausgegeben; Versionsunsicherheit ist weiterhin ausdrücklich offen.
