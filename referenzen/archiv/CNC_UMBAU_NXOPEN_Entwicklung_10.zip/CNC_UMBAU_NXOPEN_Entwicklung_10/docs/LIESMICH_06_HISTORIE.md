# SX3.5Z CNC-Umbau — Entwicklung 06

**Nächster umgesetzter Teil aus Prompt-Abschnitt 9: Nennmaß-Zeichnungsableitung.**
Ziel: Siemens NX 2406 / NX-Open-Python 3.10. Vollständiges Projekt inklusive Journale
01–16; keine Änderung an der ursprünglichen v4.x-Maschinenrekonstruktion.

**Kein Siemens-NX-Lauf beim Autor. Keine hier erzeugten `.prt` und keine
Fertigungsfreigabe.** Die native Zeichnungsroutine ist implementiert, aber noch
nicht in der Zielinstallation ausgeführt. Die sofort sichtbare PDF ist ausdrücklich
quellbasiert und kein NX-Export. Sie ersetzt weder native CAD-Teile noch deren Prüfung.

## Direkt in NX starten

1. Vollständiges ZIP in einen **neuen Ordner** entpacken. Nicht in eine alte Version mischen.
2. In NX: **Journal wiedergeben / Play Journal → `NX_17_Zeichnungsentwuerfe.py`**.
3. Keine geöffnete Originalbaugruppe und keine neuen Maschinenmaße erforderlich.
4. Ergebnis im Listing Window und im tatsächlichen Ausgabeordner lesen.

Der Lauf erzeugt aus den vier vorhandenen Halterrezepten **neue, eigene native
Einzelteile**. Er prüft Geometrie, Parameteränderungen und die wiederhergestellten
Maßausdrücke, legt dann je ein A3-Zeichnungsblatt mit drei modellabgeleiteten Ansichten
an und schreibt eine vollständige Nennmaß-/Bohrungstabelle als Zeichnungsnotiz.
Anschließend sind Speichern und ein nativer PDF-Export pro Teil vorgesehen.

**Es werden nicht beliebige bereits manuell bearbeitete NX-Teile ausgelesen.**
Geometriequelle ist `config/housings04.json`. Änderungen dort werden bei einem neuen
Lauf berücksichtigt. Manuelle Änderungen an einem zuvor erzeugten `.prt` werden
nicht automatisch in die Konfiguration übernommen.

### Welche vier Teile?

| Bauteil | Status |
|---|---|
| `D04_MUTTERTRAEGER` | Eigenentwurf, kein ausgewählter Kugelmutteranschluss |
| `D04_LAGERAUFNAHME` | Eigenentwurf mit Sitzstufen, keine Lagerauswahl/Passungsfreigabe |
| `D04_LAGERDECKEL` | Eigenentwurf, keine Vorspannungs-/Befestigungsfreigabe |
| `R04_BF20_17_Y` | BF20-Zeichnungsreferenz ohne Eckfasen, keine bestätigte SX3.5Z-Geometrie |

Nominalgeometrie und Ausgangsmaße sind gegenüber Entwicklung04/05 **unverändert**.
21 Bohrungen insgesamt. Keine neuen Schrauben, Gewinde, Passungen oder Werkstoffe
werden dabei erfunden. Die vier Teile sind keine vollständigen CNC-Achsen.

## Ausgabe des neuen NX-Laufs

Standardziel:

```text
%LOCALAPPDATA%\SX35Z_CNC\Projekt06\<Zeitstempel>_drawings06_<Kennung>\
├── NX_PARTS\                       neue native Teile inklusive Blatt
├── NX_PDF\                         nur tatsächlicher NX-PDF-Export
├── DXF_PRUEFKONTUREN\               separate quellbasierte 2D-Konturen
├── Zeichnung_Eingaben_06.json
├── <Teil>_GEOMETRIE_ZWISCHENSTAND.json
├── <Teil>_Zeichnungsnachweis.json
├── NX_Zeichnungsentwuerfe_06.json
├── NX_Protokoll.txt
├── NX_API_Befund.json
└── LAUFSTATUS.json / bei Abbruch LAUF_FEHLER.json
```

Ein anderes absolutes Ziel lässt sich in `config/project.json` setzen.
Der neue Standard `Projekt06` gilt auch für ältere Journale in diesem Paket;
bei ausdrücklich gesetztem `output_root` bleibt dieses Ziel maßgeblich.
Alle Laufverzeichnisse und Dateinamen sind neu/eindeutig. Ein Speicheraufruf ist nur
für im aktuellen Lauf erzeugte Teile erlaubt; Originale werden nicht gespeichert.

Ein `GEOMETRIE_ZWISCHENSTAND` dokumentiert lediglich das bereits gespeicherte 3D-Teil.
Er ist **kein erfolgreicher Zeichnungsnachweis**. Der vollständige Bericht entsteht
erst nach allen ausgewählten Teilen und den angeforderten Exporten. Fehlende
NX-Funktionen/PDF-Dateien führen zum Abbruch, nicht zu einer Ersatz-PDF aus ReportLab.

## Maßbezug und Zeichnungsgrenzen

- X/Y beziehen sich auf die Bauteilmitte. Vorderseite **z=0**, Rückseite **z=t**.
- Rückansicht: X nach rechts; Vorderansicht: X nach links. Tabellenkoordinaten sind
  immer Bauteilkoordinaten, nicht die gespiegelten Papierkoordinaten.
- `V` bezeichnet die Stufe von z=0, `R` die Stufe von z=t; Tiefe jeweils nach innen.
- NX-Ansichten sind modellabgeleitete Ansichten. Die Nennmaßtabellen sind
  **Momentaufnahmen, keine assoziativen NX-Bemaßungsobjekte**.
- Nach Geometrie-/Parameteränderung muss ein neuer Zeichnungslauf aus der passenden
  Konfiguration erzeugt werden. Eine alte Maßnotiz ändert sich nicht automatisch mit.
- Es wird **keine native NX-Schnittansicht** erzeugt. Stufen und Tiefen stehen in
  der vollständigen Tabelle. Ein analytisches Schnittschema gibt es nur in der
  separat bezeichneten, quellbasierten PDF-Vorschau.
- Werkstoffsorte, Passungen, Toleranzen, Oberflächen, Befestigungsauslegung und
  Maschinenanschlüsse sind offen. Daher keine fertige Fertigungszeichnung.
- Das feste A3-Layout unterstützt aktuell B≤88, H≤84, T≤45 mm und höchstens neun
  Bohrungseinträge je Teil. Größere Konfigurationen werden vor dem Zeichnen
  zurückgewiesen, nicht abgeschnitten.

`config/drawings06.json` wählt die vorhandenen Teil-IDs und `export_pdf` (Standard
`true`). Bei explizitem `false` steht der PDF-Status im Laufbericht auf `NOT_REQUESTED`;
das ist keine erfolgreiche PDF-Prüfung. Die Blätter müssen in NX visuell geprüft
werden, auch nach einem technisch erfolgreichen Journallauf.

## Sofort lesbare Vorschau und Konturen

`reports/06_Zeichnungsentwuerfe/Nennmassblaetter_KEIN_NX_EXPORT.pdf` enthält vier
A3-Blätter aus denselben Eingaberezepten: Vorder-/Rückansicht, Außenabmessungen,
Bohrungstabelle, Stufen-Schnittschema, Maßkette, Quellen und offene Angaben.

Die vier DXFs enthalten reale nominale Millimeterkoordinaten auf getrennten Ebenen
für Außenkontur, Durchgangsbohrungen und vordere/hintere Stufen. Das sind **keine
Blechabwicklungen, keine CAM-Programme und kein nativer NX-Export**. Die Konturen
verschiedener Bohrungstiefen liegen übereinander und dürfen nicht ohne Prüfung als
Schneidkontur verwendet werden. Diese Blockteile sind keine abgewickelten Blechteile.

Reproduzieren mit gewöhnlichem Python (nicht in NX erforderlich):

```text
python -m pip install -r requirements-preview.txt
python Projekt06_Zeichnungsvorschau.py --output "C:\NX_Daten\Neue_Vorschau_06"
```

Der Ausgabeordner muss absolut und neu sein. Dieser Aufruf erzeugt **nur 2D-Berichte**,
keine CAD-Geometrie. Zusätzliche Bibliotheken sind für Journal17 nicht erforderlich.

## Prüfen und fortsetzen

```text
python -m unittest discover -s tests -v
```

358 Offline-Tests: Daten-/Geometrieformeln, Dateischutz, 2D-Export und API-Verträge;
NX-Randobjekte teilweise simuliert. Keine tatsächlichen NX-CAD-Tests.
`reports/RED_*.txt` sind absichtlich fehlschlagende historische Entwicklungsstände.
Aktuell: `reports/Tests_Entwicklung_06.txt` und `reports/Pruefbericht_Entwicklung_06.json`.

Bei einem Abbruch von Journal17: `NX_Protokoll.txt`, `NX_API_Befund.json` und
`LAUF_FEHLER.json` aus dem **tatsächlichen neuen Ausgabeordner** verwenden.
Die offizielle NX2406-Python-Webreferenz konnte hier nicht abgerufen werden.
`docs/API_PRUEFSTAND_06.md` trennt Referenzdeklarationen, Laufzeitkontrollen und offene Tests.

Die maschinengenaue CNC-Montage, bestätigte Kaufteile, echte Kollisionsprüfung und
fertige Fertigungszeichnungen bleiben offen. Frühere Journale und Dokumentationen
sind enthalten; ihre historischen Pfadangaben/Testzahlen sind nicht der neue Prüfstand.
