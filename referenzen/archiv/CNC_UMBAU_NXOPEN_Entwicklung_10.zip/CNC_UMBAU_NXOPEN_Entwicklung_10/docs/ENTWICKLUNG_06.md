# Entwicklung 06 — technische Zeichnungsableitung als Nennmaßentwurf

## Bezug zum Auftrag

Der Nutzer fordert in Abschnitt9 seines Prompts technische Zeichnungen mit Ansichten,
gegebenenfalls Schnitten, Abmessungen, Bohrungen, Gewinden, Passungen, Toleranzen,
Werkstoff und Bauteilnummer. Abschnitt10 verlangt Quellcode und echte NX-Testbelege.

Dieser Schritt implementiert einen **Teilumfang** davon für die vier bestehenden
Halterrezepte. Er ergänzt keinen neuen Maschinen- oder Kaufteilanschluss. Erst drei
Eigenentwürfe plus eine BF20-Referenz sind dafür ausreichend beschrieben; weder die
vollständige Maschine noch alle künftigen Sonderteile sind zeichnungsreif.

## Datenfluss

```text
config/housings04.json
 → construction/library04.py + housing04.py (unverändert)
 → validiertes Rezept / Fingerprint
 → exports/drawing06.py (Nennmaß-/Orientierungs-/Tiefenspezifikation)
 ├─ NX_17 / cnc_nx.drawings06
 │   → neue eigene native NX-Körper / Ausdruckstest
 │   → native Modellansichten und A3-Zeichnungsblatt
 │   → Tabellen-/Statusnotizen (Snapshot)
 │   → erneute 3D-Kontrolle / Speichern / PrintPDFBuilder
 └─ Projekt06_Zeichnungsvorschau.py
     → eigene quellbasierte PDF + CSV + DXF
     → ausdrücklich kein Ersatz für den nativen Lauf
```

Der SHA256-Fingerprint enthält das vollständige Rezept einschließlich Quellen und
Geometrie. Das native Journal prüft jeden Eingabeausdruck gegen den Snapshot vor und
nach dem Zeichnen sowie Körpervolumen und Begrenzungen. Kein Tabellenwert entsteht
aus einem ungeprüften Pixelmaß oder einem geschätzten Herstelleranschluss.

## Orientierung und Stufen

Local+Z ist die Bohrungsachse, Vorderseite z=0 und Rückseite z=t. Die Rückansicht
projiziert (x,y), die Vorderansicht (-x,y), die Seitenansicht (z,y).
Die ortsfesten Tabellenkoordinaten sind ausdrücklich im Bauteilsystem angegeben.

Für die zentrale Bohrung der Lageraufnahme stehen 32×16 vorn, 22 durchgehend und
26×3 hinten im unveränderten Entwurf. Bei 24mm Dicke ergibt das in Z die Kette
16 + 5 + 3 = 24mm. Die 5mm sind eine nominale Restschulter, keine Festigkeitsfreigabe.
Die reine Zentraldurchgangsbohrung des Deckels hat dagegen keine Schulter; deren
`remaining_shoulder_mm` ist `null`, während `axial_through_section_mm` 6mm enthält.

Das lokale Schnittschema wird analytisch aus den Kreiszylindern des Rezepts berechnet.
Bei außermittigem Schnitt wird die tatsächliche Kreissehne verwendet. Bandkanten
innerhalb durchgehenden Materials erscheinen nicht als falsche Schnittkanten.
Das Schema ist **keine aus NX entnommene Schnittansicht**.

## Native Funktionen

Journal17 verwendet die vorhandene parametrische RecipeBuilder-Pipeline; 46
Geometrieoperationen und die bestehenden acht Parameteränderungsproben des Katalogs
bleiben unverändert. Beim erfolgreichen Zielrechnerlauf entstehen vier neue native
Teile mit einem Blatt und drei Ansichten je Teil. Es entsteht keine zusätzliche
Maschinenbaugruppe und es werden keine Originalteile geöffnet oder gespeichert.

Für die Zeichnung werden drei orthogonale Modellansichten angelegt und über die
vorhandene UF-Draw-Python-Schnittstelle auf ein A3-Blatt eingefügt. Die live
aufgelösten Import-/Initialisierungssignaturen werden vor Nutzung geprüft.
Blattkoordinaten der tatsächlich erzeugten Ansichten werden auf Maßstab und Position
kontrolliert. Die Toleranz von 0,10mm ist eine **Blattlayout-Prüftoleranz**, keine
Bauteilfertigungstoleranz. Sie kann legitime abweichende NX-Ansichtsränder zurückweisen;
ein solcher Fall muss am Zielsystem ausgewertet werden, nicht blind toleriert werden.

Der native PDF-Export setzt nur das aktuelle Blatt und einen Entwurfswassertext.
Eine erfolgreiche Datei muss existieren und PDF-Kopf/Endmarkierung enthalten.
Diese Dateiprüfung ersetzt keine visuelle Kontrolle von Bemaßung, Linientypen und
Blattlayout. Dafür steht im Ergebnis weiterhin `PENDING_IN_TARGET_NX`.

## Grenzen der Zeichnungsimplementierung

- Keine nativen assoziativen Maßobjekte. Die Tabelle muss neu erzeugt werden.
- Keine native Schnittansicht, Gewinde-, Passungs- oder Oberflächenobjekte.
- Keine Festlegung fehlender Werkstoffsorten, Normen oder allgemeiner Toleranzen.
- Die Blattanordnung ist eine beschriftete Projektionsübersicht, keine vollständig
  normierte und zur Fertigung geprüfte Zeichnung.
- Kein Blech-Abwickler: DXF ist eine 2D-Prüfkontur der vorhandenen Blockteile.
- Keine Auslese manuell geänderter NX-Geometrie in die Konfigurationsdatei.
- Keine tatsächliche Siemens-NX-Ausführung und keine daraus erzeugten Dateien beim Autor.

## Vergleich zu Entwicklung05

Neu: Journal17, Zeichnungsspezifikation, Vorschau-/DXF-Ausgaben, native Drafting-/PDF-
Routine, testspezifische 2D-Parserprüfungen und Dokumentation. Die Modelle, Referenzdaten,
Achsmodule, Kaufteilrecherche und bisherigen Kollisionsalgorithmen werden nicht verändert.
Der Default-Ausgabeordner und die Projektkennung wechseln auf Entwicklung06.

## Abschlussprüfung

358 Tests ohne Fehler; echte erzeugte PDF-Vorschau mit vier A3-Seiten; alle Seiten
visuell geprüft. Vier DXFs mit ezdxf zurückgelesen, Einheiten=mm, keine Fehler oder
Reparaturen. Text-/Syntaxtests sind keine Siemens-NX-Tests. Siehe Prüfbericht für
Versions- und Dateinachweise. Die Codeprüfung ist eine Autoren-Selbstprüfung, kein
unabhängiges Review. Finale CNC-Abnahme bleibt offen.
