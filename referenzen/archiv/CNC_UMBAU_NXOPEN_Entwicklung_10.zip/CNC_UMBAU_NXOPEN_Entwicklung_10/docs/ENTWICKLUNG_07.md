# Entwicklung07 – Vorkommnisstückliste und Nachverfolgbarkeit

## Bezug zum Auftrag
Prompt §5 fordert reale Kaufteile mit eindeutiger Stücklistenzuordnung, §6 native
Komponenten, §11F eine vollständige Zuordnung der verbauten Komponenten. Dieser
Schritt implementiert den Zähl-/Zuordnungsweg. Er ergänzt **keine** nicht sichtbaren
Maschinenmaße und ersetzt nicht die offene mechanische Konstruktion.

Die vorhandene `config/bom_concept.json` ist weiterhin eine Planungsliste. Der neue
BOM-Bericht enthält nur Vorkommen der abgefragten Struktur. Planungsliste und
Ist-Struktur werden nicht ungeprüft zu einer vermeintlichen Gesamtliste vermischt.

## Module
| Datei | Verantwortung |
|---|---|
| analysis/bom07.py | Baumvalidierung, Unterdrückungsweitergabe, Blattmengen, Prototypaggregation |
| analysis/bom_registry07.py | exakte Dateizuordnung, Dokument-/Modellhashbindung, offene Angaben |
| cnc_nx/bom07.py | lesende NX-Aufnahme, Quellenzustand vorher/nachher, Berichtslauf |
| cnc_nx/bom_reference07.py | bestehende Referenz erzeugen, Metadaten binden, Live-Mengen vergleichen |
| exports/bom07.py | exklusive CSV/JSON/HTML-Exporte, leere Zuordnungsvorlage, Rezeptvorschau |
| Projekt07_Stueckliste.py | Offline-Replay oder ausdrücklich nicht-native Vorschau |

## Eingabeformat der Zuordnung
Die reale Vorlage wird aus Journal18/19 erzeugt. Schemaauszug (Platzhalter, keine
funktionsfähige fertige Konfiguration):

```json
{
  "schema": "SX35Z_BOM_ASSIGNMENTS_7",
  "entries": [{
    "prototype_path": "C:\\NX_Daten\\Mein_Teil.prt",
    "prototype_sha256": "<SHA256 aus der tatsächlichen Aufnahme>",
    "item_id": "D_X_001",
    "revision": "A",
    "kind": "MANUFACTURED",
    "description": "Eigener Motorhalterentwurf",
    "material": null,
    "dimension_status": "DESIGN_NOMINAL",
    "source_refs": ["<konkrete Zeichnung / Messprotokoll / Herstellerfundstelle>"],
    "documents": [{
      "role": "DRAWING_PDF",
      "path": "C:\\NX_Daten\\Mein_Teil.pdf",
      "sha256": "<SHA256 dieser PDF>",
      "model_sha256": "<SHA256 des zugehörigen PRT-Modellstands>",
      "status": "DRAFT"
    }],
    "blockers": ["Maschinenanschluss noch nicht bestätigt"]
  }]
}
```

Für Kaufteile: zusätzlich `manufacturer`, `model`, `order_number`, optional
`catalogue_id`. Kein Größen-/Variantenabgleich wird anhand eines ähnlichen Namens
erraten. Derselbe Artikel-/Revisionsschlüssel darf nicht mehreren Modellständen
zugewiesen werden. Mehrere Bibliotheksrevisionen sind erlaubt, aber nur der exakt
passende Datei-/Hash-Eintrag wird benutzt; unbenutzte Einträge werden separat gelistet.

## Prüflogik
1. Genau eine Wurzel, eindeutige Vorkommnispfade und Prototyp-IDs, keine Zyklen/Waisen.
2. Vollständig geladene aktive Zweige. Unterdrückte Zweige werden nicht eigens geladen.
3. Bekannter Kindstatus und Körperbestand. Eigene Körper plus Unterbaugruppen sind
   nicht automatisch in eine physische Teilestruktur zerlegbar und bleiben offen.
4. Eine native Datei mit mehreren Körpern zählt pro Vorkommen einmal.
5. Vollständiger Dateipfad + SHA256 bestimmen den gespeicherten Modellstand.
6. `IsModified`, `FullPath` und Dateiinhalt werden vor/nach der Aufnahme abgeglichen.
   Bei einer Änderung wird keine vollständige Stückliste veröffentlicht.
7. Registrierte Dokumente werden auf Pfad, Endung und Hash geprüft. Zeichnung/Export
   muss zusätzlich an genau diesen Modellhash gebunden sein. Kein semantischer PDF-Test.
8. Die Stückliste wird in Kategorien gefiltert; die Gesamtmengen bleiben nachprüfbar.

## Statusfelder
| Status | Bedeutung |
|---|---|
| INCOMPLETE_INVENTORY | Struktur oder gesicherter Modellstand ist unvollständig |
| UNASSIGNED_ITEMS | bekannte Mengen, mindestens eine Artikelzuordnung fehlt |
| MAPPED_WITH_OPEN_ITEMS_NOT_RELEASED | Zuordnung gelungen, technische/dokumentarische Punkte offen |
| BOM_TRACEABLE_NOT_RELEASED | Dateizuordnung nachvollziehbar, trotzdem keine Freigabe |
| PROVENANCE_NOT_RECHECKED | bewusst nur Datenlogik, keine aktuellen Datei-Nachweise |
| RECIPE_PREVIEW_NOT_NATIVE_INVENTORY | ausschließlich Vorschau aus bestehendem Rezept |

`native_read_in_this_run` ist nur beim NX-Journal-Lesepfad true; ein Offline-Replay
bleibt false, auch wenn die gespeicherte Quelle ursprünglich aus NX kam. Kein
Status erteilt Kauf- oder Fertigungsfreigabe. Metadatenquellen werden referenziert,
nicht allein durch ihr Vorhandensein als fachlich korrekt zertifiziert.

## Grenzen und offene Integration
Die strukturelle Explosion zählt physische native Blattteile, nicht kundenspezifische
NX-BOM-Mengen/PLM-Bestelleinheiten. Gekaufte Baugruppen mit vielen Kindern werden
aktuell ebenfalls bis auf Blätter aufgelöst. Für eine Bestellung solcher Kits ist
eine spätere explizite Beschaffungsstruktur nötig; die aktuelle Kaufteilliste ist
kein Ersatz. CAD-unabhängige Artikel müssen getrennt geplant werden.

Ein neues Speichern kann den Modellhash ändern, ohne dass die Form geändert wurde.
Das löst bewusst eine erneute Zuordnungsprüfung aus. Dateihashes sichern die
Identität des gelesenen Stands, nicht seine Herkunft/Echtheit gegenüber einem
böswillig manipulierten JSON-Bericht. Keine digitale Signatur/Zertifizierung.

Es gibt keine neue Herstellerrecherche und keine neuen Kaufteil-CAD-Dateien.
Die Motorreferenz und ihr bekannter 103/104-mm-Quellenkonflikt werden unverändert
übernommen. Alle CAD-Modelle entstehen weiterhin ausschließlich im vorhandenen
NX-Open-Aufbau; Offline-Code erzeugt nur Datenberichte.
