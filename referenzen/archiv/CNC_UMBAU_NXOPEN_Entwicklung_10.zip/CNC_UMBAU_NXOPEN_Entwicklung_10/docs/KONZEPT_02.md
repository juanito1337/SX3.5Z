# SX3.5Z – CNC-Umbaukonzept 02

**Siemens NX 2406 · NX Open Python · LinuxCNC · Mesa 7i95T**  
Entwurfsstand 27. Oktober 2026 · Projektfortschreibung auf Basis von „Eingefügter Text(7).txt“

> **Status:** konstruktives Konzept und Software-Arbeitsstand. Keine Fertigungs-, Bestell- oder Inbetriebnahmefreigabe. Die NX-Journale dieses Pakets wurden hier nicht in Siemens NX ausgeführt. Noch keine native finale CNC-Baugruppe, keine Fertigungszeichnungen und kein geprüfter STEP-Export des Umbaus.

## Entscheidung in Kürze

Als Vorzugsvariante wird die vorhandene SX3.5Z mechanisch möglichst wenig verändert: originale Schwalbenschwanzführungen, Tisch, Sattel, Basis, Säule und Spindelkopf bleiben erhalten. X/Y erhalten nach Bauraumnachweis Kugelgewindetriebe und vorzugsweise Direktantriebe. Z bewegt den gesamten Kopf; die Pinole bleibt beim CNC-Fräsen in definierter, vorzugsweise eingefahrener Stellung geklemmt. Für Z ist ein unabhängig bewertetes Halte-/Absturzschutzkonzept erforderlich. Die originale Spindel samt Regler bleibt zunächst eine eigene, zu prüfende Baugruppe. Neue Achselektrik kommt in einen separaten Schaltschrank. Dies sind Bearbeiterentscheidungen für den Konzeptvergleich, keine behaupteten Nutzerfreigaben. [D1]

Die BF20-Unterlagen dienen als Lösungsreferenz, nicht als SX-Anschlusszeichnung. Eine sichtbare Fotoform oder eine im bisherigen Modell numerisch vorhandene Bohrung wird nicht automatisch zu einem bestätigten Maschinenmaß. Der vorgeschriebene Endzustand bleibt die native `FRAESMASCHINE_CNC_UMBAU.prt` samt reproduzierbarem NX-Open-Quellcode. [U1–U3]

### Was in diesem Stand zusätzlich vorliegt

Sechs berechenbare Antriebsszenarien, eine quellenbezogene Konzeptstückliste, eine I/O-Belegungsplanung, ein modulares Datenmodell für Achsschnittstellen sowie drei native NX-Entwurfsmuster für Sonderteile. Die Achsplanmodule erzeugen derzeit geprüfte Datensätze, nicht bereits komplette Achsbaugruppen. Der lesende Bestandsaudit und die separaten Projekt-/BF20-Referenzjournale aus Analyse 01 sind enthalten. [D1]

## 1. Verbindliche Entwicklungsumgebung

Die Geometrieerzeugung erfolgt ausschließlich im Python-Kontext von Siemens NX über NXOpen. Allgemeines Python dient nur für Datenprüfung, Vorrechnungen, Stücklisten und Berichte. Es werden weder FreeCAD noch CadQuery/OpenCascade als Ersatz-CAD für diesen Umbau eingesetzt. Eine erfolgreiche Offline-Rechnung ist kein erfolgreicher NX-Test. [U1]

Ziel ist NX 2406, mit der darin verfügbaren Python-3.10-Laufzeit. Neu hinzugefügte Aufrufe sind als noch nicht in NX ausgeführt gekennzeichnet. Die offizielle Online-Referenz für NX 2406 war in dieser Sitzung nicht erreichbar. Frühere Nutzerprotokolle belegen einzelne API-Muster; sie belegen nicht die vollständige Ausführung dieser neuen Generatoren. Bei jedem NX-Lauf werden verfügbare Methoden und Fehler dokumentiert. [N1, N2]

Das Paket liegt getrennt von der Bestandsrekonstruktion v4.8. Kein Patch der alten Maschinengeometrie wird benötigt. Die standardmäßige Ausgabe ist lokal unter `%LOCALAPPDATA%/SX35Z_CNC/Projekt02/`, in einem neuen Ordner je Lauf. Die Eingabe darf auf einem lesbaren Netzlaufwerk liegen; die neuen Module verlangen keine erfolgreiche `realpath`-Auflösung des Journalpfads.

## 2. Ausgangspunkt und belastbare Bestandsbasis

### 2.1 Quellenhierarchie

| Kennzeichnung | Bedeutung | Verwendung |
|---|---|---|
| USER_REQUIREMENT | ausdrückliche Projektvorgabe | Plattform, Endergebnisse und Abnahme |
| MANUFACTURER | auf konkrete Produktrevision zurückführbare Angabe | Kaufteildaten; noch kein Maschinen-Einbaunachweis |
| MEASURED_AND_REVIEWED | echte Messung mit Bezug, Methode und Prüfung | Anschlussmaß und Achsrahmen |
| FOTO_ANNAHME / DESIGN_PROPOSAL | Fotoablesung oder Bearbeiterannahme | Visualisierung, Sensitivitätsrechnung und Entwurf |
| NOT_RUN / UNKNOWN | Test oder Nachweis fehlt | niemals als bestanden werten |

Die bisherige Modellrekonstruktion kann als Ausgangsbestand referenziert werden. Sie enthält jedoch viele angenäherte Maße. Die lokal vorhandene Modelldefinition ist nicht gleichbedeutend mit einer vermessenen Originalmaschine. Die tatsächliche auf dem Nutzerrechner erzeugte NX-Baugruppe und deren Audit liegen für diesen Konzeptstand noch nicht vor. [U2]

### 2.2 BF20 alt und neu

Der vorhandene Archivvergleich bleibt gültig. Die Zeichnungssätze und fünf identische Begleitdokumente dürfen nicht zu einem vermeintlich einheitlichen Datensatz vermischt werden. Zum Beispiel unterscheiden sich X-/Y-/Z-Abstandshülsen zwischen Alt- und Neu-Zeichnung; die gemeinsame Liste ist als „BF20 alt“ bezeichnet. Ein 12-mm-Rohteil aus der Liste kann kein 15-mm-Fertigteil aus der Neu-Zeichnung ergeben. Die sechs BF20-Hülsen bleiben daher getrennte Referenzteile, nicht automatisch zu montierende SX-Komponenten. Die Fundstellen stehen in `ARCHIVVERGLEICH.md`. [U3]

### 2.3 Unveränderlicher Bestand

Originalteile werden nur gelesen oder als Referenz eingefügt. Der Prototyppfad und die Dateiprüfsumme gehören zur Bestandsaufnahme. Auch eine Unterdrückung in einer referenzierten Original-Unterbaugruppe kann deren Zustand verändern; deshalb soll die spätere CNC-Struktur eigene Träger-Unterbaugruppen erhalten. Nicht benötigte Handräder, Originalspindeln und Lagerteile werden in dieser neuen Struktur nicht übernommen, statt sie in ihren Originaldateien zu löschen. Das ist die geplante Montagearchitektur, noch nicht die Implementierung des finalen Assemblers. [U1, D1]

## 3. Auswahl der Antriebsarchitektur

### 3.1 Variantenvergleich

| Variante | Vorteil für dieses Projekt | Nachteil / Entscheidung |
|---|---|---|
| Direktantrieb, Step/Dir-Closed-Loop-Stepper | kurze Übertragungskette, weniger Teile, einfacher zu prüfende Koaxialität | seitlicher Motorüberstand; dynamische Kennlinie erforderlich; Vorzugsvariante X/Y |
| Zahnriemenuntersetzung | Motor kann räumlich versetzt werden; Übersetzung anpassbar | Riemen-/Riemenscheibenbauraum, Vorspannkräfte, höhere Motordrehzahl, zusätzlicher Ausfallpfad; Vergleich für Z |
| Step/Dir-Servoantrieb | Alternative bei erforderlicher Dynamik und passender Brems-/Sicherheitsausführung | anderes Kosten-, Abstimmungs- und Sicherheitskonzept; kein konkreter Servo in diesem Stand ausgewählt |

Ein pauschales „alle Achsen NEMA34 mit 7–10 Nm“ wird verworfen. Bewegte Masse, Reibung, Schnittkraft, Steigung, Drehzahl, Trägheit und Motor-/Treiberkennlinie müssen gemeinsam stimmen. Haltemoment ist kein belastbarer Nachweis des verfügbaren Drehmoments bei der geplanten Drehzahl. [D1; Haltemoment des Kandidaten: M2]

### 3.2 X-Achse

Im vorgesehenen Bestandsprinzip sitzen Spindellager und Motorhalter am Tisch; die Mutter ist am Sattel befestigt. Die rotierende Spindel bewegt den Tisch gegenüber der am Sattel gehaltenen Mutter. Der X-Motor folgt damit dem Tisch in X und der gesamten Tisch-/Sattelgruppe in Y. Diese Anordnung ist anhand der originalen Teile endgültig zu bestätigen. Die Energieführung muss beide Bewegungen berücksichtigen. [U2, D1]

Kandidat ist ein isel-Kugelgewindetrieb Ø16 mm mit 5 mm Steigung; 4 mm bleibt Vergleichsvariante. Der Hersteller führt beide Steigungen und kundenspezifische Endenbearbeitungen. Weder Mutterform noch Länge, Vorspannung oder Endenbearbeitung sind bestellt oder als passend bestätigt. [M4]

Die Festlagerseite wird bevorzugt motorseitig angeordnet. Die gegenüberliegende Abstützung wird so gewählt, dass die Spindel nicht versehentlich beidseitig axial verspannt wird. Der Motor darf keine Montagekräfte aus einer schiefen Kupplung aufnehmen. Axiale Positionierung und Vorspannung gehören in eine definierte Lager-/Schulter-/Mutternkette, nicht in eine Klemmung über das Motorgehäuse. Die konkrete Lagerausführung bleibt offen. [D1; Montageanforderungen M8]

### 3.3 Y-Achse

Das Konzept hält Motor, Festlager und Spindel an der Basis; die Kugelmutter bewegt den Sattel. Die vorhandene vordere Aufnahme ist ein Anschlusskandidat, keine geprüfte CNC-Festlagerung. Direktantrieb wird zuerst auf freien Raum vor der Maschine, Schraubstockzugang, Schutzabdeckung und Wartbarkeit geprüft. [U2, D1]

Für Y ist ebenfalls Ø16×5 vorgesehen, mit 16×4 als Alternative. Entscheidend ist der im gesamten Hub freie Raum zwischen Sattel und Basis: Mutterkörper, Flansch, Schmieranschluss, Befestigungsschrauben und Werkzeugzugang müssen gemeinsam Platz haben. Ein Durchbruch im Guss allein belegt diesen Raum nicht. Sattelbearbeitung wird nicht vorsorglich freigegeben. [D1]

### 3.4 Z-Achse

Der neue Antrieb ersetzt den ursprünglichen Hub-Getriebemotor und dessen nicht als CNC-Positionierantrieb nachgewiesene Übertragung. Der gesamte Kopf wird über eine neue Mutteranbindung verfahren. Das Pinolensystem mit Handhebel/Zahnstange bleibt funktional getrennt; seine Klemmung darf nicht mit einer Klemmung des Z-Schlittens verwechselt werden. [U2, D1]

Ø20×5 ist ein Bauraum-/Belastungskandidat, kein endgültiger Durchmesser. isel führt Ø20 mit 5 mm Steigung und Sonderenden. Direktantrieb und 2:1-Untersetzung werden rechnerisch verglichen. Die Entscheidung fällt erst mit einer realen Kennlinie, bestätigter Kopfmasse einschließlich Motor/Anbauteilen und einem nachgewiesenen Haltekonzept. [M5, D1]

Eine Kugelspindel darf bei Z nicht als selbsthemmend vorausgesetzt werden. THK verlangt bei vertikaler Verwendung Maßnahmen gegen ein Herabfallen. Eine Bremse auf der Motorseite eines Riemens schützt nicht automatisch gegen Riemen-, Kupplungs- oder Mutterversagen. Ein Gegengewicht oder eine Gasfeder entlastet den Antrieb, ersetzt aber nicht ohne eigenen Nachweis eine Absturzsicherung. Welche Fehlerfälle abgesichert werden müssen, ist Bestandteil der Gefährdungsbeurteilung. [M8, D1]

## 4. Parametrische Sonderteile und Maßketten

### 4.1 Erforderliche Bauteilfamilien

Jede Achse benötigt eine geprüfte Schnittstelle von Maschinenguss zu Lagerträger, von Schlitten zu Mutterhalter und von Lagerträger zu Motorhalter. Vorgesehen sind separate native NX-Teile mit klaren Bezugsflächen, nicht ein einziger verschmolzener Gesamtkörper. [U1]

Motorträger werden aus Maschinenadapter, Stütze/Distanz und Motorplatte entwickelt. Der Zentrierbund positioniert den Motor nur dann, wenn eine passende, tolerierte Zentrierung konstruiert ist. Ein großzügiger Freischnitt ist keine Passbohrung. Kugelmutterhalter müssen Verdrehung und Axialkraft übertragen, einen Schmierzugang haben und entlang der gesamten Bewegung kollisionsfrei sein. Lagerträger müssen Steifigkeit, Schulterflächen und axiale Einstellung berücksichtigen. Sensorhalter brauchen nachstellbaren Schaltpunkt und Schutz vor Spänen. Abdeckungen müssen Freigang und Demontage erlauben. [D1]

### 4.2 Wesentliche parametrische Abhängigkeiten

| Parameter / Abhängigkeit | Herkunft |
|---|---|
| Achsursprung und Achsrichtung | gemessene bzw. in NX ausgewählte, überprüfte Maschinenreferenzen |
| Motorpilot, Welle, Lochbild, Wellenüberstand | Herstellerzeichnung des gewählten Motors |
| Lager-Achshöhe, Zapfen und Schulterlage | gewähltes Lager und abgestimmte Endenbearbeitung |
| Mutterflansch und Schraubenraum | konkrete Mutterzeichnung, nicht nur Nenndurchmesser der Spindel |
| Distanz zwischen Motor- und Lagerplatte | Summe aus Wellenüberständen, Kupplungslänge, Einstecktiefen und axialem Freigang |
| Gewindelänge | nutzbarer Hub + Mutterhülle + Reserven; danach Endenbearbeitung ergänzen |
| Befestigungslöcher am Guss | Messung mit Bezugsebene, Gewinde und nutzbarer Tiefe |

Ein einfaches Längenbeispiel, ausdrücklich keine Bestellung: 500 mm Hub plus 45 mm Mutterhülle plus zweimal 10 mm Reserve ergibt 565 mm erforderliche Gewindestrecke. Die Wellen-Gesamtlänge enthält zusätzlich Übergänge, Lagerzapfen, Gewinde und Kupplungszapfen. Dieses Beispiel darf nicht als X-Spindelbestellmaß verwendet werden. [D1]

### 4.3 Jetzt implementierte NX-Entwurfsmuster

`NX_05_Sonderteilkonzepte_erzeugen.py` erzeugt bei erfolgreichem NX-Lauf drei separate native Teile:

| Muster | Entwurfsabmessungen | Aussagegrenze |
|---|---|---|
| Motorträger-Rohplatte | 90×90×12 mm; Mittelfreistellung Ø38,5; vier Ø6,6 auf ±35/±35 | äußere Löcher sind für entworfene Distanzsäulen, **nicht** das Hersteller-Motorlochbild |
| Distanzhülse | Ø16 / Ø6,6 ×45 mm | Bauformstudie; echte Länge aus Kupplungsmaßkette noch offen |
| Sensorträger-Rohplatte | 45×30×5 mm; zwei Ø4,5 bei x=±14 | noch kein ausgewählter Sensor und kein bestätigter Maschinenanschluss |

Die Ø38,5-Freistellung nimmt den dokumentierten 38,1-mm-Pilot des Motorkandidaten mit 0,4 mm Entwurfsspiel auf; sie ist bewusst keine Zentrierpassung. Alle anderen Mustermaße sind Bearbeiterentwurf. Die Muster werden nicht in die Fräse montiert und nicht als passende Kaufteil-Ersatzmodelle ausgegeben. [M2, D1]

Das Journal erzeugt benannte Maßausdrücke und assoziative Ursprünge, prüft Werkzeugabträge und das analytische Volumen. Es enthält einen echten, erst im Nutzer-NX auszuführenden Änderungstest der Plattendicke bzw. Hülsenlänge; anschließend wird der Nennwert wiederhergestellt. Eine Änderung des JSON erzeugt neue Teile. Die später notwendige Verknüpfung zwischen mehreren Teilen ist noch nicht implementiert. [D1]

## 5. Reale Kaufteile, Datenqualität und Beschaffung

| Funktion | Kandidat / Familie | Bestätigt | Auswahlhindernis |
|---|---|---|---|
| Motion-I/O | Mesa 7i95T | Vorgabe und Herstellerdokument vorhanden | elektrische Gesamtplanung und Inbetriebnahme |
| X/Y-Motor | Leadshine CS-M22326 | 2,6 Nm Haltemoment, Welle 8 mm, Länge 104 mm | Drehmomentkurve zur tatsächlichen Treiberversorgung, Lochbild und Freigang |
| X/Y-Treiber | Leadshine CS-D508 | Step/Dir, 20–50 VDC, bis 8 A; Motor als zugeordnet geführt | Signalkompatibilität, Konfiguration, Spannungsbudget |
| X/Y-Kugeltrieb | isel Ø16, Steigung 5 / Vergleich 4 mm | reale Produktfamilie und Sonderenden | konkrete Mutter, Spiel/Vorspannung, Länge, Zapfen |
| Z-Kugeltrieb | isel Ø20, Steigung 5 mm | reale Produktfamilie | Bauraum, Knicken, Drehzahl, Last und Haltesystem |
| Festlager | THK EK/BK/FK | reale Familien | exakte Größe und Endenabstimmung |
| Kupplung | KTR ROTEX GS oder TOOLFLEX | reale Familien | Moment, Bohrungen, Bauraum und Verlagerungen |
| Analogschnittstelle | Mesa 7i83, nur optional | reale Analog-Ausgangsfamilie | Originalreglereingang nicht bestätigt |

Quellen: [M1–M7, M9]. Für Z ist noch kein konkreter neuer Motor ausgewählt. Ein Leadshine-X/Y-Kandidat wird nicht durch Kopieren einer Stücklistenzeile automatisch zum zulässigen Z-Antrieb.

Die auf der Motorwebseite wiedergegebene Einheit der Rotorträgheit ist nicht eindeutig genug für eine verifizierte SI-Übernahme. Deshalb verwenden die Rechenszenarien ausdrücklich angenommene Trägheiten, nicht vermeintlich bestätigte Motordaten. Auch 48 V sind bei einem Treiber mit 50 V Obergrenze nicht automatisch eine gute Versorgung: Netzteiltoleranz und regenerative Spannungserhöhung müssen im Budget verbleiben. Motor-Phasenstrom und DC-Netzteil-Dauerstrom werden nicht gleichgesetzt. [M2, M3, D1]

### Original-CAD-Pipeline

Für jedes ausgewählte Kaufteil werden Hersteller, genaue Bestellkennung, Datenblattrevision, CAD-Datei, Dateihash, Einheit und lokale Bezugsachsen erfasst. Nach dem Import in NX sind mindestens Gesamtmaße, Pilot/Welle, Anschlussbohrungen, Mutterflansch und gegebenenfalls Gewinderichtung mit der Zeichnung abzugleichen. Eine Dateibezeichnung allein beweist die richtige Variante nicht. [U1, D1]

Hersteller-CAD-Zugänge wurden recherchiert; in diesem Stand liegt **keine heruntergeladene und als passend validierte Hersteller-STEP-Datei** bei. Deshalb sind Motor, Mutter und Lager noch keine auslieferbaren Original-CAD-Komponenten. Vereinfachte Ersatzmodelle dürfen erst mit belegten Schnittstellenmaßen erzeugt werden. Preise und Lagerbestände sind nicht bestätigt. [U1, M2–M7]

### Konzeptstückliste

Die CSV führt je Achse Kugeltrieb, Mutter, Fest-/Loslager, Motor/Treiber, Übertragung und Sonderteile sowie die elektrischen und sicherheitsbezogenen Systempositionen. Eine Zeile kann eine noch zu konkretisierende Familie sein; Mengen sind Konzeptmengen. Jede Position besitzt Quellen- und Blockerfelder sowie `order_released=False`. Sie ist ein Beschaffungs-Arbeitsregister, kein freigegebener Warenkorb. [D1]

## 6. Vorrechnung für Vorschub, Moment und Auflösung

Die folgenden Zahlen stammen aus `engineering/sizing.py` und `design_scenarios.json`, nicht aus Messungen. Die Rechnung erlaubt den Vergleich von Steigung und Übersetzung, aber keine Motorfreigabe ohne Kennlinie. [D1]

### 6.1 Einheitliche Definition

`i` ist Motorumdrehungen pro Spindelumdrehung. Ein 2:1-Antrieb bedeutet hier i=2. Bei Vorschub v in mm/min und Steigung p in mm/U gilt n_S=v/p und n_M=i·n_S. Bei N Vollschritten und μ Mikroschritten gilt S=N·μ·i/p in Impulsen/mm. Die Impulsfrequenz ist v·S/60. Ein Mikroschritt ist ein Sollwertinkrement, keine Zusicherung der Positioniergenauigkeit.

Für den betrachteten motorischen Lastfall gegen Reibung und Schnittkraft wird gerechnet:

```
F = F_Schnitt + F_Reibung + m·a + m·g       (Gewicht nur bei Z aufwärts)
alpha_S = 2·pi·a / p
T_M = [F·p/(2·pi·eta_S) + J_S·alpha_S] / (i·eta_T)
      + J_M·i·alpha_S
```

In der Momentenrechnung werden p und a in Meter bzw. Meter/Sekunde² umgerechnet. J_S umfasst spindelseitige rotierende Trägheiten, J_M motorseitige. Die translatorische Beschleunigung m·a ist bereits in F enthalten und wird nicht nochmals als reflektierte lineare Trägheit addiert. Bremsen, Abwärtsfahrt, Rückspeisung, Resonanzen, thermischer Arbeitszyklus und Gegenlastwechsel sind nicht durch diese einzelne Rechnung abgedeckt.

### 6.2 Angenommene Lastfälle

| Achse | bewegte Masse | Reibung | entgegenwirkende Schnittkraft | Vorschub | Beschleunigung |
|---|---:|---:|---:|---:|---:|
| X | 50 kg | 180 N | 500 N | 1.500 mm/min | 200 mm/s² |
| Y | 70 kg | 220 N | 500 N | 1.500 mm/min | 200 mm/s² |
| Z aufwärts | 45 kg | 250 N | 400 N | 1.000 mm/min | 100 mm/s² |

Angenommen sind η_S=0,90, η_T=1 für Direktantrieb bzw. 0,95 für die Z-Riemenvariante. J_S beträgt X 0,00002, Y 0,00001, Z 0,00004 kg·m²; J_M jeweils 0,00005 kg·m². Vollschritte 200, Mikroschritte 16. Keine dieser Größen ist damit an der Maschine bestätigt.

### 6.3 Rechenergebnisse

| Fall | Steigung / i | Motor U/min | Motor-Nennlastfall Nm | mit 1,5 Vergleichsmarge Nm | Impulse/mm |
|---|---|---:|---:|---:|---:|
| X, 4 mm | 4 / 1 | 375 | 0,510 | 0,765 | 800 |
| X, 5 mm | 5 / 1 | 300 | 0,628 | 0,942 | 640 |
| Y, 4 mm | 4 / 1 | 375 | 0,538 | 0,807 | 800 |
| Y, 5 mm | 5 / 1 | 300 | 0,664 | 0,996 | 640 |
| Z direkt | 5 / 1 | 200 | 0,980 | 1,470 | 640 |
| Z untersetzt | 5 / 2 | 400 | 0,525 | 0,788 | 1.280 |

Eine 2:1-Untersetzung reduziert in diesem Beispiel das Motorlastmoment, verlangt aber doppelte Motordrehzahl. Deshalb reicht die Aussage „mehr Drehmoment durch Riemen“ nicht. Die echte Kennlinie kann die Entscheidung umkehren. Der Programmstatus bleibt für alle sechs Fälle `NOT_EVALUATED`, weil keine passende verifizierte Kennlinie eingelesen ist. Die 1,5-Marge ist ein Vergleichswert, kein normativer Sicherheitsfaktor.

Die Impulsfrequenzen betragen etwa 10,7 bis 21,3 kHz. Für X/Y mit 5 mm sind es 16 kHz. Die Werte liegen numerisch unter dem auf der CS-D508-Seite genannten 200-kHz-Maximum; damit sind Signalpegel, Pulsbreite, Verkabelung und Dynamik aber noch nicht freigegeben. [M3]

### 6.4 Weitere notwendige Nachweise

Nach bestätigter Auswahl folgen zulässige Spindeldrehzahl/DN, kritische Drehzahl nach Lagerabstand, Knicksicherheit insbesondere bei Z, statische und dynamische Tragfähigkeit, Lebensdauer, Vorspannmoment, Halterdurchbiegung, Schraubverbindungen, Lagerpassungen und thermisches Verhalten. Maßgeblich sind die Daten des tatsächlich gewählten Produkts, nicht eine generische 1605-Bezeichnung. [D1, M8]

Der beiliegende Stoppwegansatz `v·t + v²/(2a) + Reserve` liefert bei angenommenen 20 ms Reaktion und 2 mm Zusatzreserve ca. 4,06 mm für X/Y und 3,72 mm für Z. Das ist lediglich eine rechnerische Reserve im Idealmodell. Bei ausfallendem Antrieb kann die angenommene Verzögerung gerade nicht verfügbar sein; der Wert ist kein Nachweis der Not-Halt-Strecke oder mechanischen Anschlagfestigkeit.

## 7. Automatisierte NX-Baugruppe und Achsmodule

### 7.1 Geplante Zielstruktur

```
FRAESMASCHINE_CNC_UMBAU.prt                 (erst nach Nachweisen)
  00_REFERENZEN                             (nicht produktiv/kollisionsfrei geschaltet)
  10_GESTELL                               (Basis, Säule, feste Anbauteile)
  20_Y_TRAGGRUPPE                          (Sattel, Y-Mutter)
      21_X_TRAGGRUPPE                      (Tisch, X-Spindel/Lager/Motor)
  30_Z_KOPFGRUPPE                          (Kopf, Spindelmotor, Z-Mutter)
  40_ACHSTRIEBE_FEST                       (Y-/Z-Antriebe, Lager, Halter)
  50_SCHUTZ_UND_ENERGIEFUEHRUNG
  60_SCHALTSCHRANK
```

Die exakte Hierarchie wird nach Bestandsaudit festgelegt. Keine doppelte Zählung: X-Mutter gehört zum Sattel, X-Spindel/Lager/Motor zum Tischträger. Y-Mutter gehört zum Sattel, Y-Spindel/Lager/Motor zur Basis. Z-Mutter gehört zum Kopf, Z-Spindel/Lager/Motor zur Säule. Nicht jede Datei mit der Gruppenbezeichnung „X“ ist physisch gleich bewegt. [D1]

### 7.2 Koordinatenvertrag

Das neue Mathematikmodul verwendet ausdrücklich Spaltenvektoren: `p_übergeordnet = R · p_lokal + t`. Jede Rotation muss orthonormal und rechtshändig sein. Die Rohmatrix eines NX-Occurrences wird nicht ohne Test als dieser Vertrag interpretiert. Für die Adapterfreigabe sind ein bekannter Ursprung und mindestens zwei unabhängige Richtungen zu vergleichen. Erst dann dürfen lokale Kaufteilachsen in die Maschinenlage transformiert werden.

Die bisherige Foto-Rekonstruktion enthält numerische Richtungen, aber keine Freigabe ihrer Maschinenbezüge. X/Y-Tischbewegung und Werkzeugbewegung relativ zum Werkstück können unterschiedliche Vorzeichen haben; die LinuxCNC-Skalierung folgt der geprüften Werkzeugkonvention, nicht einfach einem positiven CAD-Vektor. [D1; Bezug zur Homing-Konvention L4]

`construction/create_x_axis.py`, `create_y_axis.py` und `create_z_axis.py` sind bereits getrennte Einstiegsmodule. Sie kompilieren nur überprüfbare Achsdaten über `axis_plan.py`. Fehlende Achsrahmen, Einbaunachweise, Kaufteilquellen oder Z-Haltekonzept erzeugen einen Fehler. Diese Module enthalten noch keinen fertig implementierten Kugelspindel-/Motor-Einbau; ihr Status ist `DATA_PLAN_ONLY`.

### 7.3 Umsetzung ohne Originalschäden

Der geplante Ablauf ist: Bestand lesen, Originalprüfsummen sichern, Achsbezüge prüfen, Kaufteile einzeln in NX bereitstellen, Sonderteile bauen, neue Trägergruppen mit überprüften Transformationen erstellen und nur diese neuen Teile speichern. Handkomponenten werden anhand einer geprüften Rollenliste ausgeschlossen. Eine aktive Original-Unterbaugruppe wird weder umgespeichert noch durch ein Sammel-„Save all“ verändert.

Das heute enthaltene `NX_02_Projektcontainer_anlegen.py` macht nur den ersten sicheren Referenzcontainer. Es ist bewusst keine endgültige CNC-Montage und kein Ersatz für die spätere Rollen-/Bewegungsstruktur. [D1]

## 8. LinuxCNC, Mesa und Elektrik

### 8.1 Steuerungstopologie

Vorgesehen sind LinuxCNC auf einem geeigneten Echtzeit-PC und eine eigene kabelgebundene Netzwerkschnittstelle zur Mesa 7i95T. Die Mesa erzeugt Step/Dir für die Achstreiber; normale Sensor- und Zustands-I/O laufen über ihre isolierten Ein-/Ausgänge. Eine normale USB-Netzwerkkarte oder Funkverbindung wird nicht als vorgesehene Motion-Verbindung eingeplant. [L1]

Der Motorencoder eines Closed-Loop-Steppers bleibt zunächst am zugehörigen Treiber. Eine Stepgen-Rückmeldung in LinuxCNC ist nicht automatisch die tatsächlich gemessene Tischposition. Eine spätere Einbindung der vorhandenen Linearmaßstäbe verlangt deren elektrischen Typ, Auflösung und ein eigenes Regelungskonzept. [D1, L3]

### 8.2 I/O-Konzept

Die Mesa 7i95T besitzt sechs Step/Dir-Kanäle, sechs Encoderkanäle sowie 24 isolierte Eingänge und sechs isolierte Ausgänge. Ihre Logikversorgung ist 5 V; diese darf nicht mit einer vorgesehenen 24-V-Feldversorgung verwechselt werden. Die Pinbelegung in `linuxcnc/io_allocation.json` und `IO_Konzept.csv` wurde gegen die Connector-Tabellen des Herstellerhandbuchs abgeglichen. [M1]

Kanal 0/1/2 ist als X/Y/Z vorgesehen. Die Eingangsplanung reserviert getrennte Home- und Endsignale, Treiberfehler, Sicherheits-/Türstatus, Bedienfunktionen, Taster sowie Schmier-, Halte- und Spindelzustände. Alle sechs normalen Ausgänge sind im Vorschlag belegt; eine zusätzliche Drehrichtungsanforderung für die Spindel benötigt eine neue Belegung oder Erweiterung. Encoderkanäle sind nur reserviert, nicht als bereits elektrisch kompatibel erklärt. [D1]

Zwei Eingänge teilen sich jeweils einen Common. Die daraus entstehenden elektrischen Einschränkungen sind im Verdrahtungsentwurf zu beachten. Die eigentlichen Firmware-/HAL-Pinnamen müssen aus der eingesetzten Karte und Firmware gelesen werden. Physischer Steckkontakt, HostMot2-Funktion und LinuxCNC-Signal sind drei unterschiedliche Ebenen. [M1, L3]

### 8.3 Spindel und Versorgungen

Originalmotor und XMT-Regler bleiben Kandidaten zur Weiterverwendung. Die bereits fotografierten SA/SB/SC-Motorsignale werden nicht als externer Drehzahlsollwert verwendet. Ein Analogmodul wie die Mesa 7i83 wird nur dann ausgewählt, wenn der Originalregler einen dafür geeigneten, elektrisch geklärten Eingang besitzt. Die 7i95T wird nicht mit einem unbelegten integrierten 0–10-V-Spindelausgang verplant. [U2, M1, M9, L2]

Netzteiltypen und Sicherungswerte werden noch nicht festgelegt. Zu berechnen sind getrennte 5-V-Logiklast, 24-V-Feldlast einschließlich Haltesystem und die Antriebsleistung mit Zwischenkreis-/Rückspeisefällen. Verlustleistung, Lüftung, Leitungslängen, Schirmanschlüsse und Schutzleiterführung gehören zur Schaltschrankauslegung. Ein größerer externer Schaltschrank ist die Vorzugsvariante, weil die alte schmale Blechhülle nicht ohne Nachweis als ausreichender Raum für drei zusätzliche Treiber und Sicherheitskomponenten angesehen werden sollte. [D1]

### 8.4 Konfiguration und Inbetriebnahme

Die Dateien mit Endung `.template.txt` sind Dokumentationsvorlagen, keine startfähige Maschinenkonfiguration. Sie enthalten bewusst offene Werte statt erfundener Home-/Limit-Koordinaten. Die Formeln für Step-Skalierung sind berechnet; die endgültigen Vorzeichen, Geschwindigkeiten und Grenzen bleiben zu prüfen. [L4, L5]

Die Inbetriebnahme wird gestuft geplant: elektrische Prüfung; I/O-Test ohne angetriebene Maschine; Vorzeichen-/Skalierungsprüfung an gesicherter einzelner Achse; Referenzfahrt mit sicherem Freiraum; langsame Endlagen-/Freigangtests; Last- und Dynamikversuche; abschließend dokumentierter Test der Stopps und Fehlerfälle. Z zuerst zu referenzieren ist ein möglicher Ablauf, nicht unabhängig vom tatsächlichen Aufbau freigegeben. Ein automatischer Wiederanlauf nach Not-Halt-Reset wird nicht vorgesehen. [D1]

## 9. Sicherheit und mechanische Schutzmaßnahmen

Das Konzept verlangt eine unabhängige Bewertung der Energieabschaltung, Wiederanlaufsperre, Tür-/Haubenüberwachung und Z-Haltung. Eine Mesa-Eingangsleitung „Safety ready“ ist nur Rückmeldung; sie ersetzt keinen entsprechend ausgelegten Sicherheitskreis. Auch ein normales Treiber-Enable wird nicht als zertifiziertes STO bezeichnet. Die Auswahl von Sicherheitsrelais, Schützen und Bremssteuerung erfolgt aus der Risikobeurteilung und den echten Antriebsdaten. [D1]

Für Z ist eine Ablaufanalyse bei Spannungsausfall, Treiberfehler, Kommunikationsverlust, Not-Halt und Verlust der Übertragung erforderlich. Die Haltefreigabe muss zum aufgebauten Motormoment und zur Bremsfunktion passen; eine ungeprüfte Zeitschaltung oder direkte Kopie von „Axis enable“ genügt nicht. Rückmeldung, Haltemoment, zulässige Notbremsarbeit und möglicher mechanischer Ausfallpfad sind getrennte Nachweise. Die Stoppstrecke darf nicht aus dem Ideal-Rechenfall freigegeben werden. [M8, D1]

Spindeln und Muttern erhalten geeignete Abdeckungen und Schmierzugänge. Frässpäne, Kühlmittel und Schiefstellung sind bekannte Risiken für Kugelgewindetriebe; die Herstellerhinweise verlangen entsprechenden Schutz und Montagegenauigkeit. Die vorhandenen Schmiernuten sollen nicht durch einen Mutterhalter verdeckt werden. Notwendige Änderungen am Guss werden erst nach Geometrie- und Steifigkeitsprüfung festgelegt. [M8, D1]

Netzverdrahtung, Schutzmaßnahmen und elektrische Prüfungen müssen von einer dafür qualifizierten Fachkraft ausgelegt und geprüft werden. Dieses Konzept ist kein Schaltplan, kein Sicherheitsnachweis und keine Aussage über eine bereits erfüllte Maschinenkonformität.

## 10. Geometrische Prüfung, Zeichnungen und Exporte

### 10.1 Prüfplan

| Prüfung | Methode im Ziel-NX-Lauf | Stand Konzept 02 |
|---|---|---|
| Einheiten und Originalschutz | PartUnits, Pfad-/Hashprüfung | bestehende Journalmechanismen; neue Ausführung offen |
| Achsposition/Koaxialität | Referenzachsen plus Winkel-/Abstandskontrolle | numerisches Modul getestet; echte NX-Achsreferenzen fehlen |
| Freier Mutter-/Motorraum | tatsächliche Körperabstände und Interferenzen | nicht ausgeführt |
| Verfahrwege | Mutter innerhalb nutzbarer Gewindestrecke; Enden/Abdeckungen prüfen | Intervallformel implementiert, reale Werte fehlen |
| Bewegungszustände | 5 Stellungen je Achse = 125 Kombinationen | normierte Prüfliste erzeugt; keine Kollisionsergebnisse |
| Zwischenstellungen | adaptives Nachverdichten / kontinuierliche Hülle | geplant; diskrete Stichprobe reicht nicht als vollständiger Beweis |
| Baugruppenänderung | geänderte Steigung/Motorparameter aktualisieren und prüfen | Teilemuster enthalten Dicke-/Längentest, kein Gesamt-Update-Test |
| Herstellerimport | Modellmaße, Einheit und Revision vergleichen | kein Kaufteilimport durchgeführt |

Die 125 Einträge sind **Anteile von 0 bis 1 des später bestätigten Hubs**, keine aktuellen Maschinenmillimeter. Ein leerer Kollisionsbericht ist kein bestandenes Ergebnis. Befestigte Kontaktflächen, Lager-/Wellenkontakte und Gewinde dürfen nicht pauschal als Fehler oder pauschal als zulässig behandelt werden; die erlaubten Kontaktpaare müssen separat definiert werden. [U1, D1]

### 10.2 Fertigungszeichnungen

Eine freigegebene Sonderteilzeichnung benötigt funktionale Ansichten/Schnitte, Bezugssystem, Maße, Gewinde und nutzbare Gewindetiefe, Passungen, Oberflächen, Werkstoff, Toleranzen und Revisionskennung. Passungen werden aus dem gewählten Lager/Motor und dem Lastfall abgeleitet; ein H7-Eintrag aus einer BF20-Hülse wird nicht pauschal übertragen. Maßketten, Werkzeugzugang und Montierbarkeit sind vor Ausgabe zu prüfen. [U1, D1]

Automatische NX-Zeichnungsblätter, maßassoziative Bemaßung, PDF- und DXF-Export sind in diesem Stand noch nicht implementiert. Die vorliegenden Entwurfsmuster haben deshalb keine als Fertigungszeichnung bezeichneten PDFs. Der Konzeptbericht ist eine Dokumentation und keine Zeichnung. Ein STEP-Exporter für die CNC-Maschine wird erst an einer erfolgreich gespeicherten neuen Baugruppe implementiert und per Rückimport geprüft; eine beliebige Alt-STEP-Datei ersetzt diesen Nachweis nicht. [U1]

## 11. Reproduzierbare Skripte und Arbeitsfolge

### 11.1 Einstiegspunkte

| Datei | Tatsächliche Aufgabe |
|---|---|
| `NX_01_Bestand_analysieren.py` | Originalbaugruppe lesend inventarisieren, JSON und API-Befund |
| `NX_02_Projektcontainer_anlegen.py` | neues natives Referenzprojekt mit unverändertem Bestand |
| `NX_03_BF20_Referenzhuelsen.py` | sechs quellengetrennte native BF20-Referenzteile |
| `NX_04_Nachweise_pruefen.py` | Nachweis-Einträge inventarisieren; keine Konstruktionsfreigabe |
| `NX_05_Sonderteilkonzepte_erzeugen.py` | drei neue parametrische Entwurfsmuster, getrennt von der Maschine |
| `NX_06_Konzeptbericht_erzeugen.py` | Berechnungs-, Stücklisten- und Prüflistenberichte; keine CAD-Geometrie |
| `Projektbericht_erzeugen.py` | dieselben Konzeptberichte ohne NX mit normalem Python erzeugen |

Zusätzlich enthalten sind reine Rechenmodule für Übersetzung, Lastmoment, Kennlinieninterpolation und Idealstoppweg, Prüfmodule für Rotation/Koaxialität/Hub sowie getrennte X/Y/Z-Datenplanmodule. Die Import-/Montage-/Zeichnungsautomation ist damit noch nicht vollständig. Funktionsnamen im Achsmodul werden nicht als Nachweis schon erzeugter Achsen ausgegeben.

### 11.2 Parameterdateien

`project.json` enthält Umgebung und Ausgabeziel. `design_scenarios.json` enthält ausschließlich angenommene Rechenfälle. `design_parts.json` enthält eigene Entwurfsmuster. `component_database.json` enthält Kandidaten und Quellen, keine Freigaben. `interfaces.json` ist das ursprüngliche Nachweisregister. `axis_interfaces02.json` ist der ergänzte strukturierte Koordinaten-/Komponentenvertrag. Es wird nicht automatisch aus unbestätigten Modellwerten befüllt.

Eine Dateiänderung soll mit Einheit, Quelle, Status und Revision dokumentiert werden. Bei Zusammenbau aus Herstellerdateien wird zudem der CAD-Hash gespeichert. Herkunft und Rechenwert bleiben getrennt: ein aus Annahmen berechneter Wert ist weiterhin annahmeabhängig, auch wenn die Berechnung fehlerfrei ist.

### 11.3 Lokale Tests und echte NX-Tests

Die Offline-Tests prüfen Mathematik, ungültige Daten, Transformationskonvention, fehlende Nachweise, Quellschutz, Berichtsausgaben und Nicht-Überschreiben. Sie prüfen nicht den NX-Geometriekern, die tatsächliche Baugruppe oder die reale Maschine. Der native Muster-Generator enthält Laufzeitprüfungen, deren erfolgreiche Ausführung erst im Nutzer-NX protokolliert werden kann. Die genaue Testzahl und Ergebnisse stehen im beigefügten Prüfbericht, nicht als Zukunftszusage hier im Konzept.

## 12. Abnahme, nächste Meilensteine und offene Entscheidungen

### 12.1 Abnahmestand gemäß Nutzerprompt

| Gefordertes Ergebnis | Aktueller Stand |
|---|---|
| Finale native CNC-Baugruppe | noch nicht erzeugt |
| Native passgenaue Sonderteile | Entwurfsgenerator für drei Muster vorhanden, NX-Lauf und Maschinenanschlüsse offen |
| Vollständiger Python-Code des bisher implementierten Umfangs | enthalten |
| Zusätzlicher STEP-Export des CNC-Umbaus | noch nicht erzeugt |
| Fertigungszeichnungen / PDF / DXF | noch nicht erzeugt |
| Vollständige bestellfertige Stückliste | Konzeptstückliste mit offenen Positionen enthalten |
| Geometrisches Prüfprotokoll | Offline-Prüfbericht enthalten; NX-Kollisions-/Verfahrnachweis offen |
| LinuxCNC/Mesa-Konfiguration | I/O-Plan und nicht startfähige Vorlagen; keine Inbetriebnahmefreigabe |

Das Projekt ist im Sinne der im Prompt definierten CAD-Endabnahme **nicht abgeschlossen**. Der neue Stand präzisiert jedoch Auswahl, Rechenweg, Schnittstellen und Implementierung, statt durch angenommene Positionen eine scheinbar fertige Baugruppe zu liefern. [U1]

### 12.2 Konstruktionsfolge

**M1 – Bestand und Koordinaten:** Audit der tatsächlichen Hauptbaugruppe, prüfbare X/Y/Z-Achsrahmen und Maschinen-Nullkonvention. **M2 – X-Paket:** Mutterraum, Lager-/Motor-/Mutterschnittstellen, reale Kaufteilkonfiguration, dynamische Auswahl, native Halter und Montage. **M3 – Y-Paket:** gleicher Ablauf, danach XY-Endlagen gemeinsam prüfen. **M4 – Z-Paket:** Kopfmasse, Last-/Haltekonzept, Antriebsauswahl, neuer Mutteranschluss und Kabelweg. **M5 – Systemintegration:** Schaltschrank, Schutz, Schmierung und Spindelschnittstelle. **M6 – Freigabe:** Last-/Geometrie-/Sicherheitsprüfungen, Zeichnungen, dokumentierte Fertigung und Inbetriebnahme. [D1]

Die Arbeit kann parallel auf Datenbeschaffung und Softwarevorbereitung voranschreiten, aber keine Achse wird bestellt, bevor Spindel, Mutter, Lagerenden und Halter als zusammengehörige Maßkette geklärt sind. Der nächste entscheidende Datensatz bleibt der lesende NX-Audit. Zusätzliche Fotos sind für diesen Konzeptstand nicht vorausgesetzt.

### 12.3 Quellen und Einordnung

Die im Text verwendeten Kennungen U1–U3, M1–M9, L1–L5, N1–N2 und D1 sind in `QUELLEN_02.md` mit URL beziehungsweise lokaler Referenz dokumentiert. Bearbeiterentscheidungen sind D1; sie werden nicht als Herstellerangaben oder ausdrückliche Nutzerentscheidungen ausgegeben. Onlinequellen wurden am 27.10.2026 geprüft. Hersteller-CAD, Preise, Lagerbestand und vollständige offizielle NX2406-Aufrufverifikation bleiben offen.
