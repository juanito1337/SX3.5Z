# Abnahmematrix – Entwicklung 03

| Prompt-Anforderung | Implementierter Stand | Tatsächlich ausgeführter Nachweis |
|---|---|---|
| NX Open Python / native CAD | native Adapter, 13 Journal-Einstiegspunkte | Python-3.10-Grammatik und Offline-Tests; **kein NX-Lauf** |
| Originalmaschine analysieren | lesender Audit und explizite Flächenauswertung | JSON-Verarbeitung an Testdaten; kein neuer Nutzeraudit eingegangen |
| Originaldateien erhalten | neue Eigentümerteile, Quellenhashes, kein Original-Save | Offline-Datei-/Ablauftests |
| Parametrische Sonderteile | Motorträger, Hülsen, Flanschplatten; native Teilgeneratoren | Formeln und analytische Referenzen geprüft; reale NX-Parameterprobe ausstehend |
| Reale Kaufteile | CS-M22326 quellengebundene Ersatzgeometrie; Importweg für Original-STEP | Primärquelle überprüft; **keine Original-CAD-Datei beschafft** |
| X/Y/Z getrennt konstruieren | gemeinsame native Implementierung mit eigenen Achseinstiegen | Schema, Poseberechnung, Vorprüfungen; noch keine maschinenspezifischen Achsdaten |
| Automatisch montieren | selektive Bestandsübernahme, Kauf-/Sonderteile, neue Untergruppen | logische Tests; Matrixkalibrierung/Einfügung erst in NX |
| Geometrische Prüfung | reale NX-Volumen-/Boundsprüfung im Code, AABB-Vorprüfung | numerische Offline-Prüfungen; **keine ausgeführte NX-Kollisionsprüfung** |
| Verfahrwege prüfen | vorhandener Prüfplan und Verschiebungsfunktionen | keine reale Bewegung, kein vollständiger Hubsicherheitsnachweis |
| STEP-Export | nativer Übersetzerpfad | kein hier erzeugter Export, kein Reimportvergleich |
| Fertigungszeichnungen | weiterhin offen | keine Zeichnung oder Fertigungsfreigabe |
| Stückliste | 49 Konzeptpositionen historisch + separate Referenzbaugruppenliste | keine bestellfertige Gesamtliste |
| LinuxCNC / Mesa7i95T | Konzept02 unverändert enthalten | keine ausführbare Inbetriebnahmekonfiguration |
| Finale FRAESMASCHINE_CNC_UMBAU.prt | **offen** | keine finale native Datei erzeugt |

Die neue Motorträger-Referenz ist bei erfolgreichem NX-Lauf ein konkreter nativer
Zwischenschritt. Sie erfüllt nicht die Endabnahme der gesamten CNC-Maschine.
