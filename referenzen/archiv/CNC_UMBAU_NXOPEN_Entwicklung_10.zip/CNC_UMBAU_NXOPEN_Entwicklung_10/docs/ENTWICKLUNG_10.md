# Entwicklung 10 — Rundmuttern mit zugeordneten Aufnahmen

Stand 27.10.2026. Ziel NX2406 / Python3.10. Kein tatsächlicher NX-Lauf durch den Autor.

## 1. Bezug zum Nutzerprompt

Dieser Schritt ergänzt Abschnitt 5 (reale Kaufteilreferenzen) und Abschnitt 6
(Spindel/Mutter plus Aufnahme als native Komponenten). Er ersetzt weder die
Originalmaschinenaufnahme noch die verbindliche native Endabnahme. Es werden keine
X-/Y-/Z-Maschinenpositionen geschätzt und keine Originaldateien geöffnet/geändert.

Der Ausgangspunkt bleibt Entwicklung09. Dort waren die Spindel-/Mutterpaarungen
vorhanden; eine passende Aufnahme fehlte. Der allgemeine D04-Flanschmutterträger ist
keine bestätigte Aufnahme für die vorliegenden Rundmuttern und bleibt unverändert.

## 2. Herstellerdaten und ausdrücklich offene Details

Herstellerquelle: isel-Katalog Kugelgewindespindeln, April2025, Druckseite9:
https://www.isel.com/fileadmin/user_upload/Kataloge/20250403_Katalog_Kugelgewindespindeln_de.pdf

Die Hauptkörperdaten sind aus der Tabelle **Fußbefestigung** übernommen:

| Artikel | Spindelfamilie | M (Aufnahme) | L | B | H | H1 |
|---|---:|---:|---:|---:|---:|---:|
| 213500 | 16 mm | 28 H7 | 54 | 47 | 33 | 16,5 |
| 213600 | 20 mm | 33 H7 | 61,5 | 53 | 40 | 20 |

Einheiten mm. 213500 wird den vorhandenen Mutterartikeln 213514 (16×4) und 213505
(16×5) zugeordnet; 213600 dem Artikel 213420 0005 (20×5). Die Quelle ist ein
Katalog, keine Bestands-/Lieferverfügbarkeitsbestätigung. Die H7/h7-Kennzeichnungen
bleiben Metadaten; keine Grenzmaße oder Passungsberechnung.

**Quellenlage:** Der PDF-Text war abrufbar. Screenshot-Versuche der Zeichnungsseiten
scheiterten mit Cache miss. Direkter PDF-Download und der Hersteller-Traceparts-Zugang
waren ebenfalls nicht nutzbar. Es liegt weder eine Original-CAD-Datei noch eine lokale
Original-PDF-Datei vor. Die technischen Angaben müssen vor Bestellung an einer
zugänglichen Originalzeichnung geprüft werden.

Daher sind nur die rechteckige Haupthülle und die nominelle Aufnahme modelliert.
Die Zuordnung von H1 zur Achshöhe ist als Tabelleninterpretation gekennzeichnet,
nicht als visuell bestätigte Zeichnungsablesung. **Fußbohrungen, Senkungstiefen,
Schlitze, Stell-/Fixierschrauben, Spannmutter und Schmiernippel fehlen.** Aus L1/L2/L3
werden ohne Zeichnung keine Lochkoordinaten abgeleitet. Die Hülle ist kein exakt
rekonstruierter kompletter Spannblock und berücksichtigt nicht alle Anbauteilüberstände.

Es werden keine Herstellerzeichnungen, Gewinde oder Klemmwirkungen nachgebildet,
deren Daten nicht vorliegen. Kein Klemmmoment, keine Vorspannung und keine Tragfähigkeit
sind durch die reine Geometrie bestätigt. Die frühere vereinfachte Mutterbohrung ist
weiterhin nur eine Darstellung ohne Kugellaufbahnen. Körpervolumina sind Modellprüfwerte,
keine Massengrundlage der realen Artikel.

## 3. Aufbau und Koordinaten

`NX_23_Rundmutter_Aufnahmen.py` ist implementiert für folgende Standardsituation:

- sechs Spindel-/Mutter-Einzelteile aus Entwicklung09;
- zwei zusätzliche native Block-Einzelteile;
- drei Unterbaugruppen mit je Spindel, Mutter und Block;
- eine gemeinsame Übersicht mit neun Blattvorkommen.

Der 16-mm-Block ist ein gemeinsamer Prototyp in zwei unterschiedlichen Paarungen.
Das unterscheidet identische Artikel von gleichen äußeren Mutterformen mit
unterschiedlicher Steigung. Stückzahlgleichheit wird aus der tatsächlich aufgebauten
NX-Struktur gelesen und kontrolliert.

Lokale Z-Achse = Spindelachse. Rohlingbeginn z=0. Der Block hat seinen lokalen Ursprung
auf der Bohrungsachse an einer Stirnfläche; die Fußfläche liegt modellseitig bei
Y=-H1. Die Bauteile werden zunächst einzeln erzeugt, dann in einer neuen Baugruppe
eingesetzt. Die Anzeigeübersicht verschiebt die drei Studien um jeweils 100 mm in X.
Das sind Präsentationskoordinaten, keine Maschinenanschlüsse.

`nut_offset_mm` beschreibt die Muttermitte relativ zur Blockmitte. Standard: 0,
ausdrücklich eine **Studienannahme**. `reference_block_center_mm=null` wählt die Mitte
des rechnerisch zulässigen Intervalls. Andere Werte sind erlaubt, soweit sie nicht
gegen das berechnete Intervall verstoßen. Änderungen in Konfiguration und Neuaufbau
führen zu konsistenten Teilpositionen; keine Interpart-Verknüpfung oder Constraints.

## 4. Gemeinsamer axialer Raum

Nicht nur die Mutter, sondern auch der mitbewegte Hauptkörper des Blocks ist zu
berücksichtigen. Mit Mutterlänge N, Blocklänge B und axialem Versatz d:

```
u_min = min(-B/2, d-N/2)
u_max = max( B/2, d+N/2)
Blockmitte_min = Reserve_Anfang - u_min
Blockmitte_max = Rohlinglänge - Reserve_Ende - u_max
Bereich = Blockmitte_max - Blockmitte_min
```

Das ist die Vereinigung zweier eindimensionaler Hauptkörperintervalle. Sie funktioniert
auch bei außermittiger, aus dem Block herausragender Mutter; die nutzbare Breite ist
nicht pauschal immer die Blocklänge.

| Studie | Rohling | N | B | d | Reserven | Rechnerischer Hauptkörper-Bereich |
|---|---:|---:|---:|---:|---:|---:|
| 16×4 | 352 | 50 | 54 | 0 | 10+10 | 278 |
| 16×5 | 352 | 50 | 54 | 0 | 10+10 | 278 |
| 20×5 | 252 | 50 | 61,5 | 0 | 10+10 | 170,5 |

Diese Werte sind gegenüber der reinen Mutterbetrachtung (282/282/182 mm) geringer.
**Sie sind trotzdem keine bestätigten Maschinenverfahrwege** und nicht einmal eine
Freigabe des kompletten realen Antriebs: Rohlinge sind unbearbeitet; Lager, Ausläufe,
Schraubenüberstände, Mutternbefestigung, Faltenbälge und Anschläge bleiben unberücksichtigt.
Die 10-mm-Reserven sind Entwurfswerte, keine Herstellervorgabe.

## 5. Native Prüfungen im implementierten Ablauf

Alle Körper verwenden die vorhandenen NX-Block-/Zylinder-/Boolean-Funktionen.
Der neue Rezeptschema-Adapter nutzt keine zusätzliche, frei erfundene NX-Methode.
Nach jeder Operation werden geplantes Volumen, Endvolumen, Begrenzungen und
Festkörperstatus kontrolliert. Neues Schema `supplier_mount10` ist in der zentralen
Rezeptvalidierung registriert.

Standardmäßig vorgesehen:

- 12 bisherige Parameteränderungsproben der sechs Spindel-/Mutterteile;
- 6 neue Proben der beiden Blocks: Länge, Bohrungsdurchmesser, H1/Achshöhe;
- 9 axiale MIN/REFERENZ/MAX-Proben mit Messung der drei jeweiligen Vorkommnishüllen;
- 12 Schnittstellenprüfungen (vier je Referenzgruppe).

Die vier Schnittstellenprüfungen vergleichen gemessene Zylinderachsen von Spindel,
Mutter-Außenfläche und Aufnahmebohrung, deren nominelle Durchmesserdifferenz sowie
den Abstand der Modellbohrungsachse zur modellierten Fußfläche. Messungen stammen
im nativen Lauf aus `AskFaceData`, nicht aus kopierten Sollwerten. Sollwerte selektieren
lediglich die eindeutigen Flächen. Fehlende oder mehrdeutige Flächen brechen ab.
Grenzen: 0,01 mm / 0,01° für Modellachsen und 0,005 mm für Nennmaßvergleich, ausdrücklich
keine Fertigungstoleranzen. Diese Prüfungen beweisen nur die erzeugte vereinfachte
Modellgeometrie, nicht die reale Klemmfunktion oder Herstellerpassung.

Temporäre Prüfposen entstehen ausschließlich in einer neu angelegten Prüfbaugruppe
und werden zurückgenommen, bevor die bleibenden Unterbaugruppen entstehen. Die alte
Matrixkalibrierung am Körper bleibt erhalten. Quellen, neu gespeicherte Teile und
Baugruppen sind vor dem Abschluss an Pfad/Prüfsumme gebunden. Veränderte Dateien,
fehlende Mengen oder falsche Positionen verhindern den vollständigen Abschlussbericht.

## 6. Ergebnis und Bedienung

NX Journal wiedergeben → `NX_23_Rundmutter_Aufnahmen.py`. Das Journal kann ohne
Originalmaschinenbaugruppe gestartet werden. Standardziel:
`%LOCALAPPDATA%\SX35Z_CNC\Projekt10\<Zeitstempel>_nutmount10_<Kennung>\`.

Die `.prt`-Dateien entstehen ausschließlich bei erfolgreicher Ausführung in NX.
`NX_Rundmutter_Aufnahmen_10.json` nennt Dateipfade, Mengen, Flächendaten, Prüfwerte
und offene Nachweise. Die Bauteilzuordnung liegt in `Kaufteilzuordnung_10.json`.
Der Abschlussstatus lautet bewusst `NATIVE_MAIN_BODY_REFERENCES_CREATED_NOT_MACHINE_FITTED`.

Offline: `python Projekt10_Aufnahmebericht.py` erzeugt JSON/CSV/HTML; kein CAD.
Eine solche Vorschau ist im Paket unter `reports/10_Rundmutter_Aufnahmen/Vorschau`.

## 7. Was nicht abgeschlossen ist

Kein Autor-NX-Lauf, kein Original-Hersteller-CAD, keine vollständige Spannblockkontur,
keine Montage an der realen SX3.5Z, keine Lager-/Endenbearbeitung oder Kupplung.
Keine Fertigungszeichnungen der nur angenäherten Kaufteile. Keine Bestellfreigabe.
Der Auftrag einer fertigen nativen CNC-Gesamtmaschine bleibt damit offen.

Der nächste mechanische Anschluss ist die originalbelegte Klemm-/Fußbefestigung
und deren Anpassung an den real vermessenen Sattel/Kopf. Diese Aufgabe darf nicht
durch ein beliebiges Lochbild im jetzigen Hauptkörper ersetzt werden.
