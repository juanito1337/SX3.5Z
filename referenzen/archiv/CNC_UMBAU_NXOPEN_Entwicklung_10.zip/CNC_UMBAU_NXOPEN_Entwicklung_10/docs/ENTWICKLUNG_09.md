# Entwicklung 09 — reale Kugelgewinde-Katalogreferenzen

**Stand: 27.10.2026. Zielplattform: Siemens NX 2406 / NX Open Python 3.10.**

Diese Stufe bearbeitet den noch offenen Kaufteil-/Achstriebanteil des Nutzerprompts
(Abschnitte 5 und 6). Neu sind drei herstellerbezogene Spindel-Mutter-Paarungen,
ein nativer Modellaufbau, eine axiale Längenkette und deren Einbindung in die
bereits vorhandene Stücklistenauswertung. Keine tatsächliche Maschinenachse wird
an geschätzte Koordinaten montiert. Die Originalmaschinen-Dateien werden nicht
verwendet, verändert oder gespeichert.

## 1. Quellen und Grenzen

Quelle ist der isel-Katalog „Kugelgewindespindeln“, Stand April 2025:
https://www.isel.com/fileadmin/user_upload/Kataloge/20250403_Katalog_Kugelgewindespindeln_de.pdf

Ausgelesen wurden die Texttabellen der Druckseiten 6 und 8. Die Screenshot-Abfrage
scheiterte mit „Cache miss“. Eine lokale Original-PDF-Datei und ein originales
Hersteller-STEP konnten nicht beschafft werden. Deshalb wird keine visuelle
Zeichnungsprüfung oder ein Original-CAD-Import behauptet. Der Quellennachweis
`reference/Quellen_09.json` trennt das ausdrücklich. Eine unabhängige Prüfung
an der Originalzeichnung ist vor Teileauswahl/Bestellung noch erforderlich.

| Spindel-Nennmaß | Rundmutter-Artikel | Außen-Ø | Länge |
|---|---|---:|---:|
| 16 × 4 mm | 213514 | 28 mm | 50 mm |
| 16 × 5 mm | 213505 | 28 mm | 50 mm |
| 20 × 5 mm | 213420 0005 | 33 mm | 50 mm |

Werkstoff- und Tragzahlangaben sind als Katalog-Metadaten hinterlegt, nicht als
Nachweis einer ausreichenden Tragfähigkeit in der Fräse. Außendurchmesser h7 ist
eine Quellenangabe, keine im Modell aufgelöste Grenzmaß- oder Passungsprüfung.

Für unbearbeitete Rohlinge nennt der Katalog für Ø16 einen Bereich von
352–3052 mm und für Ø20 von 252–3052 mm, jeweils im Raster 100 mm. Die
Standardstudie verwendet 352/352/252 mm — nicht die benötigten Maschinenlängen.
Der vollständige Spindel-Bestellschlüssel wird nicht aus unvollständig
kontrollierten Zeichnungen erraten; er bleibt offen.

## 2. Tatsächlicher Modellumfang

`NX_22_Kugelgewindetriebe_Katalog.py` ist implementiert für:

- sechs native parametrische Einzelteile: je ein Rohling und eine Rundmutter pro Variante;
- drei native Paar-Unterbaugruppen mit je zwei Komponenten;
- eine Übersicht mit drei Unterbaugruppen und sechs Blattvorkommen;
- eine separate Kalibrierung und eine leere temporäre Prüfbaugruppe.

Die Körper sind **vereinfachte nominale Außenhüllen**, keine Original-CAD-Dateien:
Der Rohling ist ein Zylinder mit nominalem Spindeldurchmesser. Die Mutter ist eine
zylindrische Außenhülle mit einer rein darstellerischen Bohrung in nomineller
Spindelgröße. Die Darstellungsbohrung ist **kein Hersteller-Innenmaß, keine Passung
und keine Kugellaufbahn**. Eine Kontakt- oder Massenprüfung der realen Kaufteile
ist damit unzulässig. Die berechneten Volumina prüfen ausschließlich, ob NX die
vorgesehene vereinfachte Geometrie erzeugt hat.

Nicht dargestellt sind Kugeln, Rückführung, Abstreifer, Klemmschlitze,
Vorspannung, Schmierung, Lagerenden, Lagerpakete, Kupplung oder Motor. Die Steigung
ist ein benannter Parameter und wird in der axialen Rechnung verwendet, aber
**nicht als Schraubenlinie modelliert**. Gleiche Außenformen mit verschiedenen
Steigungen bleiben unterschiedliche Teile mit eigenen Artikel- und Quellenbezügen.

Der bestehende D04_MUTTERTRAEGER ist ein allgemeiner Flansch-Entwurf. Trotz
ähnlichem Durchgangsdurchmesser ist er **nicht als Halter dieser Rundmuttern
bestätigt**. Eine passende Aufnahme/Klemmung muss gesondert konstruiert oder nach
Originalunterlagen ausgewählt werden. Kein bestehender Halter wird automatisch
für die neuen Katalogmuttern freigegeben oder angepasst.

## 3. Axiale Längenkette

Lokales Studienkoordinatensystem: Z = 0 am Anfang des Rohlings, positive Z-Richtung
entlang seiner Achse. Die Mutterkoordinate ist ihre Mitte, nicht eine Stirnfläche.

Mit Gesamt-/Hülllänge L, Mutterlänge N, nicht befahrbaren Enden a und b und
zusätzlichen Reserven rA/rB:

```
z_min = a + rA + N/2
z_max = L - b - rB - N/2
axialer Bereich = z_max - z_min
L_min = gewünschter Bereich + N + a + b + rA + rB
Umdrehungen = linearer Weg / Steigung
```

Nur für die **unbearbeitete Rohlingstudie** werden a und b mit null angesetzt.
Bei bearbeiteten Spindeln dürfen unbekannte Endanteile nicht auf null fallen;
`minimum_length` verlangt dafür explizite Werte. Die Konfiguration dieser Stufe
enthält bewusst keine bearbeitete Variante. Endauslauf, mechanische Anschläge,
Lagergehäuse, Motoreinbau und Nachlaufreserven sind nicht enthalten.

Mit 50 mm Mutterlänge und **je 10 mm frei gewählter Studienreserve** ergeben sich:

| Studie | Muttermitte min/max | Referenzmitte | Nominaler axialer Bereich |
|---|---|---:|---:|
| 16×4 / 352 mm | 35 … 317 mm | 176 mm | 282 mm |
| 16×5 / 352 mm | 35 … 317 mm | 176 mm | 282 mm |
| 20×5 / 252 mm | 35 … 217 mm | 126 mm | 182 mm |

Das sind **keine erreichbaren Verfahrwege deiner Maschine** und keine Bestelllängen.
Der gewünschte Bereich ist standardmäßig unbekannt (`null`). Bei einem zu großen
Wunschwert weist die Rechnung die fehlende Länge aus. Der Bezug zur Steuerung
(Motorübersetzung, Impulse/mm, Referenzrichtung) wird hier noch nicht hergestellt.

## 4. Parametrik und Prüfungen in NX

Außen-Durchmesser und Länge sind benannte Ausdrücke. Die Durchgangsgeometrie der
Mutter hängt von `visual_bore_d` ab. `lead_mm` ist ausdrücklich Metadatum ohne
Kugellaufbahnfeature. Eingaben und Artikelnummer müssen zum jeweiligen Katalogfall
passen; die Registry ist gegen unmarkierte Dimensions-/Quellenänderungen gesperrt.

Pro Teil werden nach dem Aufbau Volumen, Außenbegrenzungen und Festkörperstatus
geprüft. Je Teil folgen zwei temporäre Parameteränderungen (Länge und Außen- bzw.
Darstellungsbohrungsdurchmesser) mit Wiederherstellung und Rückprüfung: **12
Parameterproben im Standardlauf**. Geänderte Probewerte werden nicht gespeichert.

Für jedes Paar werden MIN, REFERENZ und MAX in einer neu angelegten Prüfbaugruppe
aufgebaut und aus den tatsächlichen Vorkommniskörpern gemessen: **9 Lageproben**.
Diese prüfen nur Lage/axialen Hüllraum, keinen Kugelkontakt und keine physische
Kinematik. Die Spindel wird nicht animiert gedreht. Die berechneten Umdrehungen
stehen nur als idealisierte Rechengröße im Plan.

Alle temporären Posen werden vor dem Aufbau der verbleibenden Unterbaugruppen
zurückgenommen. Eine fehlgeschlagene Rücknahme oder unerwartete Körperlage bricht
ab. Die vorhandene gemessene NX-Matrixkalibrierung wird unverändert verwendet.

Zuletzt liest der bestehende BOM-Reader die tatsächliche Übersicht. Sechs
zugeordnete Blattvorkommen sind für die Standardstudie erforderlich. Dateien werden
an Pfad und SHA256 gebunden. Veränderte Quellen oder gespeicherte Modelle, falsche
Mengen und fehlende Prototypen verhindern den endgültigen Ergebnisbericht.

## 5. Verwendung

ZIP vollständig in einen neuen Ordner entpacken. In NX 2406 über „Journal
wiedergeben / Play Journal“ `NX_22_Kugelgewindetriebe_Katalog.py` starten.
Eine Originalmaschinenbaugruppe ist nicht nötig. Zusatz-CAD-Software ebenfalls nicht.

Standardziel:

```
%LOCALAPPDATA%\SX35Z_CNC\Projekt09\<Zeitstempel>_ballscrew09_<Kennung>\
  NX_PARTS\
  NX_ASSEMBLY\
  Kaufteilzuordnung_09.json
  NX_Kugelgewinde_Referenzen_09.json
  NX_Stueckliste_07.json
  BOM\
  Quellschutz_09.json
  NX_Protokoll.txt
  NX_API_Befund.json
```

Die Hauptbaugruppe beginnt mit `KUGELGEWINDE_REFERENZEN09_KEINE_CNC_MASCHINE`.
Ein erfolgreicher Lauf meldet `NATIVE_CATALOGUE_REFERENCES_CREATED_NOT_MACHINE_FITTED`.
Eine BOM mit offenen Punkten ist korrekt. Keiner dieser Status bedeutet
Maschinenpassung, Original-Hersteller-CAD, Bestell- oder Fertigungsfreigabe.

Die neue Konfiguration steht in `config/ballscrews09.json`. Für jede Variante sind
Rohlänge, Studienreserve, Muttermitte und optionaler Wunschbereich änderbar.
Ein neuer Muttern-Typ bedarf dagegen einer Quellenprüfung und Registry-Erweiterung.
Die Unterbaugruppen sind positioniert; es gibt keine Montagezwangsbedingungen und
keine automatische Anpassung ihrer Position nach einer manuellen Einzelteiländerung.
Für konsistente Baugruppen Änderungen in der Konfiguration vornehmen und neu aufbauen.

## 6. Offline-Berichte

```
python Projekt09_Kugelgewindebericht.py
python Projekt09_Kugelgewindebericht.py --config eigene_faelle.json --output C:\NX_Daten\neuer_bericht
```

Der Bericht erzeugt JSON, CSV und HTML aus den Quelldaten und Rechnungen; kein CAD,
kein NX-STEP, keine native Prüfbestätigung. Bestehende Zielordner werden nicht
überschrieben. Ein Standardbericht liegt unter `reports/09_Kugelgewinde/` bei.

## 7. Was offen bleibt

Kein tatsächlicher NX-Lauf wurde durch den Autor ausgeführt. Keine `.prt`-Datei
ist hier entstanden. Keine Original-Kaufteil-STEP-Datei wurde beschafft. Kein
Kugelgewindetrieb ist der realen X-, Y- oder Z-Achse zugeordnet. Passende
Spannblöcke, Endenbearbeitung, Fest-/Loslagerung, Kupplung, Schmierung,
Abdeckung, Tragfähigkeits-/Drehzahl-/Knicknachweise und tatsächliche Befestigungen
sind noch auszulegen. Die native Endabnahme des Gesamtprojekts bleibt offen.
