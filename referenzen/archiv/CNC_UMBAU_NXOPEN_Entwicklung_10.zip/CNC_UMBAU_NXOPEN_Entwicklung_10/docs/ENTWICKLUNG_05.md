# Entwicklung 05 — bewegte Baugruppen prüfen

## Entscheidung und Fortschritt

Nach den Motorplatten und gestuften Haltern aus 03/04 fehlt nicht primär eine
weitere frei bemaßte Hüllgeometrie, sondern der belastbare Maschinen-/Kaufteilanschluss.
Die Recherche vollständiger Herstellerzeichnungen blieb in dieser Sitzung
unvollständig. Hersteller-CAD wurde nicht beschafft. Statt fehlende Lochbilder
zu erfinden, wurde der nächste unabhängig umsetzbare Bereich des Nutzerprompts
bearbeitet: **Abschnitt 8, Prüfung an mehreren Verfahrpositionen**.

Neue CAD-Geometrie dieser Revision ist ausschließlich Diagnosegeometrie. Der
Maschinenentwurf, BF20-Varianten, Motorreferenz und Haltergeometrien bleiben unverändert.
Die finale CNC-Gesamtbaugruppe ist nicht erstellt. Die Endabnahme des Prompts
bleibt daher ausdrücklich offen.

## Bausteine

- `validation/motion05.py`: überprüfte Eingabestruktur, translatorische Mitnahmen,
  Stichprobenraster, Abstandsschranke und konservative Intervalltrennung.
- `validation/motion_input05.py`: vollständige Übernahme eines echten NX-10-Berichts,
  Hashbindung und unveränderliche Originalpositionen/-orientierungen.
- `validation/scan05.py`: Körperpaarabdeckung, Budget, Stichprobenergebnisse,
  Wiederverwendung identischer relativer Geometrie und Vollständigkeitsprüfung.
- `cnc_nx/interference05.py`: bedingter UF-Aufruf, Live-Signaturprüfung,
  gelernte Rückgabecodes, Rücknahme temporärer Baugruppeninhalte.
- `cnc_nx/collision05.py`: native Diagnosekörper und neun Kalibrierfälle.
- `cnc_nx/travel05.py`: native Prüfposen, Messung der tatsächlich eingefügten
  Körpervorkommen, Quellschutz, Einzelergebnisse und zusammenfassender Bericht.
- `Projekt05_Pruefung_vorbereiten.py`: neue, bewusst ungeprüfte JSON-Vorlage.

## Bewegungsmodell

Für Komponente c und Achskoordinaten q gilt in Root-Koordinaten:

```text
t_c(q) = t_c,ref + Summe(u_a * (q_a - q_a,ref))
```

Die Summe umfasst ausschließlich die explizit angegebenen `moving_axes`.
Orientierung und Körperform bleiben unverändert. Keine Rotation, Winkelannahme
oder aus einem Bauteilnamen geschlossene Achszuordnung. Eine Spindel wird in dieser
Prüfung nicht dynamisch um ihre eigene Achse rotiert; dafür wären ein gesondertes
Rotations-/Hüllmodell und dessen Nachweis nötig.

Bei einem Paar werden gemeinsame Mitnahmen herausgerechnet. Der X-Motor kann
beispielsweise X und Y mitfahren, während ein entsprechendes Gegenstück nur Y
mitfährt. Der Beweis nutzt dann nur die tatsächlich verbleibende Relativbewegung.

Für jede kartesische Koordinate wird das Minimum/Maximum der relativen
Translation über den konfigurierten Achsbereich berechnet. Daraus ergibt sich
eine untere Abstandsschranke der AABBs. Diese Betrachtung kann Korrelationen
verlieren und dadurch zusätzliche Kandidaten erzeugen, aber keine zusätzliche
Trennung behaupten. Trennung wird nur oberhalb `clearance_mm + tolerance_mm`
angenommen. Die Toleranz ist eine numerische Prüfreserve, keine physische
Unsicherheitsbilanz für Vermessung, Belastung oder thermische Ausdehnung.

## Native Prüffälle

Drei Prototypen: Würfel 10×10×10; Block 20×20×20 mit Durchgang Ø10;
Stift Ø4×20. Volumen und Grenzen werden mit den analytischen Sollwerten verglichen.
Die neun Klassifikationsfälle werden auf den tatsächlich eingesetzten
Körpervorkommen geprüft, jeweils in beiden Reihenfolgen.

Der Stift-in-Bohrung-Fall verhindert, dass ein reiner Hüllquadervergleich
irrtümlich als Körperprüfung akzeptiert wird. Die gedrehten Vorkommen prüfen,
dass nicht nur lokale Prototypkörper statt der Baugruppenlage getestet werden.
Eine fehlende Unterscheidung von Kontakt/Durchdringung/Trennung stoppt das Journal.

Die am Ende gespeicherte Diagnosebaugruppe zeigt die Fälle freier Stift,
berührende Würfel und überlappende Würfel nebeneinander. Sie ist kein Maschinenteil.

## Verfahrwegprüflauf

1. JSON-Schema, Bewegungsbegründungen, Grenzen und Budget prüfen.
2. Quelle `NX_Montageentwurf.json` und alle Prototypdateien gegen SHA256 prüfen.
3. Exakte Vorkommensliste binden; keine Originalposition oder Rotation überschreiben.
4. Vollständig geladene, gespeicherte Millimeter-Prototypen verlangen.
5. Im selben NX-Lauf Matrix- und Kollisionsbackend kalibrieren.
6. Referenzhüllräume an wirklichen eingefügten Vorkommen auslesen.
7. Körperpaare und Posen erzeugen. Keine Komponenten zur Budgeteinhaltung auslassen.
8. Pro Pose temporäre Vorkommen einsetzen, reale Grenzen prüfen und Kandidatenpaare
   nativ klassifizieren. Konservativ nachgewiesen getrennte Paare benötigen keine
   zusätzliche Körperabfrage.
9. Per Undo zur leeren eigenen Prüfbaugruppe zurückkehren. Erst dann zählt die Pose.
10. Vollständigkeit und Originalzustand prüfen; danach den finalen Bericht schreiben.

Ein unverändertes relatives Körperpaar braucht nicht an jeder gemeinsam
verschobenen Pose neu abgefragt werden. Der Cache verwendet die Bauteilvorkommen,
Körperindizes und **ungerundete** Relativverschiebung. Er speichert keine NX-Tags
über Undo hinweg. Veränderte Geometrie ist nicht Teil dieses Cachemodells und
wird durch gesperrte Quelldaten/Prüfannahmen ausgeschlossen, nicht simuliert.

## Ergebnisgrenzen

Eine positive Klassifikation im Kalibriertest sagt nur aus, dass die neue
Abfragemethode für diese neun Testfälle in dieser Sitzung funktioniert. Es ist
keine Zertifizierung des NX-Kerns oder beliebiger Toleranzfälle.

`continuous_collision_free` gilt nur für den gelieferten starren mathematischen
Bewegungsentwurf, wenn alle Paare kontinuierlich durch Hüllraumtrennung oder
konstante relative Lage abgedeckt sind. Zugelassener Kontakt bleibt als solcher
sichtbar. Bewegte Kandidatenpaare ohne kontinuierlichen Hüllraumbeweis behalten
`unsampled_variable_pairs` und verhindern einen vollständigen Nachweis.

Es wird kein exakter Mindestabstand und kein Durchdringungsvolumen berechnet.
Bei überlappenden AABBs und getrennten Körpern ist ein geforderter positiver
Abstand offen. Keine engen Passungen, Fertigungsgenauigkeit, Schraubenkraft,
Montagezugänglichkeit oder Z-Absturzsicherung aus dieser Klassifikation ableiten.

## Weiter offene nächste Schritte

Reale Schnittstellenaufnahme aus NX plus Messwerte der Maschine; belegte
Kugelmuttern-/Lagerzeichnungen und Lieferausführungen; Einpassung der Achsmodule;
Lager-/Kupplungs-/Wellenendenketten; vollständige kinematische Abdeckung und
Fertigungszeichnungen mit Werkstoff, Toleranzen und Freigabestatus.

Die Programmentwicklung dieses Schritts wurde mit 303 Offline-Tests überprüft.
Die neue native Aufrufkette ist hier nicht ausgeführt worden. Sämtliche
`.prt`-Dateien entstehen erst bei einem erfolgreichen Lauf in Siemens NX.
