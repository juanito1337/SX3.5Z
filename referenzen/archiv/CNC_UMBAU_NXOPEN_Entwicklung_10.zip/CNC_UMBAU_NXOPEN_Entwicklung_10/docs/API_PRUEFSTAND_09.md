# API-Prüfstand Entwicklung09

Ziel: NX2406, eingebettetes Python3.10. **Keine NX-Laufzeit beim Autor.**

Die neue Geometrie verwendet die bereits im Projekt enthaltenen Adapter für
Expressions, Zylinder, booleschen Abzug, MeasureManager-Volumen, UF-Begrenzungen,
NewDisplay/Save und AddComponent. Es wurde keine neue NX-Klasse oder unbekannte
Methodensignatur für diese Stufe eingeführt. Das ist keine Zusicherung, dass die
vorhandenen Adapter bereits in NX erfolgreich geprüft wurden.

`NX_22_Kugelgewindetriebe_Katalog.py` hat drei Arten von Nachweisen:

| Ebene | Tatsächliche Aussage |
|---|---|
| Reine Python-Tests | Katalogverknüpfungen, analytische Volumina, Längenkette, Dateischutz und Codeablauf geprüft. |
| Simulierte NX-Schnittstellen | Fehlerpfade, Wiederherstellung, Reihenfolge der Teil-/Baugruppenaufbauten, Stückzahlen geprüft. Keine NX-Kernelprüfung. |
| Live-NX-Prüfungen im Journal | Erst bei dessen erfolgreicher Ausführung: gemessene Volumina und Außenbegrenzungen,12 Parameterproben,9 axiale Proben und tatsächliche Vorkommniszählung. |

Vorgeschaltete Matrixkalibrierung und temporäre Posen verwenden vorhandene
`FindOccurrence`, `AskBoundingBoxExact`, `SetUndoMark`, `UndoToMark` und
`DeleteUndoMark`-Adapter. Die aktuelle Bindung wird in `NX_API_Befund.json`
protokolliert. Ein nicht verfügbarer oder fehlgeschlagener Messpfad bricht ab.
Es gibt keinen Ersatz durch eine andere CAD-Engine und kein erfolgreiches
NX-Ergebnis aus rein analytischen Werten.

Die vollständige offizielle NX2406-Webdokumentation war im Projekt nicht nutzbar.
Deshalb stammen keine neuen nicht belegten Aufrufe aus einer vermuteten Web-API.
Benannte Ausdrücke und einfache Features bleiben über den vorhandenen Ansatz
implementiert; Parameterwerte und Körper werden beim Anwenderlauf geprüft.

Farben werden pro Körper nach bestehendem Palette-Ansatz gesetzt. Schlägt dies
fehl, steht ein Warnhinweis im Teilebericht; eine tatsächliche Farbdarstellung ist
nicht offline nachgewiesen. Geometriefehler werden dagegen nicht übersprungen.

Keine neuen Fertigungszeichnungen, STEP-Exportdateien oder Maschinen-Kollisions-
nachweise werden durch Journal22 behauptet. Die in der Referenz verwendete
Darstellungsbohrung darf insbesondere nicht als Kontaktgeometrie dienen.
