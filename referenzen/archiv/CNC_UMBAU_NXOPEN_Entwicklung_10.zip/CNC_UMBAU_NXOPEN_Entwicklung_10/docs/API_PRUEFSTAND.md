> Historischer Stand Analyse 01, unveränderte Grundlage. Für Konzept 02 gelten KONZEPT_02.md und QUELLEN_02.md; keine neuen Freigaben aus diesem Dokument ableiten.

# NX Open – Beleglage und Prüfstand

## Kein behaupteter NX-Test

Die Skripte dieser Lieferung wurden nicht in Siemens NX ausgeführt. Lokal war
keine NX-Open-Laufzeit verfügbar; die Integrationssuche ergab keine nutzbare
NX-Verbindung. Normales Python und simulierte NX-Objekte beweisen keine
Kompatibilität mit NX2406, keine Parasolid-Geometrie und keine native Dateierzeugung.
Es wird keine .prt als angeblich erzeugtes Ergebnis geliefert.

## Herkunft der Aufrufe

- `Parts.NewDisplay(..., NXOpen.Part.Units.Millimeters)`, Prüfung gegen
  `NXOpen.BasePart.Units.Millimeters`, `ComponentAssembly.AddComponent`,
  `Component.GetPosition`, `BasePart.Save` und die korrekten Save-Enums folgen den
  Aufrufen des bisherigen Projekts. Im vom Nutzer übermittelten v4.4-Protokoll
  bestand der dortige Teil-/Speicher-/Komponentenvortest. **Das ist kein Test der
  neu geschriebenen Module.**
- `CreateCylinderBuilder(Feature.Null)` und
  `CreateBooleanBuilder(BooleanFeature.Null)` entsprechen den vorherigen
  NX-Adaptern; die neue Referenzhülsenroutine muss selbst in NX bestehen.
- Der bevorzugte Volumenweg `MeasureManager.NewMassProperties` ist aus v4.6/v4.8
  übernommen. Kein Einsatz einer anderen CAD-Engine als angeblicher NX-Ersatz.
- Neue Audit-Lesezugriffe und UF-Gruppierungen sind in dieser konkreten Installation
  noch nicht getestet. Verfügbarkeit und tatsächliche Laufzeit-Docstrings werden
  in `NX_API_Befund.json` erfasst. Fehlende Daten erzeugen `PARTIAL`, nicht „bestanden“.

## Offizielle Web-Dokumentation

Zugriffsversuche auf Siemens-Dokumentations-/Supportportale und den früheren
öffentlichen NX-Python-Referenzbereich lieferten in dieser Sitzung keinen nutzbaren
NX2406-Referenztext. Deshalb wird **keine unabhängige offizielle NX2406-Web-Verifikation
aller neuen Aufrufe behauptet**. Zugriffspunkte:

- https://docs.sw.siemens.com/en-US/product/209349590
- https://support.sw.siemens.com/en-US/product/209349590
- https://docs.plm.automation.siemens.com/data_services/resources/nx/10/nx_api/en_US/custom/nxopen_python_ref/NXOpen.Assemblies.Component.html

Der letzte Pfad ist eine alte Versionsreferenz, kein Ersatz für2406. Bei einem
Signaturfehler ist die tatsächlich installierte Siemens-Hilfe/aufgezeichnetes Journal
und der Laufzeitbefund maßgeblich. Kein ähnlich klingender API-Aufruf wird zur
Fehlerunterdrückung erfunden. Aufrufe, die nicht verfügbar sind, bleiben fehlgeschlagen.

## Unterscheidung der Testergebnisse

| Ebene | In dieser Lieferung |
|---|---|
| ZIP-/Dateiinhalt, SHA256, Quellenvarianten | Lokal tatsächlich geprüft. |
| Python-Numerik, Fehlerstatus, Dateischutz | Offline-Tests tatsächlich ausgeführt. |
| Audit mit simulierten NX-Objekten | Nur Kontrollfluss; kein Siemens-Test. |
| Python-3.10-Syntax | Statisch geprüft; nicht gleich Laufzeittest. |
| Native Konstruktion der Referenzhülsen | Code vorhanden; tatsächlicher NX-Lauf ausstehend. |
| Neuer Projektcontainer in NX | Code vorhanden; tatsächlicher NX-Lauf ausstehend. |
| Reale SX-Baugruppe auslesen | Journal vorhanden; Benutzerausführung ausstehend. |
| Finale CNC-Achsen, Kollisionen, Verfahrwege | Nicht konstruiert / nicht geprüft. |

## Grenzen der Aufnahme

`GetPosition` wird roh mit Parentpfad exportiert. Ohne abgeglichenen
Koordinatenbezug wird keine „globale“ Achslage behauptet. `AskFaceData` liest
Prototypflächen; die Art einer Schnittstelle wird nicht aus einem Radius geraten.
Keine automatische Erkennung von Passungen oder Gewindetoleranzen aus B-Rep-Flächen.
Ein gespeichertes CAD-Modell beweist zudem nicht seine Maßübereinstimmung mit der
realen Maschine. Auf Dateiebene werden Original-Hashes vor/nach Lesen kontrolliert.

Nicht implementiert: Teamcenter, Batch-Laden nicht geladener Originale, CAM,
WAVE-Abhängigkeiten, Zwangsbedingungen, geschlossene Bewegungsprüfung, universeller
STEP-/Zeichnungsexport. Die Projektstruktur enthält keine leeren Fake-Implementierungen
für diese Aufgaben.
