# API-Prüfstand Entwicklung10

Kein NXOpen-Modul und keine NX-Laufzeit in der Autorenumgebung vorhanden.
Ziel: NX2406 / Python3.10. Keine erfolgreiche native Ausführung behauptet.

Neu ist die Orchestrierung, nicht eine zusätzliche CAD-API-Familie. Verwendet werden:

| Pfad | Wiederverwendeter Adapter | Stand |
|---|---|---|
| Neues Teil / Millimeter / WCS / Save | cnc_nx/native.py | implementiert, hier nicht in NX ausgeführt |
| Block/Zylinder/Boolean/Ausdrucksänderung | cnc_nx/parts02.py + build03.py | vorhandene Methoden, neue Rezeptklasse |
| Volumen | MeasureManager.NewMassProperties | vorhandener Adapter, kein neuer Aufruf |
| Einbau / Position / FindOccurrence | cnc_nx/build03.py | vorhandene Matrixkalibrierung |
| Vorkommnisbegrenzung | UF AskBoundingBoxExact | vorhandener Adapter |
| Zylinder- und Planflächendaten | UF AskFaceData / Body.GetFaces | vorhandener Audit-/08-Adapter |
| Stückliste | cnc_nx/bom07.py | unveränderter Reader |

Die lokale Testsuite verwendet an diesen Grenzen ausdrücklich nachgebildete Objekte.
Sie prüft Programmfluss, Datenvalidierung und Rückstell-/Abbruchverhalten, **nicht**
NX-Geometrie, Lizenzverfügbarkeit, native Speicherung oder Funktionssignaturen im
NX2406-Python-Binding. API-Präsenz wird im echten Lauf protokolliert. Eine unlesbare
Fläche oder fehlende Funktion darf nicht durch synthetische Messwerte ersetzt werden.
