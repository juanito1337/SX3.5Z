# API-Prüfstand Entwicklung08

Ziel: Siemens NX2406 / mitgeliefertes NX-Open-Python3.10.
Kein NX-Modul und keine Siemens-Laufzeit beim Autor. Keine neue native .prt erzeugt.

Neue Logik verwendet schon im Projekt vorhandene API-Familien:
- Component.GetChildren, Prototype, GetPosition, FindOccurrence;
- Part.PartUnits, IsFullyLoaded, IsModified, FullPath und Bodies;
- Body.GetFaces und Face.JournalIdentifier;
- vorhandene UF-Gruppensuche für AskFaceData und AskBoundingBoxExact;
- bestehender nativer Motorträgeraufbau und bestehende Speicher-/Volumenprüfungen.

Es wurden keine zusätzlichen NX-Factorynamen erfunden. Die neuen Kombinationen
sind dennoch nicht durch einen erfolgreichen NX-Lauf bestätigt.
UF-Flächencodes16/22 und der Sieben-Werte-Parser werden unverändert aus dem
vorhandenen Audit-/Schnittstellenpfad wiederverwendet. Keine stille Ersatzmessung.
Fehlende oder mehrdeutige Flächen bzw. unerwartete Rückgaben stoppen die Zuordnung.

Die offizielle Siemens-Onlinereferenz wurde erneut angefragt:
https://docs.sw.siemens.com/en-US/product/209349590/doc/PL20230425446868577.nxopen_python_ref/html/NXOpen.UF.Modl.html
Zugriff nicht möglich; auch die zugehörige Suche lieferte keinen verwertbaren
Primärbeleg. Deshalb keine behauptete vollständige Online-Verifikation für2406.
Verfügbare Python-Methoden/Deklarationen protokolliert ApiEvidence im Zielsystem.
Verfügbarkeit oder Docstring ist kein Nachweis eines erfolgreichen Funktionsaufrufs.

Offline-Tests ersetzen weder die Siemens-Python-Bindung noch den NX-Geometriekern.
