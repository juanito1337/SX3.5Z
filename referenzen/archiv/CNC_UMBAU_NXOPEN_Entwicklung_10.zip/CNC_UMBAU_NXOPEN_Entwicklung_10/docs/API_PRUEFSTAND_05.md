# API-Prüfstand — Entwicklung 05

## Ziel und tatsächlicher Stand

Ziel: NX 2406 / NX-Open-Python 3.10. Beim Autor ist `NXOpen` nicht importierbar.
101 Projekt-Pythondateien wurden mit Python-3.10-Grammatik geparst; 303 Tests
liefen offline. Dies ersetzt keinen Siemens-NX-Lauf.

## Wiederverwendete Wege

NewDisplay / NewParts-Speicherschutz, Number-Ausdrücke, Block/Zylinder/Boolean,
MeasureManager-Volumen, UF AskBoundingBoxExact, AddComponent und FindOccurrence
werden aus den vorhandenen Projektbausteinen übernommen. Das ist keine neue
Bestätigung ihrer fehlerfreien Kombination in diesem Projekt05-Journal.

## Neuer optionaler Weg — nicht als verifiziert ausgeben

Kandidat: `UF.<verfügbare Modl-Gruppe>.CheckInterference(targ, numTools, tools)`.
Die offizielle NX-Python-Webreferenz war beim Zugriff nicht abrufbar:

https://docs.sw.siemens.com/documentation/external/PL20230425446868577/en-US/nx_api/nxopen_python_ref/NXOpen.UF.Modl.html

Deshalb wird der Kandidat **nur** aufgerufen, wenn die tatsächlich installierte
NX-Python-Methode vorhanden ist und ihre eingebettete Dokumentation genau die
implementierte Drei-Argument-Form ausweist. Fehlt sie oder hat sie eine andere
Signatur, wird kein alternativer geratenener Aufruf versucht.

Erwartete Rückgabeform: Array mit genau einem Ganzzahlcode für ein Werkzeug.
Die Bedeutung der Codes ist **nicht** fest einprogrammiert. Neun geometrisch
bestimmte native Fälle, je vorwärts/rückwärts, müssen eindeutig drei Zustände
abdecken. Unbekannte, nicht symmetrische oder uneinheitliche Codes führen zum
Abbruch. Messung der platzierten Körpergrenzen ist Teil der Testkette.

Diese Laufzeitsperren verringern Fehlinterpretationen; sie beweisen nicht schon
vor dem ersten NX-Lauf die Kompatibilität. Insbesondere bleiben die Verfügbarkeit
der Methode und ihre Unterstützung von Körpervorkommen unbestätigt.

## Temporäre Vorkommen

`Session.SetUndoMark`, `UndoToMark` und `DeleteUndoMark` müssen vorhanden sein,
bevor temporäre Körpervorkommen angelegt werden. Nur eine leere, vom aktuellen
NewParts-Owner erzeugte Prüfassembly ist zulässig. Nach Undo muss ihre Kindliste
wieder leer sein. Fehler beim Cleanup sind fatal.

Die Tests dazu simulieren die Python-NX-Grenzen. Sie sind keine Undo-Tests in NX.
Ein Speicheraufruf wird ausschließlich auf eigenen Diagnose-/Prüfteilen ausgeführt.
Originalprototypen werden weder bearbeitet noch gespeichert.

## Ergebnisbezeichnungen

`native_execution: true` wird nur von den NX-Einstiegspunkten während deren
Ausführung geschrieben. Der mitgelieferte Offline-Prüfbericht trägt
`author_native_execution: false`. Ein gefälschtes fremdes JSON ist damit nicht
kryptographisch als Siemens-Ausführung attestiert; die Hashes binden unveränderte
Projektquellen, nicht die Identität einer Laufzeit oder die reale Maschine.

## Nicht implementiert

Exakter stetiger Kollisionssolver für bewegte Kandidatenpaare; Distanzsolver;
Drehachsen; Flexkörper; fertigungstechnische oder funktionale Sicherheitsprüfung.
Kein fehlender Nachweis wird in einen positiven Abschluss umbenannt.

## Kaufteil-Recherchegrenze dieser Revision

Die Produktzugänge von isel (Ø16-Spindel) und THK (Support Units) wurden
geprüft. Vollständige Anschlusszeichnungen bzw. Original-CAD wurden dabei
nicht nutzbar beschafft. Daraus sind keine neuen Kaufteilgeometrien entstanden.
Die offene Kaufteilauswahl wird nicht durch die Diagnosekörper ersetzt.
