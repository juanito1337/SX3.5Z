# Quellenregister – Konzept 02

Stand: 27.10.2026. Kein Nachweis von Lagerbestand, Preisen oder Maschinenpassung. Keine Hersteller-CAD-Datei heruntergeladen/validiert.

## U1 – Nutzeranforderungen

353 Zeilen; Vorgabe Siemens NX/NXOpen, Originalschutz, reale Kaufteile, Mesa 7i95T

Quelle: reference/NUTZERANFORDERUNGEN.txt

Status: USER_REQUIREMENT

## U2 – Bisherige Fotos und SX-Modellrezept

Fotorekonstruktion, kein Vermessungsnachweis; native Originaldateien/Audit nicht in diesem Paket

Quelle: reference/Vorheriges_Rezept_Analyse.json

Status: USER_CONTEXT_AND_PREVIOUS_ANALYSIS

## U3 – BF20-Archivvergleich

Referenzkonzept, Alt/Neu getrennt, keine automatische Uebertragung auf SX3.5Z

Quelle: docs/ARCHIVVERGLEICH.md

Status: UPLOADED_REFERENCE_ANALYSIS

## M1 – Mesa 7i95T Manual V1.2

Beschreibung und Connector-Tafeln; TB3/TB5/TB6 visuell kontrolliert, gedruckte Seiten 10/12/13

Quelle: https://www.mesanet.com/pdf/parallel/7i95tman.pdf

Status: MANUFACTURER

## M2 – Leadshine CS-M22326

2.6 Nm Haltemoment, 104 mm, Welle 8 mm, Pilot 38.1 mm; keine numerische Kennlinie oder Bohrbild uebernommen

Quelle: https://www.leadshine.com/product-detail/closed-loop-stepper-drive/closed-loop-stepper/CS-M22326.html

Status: MANUFACTURER

## M3 – Leadshine CS-D508

Step/Dir, 20-50 VDC, bis 8 A, zugeordneter Motor CS-M22326; konkrete Betriebskombination ungeprueft

Quelle: https://www.leadshine.com/product-detail/CS-D508.html

Status: MANUFACTURER

## M4 – isel Kugelgewindespindel Durchmesser 16 mm

Steigungen 4 und 5 mm unter anderen; kundenspezifische Enden; Mutter/Bestellkonfiguration offen

Quelle: https://www.isel.com/produkte/kugelgewindespindel-oe16-mm

Status: MANUFACTURER

## M5 – isel Kugelgewindespindel Durchmesser 20 mm

Steigung 5 mm unter anderen; kundenspezifische Enden; Z-Kandidat nicht freigegeben

Quelle: https://www.isel.com/produkte/kugelgewindespindel-oe20-mm

Status: MANUFACTURER

## M6 – THK Support Units

Festlager EK/BK/FK und Abstuetzungsfamilien EF/BF/FF; keine konkrete Groesse bestaetigt

Quelle: https://www.thk.com/eu/en/products/ball_screw/support_unit/

Status: MANUFACTURER

## M7 – KTR Servokupplungen

ROTEX GS und TOOLFLEX Familien; keine Nabenbohrung/Groesse festgelegt

Quelle: https://www.ktr.com/de/de/produkte/spielfreie-servokupplungen-wellenkupplungen/

Status: MANUFACTURER

## M8 – THK Ball Screw Handling Precautions

Ausrichtung, Steifigkeit, Schutz, Schmierung, vertikale Haltesicherung

Quelle: https://www.thk.com/eu/en/products/ball_screw/precautions/

Status: MANUFACTURER

## M9 – Mesa 7i83 Manual

Optionaler Analogausgangskandidat; kein Nachweis der Eignung fuer Originalregler

Quelle: https://www.mesanet.com/pdf/parallel/7i83man.pdf

Status: MANUFACTURER

## L1 – LinuxCNC hm2_eth

Ethernet-Anbindung und Echtzeitkontext; eigene kabelgebundene Schnittstelle

Quelle: https://linuxcnc.org/docs/stable/html/man/man9/hm2_eth.9.html

Status: OFFICIAL_SOFTWARE_DOC

## L2 – LinuxCNC Spindle Control

Analogsollwert/PWM und Synchronisationsrueckmeldung; keine Aussage ueber XMT-Regler

Quelle: https://linuxcnc.org/docs/stable/html/examples/spindle.html

Status: OFFICIAL_SOFTWARE_DOC

## L3 – LinuxCNC HostMot2

Firmwareabhaengige I/O und Stepgen/Encoder; Laufzeitnamen erst aus realem Befund

Quelle: https://linuxcnc.org/docs/stable/html/man/man9/hostmot2.9.html

Status: OFFICIAL_SOFTWARE_DOC

## L4 – LinuxCNC Homing Configuration

Referenzsequenz, Schalter und Index

Quelle: https://linuxcnc.org/docs/stable/html/config/ini-homing.html

Status: OFFICIAL_SOFTWARE_DOC

## L5 – LinuxCNC INI Configuration

JOINT-/AXIS-Konfiguration, Laengeneinheiten und Grenzwerte

Quelle: https://linuxcnc.org/docs/stable/html/config/ini-config.html

Status: OFFICIAL_SOFTWARE_DOC

## N1 – Siemens NX2406 Python API Reference – Zugriffsversuch

Onlineinhalt in dieser Sitzung nicht zugaenglich; KEIN offizieller Versionsnachweis fuer neue Aufrufe

Quelle: https://support.industrysoftware.automation.siemens.com/docs/nx/nx_api/nx/2406/nx_api_python_ref/index.html

Status: UNAVAILABLE

## N2 – Fruehere reale NX-Protokolle des Nutzers

Belegen einzelne Ausdrucks-, Feature-, Save- und AddComponent-Aufrufe im damaligen Lauf, NICHT neue Journale insgesamt

Quelle: conversation: NX_Fehlerprotokoll(2).txt / (3).txt / (4).txt

Status: USER_RUNTIME_EVIDENCE

## D1 – Bearbeiterentwurf Konzept 02

Vorzugsarchitektur, Rechenszenarien, Teilemuster und noch offene Schnittstellen

Quelle: docs/KONZEPT_02.md

Status: DESIGN_PROPOSAL

