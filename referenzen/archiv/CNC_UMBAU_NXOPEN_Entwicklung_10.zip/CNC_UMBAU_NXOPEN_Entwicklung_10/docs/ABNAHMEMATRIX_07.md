# Abnahmematrix Entwicklung07
| Anforderung | Aktueller Stand |
|---|---|
| Native parametrische Modell-/Baugruppenerzeugung | bisheriger Code enthalten, neue Leser; kein Autor-NX-Lauf |
| Wirkliche SX3.5Z-Schnittstellen und Endbaugruppe | weiterhin offen, keine neuen Maschinenmaße |
| Kaufteilquellen | bisheriges Register; keine neue Kaufteilwahl/Hersteller-CAD-Beschaffung |
| Stückliste aus nativen Vorkommen | Journal18 implementiert, live noch nicht ausgeführt |
| Mengenprüfung am Referenzaufbau | Journal19 implementiert; 4 Prototypen/7 Vorkommen erwartet |
| Bezug Modellstand zu Zeichnung/Kaufteil | Pfad-/SHA256-Prüfung und Eingabeschema implementiert |
| Sofort sichtbare Stückliste | Rezeptvorschau erstellt, kein NX-Istnachweis |
| Kauf-/Fertigungsfreigabe | nicht erteilt, aus Stückzahl niemals ableitbar |
| Kollisions-/Verfahrwegprüfung | unveränderter Code aus Entwicklung05; kein neuer Prüfnachweis |
| Fertigungszeichnungen | unveränderter Entwurfsstand06, Material/Passungen usw. offen |
| Endabnahme laut Prompt | NICHT ERFÜLLT |
