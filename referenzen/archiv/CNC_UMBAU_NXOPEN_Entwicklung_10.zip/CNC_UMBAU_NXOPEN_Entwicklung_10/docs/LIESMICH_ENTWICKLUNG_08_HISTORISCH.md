# SX3.5Z CNC-Umbau — Entwicklung 08

**Neuer Baustein: messbare Referenz-Schnittstellen und ein modellstandgebundenes
Prüfdossier.** Grundlage: Prompt Abschnitte 8, 10 und 11G. Vollständiges Projekt
inklusive Journale 01–19, neue Journale 20/21. Ziel: NX2406 / NX-Open-Python3.10.

**Kein tatsächlicher Siemens-NX-Lauf beim Autor. Keine hier erzeugten `.prt`-Dateien.**
Keine neue Maschinengeometrie, kein neuer Kaufteilsatz, keine finale CNC-Baugruppe.
Geometrien, Herstellerreferenzen und Entwurfsmaße der bisherigen Teile bleiben gleich.

## 1. Direkt startbarer Referenzlauf

ZIP vollständig in einen **neuen Ordner** entpacken. Nicht mit alten Versionen mischen.
In NX: **Journal wiedergeben / Play Journal → `NX_21_Motortraeger_Prueflauf.py`**.
Es muss keine Originalmaschine geöffnet sein; zusätzliche Maschinenmaße sind nicht nötig.

Bei erfolgreicher Ausführung:
1. Bestehende native Motorträger-Referenz aufbauen: vier unterschiedliche Teile,
   sieben Vorkommen (Motor, zwei Platten, vier Distanzhülsen).
2. Reale gespeicherte Teile/Vorkommen, Dateistände und Positionen lesen.
3. Tatsächliche Zylinder-/Planflächendaten lesen, nicht Geometrie aus einer Zeichnung
   oder einem Rezept als Messung ausgeben.
4. **23 Modell-Schnittstellenprüfungen** auswerten: 13 Achs-/Lochbildvergleiche,
   ein nominaler Durchmesserspalt, neun axiale Anlagen.
5. Aktuelle Stückliste mit den erwarteten Mengen vergleichen.
6. Quellen nochmals prüfen, Prüfdossier exportieren und Abschlussdatei schreiben.

Der nominelle Durchmesserspalt zwischen Motorbund und Plattenöffnung ist 0,2 mm;
das ist ein Entwurfswert aus der bestehenden Referenz, keine bestätigte Passung.
Die numerischen Modellprüfgrenzen (0,01 mm Versatz/Anlagenabstand, 0,01 Grad,
0,005 mm Durchmesserabweichung) sind **keine Fertigungstoleranzen**.

**`INCOMPLETE_NO_RELEASE` ist auch bei bestandenen Referenzprüfungen korrekt.**
Die vollständige Maschine, Kaufteilauswahl, Kollisionsfreiheit, Verfahrwege und
Sicherheit sind damit nicht nachgewiesen. Bei Abweichungen lautet der Status
`BLOCKED`; „Journal beendet“ bedeutet nicht automatisch „alle Prüfungen bestanden“.

## 2. Eine vorhandene Baugruppe nur lesen

Gespeicherte, vollständig geladene Millimeter-Hauptbaugruppe anzeigen; ungespeicherte
Änderungen zuerst selbst prüfen. Dann **`NX_20_Pruefdossier.py`** ausführen.

Dieses Journal lädt oder speichert keine Originalteile, verschiebt nichts und
ändert keine Unterdrückung. Es erzeugt eine aktuelle Stückliste und bindet die
Beobachtung an Dateihashes sowie die gelesene Vorkommniskonfiguration/Rohpositionen.
Ohne passende Zusatzberichte bleibt die geometrische Prüfung `NOT_RUN`.

Für optionale Nachweise `config/dossier08.json` ergänzen. Beispielstruktur:

```json
{
  "schema": "SX35Z_DOSSIER_JOB_8",
  "artifacts": [
    {
      "role": "native_geometry",
      "path": "C:\\NX_Daten\\Lauf\\NX_Motortraeger_Referenz.json",
      "sha256": "HIER_DIE_TATSAECHLICHE_64_STELLIGE_DATEIPRUEFSUMME"
    }
  ]
}
```

Das Beispiel ist **keine ausführbare Konfiguration**. Die mitgelieferte Datei hat
absichtlich eine leere `artifacts`-Liste. Journal21 füllt seinen Lauf automatisch.
Zulässige Rollen: `native_geometry`, `interfaces`, `bom`, `drawings`, `step`,
`collision_selftest`, `travel`. Es gibt keine Suche nach „ähnlichen“ Dateinamen.

Die Artikelzuordnung bleibt in `config/bom07.json`. Eigene geprüfte Zuordnungen aus
älteren Ordnern bewusst übernehmen; nicht mit einer leeren Vorlage überschreiben.

## 3. Ausgabe

Standard: `%LOCALAPPDATA%\SX35Z_CNC\Projekt08\<Zeitstempel>_<Modus>_<Kennung>\`
Ein ausdrücklich eingetragener absoluter `output_root` in `config/project.json` gilt
weiterhin. Dateien werden nur in neuen Ausgabeordnern angelegt.

```text
NX_Pruefaufnahme_08.json                  zuerst gelesener Bestand + Rohpositionen
NX_Pruefaufnahme_08_nachher.json          Kontrolle nach allen NX-Leseoperationen
NX_Pruefaufnahme_08_abschluss.json        Kontrolle nach dem Berichtsexport
Quellschutz_08.json                      Dateistand-/Vorkommnisvergleich
Quellschutz_08_Abschluss.json            abschließender Quellschutz
NX_Schnittstellen_08.json                nur Journal21: echte Flächendaten + Auswertung
NX_Stueckliste_07.json / BOM/             aktuelle gezählte Stückliste
PRUEFDOSSIER/
  Pruefdossier_08.html / .json
  Pruefmatrix_08.csv
  Schnittstellen_Messwerte_08.csv
  Nachweisdateien_08.csv
  Export_SHA256_08.json
NX_Pruefdossier_08.json                  erst nach vollständigem Lauf/Quellschutz
NX_Protokoll.txt / NX_API_Befund.json
LAUFSTATUS.json oder LAUF_FEHLER.json
```

Journal21 ergänzt `NX_PARTS`, `NX_ASSEMBLY`, den bestehenden Motorträgerbericht und
`Referenzzuordnung_08.json`. Bei einem Abbruch bleiben Zwischenberichte zur Diagnose
liegen. **Ein HTML-Zwischenstand ohne `NX_Pruefdossier_08.json` und ohne bestandenen
abschließenden Quellschutz ist kein vollständig beendeter Lauf.**

## 4. Was ein Nachweis hier bedeutet

- Dateihashes prüfen Identität, nicht Echtheit oder fachliche Richtigkeit eines Berichts.
- Ein Volumen-/Parameternachweis gilt für die gebundenen Einzelteile, nicht automatisch
  für eine vollständige Baugruppe oder Maschine.
- Die neuen Schnittstellenprüfungen gelten nur für die explizite Motorträger-Referenz.
  Sie bestätigen weder eine ausgewählte Kupplung noch Spindel-/Lageranschlüsse.
- Diagnosekörper aus Journal15 sind kein Kollisionsnachweis für diese Zielbaugruppe.
- Der alte Verfahrwegbericht05 hat keinen vollständigen Baugruppen-Fingerabdruck und
  bleibt im neuen Dossier **informational/ungebunden**; sein Inhalt wird nicht gelöscht,
  aber auch nicht rückwirkend zu einem aktuellen Maschinennachweis aufgewertet.
- Zeichnungsentwürfe bleiben Entwürfe. STEP ohne Rückleseprüfung bleibt ungeprüft importierbar.
- Die aktuelle Stückliste zählt Modellvorkommen, keine nicht modellierten Kabel/Schrauben.
- Erneutes Speichern kann einen Dateihash ändern; ein alter Nachweis ist dann erneut zu prüfen.

## 5. Offline-Vorschau / erneute Auswertung

```text
python Projekt08_Pruefdossier.py --preview --output "C:\NX_Daten\Neuer_Pruefplan"
python Projekt08_Pruefdossier.py --snapshot "C:\NX_Daten\Lauf\NX_Pruefaufnahme_08.json" --config "C:\NX_Daten\dossier08.json" --output "C:\NX_Daten\Neue_Auswertung"
```

Ausgabeordner muss absolut und neu sein. `--config` beim Replay optional.
Die ältere Aufnahme07 enthält keine vollständigen Rohpositionen und wird nicht einfach
umetikettiert. Offline-Replay ist kein neuer NX-Testlauf; die referenzierten Dateien
müssen unverändert zugänglich sein. Die beiliegende Vorschau zeigt nur den Prüfplan:
**keine bestandenen NX-Messungen und keine fiktiven nativen Dateien**.

## 6. Nächster produktiver Anschluss

Für echte Maschinengeometrie bleibt der vorhandene Audit01 notwendig. Die
maschinenbezogenen Eingaben fehlen hier weiterhin. Diesen Mangel behebt auch ein
vollständig grüner Motorträger-Referenztest nicht. Details: `docs/ENTWICKLUNG_08.md`.
