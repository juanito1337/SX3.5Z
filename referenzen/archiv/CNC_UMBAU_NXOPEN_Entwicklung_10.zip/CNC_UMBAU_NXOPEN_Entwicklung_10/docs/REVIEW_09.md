# Abschlussprüfung Entwicklung09

Autoren-Selbstprüfung; kein unabhängiger Reviewer, keine separate Subagent-Prüfung.
Kein Siemens NX verfügbar. Prüfgegenstand sind Quellcode, Quelldaten, nominale
Geometrieverträge, Ablaufgrenzen und Offline-Ausgaben.

## Stärken

Die vorangegangenen Rezeptdaten bleiben unverändert. Neue Fälle trennen Artikel,
Steigung und Außenhülle. Nicht bestätigte Innenmaße und Maschinenanschlüsse werden
nicht als Herstellerangaben ausgegeben. Parameteränderungen werden vor dem
Speichern zurückgestellt. Temporäre Baugruppenposen sind lauf-eigen und werden
zurückgenommen. Dateibindung/Mengen werden vor dem Abschluss erneut gelesen.

## Behobene Befunde

1. Die erste Schleifenfassung erzeugte zwischen den Lageproben bereits eine neue
   Unterbaugruppe. Damit war die temporäre Prüfbaugruppe nicht mehr das aktuelle
   Teil. Ein konservativer simulierter Ablauf-Test reproduziert diese Abweichung.
   Jetzt laufen alle neun Posen vor dem Erzeugen der verbleibenden Baugruppen.
2. Der Berichtexport erwartete Reserven im aufgelösten Paar, obwohl diese zunächst
   nur im Eingang lagen. Die geprüften Reserven werden nun explizit weitergereicht.
3. Fester HTML-Text „10 mm pro Ende“ wäre bei geänderter Studienkonfiguration
   falsch. Ein fehlgeschlagener Test zeigte dies; Text und Tabelle verwenden nun
   die tatsächlichen Reserven, die Standardanleitung nennt weiterhin ihre Defaults.
4. Der erste Bestandsschutz-Hilfslauf verwendete einen relativen Basispfad und
   fand dadurch null Vergleichsdateien. Es wurde nichts daraus als bestandener
   Bestandsschutz abgeleitet. Der finale Lauf erzwingt ein vorhandenes Basispaket
   und mehr als20 Vergleichsdateien:30 Dateien bytegleich plus identisches
   Ausgaberezept des vorhandenen Motorträgers.

## Offene wichtige Grenzen

Hersteller-PDF nur als Texttabellen lesbar, keine visuelle Zeichnungsbestätigung.
Hersteller-STEP nicht beschafft. Kein nativer NX-Kernel-/API-Lauf. Keine realen
Kugelkontaktflächen, Endenbearbeitung, Lagerung, Klemmung oder Maschinenmontage.
Keine Massen-, Tragfähigkeits-, Drehzahl-, Knick- oder Sicherheitsfreigabe.
Die neue Parameter-/Probenlogik verwendet vorhandene NX-Adapter ohne neue Methoden,
aber auch deren konkretes Zusammenspiel bedarf eines Live-Laufs.

## Nicht als Fehler dieser Stufe gewertet

Die geringe Detaillierung ist expliziter Umfang der nominalen Katalogreferenzen,
kein behauptetes Originalmodell. Der fehlende Spindel-Bestellcode bleibt offen;
der Standardrohling ist keine Maschinenbestellung. Der generische04-Mutterträger
bleibt unverändert und ausdrücklich nicht für die Rundmutter freigegeben.
Die Referenzaufstellung ist bewusst nicht in Maschinenkoordinaten montiert.

## Bewertung

Als abgegrenztes Quellcode-/Referenzpaket nach den Offline-Tests bereitgestellt.
Nicht als in NX bestätigte Konstruktion oder finale CNC-Maschine akzeptiert.
