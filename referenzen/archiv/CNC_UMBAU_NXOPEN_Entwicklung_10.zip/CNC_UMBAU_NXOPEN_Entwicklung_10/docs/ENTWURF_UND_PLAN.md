> Historischer Stand Analyse 01, unveränderte Grundlage. Für Konzept 02 gelten KONZEPT_02.md und QUELLEN_02.md; keine neuen Freigaben aus diesem Dokument ableiten.

# CNC-Umbau – Entwurf und Implementierungsplan, Analyse 01

## Verbindliche Grundlage
Nutzeranforderungen in Eingefügter Text(7).txt, BF20_alt.zip, BF20_neu.zip;
vorheriges SX3.5Z-Journalpaket v4.8 nur als ausdrücklich angenäherte Referenz.
Zielsystem: Siemens NX 2406, NX Open Python 3.10. Keine alternative CAD-Engine.
Originaldateien unverändert. Keine endgültige CNC-Konstruktion mit ungeprüften Maßen.

## Ausgangslage
Keines der beiden BF20-Archive enthält .prt-Dateien oder 3D-Austauschmodelle.
Im verfügbaren Arbeitsbestand wurde keine native .prt gefunden.
Daher sind tatsächliche Hierarchie, Features, Bearbeitungszustand und Einbaulagen
nicht aus einer NX-Datei geprüft. Python-Rezeptanalyse ist etwas anderes.

## Entscheidung für diese Lieferung
Ein unmittelbarer CNC-Endaufbau aus den BF20-Maßen würde die Anforderung an die
Originalmaschine verletzen. Eine erneute Erzeugung der Fotoannäherung ersetzt
ebenfalls keine Schnittstellenprüfung. Gewählt wird ein lesender NX-Audit als
verbindlicher erster Schritt, plus ein separater, ausdrücklich nicht fertiger
Projektcontainer und parametrische, aus Zeichnungen belegte BF20-Referenzhülsen.
Kein universeller Vollautomaten-CNC-Umbau wird behauptet.

## Komponenten
- cnc_nx/audit.py: ausschließlich lesende NX-Bestandsaufnahme; Rohpositionen,
  Prototype-Koordinaten, WCS, Ausdrücke, Features, Körper, Flächentypen,
  zugängliche UF-Flächendaten, Dateifingerprints; Fehler => PARTIAL.
- cnc_nx/runtime.py: ausschließlich lokale, neue Ausgabeordner; Protokoll.
- cnc_nx/reference.py: neuer Referenzcontainer mit genau einer bestehenden
  Maschinenbaugruppe; keine Unterdrückung/Änderung der Originalhierarchie.
- cnc_nx/spacers.py: sechs klar benannte native Referenzhülsen nach BF20 alt/neu;
  keine Montage an der SX3.5Z, keine allgemeine Fertigungsfreigabe.
- cnc_nx/core.py: rein numerische Prüfungen, Größen, Quellenstatus.
- cnc_nx/gates.py: fehlende Nachweise je X/Y/Z explizit auflisten; niemals
  Freigabe aus Fotoannahmen oder leeren Prüfprotokollen ableiten.
- docs/: Archivvergleich, Kaufteilrecherche, API-/Prüfstand und Abnahmematrix.

## Prüfreihenfolge
1. Tests schreiben: Archivtrennung, Hülsenmaße, Negativ-/NaN-Werte,
   unbestätigte Achsdaten, Rohmatrizen, Dateischutz, Auditfehler.
2. Fehlerlauf vor Implementierung beobachten.
3. Reine Python-Logik und lesenden NX-Adapter implementieren.
4. Referenzcontainer und Referenzhülsen über bekannte NX-Klassen vorbereiten;
   tatsächliche Methoden verfügbar/Docstrings erfassen, kein NX-Test vorgeben.
5. Alle Offline-Tests und Python-3.10-Syntaxprüfung ausführen; keine CAD-
   Volumenprüfung mit anderer Engine. Native Volumenprüfung erst in NX.
6. ZIP auf vollständige Module, Daten und unveränderte Quellen prüfen.

## Nicht Bestandteil dieser Stufe
Fertige FRAESMASCHINE_CNC_UMBAU.prt, fertige X/Y/Z-Montagen, Kollisionsfreigabe,
Verfahrwegfreigabe, Zeichnungsfreigabe, finale Einkaufsliste, Elektro-/Sicherheits-
freigabe, tatsächliche NX-Ausführung. Diese Ergebnisse dürfen erst nach den
jeweiligen Nachweisen entstehen. Keine leeren Module als fertige Funktion tarnen.
