# SX3.5Z CNC-Umbau — Entwicklung 05

**Nächster umgesetzter Teil von Prompt-Abschnitt 8: Verfahrweg- und Körperprüfung.**
Zielumgebung: Siemens NX 2406, dessen NX-Open-Python 3.10. Das vollständige Projekt
enthält weiterhin die Journale 01–14. Es ersetzt nicht das ursprüngliche v4.x-Modell.

**Kein NX-Lauf beim Autor. Keine mitgelieferten nativen `.prt`, keine freigegebene
CNC-Maschine und keine Fertigungs- oder Sicherheitsfreigabe.** Die neuen
NX-Aufrufpfade müssen in deiner Installation bestehen. Offline-Tests sind keine
Siemens-NX-Tests.

## Direkt startbarer nächster Schritt

1. Dieses ZIP vollständig in einen **neuen** Ordner entpacken.
2. In NX: **Journal wiedergeben / Play Journal → `NX_15_Kollisionstest.py`**.
3. Ergebnis im Listing Window und im neuen Ausgabeordner lesen.

Dafür sind keine Maschinenmaße und keine geöffnete Originalbaugruppe erforderlich.
Das Journal erzeugt ausschließlich neue **Diagnosekörper**: Würfel, durchbohrter
Block und Stift. Es sind keine Kaufteile und keine Teile deiner Maschine.

Es prüft neun Konstellationen: getrennt, berührend, überlappend, deckungsgleich,
Stift frei in einer Bohrung, Stift mit Bohrungswandüberschneidung sowie drei gedrehte
Konstellationen. Jede Abfrage erfolgt in beiden Reihenfolgen, also 18 Abfragen.
Vorher wird die NX-Matrixkonvention mit dem bestehenden geometrischen Test bestimmt.

**Eine unbekannte API oder uneindeutige Klassifikation führt zum Abbruch**, nicht
zu einer Freigabe. Der neue UF-Aufruf wird nur versucht, wenn die eingebettete
Python-Methodendokumentation in deinem NX zur implementierten Signatur passt.
Die Bedeutung numerischer Rückgaben wird erst durch die tatsächlichen Prüfkörper
festgelegt; sie ist nicht als feste Zahlentabelle angenommen.

Bei Erfolg entstehen drei Diagnose-Einzelteile und eine Diagnosebaugruppe mit
sechs Vorkommen. Die bestehenden Matrixproben erzeugen zusätzliche Testteile.
Der Bericht `NX_Kollisionstest_05.json` nennt den tatsächlichen Baugruppenpfad.

## Ausgabe

Standardmäßig:

```text
%LOCALAPPDATA%\SX35Z_CNC\Projekt05\<Zeitstempel>_<Modus>_<Kennung>\
```

Ein anderes absolutes Ausgabeziel lässt sich in `config/project.json` setzen.
Bei Fehlern: `NX_Protokoll.txt`, `NX_API_Befund.json`, `LAUF_FEHLER.json` lesen.
Diese Berichte werden nicht als bestanden ausgegeben, wenn ein Aufruf fehlt.

## Tatsächliche Maschinen-/Entwurfsbaugruppe prüfen

`NX_16_Verfahrwegpruefung.py` braucht den Bericht **`NX_Montageentwurf.json` aus
einem erfolgreichen Journal-10-Lauf**. Der bloße ursprüngliche Bestandsaudit
ist hierfür noch nicht die freigegebene Bewegungszuordnung.

Eine Eingabevorlage lässt sich mit gewöhnlichem Python erzeugen:

```text
python Projekt05_Pruefung_vorbereiten.py --layout "C:\NX_Daten\NX_Montageentwurf.json" --output "C:\NX_Daten\travel05_review.json"
```

Beide Pfade müssen absolut sein. Die Ausgabedatei darf noch nicht existieren.
Die Vorlage übernimmt Bauteilpfade, Hashes, Orientierungen und Referenzpositionen,
aber **keine geratenen Bewegungsrichtungen oder Endlagen**.

Anschließend fachlich prüfen und vervollständigen:

- Achsrichtung als Einheitsvektor im Baugruppenkoordinatensystem, Minimum,
  Maximum und Referenzposition in mm; Bezug/Nachweis unter `evidence`.
- Pro Vorkommen `moving_axes`: `[]` bedeutet fest, `null` bedeutet unbekannt
  und wird zurückgewiesen. Mehrere Einträge beschreiben gemeinsame Bewegung,
  etwa die X-/Y-Mitnahme. Die Namen selbst lösen keine automatische Zuordnung aus.
- Prüfpunktzahl und Rechenbudget; Mindestabstand. Bewusste Kontaktpaare nur mit
  Begründung. Ein erwarteter Kontakt erlaubt **keine Volumendurchdringung**.
- Erst nach der tatsächlichen Prüfung `review.status` auf `KINEMATICS_REVIEWED`
  setzen und die Begründung ergänzen. Das ist keine Bestätigung physischer Maße.

Die überprüfte Vorlage als `config/travel05.json` im **neuen** Projektordner
ablegen. Diese Konfiguration ist beim Ausliefern absichtlich nicht ausführbar.
Keine unbestätigten Maschinenmaße werden vorbesetzt.

Danach in NX `NX_16_Verfahrwegpruefung.py` starten. Bei fünf Punkten pro Achse
und auf dem Raster liegendem Referenzpunkt ergeben sich 125 XYZ-Kombinationen.
Ein Referenzpunkt außerhalb des Rasters wird zusätzlich aufgenommen.
Die standardmäßige Grenze von 100.000 Paar-/Pose-Auswertungen kann bei großen
Baugruppen erreicht werden; dann stoppt der Lauf statt Teile wegzulassen.

## Was das Ergebnis bedeutet

| Ergebnis | Aussage |
|---|---|
| `INTERFERENCE` | Kalibrierter NX-Körpervergleich meldet Durchdringung an dieser Pose. |
| `UNREVIEWED_CONTACT` / `CONTACT_VIOLATES_CLEARANCE` | Kontakt erfordert Prüfung bzw. verletzt den geforderten Abstand. |
| `SEPARATE_GAP_UNVERIFIED` | Körper getrennt, geforderter Mindestabstand jedoch nicht nachgewiesen. |
| `NO_ISSUE_IN_EVALUATED_SAMPLES` | Nur bei den tatsächlich ausgewerteten Stichproben kein Problem. **Kein Vollhubnachweis.** |
| `continuous_collision_free: true` | Nur innerhalb des ausdrücklich angegebenen Starrkörper-Translationsmodells: jedes Paar durch Intervall-Hüllraumtrennung oder unveränderte relative Lage gedeckt. Keine Aussage über die reale Maschine. |

Ein Hüllquader ist ein konservativer Umraum. Überlappende Hüllquader beweisen
keine Kollision; deshalb gibt es die NX-Körperabfrage. Für einen positiven
Mindestabstand reicht eine getrennte Klassifikation allein ebenfalls nicht.
Es wird **kein numerischer exakter Mindestabstand** berechnet.

Bei bewegten Kandidatenpaaren ist der Bereich zwischen den Stichproben offen,
sofern nicht die konservative Intervallprüfung Trennung über den gesamten
konfigurierten Bereich beweist. Gemeinsame Bewegungen werden bei diesem Beweis
als Relativbewegung korrekt herausgerechnet. Zulässige Kontakte werden gesondert
geführt; Kontaktbegründungen beziehen sich auf Komponentenpaare, nicht einzelne Flächen.

## Schutz der Originale

Originalvorkommen werden nicht verschoben, unterdrückt oder gespeichert.
Prüfposen entstehen in einer **neuen, leeren, lauf-eigenen** NX-Baugruppe und
werden nach jeder Pose per Undo entfernt. Scheitert die Rücknahme, stoppt der
Lauf. Datei-Hashes und Änderungszustand der geladenen Prototypen werden auch bei
Fehlern kontrolliert; kein automatischer Reparatur- oder Speicherversuch.

`NX_Verfahrwegpruefung_05.json` entsteht erst nach vollständiger Pose-Auswertung
und erfolgreichem Quellschutz. `NX_Verfahrweg_Fortschritt_05.json` allein ist
**kein** positiver Prüfbericht. `Posen/Pose_*.json` enthält Einzelergebnisse.

## Grenzen

Keine Drehachsen, keine elastischen Verformungen, Kabel-/Balgbewegungen, dynamischen
Anhaltewege, Lager-/Halterfestigkeit oder funktionale Sicherheit. Keine Überprüfung
der tatsächlichen Maschinenmaße. Keine Kollisionen zwischen mehreren Körpern
innerhalb desselben Einzelteils; geprüft werden Körper verschiedener Vorkommen.
Flächenkörper werden zurückgewiesen statt stillschweigend ausgelassen.
Die unbestätigten Kaufteil- und Maschinenanschlüsse aus Entwicklung 04 bleiben offen.

## Offline prüfen

```text
python -m unittest discover -s tests -v
```

303 Tests; mathematische und Softwaretests, teilweise mit simulierten
NX-Grenzen. Kein alternativer CAD-Kern, kein ausgeführter NX-Geometrieaufbau.
Details: `docs/ENTWICKLUNG_05.md`, `docs/API_PRUEFSTAND_05.md`,
`reports/Pruefbericht_Entwicklung_05.json`.

`reports/RED_*.txt` sind absichtlich fehlschlagende historische Teststände aus der
Entwicklung. Den aktuellen Gesamtstand dokumentiert `reports/Tests_Entwicklung_05.txt`.
