# CNC-Umbau — Entwicklung 09

**Neu: herstellerbezogene Kugelgewinde-Rundmuttern, Spindelrohlinge und axiale Längenplanung.**
Siemens NX2406 + NX Open Python3.10. Kein Ersatz-CAD-System. Kein NX-Lauf beim Autor.

## Direkt in NX starten

Das vollständige ZIP in einen **neuen Ordner** entpacken. In NX:

**Journal wiedergeben / Play Journal → `NX_22_Kugelgewindetriebe_Katalog.py`**

Keine geöffnete Originalmaschine nötig. Die Dateien des Pakets zusammen belassen.
Der Standardlauf erzeugt bei Erfolg sechs native parametrische Referenzteile,
drei Paar-Unterbaugruppen und eine Übersicht. Zusätzlich sind zwölf temporäre
Parameterprüfungen, neun axiale Lageproben und eine tatsächliche Stückzählung
implementiert. Alle diese NX-Nachweise stehen bis zu deinem Lauf aus.

| Katalogfall | isel-Rundmutter | Nominelle Außenmaße der Mutter |
|---|---|---|
| 16×4 | 213514 | Ø28×50 mm |
| 16×5 | 213505 | Ø28×50 mm |
| 20×5 | 213420 0005 | Ø33×50 mm |

**Vereinfachte Außenhüllen, kein Original-Hersteller-CAD.** Kugellaufbahnen,
Endenbearbeitung, Lagerung und Klemmung fehlen. Die innere Mutterbohrung ist nur
Darstellung und KEIN bestätigtes Herstellermaß. Keine Massen-/Kontaktprüfung.
Die Paarungen sind Studienvarianten, keine automatisch zugeordneten X-/Y-/Z-Achsen.
Der bisherige Flanschmutter-Halter ist nicht für diese Rundmuttern freigegeben.

## Ausgabe

```
%LOCALAPPDATA%\SX35Z_CNC\Projekt09\<Zeitstempel>_ballscrew09_<Kennung>\
```

Dort liegen `NX_PARTS`, `NX_ASSEMBLY`, Stücklisten, Teile-/Lageprüfberichte,
`NX_Kugelgewinde_Referenzen_09.json`, `Quellschutz_09.json` und NX-Protokolle.
Nur der vollständig durchgelaufene Bericht zeigt die erfolgreiche native
Referenzerzeugung; er bestätigt **keine Maschinenpassung oder Bestellfreigabe**.
Bei Fehlern werden erzeugte Zwischenstände nicht als vollständig deklariert.

## Einstellungen

`config/ballscrews09.json`: Rohlängen, Reserven, Muttermitten und gewünschter
axialer Bereich. Rohlängen müssen in den dokumentierten Katalograstern liegen.
Standard:352/352/252 mm, Mutterlänge50 mm, Reserve je10 mm. Daraus berechnet:
282/282/182 mm axialer Hüllbereich — **nicht Maschinenverfahrweg**.
Diese Längen sind keine vorgeschlagenen Bestelllängen deiner Fräse.
`reference/Quellen_09.json` dokumentiert Katalogstand, Quelle und Datenlücken.

## Sofort lesbar, ohne NX

Öffne `reports/09_Kugelgewinde/Katalogreferenz_Vorschau/Kugelgewinde_09.html`.
Neuberechnung ausschließlich als Bericht:

```
python Projekt09_Kugelgewindebericht.py
```

Das erzeugt JSON/CSV/HTML, keine CAD-Dateien. Vorhandene Ziele bleiben unberührt.

## Enthalten und unverändert

Alle bisherigen Journale01–21 bleiben enthalten. Maschinen-/Referenzgeometrien
bis Entwicklung08 sind unverändert. Neue globale Standardausgabe ist Projekt09.
Frühere Anleitungen und Prüfberichte bleiben als historischer Entwicklungsstand
enthalten; maßgeblich für die Ergänzungen sind `docs/ENTWICKLUNG_09.md`,
`docs/API_PRUEFSTAND_09.md` und der neue Prüfbericht.

## Prüf- und Abnahmestand

Offline-Tests und Python3.10-Grammatikprüfung sind im Prüfbericht dokumentiert.
Keine `.prt`-Dateien sind hier entstanden. Keine Hersteller-STEP-Datei beschafft;
Daten aus Hersteller-Texttabellen, zugehörige Zeichnungsbilder nicht verfügbar.
Keine fertige CNC-Achse, kein vollständiger Festigkeits-/Sicherheitsnachweis und
keine fertige `FRAESMASCHINE_CNC_UMBAU.prt`. Die Endabnahme des Nutzerprompts bleibt offen.
