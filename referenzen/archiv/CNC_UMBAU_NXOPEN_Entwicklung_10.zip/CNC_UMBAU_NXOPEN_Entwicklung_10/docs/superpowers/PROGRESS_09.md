# SDD ledger — plan: docs/superpowers/plans/2026-10-27-entwicklung-09-plan.md

Isolated copy of supplied08, local Git branch development09; originals untouched.
Baseline: python -m pytest -q -> 561 passed,40 subtests passed,4.61s.
Ruling: user explicitly asked to continue; execute scoped next CAD task without
additional brainstorming approvals. Manufacturer-STEP preferred but unavailable;
select permitted nominal replacement route, not fake original geometry.
Pre-flight: T1 catalogue/interval schema consumed by T2 recipes and T3 journal.
T2 recipes consumed by existing RecipeBuilder => register explicit kind/volume probe.
T3 placement uses old measured calibration, no new undocumented NX API calls.
Ruling: no new CAD engine; pure analytical checks only offline. Standalone reference
poses are study coordinates, never asserted actual machine coordinates.

T1 complete: first run absent module => expected failures (T1_RED.txt). Targeted
suite31passed8subtests. Full suite592passed48subtests. Registry locks three real
nut codes and raw-stock ranges; mismatched diameter/pitch, unknown ends, invalid
input rejected. Catalogue manufacturing details not inferred from unreadable drawings.

T2 complete:21 failing tests before module;21 passed after implementation.
Full suite613passed48subtests. Six part recipes/three paired local-frame studies.
Ruling: represent only sourced exterior and a clearly marked visual bore; no
invented support/bearing/finished-ends. Nominal volumes may test CAD, never physical mass.

T3 complete: native adapter parameter probes, live file/BOM binding, grouped
local assemblies and three axial envelope samples per pair implemented. Review
found potential current-part hazard while switching retained assemblies during
scratch probes. Failing conservative coordinator test reproduced the hazard;
all nine scratch poses now precede the retained assembly loop. No extra NX API
added. 24 targeted simulated-seam/control-flow tests pass, full637passed48subtests.
Ruling: simulations validate orchestration/error behavior, NOT NX geometry or
method compatibility. No live NX execution claimed. Scratch persists empty and
unsaved; only run-owned objects can be written. Gallery hash checked after BOM.

T4 implementation: strict offline JSON/CSV/HTML export, CLI, source and setup docs.
13 initial report failures before implementation; tests exposed missing explicit
reserve fields in resolved pair schema. Preserve reviewed input reserves in the
resolved record (not a silent zero/default). Report green. Review test found fixed
10mm prose would be wrong for edited cases; replaced with actual reserve columns.
14 targeted report tests pass; full suite651passed48subtests;147 files parse under
Python3.10 grammar. HTML locally rendered and visually checked (not a 3D preview).
Ruling: report is an analytical/source preview, never NX measurement or CAD export.

Final review: self-review (no subagent tool), docs/REVIEW_09.md. No unresolved
critical code finding in scoped offline implementation. Live NX and source drawing
verification remain explicitly outside demonstrated evidence, not silently passed.
Full pytest651+48subtests and unittest651 green;147 Python3.10 grammar checks.
Package/fresh-extraction verification is the remaining T4 gate.

T4 complete: first freshly extracted ZIP passed651tests48subtests and all file
hashes. Final packaging reruns those checks after this ledger change; its exact
ZIP digest/file count is in the external Entwicklung_09_ZIP_Pruefung.json.
Original08 archive is unchanged. No native NX run or manufacturer STEP obtained.
