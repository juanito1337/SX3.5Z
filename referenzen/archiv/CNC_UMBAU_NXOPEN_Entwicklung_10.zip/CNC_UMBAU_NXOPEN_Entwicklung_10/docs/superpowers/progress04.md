# SDD ledger — plan: docs/superpowers/plans/2026-10-27-entwicklung-04-plan.md
Baseline isolated copy from zip; git branch development04-stepped-housings. Original zip unchanged.
Baseline: python -m unittest discover -s tests => 154 tests PASS.
No subagent tool; independent-author review impossible. Separate self-review planned.
Ruling: next point = native nut/bearing housing geometry; no new user machine audit supplied.
Ruling: supplier drawings unavailable via web, no manufacturer surrogate with guessed dimensions.
Use own clearly labeled design parameters and a supplied BF20 drawing reference, not SX fit.
Pre-flight: recipe04->recipe03 dispatcher->NX builder->axis module must share validation path;
expected volumes must be recomputed after parameter edits, not scaled as through-hole plates.
Task1 complete: 20 RED -> 20 GREEN (housing04 contract). Exact analytical stepped-volume schedule,
minimum webs, nonfinite/boolean rejection, canonical formula checks and probe plan.
Task2 complete: 8 native-integration seam tests; complete suite182 PASS. Native execution not performed.
Existing axis manifests use origin_mm/rotation, not alternative local_* names; corrected test fixture.
T3 finding before shipping: initial OWN nut-carrier draft64x64 gave 0.5mm outer edge margin
at x/y26 with D11 head recess, below configured1mm threshold. Reproduced in10 catalogue tests.
Ruling: increase only own carrier outline to66x66 (1.5mm margin), keep measured BF20 dimensions
unchanged and do not relax geometric threshold. Failed run saved RED_catalogue_dimensions04.
Task3 complete: 12 catalogue/report tests, native journal14, independent4-part layout,
01..13 preserved; source table and own design values separated. Suite194 PASS before review.
Final review finding: shared identity matrix in library layouts could mutate other occurrences/
next calls. Red regression reproduced; each occurrence now gets an independent copy.
Review suite6 PASS; full suite200 PASS. This is author self-review, no independent reviewer/NX run.

Task4: source suite200 PASS,83 Python source files accepted by Python3.10 grammar.
Offline report command executed successfully; no CAD geometry created by that command.
NXOpen import specification absent in this runtime; no native execution claimed.
Final review: self-review (no subagent tool). See docs/REVIEW_04.md.
Delivery: keep isolated local development branch; do not merge/push any user branch.
Ship full ZIP; no original machine or source archive writes. Archive tests follow separately.
