# SDD ledger — plan: docs/superpowers/plans/2026-10-27-entwicklung-08-plan.md
Baseline: development07 safely extracted into independent development08 workspace.
Baseline command: python -m unittest discover -s tests => 472 tests, OK.
Ruling: next point is prompt 11G/8, not another guessed machine component.
Ruling: no native NX runtime or subagent tool; offline tests and separate author self-review.
Ruling: use existing GetFaces/AskFaceData path, no alternate CAD system.
Official NX web lookup attempted; the Siemens reference was inaccessible. No official
NX2406 online-verification claim. Embedded runtime declarations logged by existing adapter.
Pre-flight: same saved parts feed BOM and inspection; inventory fingerprint must remain
identical before/after. Old drawing build makes distinct files: do not mark as current.
T1 complete: 24 new geometric contract tests failed on absent implementation, then passed.
T2 complete: 36 dossier/export tests failed on absent modules, then passed.
T3 complete: 18 native-boundary/pipeline tests failed before implementation, then passed.
Review: 8 additional guard/CLI regressions first failed, then passed; 3 document/race
regressions likewise RED/GREEN. Full suite exposed stale test imports after existing
module-invalidation tests: patch now targets the executing module instance. Not a
production suppression of a failure. Full suite now 561 tests, OK.
Ruling: legacy travel05 lacks complete assembly/source fingerprint. It is retained as
informational only, never promoted to current machine collision/travel success.
T4 complete: 561 offline tests OK; 136 Python files parse using Python3.10 grammar.
13 recipe/generator/prompt files compared byte-for-byte with original07 ZIP: unchanged.
HTML plan preview rendered using system Chromium and inspected visually; no horizontal
overflow at 1440px. Default Playwright executable/file URL unavailable; set_content
rendered the generated HTML itself. No alternative CAD or fake native file produced.
Final review: self-review (no subagent tool); findings and limits in docs/REVIEW_08.md.
Distribution prepared as a fresh full ZIP, not a mutation of the user's old package.
