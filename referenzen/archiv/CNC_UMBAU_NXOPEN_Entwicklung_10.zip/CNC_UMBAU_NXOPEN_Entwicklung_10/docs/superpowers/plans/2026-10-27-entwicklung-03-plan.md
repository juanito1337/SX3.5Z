# Entwicklung 03 Implementation Plan
Goal: Implement a real native motor-carrier reference assembly, reusable NX parts recipes,
reviewed-data axis generation, component placement, STEP import/export and engineering prechecks.
Architecture: Extend Concept02, native CAD only in NX; pure Python contracts and tests outside NX.
Spec: reference/NUTZERANFORDERUNGEN.txt and approved Konzept02. User requested continuous implementation.
Constraints: Python3.10; Siemens NX2406; no source saves; no claims of runtime NX validation;
unknown machine interfaces remain null, no final manufacturing assembly.
Review focus: coordinate conventions; duplicate source references; unsigned file substitution;
motor catalogue revision conflict; missing or failed checks never PASS.

- [x] Task1 RED/GREEN: manufacturer variant data, motor-carrier recipes and analytic validation.
- [x] Task2 RED/GREEN: native recipe adapter and measured placement calibration; standalone reference build.
- [x] Task3 RED/GREEN: reviewed manifests for X/Y/Z construction, selective original reuse and STEP exchange.
- [x] Task4 RED/GREEN: audit face-derived reference frames and conservative clearance screening.
- [x] Task5 full suite, Python3.10 grammar, self-review, source/ZIP hashes and detailed acceptance table.

Rulings: No NX runtime present. No subagent tool: author self-review only.
Research: motor manufacturer PDF p4 documents CS-M22326 L103, current page L104; keep revision-specific.
