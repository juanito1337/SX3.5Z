# Entwicklung 05 Implementation Plan

**Goal:** Read-only, evidence-gated multi-position travel inspection in native NX; do not create another assumed machine.
**Architecture:** Pure fixed-orientation translation model and conservative whole-range AABB proof; runtime-help-gated NX interference classifier calibrated on real solids; temporary, rollback-only inspection assemblies. Reuse existing NewParts, matrix calibration, source hashes and measurement paths. No alternate CAD kernel.
**Tech Stack:** NX2406/Python3.10 in target runtime; stdlib/unittest offline.
**Spec:** reference/NUTZERANFORDERUNGEN.txt (sections 5, 8, 10); docs/superpowers/specs/2026-10-27-entwicklung-05.md.

Global constraints: no original write; no guessed machine axes or limits; no native-execution claim without NX; no fabricated manufacturer geometry; all previous entry points retained.

Review focus: shared X/Y translations cancel in relative motion; collisions between samples must not be declared absent; unknown NX integer results fail closed; Undo errors stop; incomplete/changed source inventory stops.

- [x] T1 RED/GREEN: reviewed motion schema, source inventory binding, transforms, continuous AABB separation, finite pose sets and reports.
- [x] T2 RED/GREEN: inspect NX Python method declaration before any candidate CheckInterference call; calibrate separated/contact/intersecting cases, reversed calls, hollow-body case.
- [x] T3 RED/GREEN: native collision test journal and sweep journal, original-file guards, rollback and partial reports; input preparation tool.
- [x] T4 full regression, independent self-review pass, Python3.10 grammar, fresh extracted ZIP tests, source hashes and honest documentation.
