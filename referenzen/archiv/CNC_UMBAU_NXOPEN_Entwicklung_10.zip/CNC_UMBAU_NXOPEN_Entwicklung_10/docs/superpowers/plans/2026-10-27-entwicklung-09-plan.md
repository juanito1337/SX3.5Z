# Entwicklung09 Implementation Plan

**Goal:** Native, catalogue-grounded screw/nut reference pairs plus axial sizing.
**Architecture:** source table registry, pure contracts/recipes, existing NX adapter,
reference assembly, reproducible reports. All final-machine claims remain gated.
**Tech Stack:** NX2406 Python3.10 target; stdlib/unittest offline. No other CAD system.
**Spec:** ../specs/2026-10-27-entwicklung-09-spec.md and reference/NUTZERANFORDERUNGEN.txt

## Global constraints
Never overwrite originals. Exact machine coordinates absent => no machine montage.
Source nominal envelope distinct from visual nut bore, selected stock length and
study margins. Native measurements only after actual NX execution. Source PDFs and
CAD bytes not locally obtained: no fake checksum or screenshot verification.

## Review focus
Mismatched pitch/diameter; invented manufacturer code; end-loss/travel off-by-half;
unsupported catalogue variants; overwritten outputs; geometry/source drift; repeated
invocation; part recipe/assembly position disagreement; false full machine approval.

- [x] T1 RED/GREEN: engineering/ballscrew09.py, config/ballscrews09.json,
  reference/Quellen_09.json; validate catalogue tuples and interval math. Test negative
  inputs, mixed sources, oversized requested stroke and incomplete machined ends.
- [x] T2 RED/GREEN: construction/ballscrew09.py; strict two envelope recipes;
  origin at shaft start / nut body start; 3 cases,6 parts, separate assembly frames.
  Register new recipe type in existing validation/parameter paths without source changes.
- [x] T3 RED/GREEN: cnc_nx/ballscrew09.py, journal22; build all parts natively,
  volume/bounds/parameter probes, measured occurrence bounds, actual identities,
  catalogue/read-only source guards, no pretend native results. Use existing API only.
- [x] T4: reports/CLI, docs; full tests, Python3.10 grammar, author review; package,
  hashes, fresh extraction and full suite. Record unsupported NX checks explicitly.
