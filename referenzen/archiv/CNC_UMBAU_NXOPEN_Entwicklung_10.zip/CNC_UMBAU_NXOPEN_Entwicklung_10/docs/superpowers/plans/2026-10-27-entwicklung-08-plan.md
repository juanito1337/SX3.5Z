# Entwicklung08 Implementation Plan

**Goal:** Messbare Referenz-Schnittstellen und ein modellstandgebundenes Prüfdossier.
**Architecture:** pure geometry/evidence contracts + narrow existing NX readers + exports;
reuse live reference build/BOM; source snapshots before/after all read-only work.
**Tech Stack:** NX2406 Python3.10 in target; unittest/std library offline.
**Spec:** ../specs/2026-10-27-entwicklung-08-spec.md; reference/NUTZERANFORDERUNGEN.txt.

Constraints: no original saves, no fake native measurement, no model source changes,
no fabrication release, no implicit audit/geometry selection by filename.
Review focus: missing/ambiguous surfaces; noncoaxial axes; stale assembly/part hashes;
diagnostic test misattribution; incomplete jobs and dirty source parts.

- [x] T1 RED/GREEN: validation/interfaces08.py, tests/test_interfaces08.py;
  actual cylinder axes/planes vs reference contract; negative measurements must fail.
- [x] T2 RED/GREEN: validation/dossier08.py, exports/dossier08.py;
  model identity, explicit report-role parsers, missing/stale/failing evidence.
- [x] T3 RED/GREEN: cnc_nx/inspection08.py and dossier08.py; journals20/21;
  actual prototype faces, current positions, original protection, no silent native skip.
- [x] T4: offline previews/CLI, source-status documentation, full suite and grammar;
  separate self-review, fresh ZIP extraction and all-file hash verification.
