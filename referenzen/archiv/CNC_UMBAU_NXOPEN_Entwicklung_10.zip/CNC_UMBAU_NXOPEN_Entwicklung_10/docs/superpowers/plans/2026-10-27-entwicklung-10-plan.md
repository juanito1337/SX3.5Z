# Entwicklung10 Implementation Plan

**Goal:** Herstellerbezogene Rundmutter-Aufnahmen an Spindelreferenzen anbinden.
**Architecture:** strikter Quellenkatalog + axiale Raumrechnung, native Rezepte,
bestehender NX-Adapter mit kleinem neuen Rezeptschema, Quellschutz und Live-BOM.
**Tech Stack:** Python3.10/NX2406; stdlib/unittest offline. Keine alternative CAD-Laufzeit.
**Spec:** ../specs/2026-10-27-entwicklung-10-spec.md; reference/NUTZERANFORDERUNGEN.txt

## Global Constraints
Originaldateien niemals speichern; keine unbekannten Maschinenmaße einfüllen.
Kataloghülle nicht als Original-CAD ausgeben. Keine neuen unbestätigten NX-Aufrufe.
Offline-Tests von NX-Geometrieausführung unterscheiden. Vorhandene Journale erhalten.

## Review Focus
Falscher Mutterdurchmesser; doppeltes Zählen gleicher Blocks; axialer Versatz;
Quelländerung; falsche Halb-Längen; Aussage zu nicht vorhandenen Fußbohrungen;
Zwischenergebnis fälschlich als Abschluss; Matrix-/Vorkommnisposition nach Rücknahme.

- [x] T1: Tests zuerst für Quellenzuordnung, Bohrungshöhe, gemeinsame axiale Hülle,
  asymmetrischen Versatz, Restwege, negative/NaN/fehlende Werte, Quelländerungen.
  Dateien: engineering/nutmount10.py, reference/Quellen_10.json, config/nutmounts10.json.
- [x] T2: Tests zuerst für Blockrezepte, analytische Volumina, symmetrische und
  asymmetrische Maße, acht Teile/neun Vorkommen, Quellschutz, Rezeptschema.
  Dateien: construction/nutmount10.py + minimale Integration in recipes03/build03.
- [x] T3: Tests zuerst für nativen Ablauf, Parameter-Restore, Einbau-Lagen/BOM,
  Quellenänderung/Falschlage/Falschmengen => kein vollständiger Ergebnisbericht.
  Dateien: cnc_nx/nutmount10.py, main.py, journal23.
- [x] T4: Reports/CLI, Dokumentation, Autoren-Selbstprüfung, volle Suite,
  Python3.10-Grammatik, Paket/Hashes, frisches Entpacken und Suite.
