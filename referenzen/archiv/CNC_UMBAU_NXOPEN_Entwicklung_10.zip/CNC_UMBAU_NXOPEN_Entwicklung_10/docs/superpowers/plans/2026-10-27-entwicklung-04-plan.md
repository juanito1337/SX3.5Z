# Entwicklung 04 Implementation Plan

**Goal:** Native parametric nut-carrier / stepped bearing-housing library, reusable in X/Y/Z.
**Architecture:** Add axial stepped-hole recipe contract and native per-step/parameter tests.
Reuse original-file guards, expressions, solid primitives and placement calibration from03.
**Spec:** reference/NUTZERANFORDERUNGEN.txt; docs/superpowers/specs/2026-10-27-entwicklung-04.md.
**Tech Stack:** stdlib Python3.10 in NX2406; unittest offline, no external CAD kernel.

Global constraints: No source writes; no invented manufacturer dimensions; no native-run claim;
final geometry only NX; actual machine interfaces remain null. No final manufacturing drawings.
Review focus: overlapping counterbores; lost shoulders; parameter dependencies;
stale expected volumes; imported OEM assumptions mistaken for machine measurements.

- [x] T1 RED/GREEN — stepped-hole schema, geometry validation, analytic operation-volume schedule.
- [x] T2 RED/GREEN — integration in native builder and axes, tests for thickness AND recess-depth change.
- [x] T3 RED/GREEN — shipped design catalogue, independent native library/assembly entry, reports and BOM.
- [x] T4 full regression, self-review, Python3.10 grammar, archive/hash validation, documentation.
