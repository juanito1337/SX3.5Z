# Konzept 02 Implementation Plan
Goal: Engineering concept plus reproducible calculators, native parametric design-part generators,
source-linked BOM and validation contracts; no synthetic final machine.
Architecture: Existing cnc_nx read-only audit remains. Pure Python engineering and geometry contracts
feed native-only part creation. Explicit review and measurement evidence separate concept from fit.
Tech: Python 3.10 stdlib in NX 2406, unittest offline, Markdown/HTML documentation.
Spec: ../specs/2026-10-27-konzept-02.md
Constraints: Do not save source parts; do not use other CAD kernels; no accepted nulls or NaN;
no false PASS for unrun NX/collision/strength; all output paths new and local by default.
Review focus: ratio convention; gravity during deceleration; reflected inertia double counting;
coordinate row/column convention; schema checks must precede native writes.
- [x] Write failing numeric and part-contract tests; run RED.
- [x] Implement sizing, frames, discrete travel and plate/hole contracts; run GREEN.
- [x] Add native part construction from expressions, standalone journals; tests on dispatch/guards.
- [x] Develop sourced mechanical/control concept, candidate register, I/O map, acceptance matrix.
- [x] Run complete offline suite, syntax/ZIP manifest checks and explicitly report NX NOT_RUN.

Execution record: implementation within the stated concept scope completed. 65 offline tests pass. No NX runtime, no manufacturer STEP import, no real machine collision/strength tests. The final CNC assembly is deliberately not generated from unverified interfaces.
