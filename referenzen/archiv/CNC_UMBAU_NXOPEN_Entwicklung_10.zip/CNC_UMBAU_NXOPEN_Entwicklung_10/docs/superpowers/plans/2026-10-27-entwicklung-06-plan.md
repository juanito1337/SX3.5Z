# Entwicklung 06 Implementation Plan

**Goal:** Deliver a reproducible nominal drawing pipeline for existing housing recipes.
**Architecture:** Validated drawing specification shared by offline previews, hole tables
and native NX drafting annotations; newly built native solids with native drawing views;
separate evidence/status for source-based previews and live NX outputs.
**Tech Stack:** Python3.10 stdlib in NX, optional ReportLab for offline previews. No alternate CAD engine.
**Spec:** reference/NUTZERANFORDERUNGEN.txt sections 9,10; ../specs/2026-10-27-entwicklung-06.md.

Constraints: no guessed tolerances/materials/threads; no original modifications;
no fabrication release; no false native execution/association claim; no output overwrite.

Review focus: front z=0 versus rear z=t; depth/remaining-shoulder chain; altered recipes
must change fingerprints; native views must not silently fail to an offline drawing;
PDF/DXF errors and skipped native execution must not be success.

- [x] T1 RED/GREEN: drawing specification, coordinate projection and section profile,
  source snapshots, missing-information status and projection extents.
- [x] T2 RED/GREEN: offline PDF/DXF and bore table output; source-based labels, exact
  2D nominal coordinates, file validation, no overwrite; inspect all preview sheets.
- [x] T3 RED/GREEN: NX journal17 on new own parts, native draft sheets/views/notes,
  native PDF export checks; native result never replaced by offline export.
- [x] T4 full suite, Python3.10 syntax, self-review, hashes and clean ZIP re-test.
