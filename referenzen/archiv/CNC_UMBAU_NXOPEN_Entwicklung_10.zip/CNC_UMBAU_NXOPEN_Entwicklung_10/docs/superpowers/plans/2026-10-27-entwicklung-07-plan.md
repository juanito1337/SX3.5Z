# Entwicklung07 Implementation Plan
> Ausführung: executing-plans, inline. Test-first. Neue isolierte ZIP-Arbeitskopie,
> keine Änderung an Nutzerdaten; keine Subagent-Laufzeit verfügbar.

**Goal:** Mengen aus realen Vorkommen samt belastbarer Dateizuordnung exportieren.
**Architecture:** Reine Auswertung von Snapshot + Registry; schmaler lesender NX-Adapter;
separate Exporte/CLI; bestehende Geometriegeneratoren unverändert.
**Tech Stack:** Python3.10-Standardbibliothek, NXOpen nur im nativen Adapter.
**Spec:** docs/superpowers/specs/2026-10-27-entwicklung-07-spec.md

## Constraints
Originale nicht speichern; fehlende Nachweise offen; keine Ersatz-CAD-Engine;
kein NX-Erfolg ohne NX-Lauf; kein Matching über Dateinamenmuster; keine Bestellung.

## Review Focus
Mehrfach verbaute Unterbaugruppe und gemeinsame Prototypen; unterdrückte/ungeladene Zweige;
Multi-Body-Teile; geänderte Modellstände/Zeichnungen; Pfad-/CSV-/HTML-Inhalte und Überschreiben.

## Tasks
- [x] 1. Tests zuerst: Hierarchie/Blattzählung/Suppressions-/Fehlerzustände, Prototypaggregation;
  Modul analysis/bom07.py ausführen und volle Suite prüfen.
- [x] 2. Tests zuerst: Hashbindung Zuordnung/Dateien/Dokumente, widersprüchliche IDs,
  offene Material-/Herstellerangaben, getrennte Kategorien; implementieren und volle Suite.
- [x] 3. Tests zuerst: read-only NX Adapter einschließlich Dateischutz/Mutation/nicht geladen;
  cnc_nx/bom07.py, Journale18/19, main routing; keine neue unbekannte NX-Methode.
- [x] 4. Tests zuerst: Exporte und Eingabevorlage/Replay/Quellschutz, HTML/CSV-Injection,
  echte Rezeptvorschau ohne native Dateien; exports/bom07.py, CLI und Beispiele.
- [x] 5. Selbstprüfung, vollständige Tests/Syntax, Dokumentation, ZIP neu entpacken und testen.
