# Scope decision — Entwicklung 05

User approved continuing the existing plan, one next point. Manufacturing and true physical
machine dimensions remain unconfirmed; no actual machine .prt set or audit was newly supplied.
The current block/step-hole generators remain unchanged. The next implementable point is
prompt section8: testing movable groups at multiple positions, with explicit unexecuted status.

Supplier research was attempted first: isel/THK CAD/catalogue downloads unavailable in this
session; HIWIN category data does not include the complete interfaces. No guessed nut flange
thickness, drilling pattern or support geometry is added. Manufacturer candidates stay separate.

Deliver a directly executable artificial NX calibration setup and a real-machine input path.
For machine testing use a prior successful NX_Montageentwurf.json and verify its hash, entire
inventory, component files, rotations and placements. A person must supply/review travel limits,
fixed axis directions and each component's moving-axis membership. Never infer these from names.
Only rigid translations with unchanged orientation are supported. Rotation/elasticity/kinematics
constraints, cable motion, cutting forces and safety functions are outside scope and reported.

At every pose: add occurrences to a newly owned empty inspection assembly, read solid bounds and
optional calibrated UF interference classifications, write a report, Undo the added occurrences.
No MoveComponent on an original, suppression or save of any source. Source hashes and modified
state must be unchanged even after errors. Native body topology testing is not a minimum-distance
measurement and not an engineering release. Positive clearance requires a sufficient conservative
AABB lower bound; otherwise retain GAP_UNVERIFIED even for separate solids. Continuous AABB
separation is proven from independent translation ranges with common motions canceled. Sampling
alone never certifies intervening travel. All failed/unexecuted checks remain explicit.
