# Entwicklung 04 — Mutterhalter und gestufte Lageraufnahmen

Fortsetzung des beauftragten Konzepts, native NX-Konstruktion, Python 3.10/NX2406.
Vorhandene Originale bleiben unberuehrt. Kein lokaler NX-Lauf wird behauptet.

Naechster abgegrenzter Schritt nach Motortraeger03: parallele axiale Durchgangsbohrungen
mit vorder-/rueckseitigen Stufen, Schultern und Schraubenkopfsenkungen in parametrisierbaren
Haltern. Neue selbststaendige Referenzbibliothek: eigener Muttern-Flanschtraeger,
eigene Lageraufnahme mit Deckel sowie vereinfachter BF20-17-Referenzhalter aus Nutzerzeichnung.
Maschineneinpassung, Kaufteilauswahl, Passungstoleranzen, Last-/Haltesicherheit NICHT freigegeben.

Alternativen: (1) komplette Achse aus Annahmen — verworfen wegen unbekannter Maschinenanschluesse;
(2) nur weitere Checklisten — kein ausreichender CAD-Fortschritt; (3) wiederverwendbare native
Halterfamilie mit transparenter Referenzgeometrie — ausgewaehlter Umsetzungsschritt des Autors.
Der Nutzer hat die weitere Umsetzung delegiert. Keine erneute Konzeptfreigabe angefordert.

Herstellerabmessungen bleiben getrennt von Eigenentwuerfen. isel-Produktseite bestaetigt
16-mm-Spindelfamilie und nominelle Endmasse, nicht eine konkrete Mutter-/Lagerpaarung.
PDF/CAD-Downloads nicht erfolgreich; THK-CAD ist mitgliedschaftspflichtig. Keine fiktiven
Kaufteilkoerper eingefuegt. BF20_neu.pdf Seite16/Zeichnung BF20-17 dient nur als
quellengebundener Testfall (43x20x19.5, 2xD6.6/D11x6.4, Abstand30; Eckfasen nicht rekonstruiert).
