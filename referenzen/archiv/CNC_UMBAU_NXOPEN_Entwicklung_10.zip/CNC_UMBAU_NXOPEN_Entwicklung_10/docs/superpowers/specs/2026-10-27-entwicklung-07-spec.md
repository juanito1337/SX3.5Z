# Entwicklung 07 – aus der Baugruppe abgeleitete Stückliste
Grundlage: reference/NUTZERANFORDERUNGEN.txt, Abschnitte 5, 6, 10 und 11F.
Auftrag: nächsten offenen Schritt des vorhandenen Projekts ausführen.

## Ziel
Tatsächlich geladene NX-Komponentenvorkommen lesend inventarisieren und nachvollziehbar
zu Einzelteilmengen, Kauf-/Fertigungs-/Bestandszuordnung, Quell- und Zeichnungsdateien verbinden.
Keine Bestell- oder Fertigungsfreigabe aus einer gezählten Stückzahl.

## Auswahl
Reine Wunschliste besteht bereits. Reine Dateizählung wäre wegen mehrfacher Vorkommen
und Unterbaugruppen falsch. Gewählt: Vorkommnisbaum + datei-/hashgebundene Zuordnung.
Neue Hersteller- oder Schnittstellenmaße werden für diesen Schritt nicht benötigt.

## Umfang
1. Native lesende Bestandsaufnahme, keine Änderungen/Save/Load an Originalen.
2. Wiederholte Unterbaugruppen zählen pro Vorkommen; Knoten nicht als Teil doppelt zählen.
3. Unterdrückte Zweige getrennt; unbekannt, unvollständig geladen, gemischte Körper/Baugruppe
   und ungespeicherte/dirty Teile führen zu Teilstatus, niemals zu stillschweigend vollständiger BOM.
4. Explizite Zuordnung über absoluten Prototyppfad und SHA256; Zeichnungsdateien ebenso
   hashgebunden an den Modellstand. Kein Matching über ähnliche Namen.
5. CSV/JSON/HTML, Vorkommnisliste, offene Punkte, separate Kauf-/Fertigungs-/Bestandsfilter.
6. Direkter Lauf auf angezeigter Baugruppe und optionaler Durchlauf mit vorhandener
   Motorträger-Referenz. Offline-Beispiele ausschließlich RECIPE_PREVIEW, keine fiktiven PRT.
7. Reproduzierbarer Quellcode, Tests, lokale Ausgabe; native Ausführung bleibt ungetestet.

## Nichtziele
Neue Maschinengeometrie, reale Maße, aktuelle Lieferbarkeit/Preise, fertige CNC-Baugruppe,
PLM-Stücklistenmengen, Massenteilmengen oder NX-Teilelistentabelle im Zeichnungsblatt.
