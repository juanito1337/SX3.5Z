# Entwicklung08 — geometrisches Prüfdossier

Fortsetzung des vom Nutzer freigegebenen Plans, Prompt Abschnitte 8, 10, 11G.
Nach der Stückliste wird ein nachvollziehbares geometrisches Prüfprotokoll ergänzt.

## Umfang
1. Aus tatsächlichen NX-Flächendaten der bestehenden Motorträger-Referenz:
   Koaxialität, Lochbildzuordnung, nomineller Durchmesserspalt und axiale Anlagen.
2. Ein Prüfdossier pro vollständig identifizierter Baugruppe: gespeicherte Dateistände,
   gelesene Vorkommen, Mengen, geometrische Prüfungen, offene Prüfkategorien.
3. Lauf 20 liest eine angezeigte Baugruppe und vorhandene Ergebnisdateien. Lauf 21 baut
   die bekannte Referenz neu, prüft sie und exportiert Stückliste plus Prüfdossier.
4. Kein zusätzlicher CAD-Kern, keine neue Maschinen- oder Kaufteilgeometrie.

## Grenzen
Kein tatsächlicher NX-Zugriff beim Autor. Neue NX-Ausführung muss auf Zielsystem bestehen.
Keine automatisch bestätigten Maschinenmaße, Lagerpassungen oder Fertigungstoleranzen.
Die Prüfgrenzen sind numerische Modellprüfgrenzen, keine ISO-Passung oder Freigabe.
Ein passender Dateihash beweist Dateiidentität, nicht Echtheit eines Prüfberichts.
Ein Kollisionstest an Diagnosekörpern gilt niemals als Maschinen-Kollisionsnachweis.
Nicht ausgeführte, alte oder nur teilweise abgedeckte Prüfungen bleiben so benannt.

## Gewählte Umsetzung
Wiederverwendung der vorhandenen GetFaces/AskFaceData-, Dateischutz- und BOM-Pfade.
Keine neuen unbekannten NX-Factorys. Berichtsschemata werden einzeln geprüft;
kein generisches „irgendwo steht PASS“ und kein Zusammenrechnen von Testerfolgen
zu einer Maschinenfreigabe. Bericht 20 darf auch ohne Zusatznachweise nützlich sein.
