# Entwicklung09: konkrete Kugelgewindetrieb-Katalogreferenzen

Grundlage: reference/NUTZERANFORDERUNGEN.txt, bestehender Stand08, Zustimmung zur
Fortsetzung des Plans. Diese Stufe schließt einen Teil der bislang offenen
Abschnitte5/6: kaufteilbezogene Geometrie statt weiterer reiner Diagnosefunktionen.

## Entscheidung / Alternativen
1. Originale Hersteller-STEP-Dateien importieren: bevorzugt; Quellenportale geprüft,
   keine verwendbaren Bytes erhalten (keine Anmeldung/Account-Aktion durchgeführt).
2. Aus belegten Herstellerdaten native vereinfachte Kaufteilreferenzen erstellen:
   gewählt. isel-Katalog April2025, Seiten6/8: Rundmuttern und unbearbeitete Spindeln.
3. Direkt die SX3.5Z-Achsen fertig montieren: abgelehnt; tatsächlicher NX-Audit und
   bestätigte Maschinenanschlüsse fehlen. Keine erfundenen Maschinenpositionen.

## Umfang und Grenzen
Drei eigenständige Paare16x4,16x5,20x5. Rundmutter außen D28x50/D33x50 nach Tabelle;
Spindel als nominale ungeschliffene Laufbahn-Hülle des angebotenen unbearbeiteten
Rohlings (kein fertig endbearbeiteter Achsantrieb). Nutinnenraum nur visualisierter
Zylinder mit nominalem Spindel-Durchmesser, KEIN belegter Mutterbohrungs-/Laufbahnwert.
Keine Kugeln/Rückführung, Vorspanneinstellschlitze, Dichtungen, Lagerenden oder
Schmieranschlüsse ausgedacht. Modell nicht für Kontakt-/Massen-/Festigkeitsnachweise.

Längenmodell getrennt: bekannte unbenutzbare Endbereiche, Muttergesamtlänge und
frei festgelegte Studien-Randabstände; unabhängig von Bezug/Drehrichtung. Für die
Rohlingsstudie Endverluste0 ausdrücklichnurRohling, nicht Lagerung0. Nur axialer
Hüllraum, nicht tatsächlich erreichbarer Maschinenhub. Kein endgültiger Bestellcode
für die Spindel aus der Tabellenformatierung konstruiert. Muttercodes aus Tabelle.

## Architektur
QuellenregisterJSON -> validierte rein numerische Katalog-/Paar-/Längenverträge ->
native Rezeptgeometrie -> gespeicherte Einzelteile -> drei separate native
Referenzbaugruppen plus Übersichts-Galerie. Vorhandene geprüfte Adapterpfade nutzen;
keine neue externe CAD-Engine oder spekulative NX-API. Tabellenbericht offline.

## Abnahme dieser Stufe
Offline-Rechen-/Negativtests + vollständige Alt-Tests; native Codewege klar als
NICHT beim Autor in NX ausgeführt markieren. No native outputs shipped. Quellschutz,
keine neuen Dateien überschreiben, Originale unverändert. Herstellerzeichnung wurde
nicht visuell geprüft (Web-PDF-Screenshot fehlgeschlagen); Tabellenlesung und
nicht erhaltene CAD-Bytes ausdrücklich dokumentieren. Keine Produktionsfreigabe.
