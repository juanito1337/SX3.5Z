# Entwicklung 06: Zeichnungsableitung, Schritt aus Abschnitt 9 des Nutzerprompts

Fortsetzung des vom Nutzer zur Umsetzung freigegebenen Projekts. Geometrien aus
Entwicklung04 bleiben unverändert; keine neue Maschinen- oder Kaufteilannahme.

Umfang: vier Nennmaß-Zeichnungsentwürfe aus den vorhandenen Halterrezepten,
mit allen Bohrungspositionen und Vorder-/Rückstufen, eindeutiger Orientierung,
Bauteilnummer, Quellenkennzeichnung, offenen Werkstoffen/Passungen/Toleranzen.
Native NX-Teile mit Drafting-Blättern und modellabgeleiteten Ansichten werden
in einem neuen, eigenen Lauf erzeugt. Native PDF-Ausgabe wird separat geprüft.
Lokale PDF-Vorschauen und DXF-Prüfkonturen entstehen direkt aus den Eingabedaten
und sind KEIN NX-Export, KEINE alternative CAD-Konstruktion und KEIN Fertigungsdatensatz.

Ansätze: (1) fertige Fertigungszeichnung trotz fehlender Spezifikation: verworfen;
(2) nur Textbericht: zu geringer Fortschritt; (3) native Nennmaßableitung mit
explizit getrennten Vorschauen und Freigabesperren: gewählter Umsetzungsschritt.
Kein Herstellerteil- oder Maschinenanschluss wird dadurch als bestätigt behandelt.
Keine native CAD-Ausführung kann hier behauptet werden. Keine Originaldatei ändern.

Grenzen: native Ansichten und tabellarische Nennmaßangaben, keine automatisch
assoziativen NX-Maßobjekte und keine native Schnittansicht zugesichert. Die lokale
Schnittskizze dient ausdrücklich nur der Erläuterung des Stufenprofils.
Maßnotizen sind ein Snapshot: nach Geometrieänderung erneut erzeugen. Im NX-Lauf
werden Eingaben mit erzeugten Ausdrücken, Volumen und Grenzen abgeglichen.
