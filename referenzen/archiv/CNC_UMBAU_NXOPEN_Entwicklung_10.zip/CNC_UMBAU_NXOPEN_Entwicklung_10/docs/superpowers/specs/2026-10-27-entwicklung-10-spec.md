# Entwicklung 10 — passende isel-Rundmutteraufnahmen

Auftrag: nächsten Konstruktionsschritt nach Entwicklung 09 ausführen. Bindende Basis:
reference/NUTZERANFORDERUNGEN.txt. Ohne echte Maschinenbezüge keine Maschinenmontage.

Ziel: reale Spannblöcke 213500 / 213600 den drei bestehenden Rundmuttern zuordnen,
native Hauptgeometrie mit Hersteller-Nennbohrung und Fußhöhe erzeugen, zu den
Spindel-/Mutterreferenzen montieren, längeren gemeinsamen axialen Raumbedarf prüfen.

Alternativen: Ein freier Eigenbau-Klemmhalter könnte die unbekannte Vorspannung
verändern; der allgemeine Flanschhalter D04 ist nicht passend nachgewiesen.
Daher Auswahl der vom selben Hersteller aufgeführten Fuß-Spannblöcke.
Keine unabhängige Bauartfreigabe. Original-CAD wurde über Katalog/Traceparts versucht,
aber nicht erhalten. PDF-Screenshot scheiterte (Cache miss); lokale PDF scheiterte
bei DNS/Download. Es werden nur eindeutig benannte Tabellengrößen verwendet.

Abgrenzung: B,H,L,M,H1 sind nominale Hauptkörperdaten. Keine Rekonstruktion von
Fußbohrungen, Schlitzen, Schrauben, Schmiernippel oder Spannmutter ohne Zeichnung.
Die axial zentrierte Mutterposition ist eine explizite Studienannahme, variierbar.
H7/h7 werden als Quellenbezeichnung erhalten; keine numerischen Toleranzgrenzen.

Ergebnis: journal23 + geteilte Quellen-/Konfigurationsdateien, 8 verschiedene
native Teile / 3 Referenzgruppen / 9 Blattvorkommen bei Standardkonfiguration;
Block16 wird mit Menge2 wiederverwendet. Keine neue herstellerechte Kontaktgeometrie.
Alle Dateien neu, Originale unberührt. Keine Fertigungs-/Bestellfreigabe.
