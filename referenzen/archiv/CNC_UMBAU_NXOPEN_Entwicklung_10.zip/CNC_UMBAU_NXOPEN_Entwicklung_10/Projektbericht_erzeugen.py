"""Run with Python 3.10+, no NX required. Never creates CAD files."""
from pathlib import Path
import argparse
from cnc_nx.runtime import create_run_directory,write_json_new
from cnc_nx.concept02 import reports

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default=str(Path(__file__).absolute().parent/'output'))
    args=parser.parse_args();out=create_run_directory(args.output,'concept02')
    result=reports(out);write_json_new(out/'LAUFSTATUS.json',result);print(out)

if __name__=='__main__':main()
