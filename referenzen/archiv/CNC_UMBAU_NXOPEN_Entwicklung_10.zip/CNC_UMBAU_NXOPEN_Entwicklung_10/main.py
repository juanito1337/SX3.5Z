# -*- coding: utf-8 -*-
"""Execute via Siemens NX > Journal > Play. Default action is READ-ONLY inventory.
No mode creates or claims the final CNC conversion. See LIESMICH.md.
"""
import importlib
import os
from pathlib import Path
import sys
import traceback

HERE=Path(os.path.abspath(__file__)).parent
if str(HERE) in sys.path:sys.path.remove(str(HERE))
sys.path.insert(0,str(HERE))


def invalidate_project_modules():
    """Reload only modules whose source belongs to this project directory."""
    names=('cnc_nx','engineering','construction','assembly','validation','exports','analysis')
    root=os.path.normcase(os.path.abspath(str(HERE)))
    for key,module in list(sys.modules.items()):
        if key.split('.')[0] not in names:continue
        source=getattr(module,'__file__',None)
        if not source:continue
        try:belongs=os.path.commonpath([root,os.path.normcase(os.path.abspath(source))])==root
        except (OSError,ValueError):belongs=False
        if not belongs:
            # Recognize earlier versions of THIS shipped project, not arbitrary third-party modules.
            source_dir=Path(os.path.abspath(source)).parent
            for candidate in (source_dir,)+tuple(source_dir.parents):
                if ((candidate/'reference'/'NUTZERANFORDERUNGEN.txt').is_file()
                        and (candidate/'config'/'project.json').is_file()):
                    belongs=True;break
        if belongs:del sys.modules[key]


def main(action='audit'):
    invalidate_project_modules()
    import NXOpen
    from cnc_nx import VERSION
    from cnc_nx.runtime import configured_output,create_run_directory,RunLog,ApiEvidence,write_json_new
    session=NXOpen.Session.GetSession()
    log=None;out=None;evidence=ApiEvidence();result=None
    try:
        names={'audit':'audit','reference':'reference','spacers':'spacers','readiness':'readiness','draft_parts':'parts02','concept':'concept02','carrier03':'build03','interfaces03':'interfaces03','axes03':'axes03','assembly03':'assembly03','import03':'exchange03','export03':'export03','screen03':'screen03','housings04':'housings04','collision05':'collision05','travel05':'travel05','drawings06':'drawings06','bom07':'bom07','bom_reference07':'bom_reference07','dossier08':'dossier08','reference_inspection08':'reference_inspection08','ballscrew09':'ballscrew09','nutmount10':'nutmount10'}
        if action not in names:raise ValueError('Unbekannter Modus: '+str(action))
        root,config=configured_output(HERE)
        out=create_run_directory(root,action)
        log=RunLog(session,out)
        log('SX3.5Z CNC-Projekt '+VERSION+' / Modus '+action)
        log('Ausgabe: '+str(out))
        log('NX-Modul: '+str(NXOpen.__file__))
        log('Keine finale CNC-Baugruppe; keine Fertigungsfreigabe.')
        module=importlib.import_module('cnc_nx.'+names[action])
        result=module.run(session,NXOpen,out,log,evidence,config)
        write_json_new(out/'LAUFSTATUS.json',{'script_finished':True,'action':action,
                      'result_status':result.get('status','EVIDENCE_REPORT_ONLY'),
                      'final_cnc_assembly_created':False,'manufacturing_released':False})
        log('Journal beendet. Inhaltlichen Status im Ergebnisbericht beachten; PARTIAL ist keine Vollstaendigkeit.')
    except Exception:
        detail=traceback.format_exc()
        if log:log(detail)
        else:
            window=session.ListingWindow;window.Open();window.WriteLine(detail)
        if out:
            write_json_new(out/'LAUF_FEHLER.json',{'script_finished':False,'action':action,
                           'traceback':detail,'final_cnc_assembly_created':False})
        try:NXOpen.UI.GetUI().NXMessageBox.Show('CNC-Projekt Entwicklung 10',NXOpen.NXMessageBox.DialogType.Error,
            'Abbruch. Protokoll im Listing Window und, falls angelegt, im neuen Ausgabeordner. Originale werden nicht gespeichert.')
        except Exception:pass
    finally:
        if out:
            try:write_json_new(out/'NX_API_Befund.json',evidence.environment(NXOpen))
            except Exception as exc:
                if log:log('API-Bericht nicht gespeichert: '+str(exc))
        if log:log.close()


if __name__=='__main__':main()
