"""Traversal/planning independent of NX; callbacks must supply calibrated states.
No function in this module claims that it executed in NX. Tests use simulated callbacks.
"""
import itertools
from .motion05 import validate,poses,translation,origin_at,shift_bounds,aabb_distance,swept_pair,classify_sample,summarize
from .geometry03 import bounds


def plan(cfg,body_rows):
    validate(cfg);components={x['id']:x for x in cfg['components']};seen=set();rows=[];covered=set()
    for row in body_rows:
        c=row['component'];i=row['body_index']
        if c not in components or isinstance(i,bool) or not isinstance(i,int) or i<0:
            raise ValueError('Unknown component/invalid solid body index')
        key=(c,i)
        if key in seen:raise ValueError('Duplicate body inventory row')
        seen.add(key);covered.add(c);rows.append(dict(row,bounds_mm=bounds(row['bounds_mm'])))
    if covered!=set(components):raise ValueError('Missing component solid coverage')
    pairs=[]
    for a,b in itertools.combinations(rows,2):
        if a['component']==b['component']:continue  # intra-part solids deliberately not included
        proof=swept_pair(cfg,components[a['component']],a['bounds_mm'],components[b['component']],b['bounds_mm'])
        pairs.append(dict(id='PAIR_%05d'%len(pairs),a=a,b=b,continuous=proof))
    qs=poses(cfg)
    if not pairs:raise ValueError('No cross-component solid pairs to inspect')
    if len(pairs)*len(qs)>cfg['max_pair_evaluations']:
        raise ValueError('Pair/pose evaluation budget exceeded before native inspection')
    return dict(pairs=pairs,poses=qs,components=components,body_count=len(rows),
                same_component_solid_pairs_checked=False,physical_machine_verified=False)


def evaluate(cfg,work,pose,query,cache):
    contacts={tuple(sorted((p['a'],p['b']))) for p in cfg['expected_contacts']}
    records=[];native_calls=0;reused=0
    for pair in work['pairs']:
        a,b=pair['a'],pair['b'];ca=work['components'][a['component']];cb=work['components'][b['component']]
        ta=translation(cfg,ca,pose);tb=translation(cfg,cb,pose)
        gap=aabb_distance(shift_bounds(a['bounds_mm'],ta),shift_bounds(b['bounds_mm'],tb))
        method=None;kernel=None
        if pair['continuous']['continuous_separation_proved']:
            status='CONTINUOUS_AABB_SEPARATION';method='INTERVAL_ENVELOPE_PROOF'
        elif gap>cfg['clearance_mm']+cfg['tolerance_mm']:
            status='AABB_SEPARATION';method='POSE_ENVELOPE_PROOF'
        else:
            # No rounding: similar but distinct relative positions must not share a result.
            oa=origin_at(cfg,ca,pose);ob=origin_at(cfg,cb,pose)
            key=(a['component'],a['body_index'],b['component'],b['body_index'],tuple(ob[k]-oa[k] for k in range(3)))
            if key in cache:kernel=cache[key];reused+=1;method='UNCHANGED_RELATIVE_GEOMETRY_CACHE'
            else:
                kernel=query((a['component'],a['body_index']),(b['component'],b['body_index']))
                if kernel not in ('SEPARATE','TOUCH','INTERSECT'):raise ValueError('Unknown/unexecuted kernel state')
                cache[key]=kernel;native_calls+=1;method='CALIBRATED_NX_BODY_QUERY'
            status=classify_sample(kernel,gap,cfg['clearance_mm'],cfg['tolerance_mm'],tuple(sorted((a['component'],b['component']))) in contacts)
        records.append(dict(pair_id=pair['id'],a=a['component'],a_body=a['body_index'],
                            b=b['component'],b_body=b['body_index'],status=status,kernel_state=kernel,
                            aabb_distance_lower_bound_mm=gap,method=method))
    return dict(pose=dict(pose),checks=records,kernel_queries=native_calls,cached_queries=reused)


def finish(work,results):
    if len(results)!=len(work['poses']) or any(r['pose']!=q for r,q in zip(results,work['poses'])):
        raise ValueError('Missing/duplicate/out-of-order pose results; no complete inspection')
    per_pair={p['id']:[] for p in work['pairs']};checks=[]
    for r in results:
        if len(r['checks'])!=len(per_pair) or {c['pair_id'] for c in r['checks']}!=set(per_pair):
            raise ValueError('Incomplete pair coverage')
        for c in r['checks']:per_pair[c['pair_id']].append(c['status']);checks.append(c)
    good={'SEPARATE','EXPECTED_CONTACT','SEPARATE_WITH_CONSERVATIVE_GAP','AABB_SEPARATION','CONTINUOUS_AABB_SEPARATION'}
    unproved=0
    for p in work['pairs']:
        proof=p['continuous'];statuses=per_pair[p['id']]
        if not proof['continuous_separation_proved'] and not (proof['relative_motion_fixed'] and set(statuses)<=good):
            unproved+=1
    result=summarize(checks,continuous_complete=(unproved==0))
    result.update(pose_count=len(results),solid_pair_count=len(work['pairs']),body_count=work['body_count'],
                  kernel_queries=sum(r['kernel_queries'] for r in results),cached_queries=sum(r['cached_queries'] for r in results),
                  unsampled_variable_pairs=sum(not p['continuous']['relative_motion_fixed'] and not p['continuous']['continuous_separation_proved'] for p in work['pairs']),
                  continuous_unproved_pairs=unproved,same_component_solid_pairs_checked=False,
                  numerical_model_scope='Unchanged solid shapes and orientations; independent fixed-direction translations only',
                  minimum_distance_measured=False,safety_release=False)
    return result
