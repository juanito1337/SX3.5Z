import itertools
from engineering.sizing import positive,number

def nut_interval(thread_length_mm,nut_length_mm,left_reserve_mm,right_reserve_mm):
    L=positive(thread_length_mm,'thread_length');l=positive(nut_length_mm,'nut_length')
    a=number(left_reserve_mm,'left_reserve');b=number(right_reserve_mm,'right_reserve')
    qmax=L-l-b
    if qmax<=a:raise ValueError('No usable travel')
    return dict(min_leading_edge_mm=a,max_leading_edge_mm=qmax,usable_travel_mm=qmax-a)

def sample_grid(limits,count=5):
    if isinstance(count,bool) or not isinstance(count,int) or not 2<=count<=21:raise ValueError('2..21 samples per axis required')
    if set(limits)!={'X','Y','Z'}:raise ValueError('X,Y,Z required')
    values=[]
    for axis in 'XYZ':
        r=limits[axis]
        if len(r)!=2:raise ValueError('Two limits required')
        a,b=[float(x) for x in r]
        import math
        if any(isinstance(x,bool) for x in r) or not all(math.isfinite(x) for x in (a,b)) or a>=b:raise ValueError('Invalid limits')
        values.append([a+(b-a)*j/(count-1) for j in range(count)])
    return dict(poses=[dict(zip('XYZ',p)) for p in itertools.product(*values)],
                collision_status='NOT_RUN',continuous_sweep_proven=False)
