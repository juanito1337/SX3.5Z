"""Geometry contracts in mm, R @ column-vector. AABB screening is NOT exact collision testing."""
import itertools,math
from assembly.position_components import transform_point,validated

def scalar(x):
 if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x):raise ValueError('Finite number required')
 return float(x)
def vec(x):
 if not isinstance(x,(list,tuple)) or len(x)!=3:raise ValueError('Three-vector required')
 return [scalar(v) for v in x]
def unit(x):
 x=vec(x);n=math.sqrt(sum(v*v for v in x))
 if n<1e-12:raise ValueError('Zero vector')
 return [v/n for v in x]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def bounds(b):
 if len(b)!=6:raise ValueError('Six bounds required')
 b=[scalar(v) for v in b]
 if any(b[i]>=b[i+3] for i in range(3)):raise ValueError('Positive extent required')
 return b
def axis_frame(line_point,line_direction,plane_point,plane_normal,roll_hint):
 p=vec(line_point);z=unit(line_direction);q=vec(plane_point);n=unit(plane_normal);hint=unit(roll_hint)
 den=dot(z,n)
 if abs(den)<1e-9:raise ValueError('Axis parallel to datum plane')
 t=dot([q[i]-p[i] for i in range(3)],n)/den
 origin=[p[i]+z[i]*t for i in range(3)]
 x=unit([hint[i]-dot(hint,z)*z[i] for i in range(3)]);y=unit(cross(z,x))
 R=[[x[i],y[i],z[i]] for i in range(3)];validated(R)
 return dict(origin_mm=origin,rotation=R,status='GEOMETRIC_CANDIDATE_NOT_PHYSICALLY_VERIFIED')
def transform_bounds(b,R,t):
 b=bounds(b);t=vec(t);validated(R)
 pts=[transform_point(R,t,[b[i+3*j] for i,j in enumerate(bits)]) for bits in itertools.product((0,1),repeat=3)]
 return [min(p[i] for p in pts) for i in range(3)]+[max(p[i] for p in pts) for i in range(3)]
def screen_pair(a,b,clearance_mm):
 a=bounds(a);b=bounds(b);c=scalar(clearance_mm)
 if c<0:raise ValueError('Negative clearance')
 gaps=[max(0.,b[i]-a[i+3],a[i]-b[i+3]) for i in range(3)]
 distance=math.sqrt(sum(x*x for x in gaps))
 state='AABB_SEPARATION_AT_LEAST_CLEARANCE' if distance>0 and distance>=c else 'POTENTIAL_CONTACT_OR_INTERFERENCE'
 return dict(status=state,lower_bound_distance_mm=distance,exact_collision_checked=False)
def sweep_bounds(b,direction,start,stop,count):
 b=bounds(b);u=unit(direction);start=scalar(start);stop=scalar(stop)
 if stop<start or isinstance(count,bool) or not isinstance(count,int) or count<2:raise ValueError('Invalid sweep')
 return [dict(offset_mm=q,bounds_mm=[b[j]+u[j%3]*q for j in range(6)])
         for q in (start+(stop-start)*i/(count-1) for i in range(count))]
