"""Fixed-orientation rigid translations only. This is NOT an NX geometry kernel.
Continuous proofs concern only AABB separation. Sampled exact tests do not prove
unsampled positions. A supplied native model is not a verified physical machine.
"""
import copy
import itertools
import math
import re
from assembly.position_components import validated
from validation.geometry03 import scalar, vec, bounds


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(label + ': non-empty text required')
    return value


def _integer(value, label, lower, upper):
    if isinstance(value, bool) or not isinstance(value, int) or not lower <= value <= upper:
        raise ValueError(label + ': integer outside allowed range')
    return value


def sample_values(axis):
    n=axis['samples'];lo=axis['min_mm'];hi=axis['max_mm']
    # Explicit reference pose is required even when an even grid omits it.
    return sorted(set([lo+(hi-lo)*i/(n-1) for i in range(n)]+[axis['reference_mm']]))


def validate(cfg):
    if cfg.get('schema') != 'SX35Z_SWEEP_5':
        raise ValueError('Expected SX35Z_SWEEP_5')
    review=cfg.get('review', {})
    if review.get('status') != 'KINEMATICS_REVIEWED':
        raise ValueError('Motion assignment/limits not reviewed; do not guess them')
    _text(review.get('evidence'), 'Kinematics review evidence')
    axes=cfg.get('axes')
    if not isinstance(axes, dict) or not axes or set(axes)-set(('X','Y','Z')):
        raise ValueError('One to three fixed translation axes X/Y/Z required')
    counts=[]
    for name,a in axes.items():
        lo,hi,ref=[scalar(a.get(k)) for k in ('min_mm','max_mm','reference_mm')]
        if not lo < hi or not lo <= ref <= hi:
            raise ValueError(name+': invalid travel/reference position')
        u=vec(a['direction'])
        if abs(sum(x*x for x in u)-1.0)>1e-8:
            raise ValueError(name+': unit direction required, not silently normalized')
        _integer(a['samples'],name+' samples',2,21)
        _text(a.get('evidence'), name+' limit/direction evidence')
        counts.append(len(sample_values(a)))
    for key in ('clearance_mm','tolerance_mm'):
        x=scalar(cfg.get(key))
        if x<0 or (key=='tolerance_mm' and x<=0):
            raise ValueError(key+': invalid value')
    limit=_integer(cfg.get('max_poses'),'max_poses',1,10000)
    _integer(cfg.get('max_pair_evaluations'),'max_pair_evaluations',1,10000000)
    count=math.prod(counts)
    if count>limit:raise ValueError('Pose budget exceeded before any NX change')
    components=cfg.get('components')
    if not isinstance(components,list) or len(components)<2:
        raise ValueError('At least two explicit component occurrences required')
    ids=set()
    for c in components:
        id_=_text(c.get('id'),'component id')
        if id_ in ids or not re.fullmatch(r'[A-Za-z0-9_\-]+',id_):
            raise ValueError('Duplicate/invalid occurrence ID: '+id_)
        ids.add(id_);vec(c['origin_mm']);validated(c['rotation'])
        _text(c.get('path'),'prototype path')
        if not re.fullmatch(r'[a-fA-F0-9]{64}',str(c.get('sha256',''))):
            raise ValueError('Prototype SHA256 required')
        move=c.get('moving_axes')
        if not isinstance(move,list) or any(not isinstance(k,str) or k not in axes for k in move):
            raise ValueError('Explicit moving_axes needed; null is NOT fixed')
        if len(set(move))!=len(move):raise ValueError('Duplicate moving axis')
    policies=cfg.get('expected_contacts',[])
    if not isinstance(policies,list):raise ValueError('expected_contacts must be a list')
    pairs=set()
    for p in policies:
        a,b=p.get('a'),p.get('b')
        if a not in ids or b not in ids or a==b:raise ValueError('Invalid contact pair')
        pair=tuple(sorted((a,b)))
        if pair in pairs:raise ValueError('Duplicate contact policy')
        pairs.add(pair);_text(p.get('evidence'),'Contact evidence')
    return dict(pose_count=count,component_count=len(components),fixed_orientation=True,
                physical_machine_verified=False,manufacturing_released=False)


def poses(cfg):
    validate(cfg);names=sorted(cfg['axes'])
    return [dict(zip(names,values)) for values in itertools.product(*(sample_values(cfg['axes'][k]) for k in names))]


def translation(cfg,component,pose):
    if set(pose)!=set(cfg['axes']):raise ValueError('Pose has missing/unknown axes')
    result=[0.,0.,0.]
    for name,a in cfg['axes'].items():
        q=scalar(pose[name])
        if q<a['min_mm'] or q>a['max_mm']:raise ValueError('Pose outside reviewed range')
        if name in component['moving_axes']:
            for k in range(3):result[k]+=a['direction'][k]*(q-a['reference_mm'])
    return result


def origin_at(cfg,component,pose):
    t=translation(cfg,component,pose)
    return [scalar(component['origin_mm'][k])+t[k] for k in range(3)]


def shift_bounds(bb,shift):
    bb=bounds(bb);shift=vec(shift)
    return [bb[k]+shift[k%3] for k in range(6)]


def aabb_distance(a,b):
    a=bounds(a);b=bounds(b)
    return math.sqrt(sum(max(0.,b[k]-a[k+3],a[k]-b[k+3])**2 for k in range(3)))


def swept_pair(cfg,a,ba,b,bb):
    """Conservative lower bound on distance for ALL poses in the axis box.
    Relative translations cancel shared X/Y motions. Coordinate-wise interval
    bounds may lose correlations, which creates candidates, never false safety.
    Bounds must be measured at the configured reference coordinates.
    """
    ba=bounds(ba);bb=bounds(bb);dlo=[0.]*3;dhi=[0.]*3;fixed=True
    for name,axis in cfg['axes'].items():
        coefficient=int(name in b['moving_axes'])-int(name in a['moving_axes'])
        if coefficient:fixed=False
        for k in range(3):
            u=axis['direction'][k]*coefficient
            v=[u*(axis['min_mm']-axis['reference_mm']),u*(axis['max_mm']-axis['reference_mm'])]
            dlo[k]+=min(v);dhi[k]+=max(v)
    gaps=[max(0.,bb[k]+dlo[k]-ba[k+3],ba[k]-(bb[k+3]+dhi[k])) for k in range(3)]
    lower=math.sqrt(sum(x*x for x in gaps))
    proven=lower>cfg['clearance_mm']+cfg['tolerance_mm']
    return dict(continuous_separation_proved=proven,relative_motion_fixed=fixed,
                lower_bound_mm=lower,relative_shift_min_mm=dlo,relative_shift_max_mm=dhi,
                proof='RIGID_TRANSLATION_INTERVAL_AABB' if proven else 'NO_CONTINUOUS_SEPARATION_PROOF',
                scope='Supplied solid envelopes and reviewed rigid translation model only')


def classify_sample(kernel,lower,clearance,tolerance,expected_contact=False):
    if kernel not in ('SEPARATE','TOUCH','INTERSECT'):
        raise ValueError('Uncalibrated/unrecognized geometry result')
    lower,clearance,tolerance=[scalar(v) for v in (lower,clearance,tolerance)]
    if min(lower,clearance,tolerance)<0:raise ValueError('Invalid clearance result')
    if kernel=='INTERSECT':return 'INTERFERENCE'
    if kernel=='TOUCH':
        if clearance>0:return 'CONTACT_VIOLATES_CLEARANCE'
        return 'EXPECTED_CONTACT' if expected_contact else 'UNREVIEWED_CONTACT'
    if clearance==0:return 'SEPARATE'
    return 'SEPARATE_WITH_CONSERVATIVE_GAP' if lower>clearance+tolerance else 'SEPARATE_GAP_UNVERIFIED'


def summarize(checks,continuous_complete=False):
    if not checks:raise ValueError('Empty check set cannot pass')
    allowed={'SEPARATE','TOUCH','INTERFERENCE','CONTACT_VIOLATES_CLEARANCE','UNREVIEWED_CONTACT',
             'EXPECTED_CONTACT','SEPARATE_WITH_CONSERVATIVE_GAP','SEPARATE_GAP_UNVERIFIED',
             'AABB_SEPARATION','CONTINUOUS_AABB_SEPARATION','UNKNOWN','ERROR'}
    counts={}
    for row in checks:
        status=row.get('status')
        if status not in allowed or status=='TOUCH':raise ValueError('Unclassified/unexecuted sample status: '+str(status))
        counts[status]=counts.get(status,0)+1
    issues=sum(counts.get(k,0) for k in ('INTERFERENCE','CONTACT_VIOLATES_CLEARANCE','UNREVIEWED_CONTACT','UNKNOWN','ERROR'))
    unresolved=counts.get('SEPARATE_GAP_UNVERIFIED',0)
    return dict(status='ISSUES_FOUND' if issues else ('GAPS_UNVERIFIED' if unresolved else 'NO_ISSUE_IN_EVALUATED_SAMPLES'),
                counts=counts,continuous_collision_free=bool(continuous_complete and not issues and not unresolved),
                physical_machine_verified=False,manufacturing_released=False,
                note='Sample-only absence of interference is not a full-path proof. Expected contact is separately labeled.')
