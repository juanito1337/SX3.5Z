import math
from cnc_nx.core import unit
from assembly.position_components import vector

def axis_alignment(origin1,direction1,origin2,direction2):
    p=vector(origin1);q=vector(origin2);a=unit(direction1);b=unit(direction2)
    dot=sum(a[i]*b[i] for i in range(3));delta=[q[i]-p[i] for i in range(3)]
    proj=sum(delta[i]*a[i] for i in range(3))
    return dict(angle_deg=math.degrees(math.acos(min(1.,abs(dot)))),
                offset_mm_at_reference=math.sqrt(sum((delta[i]-proj*a[i])**2 for i in range(3))),
                opposite_directions=dot<0,source='NUMERIC_LINES_ONLY_NOT_NX_FACES')
