"""Strict model-identity binding and limited evidence interpretation.

This is not a certification engine. Hashes detect changed bytes, not forged reports.
No role may turn a diagnostic self-test, a recipe preview or an unexecuted step into
machine acceptance. Legacy travel results lack a complete assembly fingerprint and
remain informational rather than being upgraded retroactively.
"""
import copy
import hashlib
import json
from pathlib import Path
from analysis.bom07 import summarize, path_key, HASH
from cnc_nx.runtime import sha256_file
from validation.interfaces08 import number, vector, reference_checks, evaluate_reference
from assembly.position_components import validated

ROLES={'native_geometry','interfaces','bom','drawings','step','collision_selftest','travel'}
BLOCKERS={'FAILED','STALE_OR_OTHER_MODEL','UNREADABLE_OR_CHANGED','UNSUPPORTED_SCHEMA'}
CATEGORIES=[('inventory','Gespeicherter Bestand und Vorkommen'),
 ('geometry','Native Körper / Parameteränderung'),
 ('interfaces','Koaxialität, Lochbilder und axiale Anlagen'),
 ('collision','Kollisionsprüfung der Zielbaugruppe'),
 ('travel','Prüfung des vollständigen Verfahrwegs'),
 ('drawings','Fertigungsgerechte Zeichnungen'),
 ('step','Neutraler STEP-Export und Rückleseprüfung'),
 ('bom','Mengen und Artikel-/Dokumentzuordnung'),
 ('physical_fit','Reale Maschinenmaße und Einpassung'),
 ('engineering','Festigkeit, Antriebs- und Haltesicherheit')]
ROLE_CATEGORY=dict(native_geometry='geometry',interfaces='interfaces',bom='bom',
                   drawings='drawings',step='step',travel='travel')


def digest(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')).hexdigest()


def _file(path,sha,extension=None):
    path_key(path);p=Path(path)
    if not p.is_absolute() or not p.is_file() or p.is_symlink():raise ValueError('Existing absolute non-symlink file required: '+str(path))
    if extension and p.suffix.lower()!=extension:raise ValueError('Expected '+extension)
    if not isinstance(sha,str) or not HASH.fullmatch(sha) or sha256_file(p)!=sha:raise ValueError('File hash changed/missing: '+str(path))
    return p


def checked_json(spec):
    p=_file(spec.get('path'),spec.get('sha256'),'.json')
    if p.stat().st_size>50_000_000:raise ValueError('Evidence JSON too large')
    def pairs(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('Duplicate JSON key: '+k)
            d[k]=v
        return d
    def constant(value):raise ValueError('Nonfinite JSON token: '+value)
    data=json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs,parse_constant=constant)
    _file(str(p),spec['sha256'],'.json')
    if not isinstance(data,dict):raise ValueError('JSON object required')
    return data


def subject_from_snapshot(snapshot):
    summary=summarize(snapshot)
    if (snapshot.get('origin')!='LIVE_NX_READ' or snapshot.get('integrity_failure') is not False
        or not summary['inventory_complete'] or not summary['source_binding_complete']
        or snapshot.get('positions_complete') is not True):
        raise ValueError('Complete clean saved NX inventory WITH raw positions required')
    protos={r['id']:r for r in snapshot['prototypes']};files=[];occurrences=[]
    for p in protos.values():
        if p.get('unit_mm') is not True:raise ValueError('Verified millimetre part required')
        _file(p['path'],p['sha256_before'],'.prt')
        files.append(dict(path=path_key(p['path']),sha256=p['sha256_before'],solid_body_count=p['solid_body_count']))
    if len({f['path'] for f in files})!=len(files):raise ValueError('Duplicate native file identities')
    for n in snapshot['occurrences']:
        row={k:copy.deepcopy(n.get(k)) for k in ('path','parent','name','suppressed','reference_set','children_count')}
        if n['suppressed'] is False:
            p=protos[n['prototype_id']];pos=n.get('position_raw')
            if not isinstance(pos,dict):raise ValueError('Missing raw occurrence position')
            vector(pos['origin_raw']);validated(pos['matrix_raw'])
            row.update(prototype_path=path_key(p['path']),position_raw=copy.deepcopy(pos))
        occurrences.append(row)
    rootnode=next(n for n in snapshot['occurrences'] if n['path']==snapshot['root'])
    rp=protos[rootnode['prototype_id']]
    subject=dict(schema='SX35Z_INSPECTION_SUBJECT_8',root_path=path_key(rp['path']),root_sha256=rp['sha256_before'],
        files=sorted(files,key=lambda x:x['path']),occurrences=sorted(occurrences,key=lambda x:x['path']),
        quantities=sorted([dict(path=path_key(r['prototype_path']),sha256=r['prototype_sha256'],quantity=r['quantity']) for r in summary['rows']],key=lambda x:x['path']),
        counts=summary['counts'],configuration_scope='CURRENT_LOADED_ARRANGEMENT_RAW_POSITIONS',
        units='mm',physical_measurement=False)
    subject['fingerprint']=digest(subject)
    return subject


def verify_subject(subject):
    expected=subject.get('fingerprint');payload={k:v for k,v in subject.items() if k!='fingerprint'}
    if digest(payload)!=expected:raise ValueError('Subject fingerprint mismatch')
    if subject.get('schema')!='SX35Z_INSPECTION_SUBJECT_8':raise ValueError('Unknown subject schema')
    for f in subject['files']:_file(f['path'],f['sha256'],'.prt')
    return True


def _bound(path,sha,subject):
    try:
        expected={f['path']:f['sha256'] for f in subject['files']}
        return expected.get(path_key(path))==sha and bool(_file(path,sha,'.prt'))
    except (ValueError,TypeError,OSError):return False


def _result(status,message,**extra):return dict(status=status,message=message,**extra)


def inspect_artifact(role,data,subject):
    if role not in ROLES:raise ValueError('Unknown evidence role')
    if role=='bom':
        if data.get('schema')!='SX35Z_BOM_REPORT_7':return _result('UNSUPPORTED_SCHEMA','Nicht unterstütztes Stücklistenformat.')
        if data.get('source_origin')!='LIVE_NX_READ' or data.get('native_read_in_this_run') is not True:
            return _result('NOT_NATIVE_EVIDENCE','Rezeptvorschau oder nicht nativ gelesene Stückliste.')
        rows=data.get('rows',[])
        if not rows or any(not _bound(r.get('prototype_path'),r.get('prototype_sha256'),subject) for r in rows):
            return _result('STALE_OR_OTHER_MODEL','Stückliste passt nicht zu den aktuellen nativen Dateien.')
        actual=sorted([dict(path=path_key(r['prototype_path']),sha256=r['prototype_sha256'],quantity=r['quantity']) for r in rows],key=lambda x:x['path'])
        if actual!=subject['quantities'] or any(type(r['quantity']) is not int or r['quantity']<=0 for r in rows):
            return _result('FAILED','Stücklistenvorkommen stimmen nicht mit dem aktuellen Bestand überein.')
        if data.get('inventory_complete') is not True or data.get('source_binding_complete') is not True:
            return _result('FAILED','Stücklistenaufnahme war unvollständig.')
        from analysis.bom_registry07 import document_check
        for row in rows:
            for document in row.get('document_checks',[]):
                current=document_check(document,row['prototype_sha256'],True)
                if current['status']!='FILE_IDENTITY_CHECKED_NOT_APPROVED':
                    return _result('STALE_OR_OTHER_MODEL','Ein verknüpftes Stücklistendokument fehlt, wurde geändert oder gehört zu einem anderen Modellstand.')
        assigned=data.get('assignment_complete') is True
        return _result('BOM_ASSIGNED_NOT_RELEASED' if assigned else 'BOM_COUNTS_RECORDED_UNASSIGNED',
            'Mengen stimmen; Artikel-/Dokumentfreigabe ist separat offen.',part_count=len(rows),
            quantity=sum(r['quantity'] for r in rows),assignment_complete=assigned,
            document_link_complete=data.get('document_link_complete') is True)
    if data.get('native_execution') is not True:
        return _result('NOT_NATIVE_EVIDENCE','Kein als nativ ausgeführt ausgewiesener Bericht; nicht als bestanden übernommen.')
    if role=='native_geometry':
        if data.get('status') not in ('NATIVE_REFERENCE_ASSEMBLY_CREATED_IN_THIS_RUN','NATIVE_HOUSING_LIBRARY_CREATED_IN_THIS_RUN'):
            return _result('UNSUPPORTED_SCHEMA','Nicht unterstützter nativer Bauteilbericht.')
        rows=data.get('parts',[])
        if not rows:return _result('FAILED','Keine geprüften Teile enthalten.')
        if len({path_key(p['path']) for p in rows})!=len(rows):return _result('FAILED','Doppelte Geometrienachweise.')
        if any(not _bound(p.get('path'),p.get('sha256'),subject) for p in rows):
            return _result('STALE_OR_OTHER_MODEL','Bauteilstand des Geometrieberichts ist fremd oder veraltet.')
        for p in rows:
            g=p.get('geometry_check',{});b=g.get('actual_nx_bounds_mm',[])
            if (g.get('solid_body') is not True or number(g.get('actual_nx_volume_mm3'))<=0
                or len(b)!=6 or any(number(b[i])>=number(b[i+3]) for i in range(3))):
                return _result('FAILED','Ungültiger oder fehlender Körpernachweis.')
            check=p.get('parameter_check',p.get('parameter_test',{}))
            if check.get('status')!='PASSED_IN_THIS_NX_RUN':return _result('FAILED','Parameteränderungsprüfung fehlgeschlagen oder nicht ausgeführt.')
            if any(o.get('status')!='PASSED_IN_THIS_NX_RUN' for o in g.get('operation_checks',[])):
                return _result('FAILED','Eine Zwischenoperation ist nicht bestanden.')
        return _result('PART_CHECKS_RECORDED','Native Körper-/Parameterprüfungen für die gebundenen Einzelteile dokumentiert; keine Montage-/Maschinenfreigabe.',
            covered_parts=sorted(path_key(p['path']) for p in rows),part_count=len(rows),
            active_distinct_part_count=len(subject['quantities']))
    if role=='interfaces':
        if data.get('schema')!='SX35Z_NATIVE_INTERFACES_8':return _result('UNSUPPORTED_SCHEMA','Unbekanntes Schnittstellenformat.')
        if data.get('subject_fingerprint')!=subject['fingerprint']:
            return _result('STALE_OR_OTHER_MODEL','Schnittstellenbericht gehört zu anderer Konfiguration oder anderem Dateistand.')
        if data.get('contract_sha256')!=digest(reference_checks()):return _result('STALE_OR_OTHER_MODEL','Prüfvertrag geändert.')
        evaluation=evaluate_reference(data.get('measurements',[]))
        if not evaluation['all_within_limits']:return _result('FAILED','Schnittstellenprüfung hat Abweichungen oder fehlende Flächen.',evaluation=evaluation)
        rows=data['measurements']
        if any(not _bound(r.get('prototype_path'),r.get('prototype_sha256'),subject) for r in rows):
            return _result('FAILED','Messflächen sind nicht an aktuelle Prototypdateien gebunden.')
        for measured in rows:
            matches=[o for o in subject['occurrences'] if o.get('name')==measured['id']
                     and o.get('prototype_path')==path_key(measured['prototype_path'])
                     and o.get('suppressed') is False]
            if len(matches)!=1:
                return _result('STALE_OR_OTHER_MODEL','Messung ist keinem eindeutigen aktuellen Vorkommen zugeordnet.')
            position=matches[0].get('position_raw',{})
            if (position.get('origin_raw')!=measured['translation_mm']
                    or position.get('matrix_raw')!=measured['rotation']):
                return _result('STALE_OR_OTHER_MODEL','Messdaten und aktuell gespeicherte Vorkommnisposition unterscheiden sich.')
        # A carrier result is not transferable to a full machine or to additional occurrences.
        from construction.recipes03 import reference_carrier
        if len(rows)!=7 or subject['counts']['active_leaf_occurrences']!=7 or data.get('scope')!='REFERENCE_CARRIER_ONLY':
            return _result('FAILED','Abweichender Prüfumfang; Referenznachweis gilt nur für diese sieben Vorkommen.')
        return _result('LIMITED_REFERENCE_CHECKS_RECORDED','Koaxialität und Anlagen der Motorträger-Referenz innerhalb der numerischen Modellgrenzen.',
            check_count=len(evaluation['checks']),evaluation=evaluation,scope='REFERENCE_CARRIER_ONLY')
    if role=='collision_selftest':
        if data.get('status')!='NATIVE_COLLISION_SELFTEST_PASSED_IN_THIS_RUN':return _result('FAILED','Kollisions-Selbsttest nicht bestanden.')
        return _result('DIAGNOSTIC_ONLY','Diagnosekörper testen die Schnittstelle, nicht die Zielmaschine.',probe_count=data.get('probe_count'))
    if role=='travel':
        return _result('SCOPE_UNBOUND_LEGACY','Bericht 05 enthält keinen vollständigen Baugruppen-Fingerabdruck. Nicht als aktuellen Maschinen-/Verfahrwegnachweis übernommen.',
            recorded_status=data.get('status'),recorded_continuous_collision_free=data.get('continuous_collision_free'))
    if role=='step':
        if data.get('status')!='STEP_FILE_WRITTEN_REIMPORT_NOT_PERFORMED':return _result('UNSUPPORTED_SCHEMA','Nicht unterstützter STEP-Nachweis.')
        if not _bound(data.get('source'),data.get('source_sha256'),subject):return _result('STALE_OR_OTHER_MODEL','STEP bezieht sich nicht auf aktuellen nativen Stand.')
        p=_file(data.get('path'),data.get('sha256'))
        if p.suffix.lower() not in ('.stp','.step'):return _result('FAILED','Falsche STEP-Dateiendung.')
        return _result('EXPORT_EXISTS_NO_ROUNDTRIP','STEP-Datei hashgebunden vorhanden; keine Rückleseprüfung.',source=data['source'])
    if role=='drawings':
        if data.get('status')!='NATIVE_NOMINAL_DRAWING_DRAFTS_CREATED_IN_THIS_RUN':return _result('UNSUPPORTED_SCHEMA','Nicht unterstützter Zeichnungsnachweis.')
        rows=data.get('parts',[])
        if not rows:return _result('FAILED','Leerer Zeichnungsnachweis.')
        if any(not _bound(p.get('path'),p.get('sha256'),subject) for p in rows):return _result('STALE_OR_OTHER_MODEL','Zeichnungen gehören nicht zu aktuellen Bauteildateien.')
        for p in rows:
            if p.get('native_pdf'):
                doc=p['native_pdf'];_file(doc.get('path'),doc.get('sha256'),'.pdf')
        return _result('BOUND_DRAFT_ONLY','Nennmaßentwürfe vorhanden; Schnitte, Passungen, Werkstoff und Fertigungsfreigabe weiterhin offen.',part_count=len(rows))
    raise AssertionError('Unreachable evidence role')


def _categories():
    return [dict(id=k,title=t,status='NOT_RUN',message='Kein passender, ausgeführter Nachweis für diese Baugruppe.',artifact_indices=[]) for k,t in CATEGORIES]


def build_dossier(snapshot,artifact_specs):
    if not isinstance(artifact_specs,list):raise ValueError('Artifact list required')
    seen=set()
    for spec in artifact_specs:
        if not isinstance(spec,dict) or spec.get('role') not in ROLES:raise ValueError('Unknown evidence role')
        key=path_key(spec.get('path'))
        if key in seen:raise ValueError('Duplicate artifact file')
        seen.add(key)
    subject=subject_from_snapshot(snapshot);artifacts=[]
    for spec in artifact_specs:
        entry=copy.deepcopy(spec)
        try:data=checked_json(spec)
        except (OSError,TypeError,ValueError) as exc:
            entry.update(_result('UNREADABLE_OR_CHANGED',str(exc)))
        else:
            try:entry.update(inspect_artifact(spec['role'],data,subject))
            except (KeyError,ValueError,TypeError,OSError) as exc:entry.update(_result('FAILED','Unvollständige/ungültige Evidenz: '+str(exc)))
        artifacts.append(entry)
    # Recheck evidence bytes after interpretation; success strings from files
    # altered mid-run must not survive into the consolidated report.
    for entry in artifacts:
        if entry['status']=='UNREADABLE_OR_CHANGED':continue
        try:_file(entry['path'],entry['sha256'],'.json')
        except (ValueError,TypeError,OSError) as exc:
            entry.update(_result('UNREADABLE_OR_CHANGED','Berichtsdatei während der Auswertung geändert: '+str(exc)))
    cats=_categories();byid={c['id']:c for c in cats}
    byid['inventory'].update(status='BOUND_INVENTORY_RECORDED',message='Gespeicherte Millimeterteile, Vorkommen und Rohpositionen vollständig gebunden.')
    for i,a in enumerate(artifacts):
        key=ROLE_CATEGORY.get(a['role'])
        if not key:continue
        c=byid[key];c['artifact_indices'].append(i)
        if a['status'] in BLOCKERS:c.update(status='BLOCKED',message='Mindestens ein zugeordneter Nachweis fehlt, ist fehlerhaft oder veraltet.')
        elif c['status']!='BLOCKED':
            c.update(status=a['status'],message=a['message'])
    verify_subject(subject)
    return dict(schema='SX35Z_DOSSIER_8',status='BLOCKED' if any(a['status'] in BLOCKERS for a in artifacts) else 'INCOMPLETE_NO_RELEASE',
        subject=subject,categories=cats,artifacts=artifacts,native_read_in_this_run=False,
        native_geometry_created_in_this_dossier=False,final_cnc_assembly_accepted=False,
        manufacturing_released=False,order_released=False,physical_machine_verified=False,
        replay_policy='Recorded evidence + current file identity, not reexecution of previous NX tests',
        trust_policy='File hashes are integrity bindings, not signatures or proof of genuine test execution',
        limitations=['No final CNC-machine acceptance','No physical measurement or engineering release',
          'Reference interfaces do not prove collision freedom','Legacy travel05 results remain informational',
          'Bound nominal drawings are not manufacturing-ready drawings'])


def preview():
    return dict(schema='SX35Z_DOSSIER_8',status='PREVIEW_CHECK_PLAN_ONLY',subject=None,categories=_categories(),
        artifacts=[],planned_interface_checks=reference_checks(),native_read_in_this_run=False,
        native_geometry_created_in_this_dossier=False,final_cnc_assembly_accepted=False,
        manufacturing_released=False,order_released=False,physical_machine_verified=False,
        limitations=['No NX run, no native files or measurements','Nominal check plan only, not passed checks'])
