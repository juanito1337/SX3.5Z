"""Bind travel review to a successfully generated NX layout; never infer axes."""
import copy,json,os
from pathlib import Path
from assembly.manifest03 import checked_file
from cnc_nx.runtime import sha256_file
from .motion05 import validate


def _report(path):
    with open(path,encoding='utf-8-sig') as f:r=json.load(f)
    if r.get('native_execution') is not True or r.get('status')!='NATIVE_REVIEWED_LAYOUT_CREATED_NOT_RELEASED':
        raise ValueError('Requires actual NX_Montageentwurf.json from Journal10, not a simulated or partial report')
    rows=r.get('components')
    if not isinstance(rows,list) or len(rows)<2 or len({x['id'] for x in rows})!=len(rows):
        raise ValueError('Incomplete/duplicate native occurrence inventory')
    return r


def load_reviewed(cfg):
    validate(cfg)
    reference=cfg.get('input_layout',{})
    path=checked_file(reference.get('path'),reference.get('sha256'),'.json')
    report=_report(path)
    originals={x['id']:x for x in report['components']}
    if set(originals)!={x['id'] for x in cfg['components']}:
        raise ValueError('Inspection inventory differs from source layout; do not omit components')
    for c in cfg['components']:
        original=originals[c['id']]
        for field in ('path','sha256','rotation','origin_mm'):
            if c[field]!=original[field]:
                raise ValueError(c['id']+': changed original field '+field+'; rebuild/review the source layout first')
        checked_file(c['path'],c['sha256'],'.prt')
    result=copy.deepcopy(cfg)
    result['physical_machine_verified']=False
    return result


def prepare(layout_path):
    """Produce a deliberately incomplete review form, not a guessed motion model."""
    path=Path(os.path.abspath(os.fspath(layout_path)))
    report=_report(path)
    components=[]
    for c in report['components']:
        components.append({k:copy.deepcopy(c[k]) for k in ('id','path','sha256','rotation','origin_mm')})
        components[-1]['moving_axes']=None
    axes={k:dict(min_mm=None,max_mm=None,reference_mm=None,direction=None,samples=5,
                evidence='') for k in ('X','Y','Z')}
    return dict(schema='SX35Z_SWEEP_5',review=dict(status='NOT_REVIEWED',evidence=''),
                input_layout=dict(path=str(path),sha256=sha256_file(path)),axes=axes,
                components=components,clearance_mm=0.1,tolerance_mm=0.005,
                max_poses=216,max_pair_evaluations=100000,expected_contacts=[],
                instructions='Review actual directions/ranges/reference pose. Assign all moving_axes explicitly: [] means fixed. No name-based inference. Values are not physical-machine certification.')
