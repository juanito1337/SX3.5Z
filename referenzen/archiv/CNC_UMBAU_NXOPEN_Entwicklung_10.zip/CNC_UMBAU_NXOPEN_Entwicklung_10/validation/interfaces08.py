"""Model-interface checks from supplied face measurements, never from rendered pixels.

Expected dimensions select a labelled nominal interface. Actual axes/planes are read
separately. An ambiguous or missing face is an ERROR, not an accepted guess.
The numerical limits below are model-check limits, NOT manufacturing tolerances.
This pure module neither imports NX nor claims execution of a native measurement.
"""
import math
from assembly.position_components import validated
from construction.recipes03 import reference_carrier

OFFSET_LIMIT_MM = 0.01
ANGLE_LIMIT_DEG = 0.01
DIMENSION_LIMIT_MM = 0.005
SELECT_DISTANCE_MM = 0.5
SELECT_ANGLE_DEG = 1.0


def number(x):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x):
        raise ValueError('Finite real scalar required')
    return float(x)


def vector(v):
    if not isinstance(v,(list,tuple)) or len(v)!=3:raise ValueError('Three coordinates required')
    return [number(x) for x in v]


def unit(v):
    v=vector(v);n=math.sqrt(sum(x*x for x in v))
    if n<=1e-12:raise ValueError('Nonzero direction required')
    return [x/n for x in v]


def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def norm(v):return math.sqrt(dot(v,v))
def difference(a,b):return [x-y for x,y in zip(a,b)]


def axis_metrics(p,a,q,b):
    p,q=vector(p),vector(q);a,b=unit(a),unit(b)
    angle=math.degrees(math.atan2(norm(cross(a,b)),abs(dot(a,b))))
    delta=difference(q,p)
    return dict(angle_deg=angle,offset_mm=max(norm(cross(delta,a)),norm(cross(delta,b))),
                opposite_directions=dot(a,b)<0)


def _one(matches,kind):
    if len(matches)!=1:raise ValueError('%s: expected exactly one face, found %d'%(kind,len(matches)))
    return matches[0]


def select_cylinder(faces,selector):
    x,y=[number(v) for v in selector['center_xy']];r=number(selector['radius_mm']);z=number(selector['station_z_mm'])
    if r<=0:raise ValueError('Positive nominal radius required')
    matches=[]
    for f in faces:
        if f.get('uf_type_code')!=16:continue  # Existing project UF cylinder code.
        radius=number(f['radius_part_units'])
        if radius<=0:raise ValueError('Nonpositive measured cylinder radius')
        if len(f['bounds_raw'])!=6:raise ValueError('Six bound values required')
        bounds=[number(v) for v in f['bounds_raw']]
        if any(bounds[i]>bounds[i+3] for i in range(3)):raise ValueError('Reversed face bounds')
        m=axis_metrics(f['point_raw'],f['direction_raw'],[x,y,z],[0,0,1])
        if (m['angle_deg']<=SELECT_ANGLE_DEG and m['offset_mm']<=SELECT_DISTANCE_MM
            and abs(radius-r)<=SELECT_DISTANCE_MM
            and bounds[2]-1e-5<=z<=bounds[5]+1e-5):matches.append(f)
    return _one(matches,'cylinder')


def select_plane(faces,z):
    z=number(z);matches=[]
    for f in faces:
        if f.get('uf_type_code')!=22:continue
        a=unit(f['direction_raw']);p=vector(f['point_raw'])
        angle=math.degrees(math.atan2(norm(cross(a,[0,0,1])),abs(a[2])))
        if angle<=SELECT_ANGLE_DEG and abs(p[2]-z)<=SELECT_DISTANCE_MM:matches.append(f)
    return _one(matches,'plane')


def reference_checks():
    """Explicit pair list for the existing seven-occurrence carrier, not the machine."""
    data=reference_carrier();parts={r['id']:r for r in data['parts']}
    cp={c['id']:c for c in data['components']}
    mp=parts[cp['motor']['part_id']]['parameters'];pp=parts[cp['motorplate']['part_id']]['parameters']
    sp=parts[cp['spacer_0']['part_id']]['parameters'];bp=parts[cp['interface_blank']['part_id']]['parameters']
    rows=[]
    def cylinder_ref(c,x,y,r,z):return dict(component=c,selector=dict(center_xy=[x,y],radius_mm=r,station_z_mm=z))
    def plane_ref(c,z):return dict(component=c,z_mm=z)
    def add(id_,kind,a,b,expected=0.):rows.append(dict(id=id_,kind=kind,a=a,b=b,expected=expected))
    pilot=cylinder_ref('motor',0,0,mp['pilot_d']/2,-mp['pilot_h']/2)
    opening=cylinder_ref('motorplate',0,0,pp['pilot_clearance']/2,pp['thickness']/2)
    add('PILOT_COAXIAL','coaxial',pilot,opening)
    add('PILOT_DIAMETER_CLEARANCE','diameter_clearance',pilot,opening,pp['pilot_clearance']-mp['pilot_d'])
    for i,(x,y) in enumerate(( (x,y) for x in (-mp['hole_pitch']/2,mp['hole_pitch']/2) for y in (-mp['hole_pitch']/2,mp['hole_pitch']/2) )):
        add('MOTOR_HOLE_%d'%i,'coaxial',cylinder_ref('motor',x,y,mp['hole_d']/2,mp['flange_t']/2),
            cylinder_ref('motorplate',x,y,pp['hole_%02d_d'%i]/2,pp['thickness']/2))
    add('MOTOR_FLANGE_CONTACT','plane_gap',plane_ref('motor',0),plane_ref('motorplate',pp['thickness']))
    for i in range(4):
        cid='spacer_%d'%i;x,y,_=cp[cid]['origin_mm'];s=cylinder_ref(cid,0,0,sp['inner_d']/2,sp['length']/2)
        add('SPACER_%d_MOTORPLATE_AXIS'%i,'coaxial',s,cylinder_ref('motorplate',x,y,pp['hole_%02d_d'%(i+4)]/2,pp['thickness']/2))
        add('SPACER_%d_BACKPLATE_AXIS'%i,'coaxial',s,cylinder_ref('interface_blank',x,y,bp['hole_%02d_d'%i]/2,bp['thickness']/2))
        add('SPACER_%d_FRONT_CONTACT'%i,'plane_gap',plane_ref(cid,sp['length']),plane_ref('motorplate',0))
        add('SPACER_%d_REAR_CONTACT'%i,'plane_gap',plane_ref(cid,0),plane_ref('interface_blank',bp['thickness']))
    return rows


def _world(component,p,d):
    R=component['rotation'];t=component['translation_mm']
    return ([sum(R[i][j]*p[j] for j in range(3))+t[i] for i in range(3)],
            [sum(R[i][j]*d[j] for j in range(3)) for i in range(3)])


def evaluate_reference(measurements):
    if not isinstance(measurements,list):raise ValueError('Measurement list required')
    components={}
    allowed={c['id'] for c in reference_carrier()['components']}
    for c in measurements:
        key=c['id']
        if key in components or key not in allowed:raise ValueError('Duplicate/unknown occurrence '+str(key))
        validated(c['rotation']);vector(c['translation_mm'])
        if not isinstance(c['faces'],list):raise ValueError('Face list required')
        components[key]=c
    results=[]
    for check in reference_checks():
        row=dict(id=check['id'],kind=check['kind'],expected=check['expected'],
                 limits=dict(offset_mm=OFFSET_LIMIT_MM,angle_deg=ANGLE_LIMIT_DEG,dimension_mm=DIMENSION_LIMIT_MM),
                 limits_basis='NUMERICAL_MODEL_CHECK_NOT_MANUFACTURING_TOLERANCE')
        try:
            a,b=[components[check[k]['component']] for k in ('a','b')]
            if check['kind']=='plane_gap':
                fa=select_plane(a['faces'],check['a']['z_mm']);fb=select_plane(b['faces'],check['b']['z_mm'])
                pa,da=_world(a,vector(fa['point_raw']),unit(fa['direction_raw']))
                pb,db=_world(b,vector(fb['point_raw']),unit(fb['direction_raw']))
                _,positive_axis=_world(a,[0,0,0],[0,0,1])
                gap=dot(difference(pb,pa),unit(positive_axis));angle=axis_metrics([0,0,0],da,[0,0,0],db)['angle_deg']
                row['measured']=dict(gap_mm=gap,normal_angle_deg=angle)
                passed=abs(gap-check['expected'])<=OFFSET_LIMIT_MM and angle<=ANGLE_LIMIT_DEG
            else:
                fa=select_cylinder(a['faces'],check['a']['selector']);fb=select_cylinder(b['faces'],check['b']['selector'])
                pa,da=_world(a,vector(fa['point_raw']),unit(fa['direction_raw']))
                pb,db=_world(b,vector(fb['point_raw']),unit(fb['direction_raw']))
                am=axis_metrics(pa,da,pb,db)
                da_mm,db_mm=2*number(fa['radius_part_units']),2*number(fb['radius_part_units'])
                row['measured']=dict(am,diameter_a_mm=da_mm,diameter_b_mm=db_mm)
                nominal_errors=[abs(diam-2*check[k]['selector']['radius_mm']) for diam,k in ((da_mm,'a'),(db_mm,'b'))]
                passed=(am['offset_mm']<=OFFSET_LIMIT_MM and am['angle_deg']<=ANGLE_LIMIT_DEG
                        and max(nominal_errors)<=DIMENSION_LIMIT_MM)
                if check['kind']=='diameter_clearance':
                    clearance=db_mm-da_mm;row['measured']['diametral_clearance_mm']=clearance
                    passed=passed and clearance>0 and abs(clearance-check['expected'])<=DIMENSION_LIMIT_MM
            row['faces']=[dict(component=check[k]['component'],journal_id=f.get('journal_id')) for k,f in (('a',fa),('b',fb))]
            row['status']='WITHIN_MODEL_CHECK_LIMIT' if passed else 'OUTSIDE_MODEL_CHECK_LIMIT'
        except (KeyError,ValueError,TypeError) as exc:
            row.update(status='ERROR',message=str(exc))
        results.append(row)
    failed=sum(r['status']=='OUTSIDE_MODEL_CHECK_LIMIT' for r in results)
    errors=sum(r['status']=='ERROR' for r in results)
    return dict(schema='SX35Z_INTERFACE_EVALUATION_8',checks=results,
        all_within_limits=bool(results) and not failed and not errors,error_count=errors,failed_count=failed,
        physical_measurement=False,manufacturing_released=False,
        scope='REFERENCE_CARRIER_INTERFACES_ONLY_NOT_MACHINE_OR_COLLISION',
        data_policy='Input surfaces must be measured separately; calculation alone is not native execution')
