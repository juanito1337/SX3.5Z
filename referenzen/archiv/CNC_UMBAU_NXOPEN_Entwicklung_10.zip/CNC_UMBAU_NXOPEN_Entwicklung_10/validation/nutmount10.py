"""Comparison of measured simple faces, not real component fit/retention proof."""
import math
from validation.interfaces08 import (select_cylinder,axis_metrics,vector,unit,number,
                                    OFFSET_LIMIT_MM,ANGLE_LIMIT_DEG,DIMENSION_LIMIT_MM)


def verify_interfaces(group,measurements):
 if set(measurements)!={'screw','nut','block'}:raise ValueError('Exactly screw/nut/block face records required')
 p=group['resolved'];n=p['pair']['nut'];b=p['block']
 selectors={'screw':(p['pair']['screw_diameter_mm']/2,p['pair']['stock_length_mm']/2),
            'nut':(n['outer_diameter_mm']/2,n['length_mm']/2),
            'block':(b['bore_d_mm']/2,b['length_mm']/2)}
 selected={};world={}
 for role,(r,z) in selectors.items():
  m=measurements[role];t=vector(m['translation_mm'])
  f=select_cylinder(m['faces'],dict(center_xy=[0.,0.],radius_mm=r,station_z_mm=z))
  if abs(number(f['radius_part_units'])-r)>DIMENSION_LIMIT_MM/2:
   raise RuntimeError('Measured nominal cylinder diameter differs: '+role)
  selected[role]=f;world[role]=([a+c for a,c in zip(vector(f['point_raw']),t)],unit(f['direction_raw']))
 rows=[]
 def append(id_,values,passed):
  row=dict(id=id_,measured=values,status='PASSED_MODEL_INTERFACE_ONLY' if passed else 'FAILED_MODEL_INTERFACE',
           physical_fit_verified=False,limits_basis='NUMERICAL_MODEL_CHECK_NOT_FIT_TOLERANCES')
  rows.append(row)
  if not passed:raise RuntimeError('Mount interface failed: '+id_+' / '+repr(values))
 for a,c in [('screw','nut'),('nut','block')]:
  met=axis_metrics(*world[a],*world[c])
  append(a.upper()+'_'+c.upper()+'_AXIS',met,met['offset_mm']<=OFFSET_LIMIT_MM and met['angle_deg']<=ANGLE_LIMIT_DEG)
 gap=2*(selected['block']['radius_part_units']-selected['nut']['radius_part_units'])
 append('NOMINAL_BORE_MINUS_NUT_DIAMETER',dict(diametral_difference_mm=gap),abs(gap)<=DIMENSION_LIMIT_MM)
 foot=[]
 for f in measurements['block']['faces']:
  if f.get('uf_type_code')!=22:continue
  v=unit(f['direction_raw']);q=vector(f['point_raw'])
  if abs(v[1])>1-1e-8 and abs(q[1]+b['axis_height_mm'])<.5:foot.append(f)
 if len(foot)!=1:raise ValueError('Expected exactly one model foot plane')
 height=vector(selected['block']['point_raw'])[1]-vector(foot[0]['point_raw'])[1]
 append('BORE_AXIS_TO_MODEL_FOOT',dict(axis_height_mm=height),abs(height-b['axis_height_mm'])<=DIMENSION_LIMIT_MM)
 return rows
