"""Offline 2D review sheets; no NX run, native CAD, or fabrication release.
Usage: python Projekt06_Zeichnungsvorschau.py --output C:\\NX_Daten\\Vorschau06
Requires optional ReportLab. Never run this as a substitute for NX_17.
"""
import argparse
from pathlib import Path
from exports.drawing_outputs06 import write_bundle


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',required=True,help='Neuer absoluter Ausgabeordner')
    args=p.parse_args(argv)
    out=Path(args.output).expanduser()
    if not out.is_absolute():raise ValueError('Absoluter neuer Ausgabeordner erforderlich')
    r=write_bundle(out)
    print('Quellbasierte Nennmassvorschau, KEIN NX-Export: '+str(out))
    print('%s Teile; Fertigungsfreigabe: NEIN' % r['part_count'])
    return r


if __name__=='__main__':main()
