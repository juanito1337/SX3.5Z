"""Native-friendly design recipes. CAD is built ONLY by NX, not by this module.
Coordinates are in mm, local Z is the shaft axis. Reference recipes are NOT a
machine fit or a production release. Motor geometry represents one 2022 catalogue revision.
"""
import copy,math,re
from cnc_nx.parts02 import arithmetic

MOTOR_SOURCE='https://www.leadshine.com/upfiles/downloads/a5e0bafe68d54b1b5dac35ef79db01a3_1662082668689.pdf'
CURRENT_SOURCE='https://www.leadshine.com/product-detail/closed-loop-stepper-drive/closed-loop-stepper/CS-M22326.html'
I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]

def number(x,positive=False):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x):raise ValueError('Finite numeric dimension required')
    if positive and x<=0:raise ValueError('Positive dimension required')
    return float(x)

def _base(id_,kind,source):
    return dict(id=id_,kind=kind,parameters={},ops=[],source=source,
                dimensions_status='DESIGN_NOMINAL_NOT_MACHINE_MEASURED',order_released=False,
                manufacturing_released=False,machine_fit_verified=False,limitations='Nominal study only')

def box(r,o,s,op='add',name='Block'):
    r['ops'].append(dict(kind='box',origin=list(map(str,o)),size=list(map(str,s)),operation=op,name=name))

def cylinder(r,o,d,h,op='add',name='Zylinder'):
    r['ops'].append(dict(kind='cylinder',origin=list(map(str,o)),diameter=str(d),height=str(h),operation=op,name=name))

def motor_recipe():
    r=_base('M03_CS_M22326_CATALOG2022','motor_envelope',MOTOR_SOURCE+'; page 4')
    r.update(manufacturer='Leadshine',manufacturer_model='CS-M22326',
        dimensions_status='CATALOGUE_2022_NOMINAL_CONFLICT_WITH_CURRENT_PAGE',
        revision_conflicts={'body_length_mm':{'catalogue_2022':103,'product_page':104},
                            'inertia_kg_cm2':{'catalogue_2022':0.7,'product_page':0.52}},
        limitations='CAT2022 L103; current product page L104 (104 mm) differs. No mixing. No connector/cable solid, no internal motor, no exact flange fillets or rear detail. Shaft flat is nominal; no tolerance release.',
        color_index=31)
    p=r['parameters']=dict(body_w=56.4,motor_length=103.,flange_t=5.,pilot_d=38.1,pilot_h=1.6,
        shaft_d=8.,shaft_l=21.,hole_pitch=47.14,hole_d=5.,flat_l=15.,flat_height=7.5)
    box(r,['-body_w/2','-body_w/2',0],['body_w','body_w','motor_length'],name='Motor_Huellkoerper_CAT2022')
    cylinder(r,[0,0,'-pilot_h'],'pilot_d','pilot_h',name='Zentrierbund')
    cylinder(r,[0,0,'-shaft_l'],'shaft_d','shaft_l',name='Welle')
    for ix in (-1,1):
        for iy in (-1,1):
            cylinder(r,[f'{ix}*hole_pitch/2',f'{iy}*hole_pitch/2',-1],'hole_d','flange_t+1','cut',f'Flanschloch_{ix}_{iy}')
    box(r,['-shaft_d/2-1','-shaft_d/2+flat_height','-shaft_l'],['shaft_d+2','shaft_d','flat_l'],'cut','Wellenabflachung')
    r['expected_volume_mm3']=motor_volume(p)
    r['bounds_mm']=[-28.2,-28.2,-21.,28.2,28.2,103.]
    return r

def motor_volume(p):
    radius=p['shaft_d']/2.;c=p['flat_height']-radius
    if not -radius<c<radius:raise ValueError('Invalid shaft flat')
    seg=radius**2*math.acos(c/radius)-c*math.sqrt(radius**2-c*c)
    return (p['body_w']**2*p['motor_length']+math.pi*p['pilot_d']**2/4*p['pilot_h']
            +math.pi*p['shaft_d']**2/4*(p['shaft_l']-p['pilot_h'])
            -4*math.pi*p['hole_d']**2/4*p['flange_t']-seg*p['flat_l'])

def sleeve_recipe(id_,outer,inner,length,source):
    outer,inner,length=[number(x,True) for x in (outer,inner,length)]
    if inner>=outer:raise ValueError('Nonpositive sleeve wall')
    r=_base(id_,'sleeve',source);r['parameters']=dict(outer_d=outer,inner_d=inner,length=length)
    cylinder(r,[0,0,0],'outer_d','length',name='Distanzhuelse')
    cylinder(r,[0,0,-1],'inner_d','length+2','cut','Durchgang')
    r['expected_volume_mm3']=math.pi*(outer**2-inner**2)*length/4
    r['bounds_mm']=[-outer/2,-outer/2,0,outer/2,outer/2,length];r['color_index']=36
    return r

def flange_holder_recipe(id_,width,height,thickness,center_bore,holes,source):
    w,h,t,d=[number(x,True) for x in (width,height,thickness,center_bore)]
    if not isinstance(source,str) or not source.strip():raise ValueError('Source/engineering rationale required')
    allholes=[(0.,0.,d)]+[(number(v['x']),number(v['y']),number(v['d'],True)) for v in holes]
    for i,(x,y,di) in enumerate(allholes):
        if abs(x)+di/2>=w/2 or abs(y)+di/2>=h/2:raise ValueError('Hole breaks plate edge')
        for a,b,dj in allholes[:i]:
            if math.hypot(x-a,y-b)<=(di+dj)/2:raise ValueError('Overlapping holes')
    r=_base(id_,'flange_holder',source);r['parameters']=dict(width=w,height=h,thickness=t,center_bore=d)
    box(r,['-width/2','-height/2',0],['width','height','thickness'],name='Halter_Rohplatte')
    cylinder(r,[0,0,-1],'center_bore','thickness+2','cut','Zentraldurchgang_KEIN_LAGERSITZ')
    for i,(x,y,di) in enumerate(allholes[1:]):
        stem=f'hole_{i:02d}';r['parameters'].update({stem+'_x':x,stem+'_y':y,stem+'_d':di})
        cylinder(r,[stem+'_x',stem+'_y',-1],stem+'_d','thickness+2','cut','Durchgang_'+stem)
    r['expected_volume_mm3']=(w*h-sum(math.pi*di*di/4 for x,y,di in allholes))*t
    r['bounds_mm']=[-w/2,-h/2,0,w/2,h/2,t];r['color_index']=36
    return r

def reference_carrier():
    """One real catalogue motor, three custom designs, seven occurrences. No machine location."""
    motor=motor_recipe()
    holes=[dict(x=x,y=y,d=5.5) for x in (-47.14/2,47.14/2) for y in (-47.14/2,47.14/2)]
    holes += [dict(x=x,y=y,d=6.6) for x in (-35,35) for y in (-35,35)]
    plate=flange_holder_recipe('D03_MOTOR_PLATE',90,90,12,38.3,holes,'Own design; motor interface pitch from CS-M catalogue p4, CAT2022 only')
    plate['parameters'].update(motor_pitch=47.14,pilot_clearance=38.3)
    # Bind central opening and inner hole pattern to interface parameters, not duplicate literals.
    plate['ops'][1]['diameter']='pilot_clearance'
    for i,(ix,iy) in enumerate(( (x,y) for x in (-1,1) for y in (-1,1) )):
        plate['ops'][i+2]['origin']=[f'{ix}*motor_pitch/2',f'{iy}*motor_pitch/2','-1']
    spacer=sleeve_recipe('D03_SPACER',14,6.6,50,'Own nominal motor-carrier spacer design')
    back=flange_holder_recipe('D03_INTERFACE_BLANK',90,90,12,26,
        [dict(x=x,y=y,d=6.6) for x in (-35,35) for y in (-35,35)],'Own interface blank: NO machine mounting holes or bearing seat determined')
    comps=[dict(id='motor',part_id=motor['id'],origin_mm=[0.,0.,12.],rotation=copy.deepcopy(I)),
           dict(id='motorplate',part_id=plate['id'],origin_mm=[0.,0.,0.],rotation=copy.deepcopy(I)),
           dict(id='interface_blank',part_id=back['id'],origin_mm=[0.,0.,-62.],rotation=copy.deepcopy(I))]
    for i,(x,y) in enumerate(( (x,y) for x in (-35,35) for y in (-35,35) )):
        comps.append(dict(id='spacer_%d'%i,part_id=spacer['id'],origin_mm=[float(x),float(y),-50.],rotation=copy.deepcopy(I)))
    return dict(parts=[motor,plate,spacer,back],components=comps,status='STANDALONE_REFERENCE_NOT_MACHINE_FITTED',
                machine_fit_verified=False,manufacturing_released=False,fasteners_included=False,
                missing=['machine attachment','coupling selection','bearing seat','stiffness check','screws and access','cable envelope'])

def validate_recipe(r):
    if isinstance(r,dict) and r.get('kind')=='supplier_mount10':
        from construction.nutmount10 import contract
        return contract(r)
    if isinstance(r,dict) and r.get('kind')=='supplier_envelope09':
        from construction.ballscrew09 import contract
        return contract(r)
    if isinstance(r,dict) and r.get('kind')=='stepped_housing04':
        from construction.housing04 import contract
        return contract(r)
    if not isinstance(r,dict) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',str(r.get('id',''))):raise ValueError('Invalid part ID')
    if not r.get('source'):raise ValueError('Missing source')
    required={'motor_envelope':('motor_length','body_w'),'sleeve':('length',),'flange_holder':('thickness',)}
    if r.get('kind') not in required:raise ValueError('Unsupported recipe type')
    p=r['parameters']
    for key in required[r['kind']]:
        if key not in p:raise ValueError('Missing parameter-test input: '+key)
        number(p[key],True)
    for k,v in p.items():
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',k):raise ValueError('Invalid parameter name')
        number(v)
    if not r.get('ops') or r['ops'][0]['operation']!='add':raise ValueError('First operation must create positive solid')
    for op in r['ops']:
        if op['kind'] not in ('box','cylinder') or op['operation'] not in ('add','cut'):raise ValueError('Unsupported recipe operation')
        if len(op['origin'])!=3:raise ValueError('Origin length')
        for v in op['origin']:arithmetic(v,p)
        dims=op['size'] if op['kind']=='box' else [op['diameter'],op['height']]
        if len(dims)!=(3 if op['kind']=='box' else 2):raise ValueError('Wrong dimension count')
        for x in dims:number(arithmetic(x,p),True)
    v=number(r['expected_volume_mm3'],True);bounds=[number(x) for x in r['bounds_mm']]
    if len(bounds)!=6 or any(bounds[i]>=bounds[i+3] for i in range(3)):raise ValueError('Invalid bounds')
    return dict(id=r['id'],expected_volume_mm3=v,bounds_mm=bounds,validation='ANALYTICAL_INPUTS_ONLY_NOT_CAD_VALIDITY')
