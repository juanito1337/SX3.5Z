"""Y-axis interface-plan entry, not a guessed assembly builder."""
from .axis_plan import compile_axis

def plan(data):
    return compile_axis('Y',data)


def build_native(session, nx, directory, log, evidence, data):
    from construction.axis_native03 import build_axis
    if data.get('axis') != 'Y':
        raise ValueError('Wrong axis module')
    return build_axis(session, nx, directory, log, evidence, data)
