"""Native-friendly nominal envelopes of real catalogue screw/nut families.

Not supplier original CAD. Nut raceway void is a DISPLAY simplification.
No mounting/kinematic release; assemblies remain in an explicit local study frame.
"""
import copy
import math
from engineering.ballscrew09 import (load_registry,load_cases,validate_cases,resolve_pair,
                                     number,turns_for_distance,SOURCE)
from construction.recipes03 import cylinder,I

KIND='supplier_envelope09'


def envelope_metrics(parameters,role):
    p=parameters
    d=number(p['outer_d'],positive=True);length=number(p['length'],positive=True)
    number(p['lead_mm'],positive=True)
    inner=0.
    if role=='nut':
        inner=number(p['visual_bore_d'],positive=True)
        if inner>=d:
            raise ValueError('Visual annulus has no wall')
    elif role!='screw':
        raise ValueError('Unknown envelope role')
    return dict(expected_volume_mm3=math.pi*(d*d-inner*inner)*length/4.,
                bounds_mm=[-d/2.,-d/2.,0.,d/2.,d/2.,length])


def _recipe(case,pair,role):
    n=pair['nut'];is_nut=role=='nut'
    part_id=('K09_NUT_' if is_nut else 'K09_RAW_SCREW_')+pair['id']
    p=dict(outer_d=float(n['outer_diameter_mm'] if is_nut else pair['screw_diameter_mm']),
           length=float(n['length_mm'] if is_nut else pair['stock_length_mm']),lead_mm=pair['screw_lead_mm'])
    if is_nut:p['visual_bore_d']=pair['screw_diameter_mm']
    provenance={'outer_d':'MANUFACTURER_TABLE_NOMINAL','length':'MANUFACTURER_TABLE_NOMINAL' if is_nut else 'SELECTED_CATALOGUE_RAW_STOCK_LENGTH',
                'lead_mm':'MANUFACTURER_TABLE_METADATA_NO_MODELLED_RACEWAY'}
    if is_nut:provenance['visual_bore_d']='DISPLAY_ONLY_EQUALS_NOMINAL_SCREW_DIAMETER_NOT_ACTUAL_BORE'
    r=dict(id=part_id,kind=KIND,role=role,design_case=copy.deepcopy(case),parameters=p,ops=[],
           source=SOURCE+'; April2025; page '+('8' if is_nut else '6'),
           catalogue=dict(manufacturer=pair['manufacturer'],article_number=pair['nut_article'] if is_nut else None,
                          configuration=('Rundmutter ' if is_nut else 'Unbearbeitete Spindel ')+pair['id'],
                          revision='April 2025',source_url=SOURCE),
           parameter_provenance=provenance,
           dimensions_status='TABLE_EXTERNAL_NOMINALS_INTERNAL_SHAPE_SIMPLIFIED',
           manufacturer_original_cad=False,machine_fit_verified=False,manufacturing_released=False,
           order_released=False,contact_geometry_verified=False,mass_properties_represent_physical_part=False,
           limitations='NO ball grooves, return paths, slits, seals or lube ports. Inner nut cylinder equals nominal screw diameter only for display; not a real bore, fit or contact solid. Raw screw has no bearing/drive ends.',
           color_index=36 if not is_nut else 32)
    if not is_nut:r['end_condition']='UNMACHINED'
    cylinder(r,[0,0,0],'outer_d','length',name='Katalog_Aussenhuelle_KEINE_ORIGINAL_CAD')
    if is_nut:
        cylinder(r,[0,0,-1],'visual_bore_d','length+2',op='cut',name='DARSTELLUNG_DURCHGANG_KEIN_HERSTELLERMASS')
    r.update(envelope_metrics(p,role))
    return r


def contract(recipe):
    if not isinstance(recipe,dict) or recipe.get('kind')!=KIND or recipe.get('role') not in ('screw','nut'):
        raise ValueError('Unknown supplier envelope recipe')
    case=recipe.get('design_case')
    pair=resolve_pair(case,load_registry())
    expected=_recipe(case,pair,recipe['role'])
    # Every construction field, claim and source must still match its locked origin.
    if recipe!=expected:
        raise ValueError('Supplier envelope recipe differs from its source/selected study; regenerate from the case')
    return dict(id=recipe['id'],**envelope_metrics(recipe['parameters'],recipe['role']),
                validation='ANALYTICAL_ENVELOPE_NOT_ACTUAL_NUT_CONTACT_OR_MASS')


def operation_volumes(recipe):
    contract(recipe);p=recipe['parameters']
    result=[dict(index=1,volume_after_mm3=math.pi*p['outer_d']**2*p['length']/4.)]
    if recipe['role']=='nut':
        result.append(dict(index=2,volume_after_mm3=recipe['expected_volume_mm3']))
    return result


def parameter_probes(recipe):
    contract(recipe);p=recipe['parameters'];role=recipe['role']
    changes=[('length',1.),('visual_bore_d',.2) if role=='nut' else ('outer_d',.2)]
    result=[]
    for name,delta in changes:
        changed=dict(p);changed[name]+=delta
        metrics=envelope_metrics(changed,role)
        result.append(dict(parameter=name,original_value=p[name],changed_value=changed[name],
                           changed_volume_mm3=metrics['expected_volume_mm3'],changed_bounds_mm=metrics['bounds_mm'],
                           scope='TEMPORARY_PARAMETRIC_TEST_RESTORE_CATALOGUE_NOMINAL'))
    return result


def reference_set(cases=None,registry=None):
    registry=load_registry() if registry is None else registry
    cases=load_cases() if cases is None else cases
    pairs=validate_cases(cases,registry);parts=[];assemblies=[]
    for case,pair in zip(cases,pairs):
        screw=_recipe(case,pair,'screw');nut=_recipe(case,pair,'nut')
        parts.extend([screw,nut]);w=pair['window']
        components=[dict(id=pair['id']+'_screw',role='screw',part_id=screw['id'],origin_mm=[0.,0.,0.],rotation=copy.deepcopy(I)),
                    dict(id=pair['id']+'_nut',role='nut',part_id=nut['id'],origin_mm=[0.,0.,w['nut_start_mm']],rotation=copy.deepcopy(I))]
        samples=[]
        for name,z in [('MIN',w['center_min_mm']),('REFERENCE',w['reference_center_mm']),('MAX',w['center_max_mm'])]:
            samples.append(dict(name=name,nut_center_mm=z,nut_start_mm=z-pair['nut']['length_mm']/2.,
                                nut_end_mm=z+pair['nut']['length_mm']/2.,
                                ideal_screw_turns_from_reference=turns_for_distance(z-w['reference_center_mm'],pair['screw_lead_mm']),
                                rotation_actuated_in_nx=False))
        assemblies.append(dict(id=pair['id'],resolved=pair,components=components,axial_samples=samples,
                               frame='STUDY_LOCAL_Z_NOT_MACHINE_COORDINATES',machine_fit_verified=False,
                               contact_checked=False,physical_drive_complete=False))
    return dict(schema='CNC_CATALOGUE_REFERENCES_09',status='STANDALONE_CATALOGUE_STUDIES_NOT_MACHINE_MOUNTED',
                parts=parts,pairs=assemblies,source_url=SOURCE,manufacturer_original_cad=False,
                bearing_support_verified=False,full_collision_checked=False,machine_fit_verified=False,
                manufacturing_released=False,order_released=False,
                limitations=['no selected bearing seats or finished shaft ends','no clamp/preload geometry','no motor/coupling',
                             'visual nut bore is NOT manufacturer bore','nominal envelope volumes are not physical material volumes',
                             'catalogue text tables read; drawing screenshot was not available','not a CNC X/Y/Z assignment'])
