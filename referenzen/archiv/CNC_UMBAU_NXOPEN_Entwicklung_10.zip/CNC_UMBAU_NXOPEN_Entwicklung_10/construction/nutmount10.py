"""Native recipe of nominal catalogue main bodies; no unknown fixing details.
Z = screw axis; Y = height above foot. Nut/block axial relation is a study input.
"""
import copy,math
from engineering import nutmount10 as eng
from engineering.ballscrew09 import number,SOURCE
from construction.recipes03 import box,cylinder,I
from construction.ballscrew09 import reference_set as pair_reference
KIND='supplier_mount10'


def metrics(p):
 w,h,L,d,a=[number(p[k],positive=True) for k in ('width','height','length','bore_d','axis_height')]
 if d>=w or d/2>=a or d/2>=h-a:raise ValueError('Bore breaks catalogue main-body envelope')
 return dict(expected_volume_mm3=(w*h-math.pi*d*d/4)*L,bounds_mm=[-w/2,-a,0.,w/2,h-a,L])


def block_recipe(article,registry=None):
 reg=eng.validate_registry(eng.load_registry() if registry is None else registry)
 if article not in reg['blocks']:raise ValueError('Unknown block article')
 b=reg['blocks'][article]
 p=dict(width=float(b['width_mm']),height=float(b['height_mm']),length=float(b['length_mm']),
        bore_d=float(b['bore_d_mm']),axis_height=float(b['axis_height_mm']))
 r=dict(id='K10_BLOCK_ISEL_'+article,kind=KIND,role='block',article_number=article,
     parameters=p,source=SOURCE+'; April2025; printed page9, foot mounting table',ops=[],
     manufacturer='isel Germany GmbH',color_index=31,
     dimensions_status='CATALOGUE_MAIN_BODY_NOMINALS_H1_INTERPRETATION_DRAWING_REVIEW_PENDING',
     parameter_provenance={'width':'TABLE_B','height':'TABLE_H','length':'TABLE_L','bore_d':'TABLE_M_H7',
       'axis_height':'TABLE_H1_INTERPRETED_AS_AXIS_TO_FOOT_DRAWING_NOT_VISUALLY_VERIFIED'},
     fit_labels={'bore':'H7','nut_exterior':'h7','numeric_tolerance_limits_resolved':False},
     manufacturer_original_cad=False,machine_fit_verified=False,manufacturing_released=False,
     order_released=False,physical_mass_verified=False,contact_verified=False,retention_verified=False,
     foot_holes_modelled=False,full_envelope_verified=False,
     limitations='Main rectangular body with nominal bore ONLY. No foot-hole coordinates, counterbores, clamping slits, screws, tension nut or lube fitting. No complete external envelope or mass/contact claim.')
 box(r,['-width/2','-axis_height',0],['width','height','length'],name='Katalog_Hauptkoerper_VEREINFACHT')
 cylinder(r,[0,0,-1],'bore_d','length+2','cut','Nennaufnahme_H7_KEINE_TOLERANZAUSWERTUNG')
 r.update(metrics(p));return r


def contract(r):
 if not isinstance(r,dict) or r.get('kind')!=KIND:raise ValueError('Not a supplier mount recipe')
 expected=block_recipe(r.get('article_number'))
 if r!=expected:raise ValueError('Mount recipe modified outside catalogue; regenerate after source review')
 return dict(id=r['id'],**metrics(r['parameters']),validation='SIMPLIFIED_KNOWN_MAIN_BODY_ONLY')


def operation_volumes(r):
 contract(r);p=r['parameters']
 return [dict(index=1,volume_after_mm3=p['width']*p['height']*p['length']),
         dict(index=2,volume_after_mm3=r['expected_volume_mm3'])]


def parameter_probes(r):
 contract(r);out=[]
 for k,delta in [('length',1.),('bore_d',.2),('axis_height',.25)]:
  p=copy.deepcopy(r['parameters']);p[k]+=delta;m=metrics(p)
  out.append(dict(parameter=k,changed_value=p[k],changed_volume_mm3=m['expected_volume_mm3'],
                  changed_bounds_mm=m['bounds_mm'],source_scope='TEMPORARY_PARAMETRIC_TEST_NOT_NEW_SUPPLIER_SIZE'))
 return out


def reference_set(cases=None,pairs=None,nuts=None,registry=None):
 resolved=eng.resolve_all(cases,pairs,nuts,registry);parts={};groups=[]
 def retain(r):
  if r['id'] in parts and parts[r['id']]!=r:raise ValueError('Conflicting recipes share an ID')
  parts[r['id']]=r
 for p in resolved:
  data=pair_reference(cases=[p['pair_case']],registry=nuts)
  roles={r['role']:r for r in data['parts']}
  block=block_recipe(p['block_article'],registry);roles['block']=block
  for r in roles.values():retain(r)
  s=p['samples'][1];comps=[]
  for role,z in [('screw',0.),('nut',s['nut_start_mm']),('block',s['block_start_mm'])]:
   comps.append(dict(id=role,role=role,part_id=roles[role]['id'],origin_mm=[0.,0.,z],rotation=copy.deepcopy(I)))
  groups.append(dict(id=p['id'],resolved=p,components=comps,
      assembly_relation='COAXIAL_MAIN_BODIES_WITH_EXPLICIT_STUDY_AXIAL_OFFSET',retention_verified=False))
 return dict(parts=list(parts.values()),groups=groups,native_execution=False,machine_fit_verified=False,
      order_released=False,manufacturing_released=False,full_collision_checked=False,
      original_supplier_cad=False,
      limitations=['No machine mounting','No foot fastening geometry','No clamping/retention details',
                   'Axial nut offset is a study choice','No bearings, machined ends, motor/coupling',
                   'H1 interpretation and entire drawing must be verified','No full physical envelope'])
