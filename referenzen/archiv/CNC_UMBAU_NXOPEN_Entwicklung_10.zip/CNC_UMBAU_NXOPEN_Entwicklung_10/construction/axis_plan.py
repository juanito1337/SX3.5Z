"""Compile reviewed data, not invented axis positions, into a placement plan.
This plan is NOT an NX assembly and NOT a manufacturing release.
"""
from pathlib import Path
from assembly.position_components import validated,vector
from engineering.sizing import positive

def compile_axis(axis,data):
    if axis not in 'XYZ' or len(axis)!=1:raise ValueError('Axis must be X,Y,Z')
    frame=data.get('frame',{})
    if frame.get('status')!='MEASURED_AND_REVIEWED' or not frame.get('evidence'):
        raise ValueError(axis+': measured/reviewed axis frame missing')
    R=frame.get('rotation_local_to_machine');t=frame.get('origin_mm')
    validated(R);vector(t)
    if data.get('nx_matrix_convention_validated') is not True:raise ValueError('NX matrix convention has not been checked')
    interfaces=data.get('interface_review',{})
    if interfaces.get('status')!='REVIEWED' or not interfaces.get('evidence'):raise ValueError('Interface review required')
    q=data.get('usable_travel_mm');positive(q,'usable travel')
    components=data.get('components',[])
    if not components:raise ValueError('No axis components')
    ids=set()
    for c in components:
        if c['id'] in ids:raise ValueError('Duplicate component id')
        ids.add(c['id']);vector(c['local_origin_mm']);validated(c['rotation_local_to_axis'])
        if not c.get('source') or c.get('dimensions_status') not in ('MANUFACTURER_CONFIRMED','MEASURED_AND_REVIEWED'):
            raise ValueError('Unconfirmed component dimensions: '+c['id'])
    if axis=='Z' and not data.get('holding_concept_review'):raise ValueError('Z holding concept review missing')
    return dict(axis=axis,frame=frame,components=components,usable_travel_mm=q,
                status='DATA_PLAN_ONLY',nx_geometry_created=False,manufacturing_released=False)
