"""Parametric parallel stepped bores in a rectangular nut/bearing carrier.
No CAD is created here. Native geometry is generated exclusively by NX Open.
All circular axes are local +Z. Distinct bores MUST have disjoint maximum
cross-sections; front/rear recesses of the same bore leave a positive shoulder.
These restrictions make the analytical volume contract exact (not voxel CAD).
"""
import copy
import math
import re
from cnc_nx.parts02 import arithmetic

KIND = 'stepped_housing04'
ID = re.compile(r'[A-Za-z][A-Za-z0-9_]*\Z')


def finite(value, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError('Finite numerical dimension required')
    v = float(value)
    if positive and v <= 0:
        raise ValueError('Positive dimension required')
    return v


def identifier(value):
    if not isinstance(value, str) or not ID.fullmatch(value):
        raise ValueError('Invalid identifier: ' + str(value))
    return value


def _operations(topology):
    rows = [dict(kind='box', operation='add', name='Gehaeuse_Rohkoerper',
                 origin=['-width/2', '-height/2', '0'], size=['width', 'height', 'thickness'])]
    for item in topology:
        k = 'hole_' + item['id']
        xy = [k + '_x', k + '_y']
        rows.append(dict(kind='cylinder', operation='cut', name=item['id'] + '_Durchgang',
                         origin=xy + ['-1'], diameter=k + '_through_d', height='thickness+2'))
        if item['front']:
            rows.append(dict(kind='cylinder', operation='cut', name=item['id'] + '_Frontstufe',
                             origin=xy + ['-1'], diameter=k + '_front_d', height=k + '_front_depth+1'))
        if item['rear']:
            rows.append(dict(kind='cylinder', operation='cut', name=item['id'] + '_Rueckstufe',
                             origin=xy + ['thickness-' + k + '_rear_depth'],
                             diameter=k + '_rear_d', height=k + '_rear_depth+1'))
    return rows


def _geometry(r, parameters=None):
    if r.get('kind') != KIND:
        raise ValueError('Not a stepped-housing recipe')
    identifier(r.get('id'))
    if not isinstance(r.get('source'), str) or not r['source'].strip():
        raise ValueError('Source required')
    if r.get('manufacturing_released') is not False or r.get('machine_fit_verified') is not False:
        raise ValueError('This family has no manufacturing/machine-fit release')
    p = r['parameters'] if parameters is None else parameters
    topo = r.get('bore_topology')
    if not isinstance(topo, list) or not topo:
        raise ValueError('Nonempty bore topology required')
    expected = {'width', 'height', 'thickness', 'minimum_wall'}
    seen = set()
    holes = []
    w, h, t, wall = [finite(p.get(n), True) for n in ('width', 'height', 'thickness', 'minimum_wall')]
    for item in topo:
        name = identifier(item.get('id'))
        if name in seen:
            raise ValueError('Duplicate hole identifier')
        seen.add(name)
        if type(item.get('front')) is not bool or type(item.get('rear')) is not bool:
            raise ValueError('Recess topology requires explicit booleans')
        k = 'hole_' + name
        fields = ['x', 'y', 'through_d']
        for side in ('front', 'rear'):
            if item[side]:
                fields += [side + '_d', side + '_depth']
        expected.update(k + '_' + field for field in fields)
        vals = {field: finite(p.get(k + '_' + field), field not in ('x', 'y')) for field in fields}
        diameter = vals['through_d']
        depth_sum = 0.0
        largest_d = diameter
        for side in ('front', 'rear'):
            if not item[side]:
                continue
            d, depth = vals[side + '_d'], vals[side + '_depth']
            if d <= diameter:
                raise ValueError(name + ': counterbore must exceed through diameter')
            depth_sum += depth
            largest_d = max(largest_d, d)
        if depth_sum > 0 and t - depth_sum < wall - 1e-9:
            raise ValueError(name + ': insufficient axial shoulder between recesses')
        if abs(vals['x']) + largest_d / 2 + wall > w / 2 + 1e-9 or abs(vals['y']) + largest_d / 2 + wall > h / 2 + 1e-9:
            raise ValueError(name + ': counterbore/hole breaks edge or minimum wall')
        for old in holes:
            clearance = math.hypot(vals['x'] - old['x'], vals['y'] - old['y']) - (largest_d + old['max_d']) / 2
            if clearance < wall - 1e-9:
                raise ValueError(name + ': bores/counterbores overlap or minimum ligament missing')
        holes.append(dict(vals, id=name, front=item['front'], rear=item['rear'], max_d=largest_d,
                          role=item.get('role', 'unspecified'), fit_note=item.get('fit_note', 'NO_FIT_RELEASE')))
    if set(p) != expected:
        raise ValueError('Missing or unknown geometry parameters: ' + repr(sorted(set(p) ^ expected)))
    if r.get('ops') != _operations(topo):
        raise ValueError('Noncanonical operations: regenerate the recipe, do not edit cutting formulas')
    return w, h, t, holes


def operation_volumes(r, parameters=None):
    w, h, t, holes = _geometry(r, parameters)
    volume = w * h * t
    rows = [dict(index=1, name='Gehaeuse_Rohkoerper', volume_after_mm3=volume,
                 removed_mm3=0.0)]
    for hole in holes:
        removed = math.pi * hole['through_d'] ** 2 * t / 4
        volume -= removed
        rows.append(dict(index=len(rows) + 1, name=hole['id'] + '_Durchgang',
                         removed_mm3=removed, volume_after_mm3=volume))
        for side, suffix in (('front', '_Frontstufe'), ('rear', '_Rueckstufe')):
            if hole[side]:
                removed = math.pi / 4 * (hole[side + '_d'] ** 2 - hole['through_d'] ** 2) * hole[side + '_depth']
                volume -= removed
                rows.append(dict(index=len(rows) + 1, name=hole['id'] + suffix,
                                 removed_mm3=removed, volume_after_mm3=volume))
    if volume <= 0 or not math.isfinite(volume):
        raise ValueError('No positive analytical solid remaining')
    return rows


def contract(r, parameters=None):
    w, h, t, holes = _geometry(r, parameters)
    return dict(id=r['id'], expected_volume_mm3=operation_volumes(r, parameters)[-1]['volume_after_mm3'],
                bounds_mm=[-w / 2, -h / 2, 0., w / 2, h / 2, t],
                minimum_wall_mm=(r['parameters'] if parameters is None else parameters)['minimum_wall'],
                hole_count=len(holes), validation='ANALYTICAL_INPUTS_ONLY_NOT_NX_EXECUTION',
                manufacturing_released=False, machine_fit_verified=False)


def make_recipe(spec):
    """Design values come from the supplied spec; there are no hidden bearing/nut defaults."""
    if not isinstance(spec, dict):
        raise ValueError('Specification must be a mapping')
    allowed = {'id', 'width', 'height', 'thickness', 'minimum_wall', 'source', 'holes',
               'purpose', 'limitations', 'material', 'dimension_sources', 'machine_fit_verified',
               'manufacturing_released'}
    if set(spec) - allowed:
        raise ValueError('Unknown specification field: ' + repr(sorted(set(spec) - allowed)))
    if spec.get('machine_fit_verified', False) is not False or spec.get('manufacturing_released', False) is not False:
        raise ValueError('No implicit release from a dimensional sketch')
    identifier(spec.get('id'))
    if not isinstance(spec.get('source'), str) or not spec['source'].strip():
        raise ValueError('Source/engineering rationale required')
    holes = spec.get('holes')
    if not isinstance(holes, list) or not holes:
        raise ValueError('At least one bore required')
    params = {key: finite(spec.get(key), True) for key in ('width', 'height', 'thickness', 'minimum_wall')}
    topology = []
    for hole in holes:
        permitted = {'id', 'x', 'y', 'through_d', 'front_d', 'front_depth', 'rear_d', 'rear_depth', 'role', 'fit_note'}
        if not isinstance(hole, dict) or set(hole) - permitted:
            raise ValueError('Unknown hole field')
        name = identifier(hole.get('id'))
        item = dict(id=name, role=str(hole.get('role', 'unspecified')),
                    fit_note=str(hole.get('fit_note', 'NO_FIT_RELEASE')))
        fields = ['x', 'y', 'through_d']
        for side in ('front', 'rear'):
            exists = (side + '_d' in hole, side + '_depth' in hole)
            if exists[0] != exists[1]:
                raise ValueError('Counterbore needs both diameter and depth')
            item[side] = all(exists)
            if item[side]:
                fields += [side + '_d', side + '_depth']
        params.update({'hole_' + name + '_' + f: finite(hole.get(f), f not in ('x', 'y')) for f in fields})
        topology.append(item)
    r = dict(id=spec['id'], kind=KIND, parameters=params, bore_topology=topology,
             ops=_operations(topology), source=spec['source'],
             purpose=spec.get('purpose', 'OWN_DESIGN_REFERENCE'),
             limitations=spec.get('limitations', 'No part selection, no machine-fit or strength validation'),
             dimensions_status='SOURCE_ANNOTATED_NOMINAL_REFERENCE_NOT_MACHINE_MEASURED',
             dimension_sources=copy.deepcopy(spec.get('dimension_sources', {})),
             material=spec.get('material', 'NOT_SELECTED'), color_index=36,
             machine_fit_verified=False, manufacturing_released=False, order_released=False)
    checked = contract(r)
    r['expected_volume_mm3'] = checked['expected_volume_mm3']
    r['bounds_mm'] = checked['bounds_mm']
    return r


def parameter_probes(r):
    """Preflight all probe dimensions before NX edits. Expected volumes are recomputed."""
    contract(r)
    p = r['parameters']
    variants = [('thickness', 1.)]
    for item in r['bore_topology']:
        k = 'hole_' + item['id']
        if item['front'] or item['rear']:
            side = 'front' if item['front'] else 'rear'
            total = sum(p[k + '_' + s + '_depth'] for s in ('front', 'rear') if item[s])
            room = p['thickness'] - p['minimum_wall'] - total
            # A deepening test must remain admissible; at the wall limit test shallowing.
            delta = min(.5, room / 2) if room > 1e-8 else -min(.5, p[k + '_' + side + '_depth'] / 2)
            variants.append((k + '_' + side + '_depth', delta))
            break
    rows = []
    for key, delta in variants:
        changed = dict(p)
        changed[key] += delta
        c = contract(r, changed)
        rows.append(dict(parameter=key, original_value=p[key], changed_value=changed[key],
                         changed_volume_mm3=c['expected_volume_mm3'], changed_bounds_mm=c['bounds_mm']))
    return rows


def bore_schedule(r):
    """Hole table is a model-input report, NOT a manufacturing drawing."""
    w, h, t, holes = _geometry(r)
    return [dict(part_id=r['id'], hole_id=x['id'], x_mm=x['x'], y_mm=x['y'],
                 through_d_mm=x['through_d'], through_length_mm=t,
                 front_d_mm=x.get('front_d'), front_depth_mm=x.get('front_depth'),
                 rear_d_mm=x.get('rear_d'), rear_depth_mm=x.get('rear_depth'),
                 fit_note=x['fit_note'], role=x['role'], source=r['source'],
                 manufacturing_released=False) for x in holes]
