"""Analytical contracts for genuinely machinable concept plates and sleeves.
Design dimensions are intentional proposals, NOT measured machine interfaces.
"""
import math,re
from engineering.sizing import positive,number

def validate_part(s):
    if not re.fullmatch('[A-Za-z][A-Za-z0-9_]{0,65}',str(s.get('id',''))):raise ValueError('Unsafe part ID')
    if s.get('status')!='DESIGN_PROPOSAL':raise ValueError('Only explicitly unapproved design proposals permitted here')
    if not str(s.get('source','')).strip():raise ValueError('Source/proposal owner required')
    kind=s.get('kind')
    if kind=='plate':
        w=positive(s['width_mm'],'width');h=positive(s['height_mm'],'height');t=positive(s['thickness_mm'],'thickness')
        d=number(s.get('center_bore_mm',0),'center_bore');holes=[]
        if d>=min(w,h):raise ValueError('Centre bore breaks blank boundary')
        if d:holes.append((0.,0.,d))
        for item in s.get('holes',[]):
            x=item['x_mm'];y=item['y_mm'];r=positive(item['diameter_mm'],'hole diameter')/2
            if isinstance(x,bool) or isinstance(y,bool):raise ValueError('Invalid centre')
            x=float(x);y=float(y)
            if not all(math.isfinite(v) for v in (x,y)):raise ValueError('Nonfinite hole position')
            if abs(x)+r>=w/2 or abs(y)+r>=h/2:raise ValueError('Hole intersects blank edge')
            holes.append((x,y,r*2))
        for j,(x,y,d1) in enumerate(holes):
            for u,v,d2 in holes[j+1:]:
                if math.hypot(x-u,y-v)<=(d1+d2)/2:raise ValueError('Holes overlap/touch')
        vol=w*h*t-sum(math.pi*dd*dd/4*t for _,_,dd in holes)
        lengths=[w,h,t]
    elif kind=='sleeve':
        d=positive(s['outer_mm'],'outer');b=positive(s['inner_mm'],'inner');L=positive(s['length_mm'],'length')
        if b>=d:raise ValueError('Negative wall')
        vol=math.pi/4*(d*d-b*b)*L;lengths=[d,d,L]
    else:raise ValueError('Unsupported part kind '+str(kind))
    return dict(id=s['id'],kind=kind,volume_mm3=vol,envelope_mm=lengths,
                manufacturing_released=False,machine_fit_verified=False)
