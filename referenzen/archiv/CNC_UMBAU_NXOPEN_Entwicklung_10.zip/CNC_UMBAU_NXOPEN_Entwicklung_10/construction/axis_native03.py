"""All three axes share the native pipeline; geometry/placement remains explicit reviewed input."""
import copy
from assembly.manifest03 import place_axis_component,idcheck
from validation.geometry03 import vec
from assembly.position_components import validated
from construction.recipes03 import validate_recipe

def validate_axis_design(data):
 if data.get('axis') not in ('X','Y','Z'):raise ValueError('X/Y/Z required')
 review=data.get('review',{})
 if review.get('status')!='MODEL_LAYOUT_REVIEWED' or not review.get('evidence'):raise ValueError('Reviewed axis layout missing')
 frame=data['frame'];vec(frame['origin_mm']);validated(frame['rotation'])
 if not frame.get('evidence'):raise ValueError('No axis-reference evidence')
 parts=data.get('custom_parts',[]);ids=set()
 for recipe in parts:
  validate_recipe(recipe)
  if recipe['id'] in ids:raise ValueError('Duplicate custom part')
  ids.add(recipe['id'])
 comps=data.get('components',[])
 if not comps:raise ValueError('No components; no native axis will be claimed')
 seen=set();used=set()
 for c in comps:
  idcheck(c['id'])
  if c['id'] in seen:raise ValueError('Duplicate axis occurrence')
  seen.add(c['id']);place_axis_component(frame,c)
  if c.get('part_id'):
   if c['part_id'] not in ids:raise ValueError('Unknown custom part reference')
   used.add(c['part_id'])
  else:
   if not c.get('path') or not c.get('sha256') or not c.get('source'):raise ValueError('Native purchase part/source identity missing')
   if c.get('kind')!='PURCHASE':raise ValueError('Axis module takes purchased or generated parts; original reuse belongs in reviewed machine manifest')
   if c.get('dimensions_status') not in ('CATALOGUE_REFERENCE','MANUFACTURER_CONFIRMED','MEASURED_AND_REVIEWED'):
    raise ValueError('Purchase dimensional evidence missing')
 if used!=ids:raise ValueError('Unused/unplaced custom part')
 # This is a study assembly, never an operational Z axis; missing holding design is reported.
 return dict(axis=data['axis'],components=len(comps),custom_parts=len(parts),manufacturing_released=False,
             holding_review=data.get('holding_concept_review','NOT_REVIEWED'))

def build_axis(session,nx,directory,log,evidence,data):
 from pathlib import Path
 from cnc_nx.native import NewParts
 from cnc_nx.build03 import RecipeBuilder
 from cnc_nx.assembly03 import build_manifest
 from cnc_nx.runtime import sha256_file,write_json_new
 from assembly.manifest03 import checked_file
 report=validate_axis_design(data)
 for c in data['components']:
  if not c.get('part_id'):checked_file(c['path'],c['sha256'])
 pd=Path(directory)/'NX_PARTS';pd.mkdir();owned=NewParts(session,nx,pd,log,evidence);made={};source={}
 for recipe in data.get('custom_parts',[]):
  part=owned.create(recipe['id']);builder=RecipeBuilder(part,nx,evidence)
  f,body,measured=builder.build_recipe(recipe);test=builder.test_parameter(session,recipe,f)
  made[recipe['id']]=owned.save(part);source[recipe['id']]=recipe['source']
  write_json_new(pd/(recipe['id']+'_Nachweis.json'),dict(geometry=measured,parameter_test=test,manufacturing_released=False))
 components=[]
 for item in data['components']:
  c=copy.deepcopy(item);pose=place_axis_component(data['frame'],c)
  if c.get('part_id'):
   path=made[c.pop('part_id')];c.update(path=path,sha256=sha256_file(path),kind='GENERATED',source=source[item['part_id']],dimensions_status='DESIGN_NOMINAL')
  c.update(pose,group='ACHSE_'+data['axis']);components.append(c)
 manifest=dict(schema='SX35Z_ASSEMBLY_3',review=data['review'],groups=['ACHSE_'+data['axis']],components=components,source_inventory=None)
 output=build_manifest(session,nx,directory,log,evidence,manifest)
 output['axis_precheck']=report;return output
