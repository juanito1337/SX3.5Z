"""Standalone study library; display positions are NOT machine attachment points."""
import copy
import csv
import json
import os
from pathlib import Path
from .housing04 import make_recipe, contract, bore_schedule, parameter_probes

I = [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]]


def load_catalogue(path=None):
    if path is None:
        path = Path(os.path.abspath(__file__)).parents[1] / 'config' / 'housings04.json'
    with open(path, encoding='utf-8-sig') as f:
        return json.load(f)


def check_cover_pair(parts, components):
    byid = {p['id']: p for p in parts}
    housing, cover = byid['D04_LAGERAUFNAHME'], byid['D04_LAGERDECKEL']
    contract(housing); contract(cover)
    hp, cp = housing['parameters'], cover['parameters']
    hc = next(c for c in components if c['id'] == 'bearing_housing')
    cc = next(c for c in components if c['id'] == 'cover')
    if hc['rotation'] != I or cc['rotation'] != I:
        raise ValueError('Reference cover pair only supports common identity frame')
    if hc['origin_mm'][:2] != cc['origin_mm'][:2] or abs(cc['origin_mm'][2]+cp['thickness']-hc['origin_mm'][2])>1e-9:
        raise ValueError('Cover face not on housing face')
    if (hp['width'],hp['height']) != (cp['width'],cp['height']):
        raise ValueError('Cover outline mismatch')
    for i in range(1,5):
        for suffix in ('_x','_y','_through_d'):
            key = 'hole_bolt'+str(i)+suffix
            if abs(hp[key]-cp[key])>1e-9:
                raise ValueError('Cover fastener pattern mismatch')
    if not hp['hole_seat_through_d'] < cp['hole_shaft_through_d'] < hp['hole_seat_front_d']:
        raise ValueError('Cover does not retain a nominal outer seat annulus while clearing shaft passage')
    return dict(status='RECIPE_INTERFACE_CONSISTENT_NOT_NX_CONTACT_TEST',
                coaxial_by_recipe=True,matching_fastener_patterns=True,
                front_pocket_depth_mm=hp['hole_seat_front_depth'],
                bearing_stack_selected=False,axial_preload_verified=False,manufacturing_released=False)


def reference_library(config=None):
    cfg = load_catalogue() if config is None else config
    if cfg.get('schema') != 'SX35Z_HOUSING_LIBRARY_4':
        raise ValueError('Wrong housing-library schema')
    for key in ('machine_fit_verified','manufacturing_released','contains_purchase_models'):
        if cfg.get(key) is not False:
            raise ValueError('This standalone library cannot grant a release or contain assumed purchase models')
    parts = [make_recipe(spec) for spec in cfg['parts']]
    if len(parts)!=4 or len({p['id'] for p in parts})!=4:
        raise ValueError('Expected four unique reference-part identifiers')
    byid = {p['id']: p for p in parts}
    if set(byid) != {'D04_MUTTERTRAEGER','D04_LAGERAUFNAHME','D04_LAGERDECKEL','R04_BF20_17_Y'}:
        raise ValueError('Reference library part identities changed')
    from .housing04 import finite
    spacing = finite(cfg['presentation_spacing_mm'],True)
    if spacing < max(p['parameters']['width'] for p in parts)+10:
        raise ValueError('Display layout spacing too small')
    components = [dict(id='nut_carrier',part_id='D04_MUTTERTRAEGER',origin_mm=[0.,0.,0.],rotation=copy.deepcopy(I)),
                  dict(id='bearing_housing',part_id='D04_LAGERAUFNAHME',origin_mm=[spacing,0.,0.],rotation=copy.deepcopy(I)),
                  dict(id='cover',part_id='D04_LAGERDECKEL',origin_mm=[spacing,0.,-byid['D04_LAGERDECKEL']['parameters']['thickness']],rotation=copy.deepcopy(I)),
                  dict(id='bf20_reference',part_id='R04_BF20_17_Y',origin_mm=[2*spacing,0.,0.],rotation=copy.deepcopy(I))]
    pair = check_cover_pair(parts,components)
    for recipe in parts:
        parameter_probes(recipe)
    return dict(parts=parts,components=components,cover_pair=pair,
                position_semantics='LIBRARY_DISPLAY_LAYOUT_NOT_MACHINE',
                status='STANDALONE_HOUSING_LIBRARY_NO_SELECTED_BEARING_OR_NUT',
                contains_purchase_models=False,machine_fit_verified=False,manufacturing_released=False,
                missing=['purchased nut and bearing selection','actual machine interfaces','fits/tolerances',
                         'strength and screw checks','bearing internal stack/preload','fasteners','exact collision/travel checks'])


def write_reports(directory, config=None):
    data = reference_library(config)
    directory = Path(directory)
    directory.mkdir(parents=True,exist_ok=False)
    checked = [dict(contract(p),source=p['source'],parameter_probe_plan=parameter_probes(p)) for p in data['parts']]
    summary = dict(data,native_execution=False,author_executed_nx=False,analytical_checks=checked)
    (directory/'Halterbibliothek_04.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    rows = [row for p in data['parts'] for row in bore_schedule(p)]
    with open(directory/'Bohrungstabelle_04.csv','x',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');writer.writeheader();writer.writerows(rows)
    bom = [dict(id=p['id'],quantity=1,kind='OWN_DESIGN' if p['id'].startswith('D') else 'BF20_DRAWING_REFERENCE',
                material=p['material'],source=p['source'],native_prt_created=False,manufacturing_released=False,
                limitations=p['limitations']) for p in data['parts']]
    with open(directory/'Stueckliste_Halter_04.csv','x',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(bom[0]),delimiter=';');writer.writeheader();writer.writerows(bom)
    return summary
