#!/usr/bin/env python3
"""Read ZIP central directories and hash files. Does not extract or execute anything.
Usage: python analysis/inspect_archives.py BF20_neu.zip BF20_alt.zip --output manifest.json
This is file analysis, NOT an alternative CAD environment.
"""
import argparse,hashlib,json
from pathlib import Path,PurePosixPath
from zipfile import ZipFile


def inspect(paths):
    rows=[]
    for path in paths:
        with ZipFile(path) as archive:
            for item in archive.infolist():
                if item.is_dir():continue
                if item.file_size>256*1024*1024:raise ValueError('Oversized archive member: '+item.filename)
                name=PurePosixPath(item.filename.replace('\\','/'))
                if name.is_absolute() or '..' in name.parts:raise ValueError('Unsafe archive member: '+item.filename)
                digest=hashlib.sha256()
                with archive.open(item) as f:
                    for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
                rows.append({'archive':Path(path).name,'path':item.filename,'bytes':item.file_size,
                             'sha256':digest.hexdigest(),'suffix':name.suffix.lower()})
    return rows


def main():
    parser=argparse.ArgumentParser();parser.add_argument('archives',nargs='+');parser.add_argument('--output',required=True)
    args=parser.parse_args();rows=inspect(args.archives)
    with open(args.output,'x',encoding='utf-8') as f:json.dump(rows,f,ensure_ascii=False,indent=2)
    print('Read '+str(len(rows))+' members; no extraction/execution.')

if __name__=='__main__':main()
