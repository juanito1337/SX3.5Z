"""Derive a prototype-local axis from explicitly selected audited faces.
A CAD measurement is NOT a measurement of the physical machine, and this module
never guesses a root-assembly transform from the raw NX orientation fields.
"""
import math
from validation.geometry03 import axis_frame,scalar

def derive_frames(audit,requests):
 if audit.get('schema')!='SX35Z_NX_AUDIT_1':raise ValueError('Wrong audit schema')
 if not requests:raise ValueError('Select cylinder and plane references first; no axes inferred from names')
 ps={p['id']:p for p in audit['prototypes']};out=[];seen=set()
 for req in requests:
  axis=req['axis']
  if axis not in ('X','Y','Z') or axis in seen:raise ValueError('Unique X/Y/Z requests required')
  seen.add(axis);p=ps[req['prototype_id']]
  if p.get('unit_mm') is not True:raise ValueError('Only audited millimetre prototypes supported')
  faces=[f for b in p.get('bodies',[]) for f in b.get('faces',[])]
  def find(jid,typ):
   matches=[f for f in faces if f.get('journal_id')==jid]
   if len(matches)!=1:raise ValueError('Missing/ambiguous face journal identifier: '+jid)
   d=matches[0].get('uf_data')
   if not d or d.get('uf_type_code')!=typ:raise ValueError('Selected face is not the required cylinder/plane')
   return d
  c=find(req['cylinder_face'],16);pl=find(req['plane_face'],22)
  sign=req.get('axis_sign')
  if isinstance(sign,bool) or sign not in (-1,1):raise ValueError('Explicit axis sign +1 or -1 required')
  radius=scalar(c['radius_part_units'])
  if radius<=0:raise ValueError('Invalid radius')
  frame=axis_frame(c['point_raw'],[sign*x for x in c['direction_raw']],pl['point_raw'],pl['direction_raw'],req['roll_hint'])
  frame.update(axis=axis,prototype_id=p['id'],prototype_path=p['path'],source_sha256=p.get('source_sha256_before'),
               cylinder_face=req['cylinder_face'],plane_face=req['plane_face'],diameter_mm=2*radius,
               coordinate_frame='PROTOTYPE_ABSOLUTE',physical_measurement_verified=False,
               use_for_machine_placement='REQUIRES_OCCURRENCE_REGISTRATION_AND_REVIEW')
  out.append(frame)
 return out

def candidate_faces(audit):
 rows=[]
 for p in audit['prototypes']:
  for b in p.get('bodies',[]):
   for f in b.get('faces',[]):
    d=f.get('uf_data')
    if d and d.get('uf_type_code') in (16,22):
     rows.append(dict(prototype_id=p['id'],prototype_name=p.get('name'),body_name=b.get('name'),face_journal_id=f.get('journal_id'),
                      type='CYLINDER' if d['uf_type_code']==16 else 'PLANE',data=d,unit_mm=p.get('unit_mm'),status='UNCLASSIFIED_GEOMETRY'))
 return rows
