"""Occurrence-derived BOM; no CAD imports, no inferred procurement approval.

Quantities mean active leaf occurrences, NOT number of solids or configured NX BOM
quantity attributes. Suppressed branches are outside the counted arrangement.
"""
from collections import defaultdict
from copy import deepcopy
import ntpath
import os
import re

SCHEMA = 'SX35Z_BOM_SNAPSHOT_7'
HASH = re.compile(r'^[0-9a-f]{64}$')


def path_key(path):
    """Compare saved file identities without realpath / resolving mounted drives."""
    if not isinstance(path, str) or not path or '\x00' in path:
        raise ValueError('Absolute native file path required')
    if ntpath.isabs(path) and (ntpath.splitdrive(path)[0] or path.startswith('\\\\')):
        return ntpath.normcase(ntpath.normpath(path))
    if not os.path.isabs(path):
        raise ValueError('Absolute file path required: ' + path)
    return os.path.normpath(path)


def _integer(value):
    return type(value) is int and value >= 0


def _unique(rows, key):
    result = {}
    for row in rows:
        value = row.get(key)
        if not isinstance(value, str) or not value or value in result:
            raise ValueError('Missing / duplicate ' + key)
        result[value] = row
    return result


def _tree(snapshot):
    if snapshot.get('schema') != SCHEMA:
        raise ValueError('Unsupported BOM snapshot schema')
    nodes = _unique(snapshot['occurrences'], 'path')
    protos = _unique(snapshot['prototypes'], 'id')
    root = snapshot.get('root')
    if root not in nodes or nodes[root].get('parent') is not None:
        raise ValueError('Exactly one valid root required')
    if len(nodes) > 100000:
        raise ValueError('More than 100000 occurrences; explicitly partition this BOM')
    children = defaultdict(list)
    for key, row in nodes.items():
        parent = row.get('parent')
        if key != root:
            if parent not in nodes:
                raise ValueError('Orphan occurrence: ' + key)
            children[parent].append(key)
    seen = set()
    stack = [root]
    while stack:
        key = stack.pop()
        if key in seen:
            raise ValueError('Cyclic occurrence tree')
        seen.add(key)
        stack.extend(children[key])
    if seen != set(nodes):
        raise ValueError('Disconnected / cyclic occurrence tree')
    return nodes, protos, children


def summarize(snapshot):
    """Count only identifiable leaves; preserve all uncertainty in the result.

    Pure replay never claims a live NX execution even if its source was live.
    No files are opened by this function. Disk checks belong to the live reader
    and, for assigned documents, to the registry validator.
    """
    nodes, protos, children = _tree(snapshot)
    issues = deepcopy(snapshot.get('issues', []))
    occurrence_rows = []
    grouped = {}
    counts = dict(active_leaf_occurrences=0, assembly_occurrences=0,
                  suppressed_branches=0, unresolved_occurrences=0)
    source_ok = True
    quantity_ok = not any(i.get('severity', 'ERROR') == 'ERROR' for i in issues)
    checked_protos = set()

    def issue(code, where, detail):
        issues.append(dict(code=code, where=where, message=detail, severity='ERROR'))

    def source_valid(p):
        nonlocal source_ok
        valid = True
        try:
            path_key(p.get('path'))
        except ValueError:
            valid = False
        before = p.get('sha256_before')
        valid = (valid and isinstance(before, str) and bool(HASH.fullmatch(before))
                 and before == p.get('sha256_after')
                 and p.get('modified_before') is False and p.get('modified_after') is False)
        if not valid:
            source_ok = False
            if p['id'] not in checked_protos:
                issue('UNBOUND_SOURCE', p['id'], 'Saved clean file identity is missing, changed or unverified')
        checked_protos.add(p['id'])
        return valid

    stack = [(snapshot['root'], 'ACTIVE')]
    while stack:
        key, inherited = stack.pop()
        n = nodes[key]
        out = dict(path=key, parent=n.get('parent'), name=n.get('name', ''),
                   prototype_id=n.get('prototype_id'), reference_set=n.get('reference_set'),
                   disposition='UNRESOLVED', row_id=None)
        occurrence_rows.append(out)
        state = inherited
        if inherited == 'ACTIVE':
            if n.get('suppressed') is True:
                state = 'SUPPRESSED'; counts['suppressed_branches'] += 1
            elif n.get('suppressed') is not False:
                state = 'UNKNOWN'
                issue('UNKNOWN_SUPPRESSION', key, 'Cannot decide whether this occurrence is active')
                quantity_ok = False
        if state == 'SUPPRESSED':
            out['disposition'] = 'EXCLUDED_SUPPRESSED'
        elif state == 'UNKNOWN':
            out['disposition'] = 'UNRESOLVED_BRANCH'
            counts['unresolved_occurrences'] += 1
        else:
            p = protos.get(n.get('prototype_id'))
            cc = n.get('children_count')
            if p is None or p.get('fully_loaded') is not True or not _integer(cc):
                state = 'UNKNOWN'; quantity_ok = False
                counts['unresolved_occurrences'] += 1
                issue('UNREAD_NODE', key, 'Prototype, full loading or child count not confirmed')
            else:
                clean_source = source_valid(p)
                if cc != len(children[key]):
                    quantity_ok = False
                    issue('CHILD_COUNT_MISMATCH', key, 'Reported children do not match snapshot tree')
                bc = p.get('body_count')
                solids = p.get('solid_body_count')
                sheets = p.get('non_solid_body_count')
                bodies_known = (_integer(bc) and _integer(solids) and _integer(sheets)
                                and solids + sheets == bc)
                if cc or children[key]:
                    counts['assembly_occurrences'] += 1
                    out['disposition'] = 'ASSEMBLY_CONTAINER_NOT_COUNTED'
                    if not bodies_known or bc:
                        quantity_ok = False
                        issue('MIXED_BODY_ASSEMBLY', key,
                              'Assembly has own/unknown geometry; manual decomposition required')
                elif not bodies_known or not bc:
                    quantity_ok = False
                    counts['unresolved_occurrences'] += 1
                    issue('EMPTY_OR_UNKNOWN_LEAF', key, 'Leaf geometry missing; not silently excluded')
                else:
                    counts['active_leaf_occurrences'] += 1
                    out['disposition'] = 'COUNTED_LEAF'
                    # Identical file names in different directories remain separate.
                    group_key = (path_key(p['path']), p['sha256_before']) if clean_source else ('unbound', p['id'])
                    if group_key not in grouped:
                        grouped[group_key] = dict(prototype_path=p.get('path'), prototype_sha256=p.get('sha256_before'),
                            name=p.get('name', ''), prototype_ids=[], occurrence_paths=[], quantity=0,
                            unit='Stueck', solid_body_count=solids, non_solid_body_count=sheets,
                            source_bound=clean_source, item_id=None, revision=None, kind='UNASSIGNED',
                            order_released=False, manufacturing_released=False)
                    row = grouped[group_key]
                    if (row['solid_body_count'], row['non_solid_body_count']) != (solids, sheets):
                        quantity_ok = False
                        issue('PROTOTYPE_CONFLICT', key, 'Same saved file has inconsistent body inventory')
                    row['quantity'] += 1
                    if p['id'] not in row['prototype_ids']:
                        row['prototype_ids'].append(p['id'])
                    row['occurrence_paths'].append(key)
        for child in sorted(children[key], reverse=True):
            stack.append((child, state))

    rows = sorted(grouped.values(), key=lambda r: (str(r['prototype_path']), str(r['prototype_sha256'])))
    by_occ = {o['path']: o for o in occurrence_rows}
    for index, row in enumerate(rows, 1):
        row['row_id'] = 'B%04d' % index
        row['occurrence_paths'].sort(); row['prototype_ids'].sort()
        for path in row['occurrence_paths']:
            by_occ[path]['row_id'] = row['row_id']
    counts['distinct_part_rows'] = len(rows)
    counts['occurrences_including_root'] = len(nodes)
    complete = quantity_ok and source_ok
    return dict(schema='SX35Z_BOM_REPORT_7', status='UNASSIGNED_ITEMS' if complete else 'INCOMPLETE_INVENTORY',
                source_origin=snapshot.get('origin', 'UNKNOWN'), native_read_in_this_run=False,
                inventory_complete=quantity_ok, source_binding_complete=source_ok,
                assignment_complete=False, order_released=False, manufacturing_released=False,
                source_files=[dict(path=protos[pid]['path'], sha256=protos[pid].get('sha256_before'))
                              for pid in sorted(checked_protos) if protos[pid].get('path')],
                rows=rows, occurrences=sorted(occurrence_rows, key=lambda r: r['path']),
                issues=issues, counts=counts,
                limitations=['Only active leaf occurrences in current arrangement; no PLM/BOM quantity override',
                             'A multi-body native part counts once per occurrence',
                             'No fit, safety, stock, price or procurement approval'])
