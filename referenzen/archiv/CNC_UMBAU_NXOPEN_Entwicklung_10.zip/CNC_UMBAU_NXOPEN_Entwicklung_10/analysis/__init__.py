"""Read-only model analysis."""
