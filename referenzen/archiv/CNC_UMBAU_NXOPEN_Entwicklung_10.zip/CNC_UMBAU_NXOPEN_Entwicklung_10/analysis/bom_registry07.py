"""Strict model/document identity links, never procurement/engineering approval."""
from copy import deepcopy
from pathlib import Path
import re
from analysis.bom07 import HASH, path_key
from cnc_nx.runtime import sha256_file

KINDS = {'UNASSIGNED', 'PURCHASE', 'MANUFACTURED', 'ORIGINAL', 'REFERENCE'}
ROLES = {'DRAWING_PDF': '.pdf', 'NX_DRAWING': '.prt', 'STEP': ('.step', '.stp'),
         'DXF': '.dxf', 'DATASHEET': '.pdf', 'SOURCE_DOCUMENT': None}


def validate_registry(registry):
    if registry.get('schema') != 'SX35Z_BOM_ASSIGNMENTS_7':
        raise ValueError('Unsupported BOM assignment schema')
    entries = registry.get('entries')
    if not isinstance(entries, list):
        raise ValueError('entries must be a list')
    pairs = set(); ids = set()
    for e in entries:
        pair = (path_key(e.get('prototype_path')), e.get('prototype_sha256'))
        if not isinstance(pair[1], str) or not HASH.fullmatch(pair[1]):
            raise ValueError('Valid model SHA256 required')
        if pair in pairs:
            raise ValueError('Duplicate model assignment')
        pairs.add(pair)
        kind = e.get('kind')
        if kind not in KINDS:
            raise ValueError('Unsupported assignment kind')
        if kind != 'UNASSIGNED':
            item = e.get('item_id'); rev = e.get('revision')
            if not isinstance(item, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,119}', item):
                raise ValueError('Explicit item ID required')
            if not isinstance(rev, str) or not rev.strip():
                raise ValueError('Explicit revision label required; use UNREVIEWED if unknown')
            if (item, rev) in ids:
                raise ValueError('Same item/revision assigned to more than one model file')
            ids.add((item, rev))
        for key in ('source_refs', 'documents', 'blockers'):
            if key in e and not isinstance(e[key], list):
                raise ValueError(key + ' must be a list')
        if any(not isinstance(x, str) or not x.strip() for x in e.get('source_refs', [])):
            raise ValueError('Source references must be nonempty text')
        for d in e.get('documents', []):
            if d.get('role') not in ROLES:
                raise ValueError('Unsupported document role')
            path_key(d.get('path'))
            if not isinstance(d.get('sha256'), str) or not HASH.fullmatch(d['sha256']):
                raise ValueError('Document SHA256 required')
            if d['role'] in ('DRAWING_PDF', 'NX_DRAWING', 'STEP', 'DXF'):
                if not isinstance(d.get('model_sha256'), str) or not HASH.fullmatch(d['model_sha256']):
                    raise ValueError('Drawing/export must be bound to model SHA256')
    return deepcopy(entries)


def check_file(path, digest, extension=None):
    """Checks bytes/identity only, not the engineering content of the file."""
    p = Path(path)
    if not p.is_absolute() or p.is_symlink() or not p.is_file():
        return 'MISSING_OR_INVALID_FILE'
    if extension:
        endings = (extension,) if isinstance(extension, str) else extension
        if p.suffix.lower() not in endings:
            return 'MISSING_OR_INVALID_FILE'
    try:
        if sha256_file(p) != digest:
            return 'CONTENT_CHANGED'
    except OSError:
        return 'MISSING_OR_INVALID_FILE'
    return 'FILE_IDENTITY_CHECKED_NOT_APPROVED'


def document_check(d, model_hash, verify_files):
    row = deepcopy(d)
    if not verify_files:
        row['status'] = 'NOT_RECHECKED'
    elif d['role'] in ('DRAWING_PDF', 'NX_DRAWING', 'STEP', 'DXF') and d['model_sha256'] != model_hash:
        row['status'] = 'STALE_MODEL_BINDING'
    else:
        row['status'] = check_file(d['path'], d['sha256'], ROLES[d['role']])
    return row


def apply_registry(report, registry, verify_files=True):
    if type(verify_files) is not bool:
        raise ValueError('verify_files must be boolean')
    entries = validate_registry(registry)
    r = deepcopy(report)
    r['file_check_mode'] = 'RECHECKED' if verify_files else 'NOT_RECHECKED'
    lookup = {(path_key(e['prototype_path']), e['prototype_sha256']): e for e in entries}
    used = set(); all_assigned = bool(r['rows']); docs_ok = True
    r['source_file_checks'] = []
    if verify_files:
        for src in r.get('source_files', []):
            status = check_file(src['path'], src['sha256'], '.prt')
            r['source_file_checks'].append(dict(src, status=status))
            if status != 'FILE_IDENTITY_CHECKED_NOT_APPROVED':
                r['source_binding_complete'] = False
                r['issues'].append(dict(code='SOURCE_FILE_NOT_CURRENT', where=src['path'],
                    severity='ERROR', message='Snapshot no longer matches saved native file: ' + status))
    for row in r['rows']:
        row['blockers'] = []; row['document_checks'] = []
        row['identity_status'] = 'UNASSIGNED'
        try:
            pair = (path_key(row['prototype_path']), row['prototype_sha256'])
        except ValueError:
            pair = (None, None)
        match = lookup.get(pair) if row['source_bound'] else None
        model_status = check_file(row['prototype_path'], row['prototype_sha256'], '.prt') if verify_files and row['source_bound'] else 'NOT_RECHECKED'
        row['model_file_check'] = model_status
        if verify_files and model_status != 'FILE_IDENTITY_CHECKED_NOT_APPROVED':
            row['source_bound'] = False
            r['source_binding_complete'] = False
            row['blockers'].append('MODEL_FILE_CHANGED' if model_status == 'CONTENT_CHANGED' else 'MODEL_FILE_NOT_VERIFIED')
            match = None
        if match is None or match['kind'] == 'UNASSIGNED':
            all_assigned = False
            row['blockers'].append('ITEM_ASSIGNMENT_MISSING')
            if pair[0] and any(k[0] == pair[0] and k[1] != pair[1] for k in lookup):
                row['blockers'].append('STALE_ASSIGNMENT')
            continue
        used.add(pair)
        for key in ('item_id', 'revision', 'kind', 'description', 'manufacturer', 'model', 'order_number',
                    'dimension_status', 'catalogue_id', 'material', 'source_refs'):
            row[key] = deepcopy(match.get(key))
        row['identity_status'] = 'MATCHED_FILE_AND_HASH'
        row['blockers'].extend(str(x) for x in match.get('blockers', []))
        if not match.get('source_refs'):
            row['blockers'].append('SOURCE_REFERENCE_MISSING')
        if not match.get('description'):
            row['blockers'].append('DESCRIPTION_MISSING')
        if match['revision'] == 'UNREVIEWED':
            row['blockers'].append('REVISION_UNREVIEWED')
        row['document_checks'] = [document_check(d, pair[1], verify_files) for d in match.get('documents', [])]
        if any(d['status'] != 'FILE_IDENTITY_CHECKED_NOT_APPROVED' for d in row['document_checks']):
            docs_ok = False; row['blockers'].append('DOCUMENT_IDENTITY_NOT_VERIFIED')
        if match['kind'] == 'MANUFACTURED':
            if not match.get('material'):
                row['blockers'].append('MATERIAL_NOT_SPECIFIED')
            if not any(d['role'] in ('DRAWING_PDF', 'NX_DRAWING') for d in row['document_checks']):
                docs_ok = False; row['blockers'].append('DRAWING_NOT_LINKED')
            row['blockers'].append('MANUFACTURING_REVIEW_REQUIRED')
        elif match['kind'] == 'PURCHASE':
            if not match.get('manufacturer') or not match.get('model'):
                row['blockers'].append('MANUFACTURER_OR_MODEL_MISSING')
            if not match.get('order_number'):
                row['blockers'].append('ORDER_IDENTIFIER_NOT_SPECIFIED')
            row['blockers'].extend(['MACHINE_FIT_NOT_CONFIRMED', 'PROCUREMENT_REVIEW_REQUIRED'])
        elif match['kind'] == 'REFERENCE':
            row['blockers'].append('REFERENCE_NOT_MACHINE_COMPONENT')
        row['blockers'] = sorted(set(row['blockers']))
        # Registry fields cannot switch these flags on.
        row['order_released'] = False; row['manufacturing_released'] = False
    r['unused_assignments'] = [dict(item_id=e.get('item_id'), revision=e.get('revision'),
        prototype_path=e['prototype_path'], prototype_sha256=e['prototype_sha256'])
        for pair, e in lookup.items() if pair not in used]
    r['assignment_complete'] = all_assigned
    r['document_link_complete'] = docs_ok and all_assigned and verify_files
    r['views'] = {k: [x['row_id'] for x in r['rows'] if x['kind'] == value]
                  for k, value in [('purchase', 'PURCHASE'), ('manufacture', 'MANUFACTURED'),
                                   ('original', 'ORIGINAL'), ('reference', 'REFERENCE'), ('unassigned', 'UNASSIGNED')]}
    r['counts']['assigned_part_rows'] = sum(row['kind'] != 'UNASSIGNED' for row in r['rows'])
    r['counts']['unassigned_part_rows'] = len(r['rows']) - r['counts']['assigned_part_rows']
    if not r['inventory_complete'] or not r['source_binding_complete']:
        r['status'] = 'INCOMPLETE_INVENTORY'
    elif not verify_files:
        r['status'] = 'PROVENANCE_NOT_RECHECKED'
    elif not all_assigned:
        r['status'] = 'UNASSIGNED_ITEMS'
    elif any(row['blockers'] for row in r['rows']):
        r['status'] = 'MAPPED_WITH_OPEN_ITEMS_NOT_RELEASED'
    else:
        r['status'] = 'BOM_TRACEABLE_NOT_RELEASED'
    r['order_released'] = False; r['manufacturing_released'] = False
    return r
