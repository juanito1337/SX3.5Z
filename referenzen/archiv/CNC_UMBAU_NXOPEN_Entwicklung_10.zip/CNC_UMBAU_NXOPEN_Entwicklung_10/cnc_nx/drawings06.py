"""NX-only native nominal drawing workflow. Author has NOT executed this in NX.

Creates OWN new parts from existing housing recipes. Drawings contain native
model-derived views and snapshot nominal schedules (not associative dimensions).
No source part is opened or edited. Native PDF errors NEVER fall back to a
source-based preview. See docs/API_PRUEFSTAND_06.md for reference limitations.
"""
import json
import math
import re
import textwrap
from pathlib import Path
from construction.library04 import reference_library
from exports.drawing06 import drawing_spec, note_lines
from exports.drawing_outputs06 import validate_pdf_file, write_dxf
from .runtime import write_json_new, sha256_file
from .native import NewParts, volume
from .build03 import RecipeBuilder, exact_bounds

NATIVE_EXECUTED_BY_AUTHOR = False


def require_declared(function, path, arity):
    """Require the live Python declaration for UF bindings, not a C# out-arg guess."""
    if not callable(function):
        raise RuntimeError('NX callable missing: '+path)
    name = path.rsplit('.',1)[-1]
    doc = str(getattr(function,'__doc__',''))
    matches = re.findall(r'\b'+re.escape(name)+r'\s*\(([^()]*)\)',doc)
    counts = [len([p for p in params.split(',') if p.strip()]) for params in matches]
    if arity not in counts:
        raise RuntimeError('Unsupported/missing live Python declaration for %s (%s inputs); see NX_API_Befund.json' % (path,arity))
    return function


def view_plan(s):
    # Fixed A3 layout intentionally fails for oversized configurations instead
    # of silently clipping. The user may subsequently implement scale selection.
    if s['width'] > 88 or s['height'] > 84 or s['thickness'] > 45:
        raise ValueError('Part exceeds the admitted drawing layout; revise layout explicitly')
    matrices = {'rear':[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]],
                'front':[[-1.,0.,0.],[0.,1.,0.],[0.,0.,-1.]],
                'side':[[0.,0.,1.],[0.,1.,0.],[-1.,0.,0.]]}
    return [dict(v,matrix=matrices[v['id']],size_mm=[s['thickness'] if v['id']=='side' else s['width'],s['height']])
            for v in s['projected_views']]


def validate_view_borders(bounds, size, centre, tolerance=.10):
    if len(bounds)!=4 or not all(math.isfinite(float(x)) for x in bounds):
        raise ValueError('Invalid native drawing-view bounds')
    x0,y0,x1,y1=map(float,bounds)
    if x1<=x0 or y1<=y0:raise ValueError('Empty or reversed native drawing view')
    if abs(x1-x0-size[0])>tolerance or abs(y1-y0-size[1])>tolerance:
        raise ValueError('Native view size/scale differs from recipe projection: '+repr(bounds))
    if abs((x0+x1)/2-centre[0])>tolerance or abs((y0+y1)/2-centre[1])>tolerance:
        raise ValueError('Native drawing view is not at its requested paper position')
    return list(map(float,bounds))


def check_expression_snapshot(expressions, recipe):
    for name,value in recipe['parameters'].items():
        if name not in expressions:raise RuntimeError('Missing drawing-driving expression '+name)
        actual=float(expressions[name].Value)
        if not math.isfinite(actual) or abs(actual-value)>1e-7:
            raise RuntimeError('Drawing snapshot no longer matches NX expression '+name)


def select_specs(job):
    if job.get('schema')!='SX35Z_DRAWING_JOB_06':raise ValueError('Wrong drawing job schema')
    if set(job)-{'schema','part_ids','export_pdf'}:raise ValueError('Unknown drawing job field')
    if type(job.get('export_pdf')) is not bool:raise ValueError('Explicit PDF export flag required')
    names=job.get('part_ids')
    if not isinstance(names,list) or not names or any(not isinstance(n,str) for n in names) or len(set(names))!=len(names):
        raise ValueError('Unique nonempty list of drawing part ids required')
    library={r['id']:r for r in reference_library()['parts']}
    if set(names)-set(library):raise ValueError('Unknown drawing part id')
    result=[]
    for name in names:
        r=library[name];s=drawing_spec(r);view_plan(s);result.append((r,s))
    return result


def export_native_pdf(part, sheet, path, evidence):
    path=Path(path)
    if path.exists() or path.is_symlink():raise FileExistsError(str(path))
    b=evidence.require('PlotManager.CreatePrintPdfbuilder',part.PlotManager.CreatePrintPdfbuilder)()
    try:
        b.Filename=str(path);b.Append=False
        b.AddWatermark=True;b.Watermark='ENTWURF - NICHT ZUR FERTIGUNG'
        evidence.require('PlotSourceBuilder.SetSheets',b.SourceBuilder.SetSheets)([sheet])
        evidence.require('PrintPDFBuilder.Commit',b.Commit)()
    finally:b.Destroy()
    # Absence/truncation is an error, not a successful drawing export.
    result=validate_pdf_file(path)
    result['origin']='NX_PrintPDFBuilder_IN_THIS_RUN'
    return result


def _matrix(nx, rows):
    m=nx.Matrix3x3()
    for k,v in zip(('Xx','Xy','Xz','Yx','Yy','Yz','Zx','Zy','Zz'),[x for r in rows for x in r]):setattr(m,k,v)
    return m


def _borders(draw,tag,evidence):
    fn=evidence.require('UF.Draw.AskViewBorders',getattr(draw,'AskViewBorders',None))
    doc=str(getattr(fn,'__doc__',''))
    matches=re.findall(r'\bAskViewBorders\s*\(([^()]*)\)',doc)
    arities={len([x for x in p.split(',') if x.strip()]) for p in matches}
    if 1 in arities:
        value=fn(tag)
    elif 2 in arities:
        value=[math.nan]*4;returned=fn(tag,value)
        if returned is not None:value=returned
    else:raise RuntimeError('AskViewBorders Python signature not supported; see API report')
    if len(value)!=4:raise RuntimeError('AskViewBorders did not return four drawing coordinates')
    return [float(v) for v in value]


def _notes(part,nx,evidence,lines,x,y,size=2.4):
    fn=evidence.require('Annotations.CreateDraftingNoteBuilder',part.Annotations.CreateDraftingNoteBuilder)
    b=fn(nx.Annotations.SimpleDraftingAid.Null)
    try:
        b.Origin.Plane.PlaneMethod=nx.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
        b.Origin.SetInferRelativeToGeometry(False)
        b.Origin.Anchor=nx.Annotations.OriginBuilder.AlignmentPosition.TopLeft
        b.Origin.OriginPoint=nx.Point3d(float(x),float(y),0.)
        b.Style.LetteringStyle.GeneralTextSize=float(size)
        b.Text.TextBlock.SetText(list(lines))
        obj=b.Commit()
        if obj is None:raise RuntimeError('No native drawing note created')
        return int(obj.Tag)
    finally:b.Destroy()


def make_sheet(part,nx,s,evidence,log):
    import NXOpen.UF
    draw=NXOpen.UF.UFSession.GetUFSession().Draw
    # Record live declarations BEFORE any drawing modifications.
    imported=evidence.require('UF.Draw.ImportView',getattr(draw,'ImportView',None))
    require_declared(imported,'UF.Draw.ImportView',4)
    init=evidence.require('UF.Draw.InitializeViewInfo',getattr(draw,'InitializeViewInfo',None))
    require_declared(init,'UF.Draw.InitializeViewInfo',0)
    update=evidence.require('UF.Draw.UpdateOneView',getattr(draw,'UpdateOneView',None))
    scale=evidence.require('UF.Draw.SetViewScale',getattr(draw,'SetViewScale',None))
    move=evidence.require('UF.Draw.MoveView',getattr(draw,'MoveView',None))
    plan=view_plan(s);saved=[]
    work=part.ModelingViews.WorkView
    for v in plan:
        evidence.require('View.Orient_matrix',work.Orient)(_matrix(nx,v['matrix']))
        savedview=evidence.require('ViewCollection.SaveAs',part.Views.SaveAs)(work,'D06_'+v['id'].upper(),False,False)
        if savedview is None:raise RuntimeError('No saved model view returned')
        actual=[getattr(savedview.Matrix,k) for k in ('Xx','Xy','Xz','Yx','Yy','Yz','Zx','Zy','Zz')]
        if any(abs(a-b)>1e-7 for a,b in zip(actual,[x for r in v['matrix'] for x in r])):
            raise RuntimeError('Saved model view has unexpected orientation')
        saved.append(savedview)
    # Legacy InsertSheet is still documented. Use only the actual present API;
    # no fake drawing or alternate CAD replacement if the binding differs.
    insert=evidence.require('DrawingSheets.InsertSheet',getattr(part.DrawingSheets,'InsertSheet',None))
    sheet=insert('D06_NENNMASSE_NICHT_FERTIGEN',nx.Drawings.DrawingSheet.StandardSheetSize.A3,
                 1.,1.,nx.Drawings.DrawingSheet.ProjectionAngleType.FirstAngle)
    if sheet is None:raise RuntimeError('No native drawing sheet created')
    evidence.require('DrawingSheet.Open',sheet.Open)()
    checked=[]
    for v,model in zip(plan,saved):
        info=init()
        tag=imported(sheet.Tag,model.Tag,list(v['origin_mm']),info)
        # Python output has to be a single tag, not an unexplained tuple.
        if isinstance(tag,(tuple,list)) or not tag:raise RuntimeError('Unexpected ImportView return; no guessed tag')
        scale(tag,1.);update(sheet.Tag,tag)
        bounds=_borders(draw,tag,evidence)
        centre=[(bounds[i]+bounds[i+2])/2 for i in (0,1)]
        reference=[v['origin_mm'][i]+v['origin_mm'][i]-centre[i] for i in (0,1)]
        move(tag,reference);update(sheet.Tag,tag)
        bounds=validate_view_borders(_borders(draw,tag,evidence),v['size_mm'],v['origin_mm'])
        checked.append(dict(v,tag=int(tag),actual_sheet_bounds_mm=bounds,
                            status='NATIVE_VIEW_EXTENTS_CHECKED_IN_THIS_RUN'))
        _notes(part,nx,evidence,[v['name']+' / 1:1'],v['origin_mm'][0]-42,v['origin_mm'][1]-v['size_mm'][1]/2-8,2.6)
    _notes(part,nx,evidence,['SX3.5Z - ENTWICKLUNG 06',s['part_id']],14,282,3.5)
    _notes(part,nx,evidence,note_lines(s),245,260,2.4)
    _notes(part,nx,evidence,['Keine native Schnittansicht. Stufen vollstaendig in Bohrungstabelle.',
                           'Maschinenpassung und Lager-/Kugelmutterauswahl sind offen.',
                           'Nach Parameter-/Geometrieaenderungen Zeichnungsjournal erneut ausfuehren.'],14,64,2.6)
    source=textwrap.wrap('Quelle: '+s['source'],170)
    _notes(part,nx,evidence,source+['Rezept SHA256: '+s['recipe_sha256'],
                                'NICHT ZUR FERTIGUNG - keine Passungs-/Toleranz-/Werkstofffreigabe.'],14,36,2.2)
    log('Native Ansichten und Nennmassnotizen angelegt: '+s['part_id'])
    return sheet,checked


def run(session,NXOpen,directory,log,evidence,config):
    import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Drawings,NXOpen.Annotations
    root=Path(directory)
    configfile=Path(__file__).resolve().parents[1]/'config'/'drawings06.json'
    with open(configfile,encoding='utf-8-sig') as f:job=json.load(f)
    items=select_specs(job)  # before first NX edit
    write_json_new(root/'Zeichnung_Eingaben_06.json',dict(job=job,recipes=[r for r,s in items],specifications=[s for r,s in items]))
    native=root/'NX_PARTS';native.mkdir();pdfdir=root/'NX_PDF';pdfdir.mkdir();dxfdir=root/'DXF_PRUEFKONTUREN';dxfdir.mkdir()
    owned=NewParts(session,NXOpen,native,log,evidence);rows=[]
    for recipe,s in items:
        log('Nennmasszeichnung: '+recipe['id'])
        part=owned.create(recipe['id']+'_D06_ENTWURF')
        b=RecipeBuilder(part,NXOpen,evidence)
        final,body,geometry=b.build_recipe(recipe)
        probe=b.test_parameter(session,recipe,final)
        check_expression_snapshot(b.expressions,recipe)
        # Save native solid first. If drafting fails this remains explicitly partial.
        partial=owned.save(part)
        write_json_new(root/(recipe['id']+'_GEOMETRIE_ZWISCHENSTAND.json'),dict(
            status='GEOMETRY_ONLY_DRAWING_NOT_YET_CREATED',native_execution=True,path=partial,
            geometry_check=geometry,parameter_test=probe,manufacturing_released=False))
        sheet,views=make_sheet(part,NXOpen,s,evidence,log)
        check_expression_snapshot(b.expressions,recipe)
        b.assert_volume(volume(part,final.GetBodies()[0],evidence),s['nominal_contract']['expected_volume_mm3'])
        bb=exact_bounds(part,final.GetBodies()[0],evidence)
        if any(abs(a-c)>.005 for a,c in zip(bb,s['nominal_contract']['bounds_mm'])):
            raise RuntimeError('Solid changed during drafting')
        nativepath=owned.save(part)
        exported=export_native_pdf(part,sheet,pdfdir/(recipe['id']+'_NX_ENTWURF.pdf'),evidence) if job['export_pdf'] else None
        dxf=write_dxf(dxfdir/(recipe['id']+'_PRUEFKONTUR_KEIN_CAM.dxf'),s)
        row=dict(part_id=recipe['id'],path=nativepath,sha256=sha256_file(nativepath),
                 recipe_sha256=s['recipe_sha256'],native_execution=True,sheet_tag=int(sheet.Tag),
                 native_views=views,geometry_check=geometry,parameter_test=probe,native_pdf=exported,
                 native_pdf_status='EXPORTED_HEADER_TRAILER_CHECKED' if exported else 'NOT_REQUESTED',
                 dxf_source_based=dxf,dimensions='SNAPSHOT_TABLE_NOT_ASSOCIATIVE_DIMENSION_OBJECTS',
                 native_section_created=False,manufacturing_released=False,
                 visual_drawing_review='PENDING_IN_TARGET_NX',open_items=s['open_items'])
        write_json_new(root/(recipe['id']+'_Zeichnungsnachweis.json'),row);rows.append(row)
    report=dict(status='NATIVE_NOMINAL_DRAWING_DRAFTS_CREATED_IN_THIS_RUN',native_execution=True,
                parts=rows,part_count=len(rows),sheet_count=len(rows),manufacturing_released=False,
                nx_manufacturing_drawings_created=False,final_cnc_assembly_created=False,
                dimensions_associative=False,notes_are_parameter_snapshot=True)
    write_json_new(root/'NX_Zeichnungsentwuerfe_06.json',report)
    log('Nennmass-Zeichnungsentwuerfe gespeichert. Visuelle Pruefung offen; KEINE Fertigungszeichnungen freigegeben.')
    return report
