"""Evidence completeness report. No CAD creation and no engineering release."""
import json
import os
from pathlib import Path
from .gates import axis_readiness
from .runtime import write_json_new


def run(session,NXOpen,directory,log,evidence,config):
    path=Path(os.path.abspath(__file__)).parents[1]/'config'/'interfaces.json'
    with open(path,encoding='utf-8-sig') as f:data=json.load(f)
    rows={a:axis_readiness(a,data.get(a,{})) for a in ('X','Y','Z')}
    report={'schema':'SX35Z_EVIDENCE_GATES_1','manufacturing_released':False,'axes':rows,
            'collision':'NOT_RUN','travel_positions':'NOT_RUN',
            'coaxiality':'NOT_RUN','actual_interface_geometry':'NOT_YET_CONFIRMED',
            'note':'Dateifelder pruefen nur Nachweisvollstaendigkeit. Kein bestandenes NX-/Maschinenpruefergebnis.'}
    write_json_new(Path(directory)/'Schnittstellenstatus.json',report)
    for a,r in rows.items():log(a+': '+r['status']+'; fehlende Eintraege: '+str(len(r['missing'])))
    return report
