"""Native draft-part library for NX 2406. NOT executed in NX by the author.
No read/write access to original machine; no automatic machine assembly.
All dimensions and hole coordinates are named, associative NX expressions.
"""
import ast,json,math,operator,os
from pathlib import Path
from construction.part_contracts import validate_part
from .native import NewParts,subtract,volume
from .runtime import write_json_new


def validate_batch(specs):
    if not isinstance(specs,list) or not specs:raise ValueError('Nonempty part specification list required')
    ids=set();rows=[]
    for s in specs:
        row=validate_part(s)
        if row['id'] in ids:raise ValueError('Duplicate part ID')
        ids.add(row['id']);rows.append(row)
    return rows


def arithmetic(text,values):
    """Limited scalar arithmetic, never eval() user input."""
    ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv}
    def visit(n):
        if isinstance(n,ast.Expression):return visit(n.body)
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)) and not isinstance(n.value,bool):return float(n.value)
        if isinstance(n,ast.Name) and n.id in values:return float(values[n.id])
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):return visit(n.operand)*(-1 if isinstance(n.op,ast.USub) else 1)
        if isinstance(n,ast.BinOp) and type(n.op) in ops:return ops[type(n.op)](visit(n.left),visit(n.right))
        raise ValueError('Unsupported formula '+text)
    result=visit(ast.parse(str(text),mode='eval'))
    if not math.isfinite(result):raise ValueError('Nonfinite formula')
    return result

class DraftBuilder:
    def __init__(self,part,nx,evidence):
        self.part=part;self.nx=nx;self.evidence=evidence;self.values={};self.expressions={};self.counter=0
        self.update=nx.SmartObject.UpdateOption.WithinModeling
    def expression(self,name,value):
        # Fetch a fresh NX Unit object for every expression, as in the previous fixes.
        make=self.evidence.require('Expressions.CreateNumberExpression',self.part.Expressions.CreateNumberExpression)
        exp=make('%s = %.12g'%(name,value),self.part.UnitCollection.GetBase('Length'))
        self.expressions[name]=exp;self.values[name]=float(value);return exp
    def point(self,coords):
        scalars=[]
        for text in coords:
            self.counter+=1
            name='cnc_hilfskoordinate_%04d'%self.counter
            exp=self.part.Expressions.CreateNumberExpression(name+' = '+str(text),self.part.UnitCollection.GetBase('Length'))
            create=self.evidence.require('Scalars.CreateScalarExpression',self.part.Scalars.CreateScalarExpression)
            scalars.append(create(exp,self.nx.Scalar.DimensionalityType.Length,self.update))
        create=self.evidence.require('Points.CreatePoint_smart',self.part.Points.CreatePoint)
        p=create(*scalars,self.update);p.Evaluate();p.Blank()
        got=[p.Coordinates.X,p.Coordinates.Y,p.Coordinates.Z]
        expected=[arithmetic(x,self.values) for x in coords]
        if any(abs(a-b)>1e-6 for a,b in zip(got,expected)):raise RuntimeError('Associative point not at intended coordinates')
        return p
    def block(self,coords,sizes,name):
        NX=self.nx
        b=self.evidence.require('Features.CreateBlockFeatureBuilder',self.part.Features.CreateBlockFeatureBuilder)(NX.Features.Feature.Null)
        try:
            b.Type=NX.Features.BlockFeatureBuilder.Types.OriginAndEdgeLengths
            b.SetOriginAndLengths(NX.Point3d(*[arithmetic(v,self.values) for v in coords]),*sizes)
            b.SetOrientation(NX.Vector3d(1.,0.,0.),NX.Vector3d(0.,1.,0.))
            b.OriginPoint=self.point(coords);b.ParentAssociativity=True
            b.BooleanOption.Type=NX.GeometricUtilities.BooleanOperation.BooleanType.Create
            f=b.CommitFeature();f.SetName(name);return self.one(f)
        finally:b.Destroy()
    def cylinder(self,coords,d,h,name):
        NX=self.nx;b=self.evidence.require('Features.CreateCylinderBuilder',self.part.Features.CreateCylinderBuilder)(NX.Features.Feature.Null)
        try:
            b.Type=NX.Features.CylinderBuilder.Types.AxisDiameterAndHeight
            b.Diameter.RightHandSide=d;b.Height.RightHandSide=h
            b.Origin=NX.Point3d(*[arithmetic(v,self.values) for v in coords]);b.Direction=NX.Vector3d(0.,0.,1.)
            direction=self.part.Directions.CreateDirection(NX.Point3d(0.,0.,0.),NX.Vector3d(0.,0.,1.),self.update)
            axis=self.part.Axes.CreateAxis(self.point(coords),direction,self.update);axis.Evaluate()
            b.Axis=axis;b.ParentAssociativity=True;b.ReverseDirection=False
            b.BooleanOption.Type=NX.GeometricUtilities.BooleanOperation.BooleanType.Create
            f=b.CommitFeature();f.SetName(name);return self.one(f)
        finally:b.Destroy()
    @staticmethod
    def one(f):
        bodies=f.GetBodies()
        if len(bodies)!=1:raise RuntimeError('Expected exactly one solid body')
        return f,bodies[0]
    def cut(self,target,tool,name):
        before=volume(self.part,target,self.evidence)
        f,body=subtract(self.part,self.nx,self.evidence,target,tool);f.SetName(name)
        if volume(self.part,body,self.evidence)>=before-1e-6:raise RuntimeError('Cut removed no material')
        return f,body
    def build(self,s):
        check=validate_part(s)
        if s['kind']=='sleeve':
            for name,key in [('cnc_aussen_d','outer_mm'),('cnc_innen_d','inner_mm'),('cnc_laenge','length_mm')]:self.expression(name,s[key])
            f,body=self.cylinder(['0','0','0'],'cnc_aussen_d','cnc_laenge','Huelse_Rohkoerper')
            _,tool=self.cylinder(['0','0','-1'],'cnc_innen_d','cnc_laenge+2','Bohrwerkzeug')
            f,body=self.cut(body,tool,'Durchgangsbohrung');adjust='cnc_laenge';base=s['length_mm']
        else:
            for name,key in [('cnc_breite','width_mm'),('cnc_hoehe','height_mm'),('cnc_dicke','thickness_mm')]:self.expression(name,s[key])
            f,body=self.block(['-cnc_breite/2','-cnc_hoehe/2','0'],['cnc_breite','cnc_hoehe','cnc_dicke'],'Plattenrohteil')
            holes=list(s.get('holes',[]))
            if s.get('center_bore_mm',0):holes.insert(0,dict(x_mm=0,y_mm=0,diameter_mm=s['center_bore_mm']))
            for i,h in enumerate(holes):
                stem='cnc_bohrung_%02d'%i
                for suffix,key in [('_x','x_mm'),('_y','y_mm'),('_d','diameter_mm')]:self.expression(stem+suffix,h[key])
                _,tool=self.cylinder([stem+'_x',stem+'_y','-1'],stem+'_d','cnc_dicke+2','Werkzeug_'+stem)
                f,body=self.cut(body,tool,'Durchgang_'+stem)
            adjust='cnc_dicke';base=s['thickness_mm']
        actual=volume(self.part,body,self.evidence);expected=check['volume_mm3']
        self.assert_volume(actual,expected)
        body.SetName(s['id']+'_ENTWURF_NICHT_FERTIGEN')
        return f,body,adjust,base,expected
    @staticmethod
    def assert_volume(actual,expected):
        if not math.isfinite(actual) or abs(actual-expected)>max(.002,expected*1e-5):
            raise RuntimeError('NX volume %.9g differs from analytical %.9g'%(actual,expected))


def run(session,NXOpen,directory,log,evidence,config):
    import NXOpen.Features,NXOpen.GeometricUtilities
    root=Path(os.path.abspath(__file__)).parents[1]
    # Read only the shipped design library; these are NOT production dimensions.
    with open(root/'config'/'design_parts.json',encoding='utf-8-sig') as f:data=json.load(f)
    specs=data['parts'];validate_batch(specs)  # Complete validation BEFORE first part creation.
    owned=NewParts(session,NXOpen,directory,log,evidence);rows=[]
    for s in specs:
        p=owned.create(s['id']+'_ENTWURF');b=DraftBuilder(p,NXOpen,evidence)
        final,body,key,base,nominal=b.build(s)
        mark=session.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible,'CNC02 Dicken-/Laengentest')
        try:
            b.expressions[key].RightHandSide=str(base+1)
            if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Parametric update failed')
            changed=volume(p,final.GetBodies()[0],evidence)
            b.assert_volume(changed,nominal*(base+1)/base)
        finally:
            b.expressions[key].RightHandSide=str(base)
            if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Failed to restore nominal draft size')
        actual_volume=volume(p,final.GetBodies()[0],evidence)
        b.assert_volume(actual_volume,nominal)
        filename=owned.save(p)
        row=dict(id=s['id'],filename=filename,status='NATIVE_DESIGN_DRAFT',
                 actual_nx_volume_mm3=actual_volume,parametric_thickness_test='PASSED_IN_THIS_NX_RUN',
                 machine_fit_verified=False,manufacturing_released=False,
                 source=s['source'],limitations=s.get('limitations',[]))
        rows.append(row);write_json_new(Path(directory)/(s['id']+'_Bericht.json'),row)
    report=dict(status='DRAFT_LIBRARY_ONLY_NOT_ASSEMBLED',parts=rows,native_execution=True,
                nx_manufacturing_drawings_created=False,manufacturing_released=False)
    write_json_new(Path(directory)/'NX_Sonderteilkonzepte.json',report)
    log('Entwurfsmuster gespeichert. KEINE Maschinenpositionen und KEINE Fertigungsfreigabe.')
    return report
