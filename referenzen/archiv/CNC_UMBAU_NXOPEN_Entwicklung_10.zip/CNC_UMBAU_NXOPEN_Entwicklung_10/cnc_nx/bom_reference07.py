"""Existing native reference-carrier build followed by a live read-only BOM.
No new geometry and no machine fit are introduced by this workflow.
"""
from collections import Counter
from pathlib import Path
from analysis.bom07 import path_key
from analysis.bom_registry07 import check_file
from construction.recipes03 import reference_carrier
from exports.bom07 import recipe_metadata
from cnc_nx.runtime import write_json_new


def reference_registry(built):
    if built.get('native_execution') is not True or built.get('status') != 'NATIVE_REFERENCE_ASSEMBLY_CREATED_IN_THIS_RUN':
        raise ValueError('A completed native reference build from this run is required')
    recipes = {r['id']:r for r in reference_carrier()['parts']}
    rows = built.get('parts',[])
    if len(rows)!=len(recipes) or {r['id'] for r in rows}!=set(recipes):
        raise ValueError('Reference prototype list does not match current recipe')
    expected=Counter(c['part_id'] for c in reference_carrier()['components'])
    if Counter(c['part_id'] for c in built.get('components',[]))!=expected:
        raise ValueError('Reference component list changed')
    entries=[]
    for row in rows:
        recipe=recipes[row['id']]
        if row.get('source')!=recipe['source']:
            raise ValueError('Reference source differs from current recipe')
        if check_file(row['path'],row['sha256'],'.prt')!='FILE_IDENTITY_CHECKED_NOT_APPROVED':
            raise ValueError('Generated native reference file missing/changed')
        entry=recipe_metadata(recipe)
        entry.update(prototype_path=row['path'],prototype_sha256=row['sha256'])
        entries.append(entry)
    return dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=entries,
        scope='GENERATED_REFERENCE_ONLY_NOT_MACHINE_SELECTION',review='DESIGN_REFERENCE_NOT_APPROVED')


def run(session,NXOpen,directory,log,evidence,config):
    from cnc_nx.build03 import build_reference
    from cnc_nx.bom07 import run_report
    built=build_reference(session,NXOpen,directory,log,evidence,config)
    displayed=session.Parts.Display
    if displayed is None or path_key(displayed.FullPath)!=path_key(built['assembly_file']):
        raise RuntimeError('Erzeugte Referenzbaugruppe ist nicht das angezeigte Teil. Keine Namenssuche.')
    registry=reference_registry(built)
    write_json_new(Path(directory)/'Referenzzuordnung_07.json',registry)
    expected=Counter(c['part_id'] for c in reference_carrier()['components'])
    report=run_report(session,directory,log,evidence,registry,expected_quantities=expected)
    actual=Counter({row['item_id']:row['quantity'] for row in report['rows']})
    if not report['inventory_complete'] or not report['source_binding_complete'] or not report['assignment_complete'] or actual!=expected:
        raise RuntimeError('Live-Referenzstueckliste stimmt nicht mit den sieben Rezeptvorkommen ueberein.')
    write_json_new(Path(directory)/'NX_Referenzmengenvergleich_07.json',dict(
        status='QUANTITIES_MATCHED_IN_THIS_NX_RUN',expected=dict(expected),actual=dict(actual),
        native_execution=True,manufacturing_released=False,order_released=False))
    return report
