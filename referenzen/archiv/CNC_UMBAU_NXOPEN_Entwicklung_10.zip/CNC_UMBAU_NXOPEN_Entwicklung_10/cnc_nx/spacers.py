"""Construct six separate BF20 source-reference parts in NX; NOT SX retrofit parts."""
import math
from pathlib import Path
from .spacer_data import SPACERS
from .core import sleeve_volume
from .native import NewParts,cylinder,subtract,volume
from .runtime import write_json_new


def run(session,NXOpen,directory,log,evidence,config):
    import NXOpen.Features
    import NXOpen.GeometricUtilities
    owned=NewParts(session,NXOpen,directory,log,evidence);rows=[]
    # Original SX geometry is neither read nor modified in this journal.
    for item in SPACERS:
        nominal=sleeve_volume(item['outer_d_mm'],item['inner_d_mm'],item['length_mm'])
        p=owned.create(item['id']+'_NUR_REFERENZ')
        expressions={}
        create=evidence.require('Expressions.CreateNumberExpression',p.Expressions.CreateNumberExpression)
        for name,val in [('ref_aussendurchmesser',item['outer_d_mm']),('ref_bohrungsdurchmesser',item['inner_d_mm']),('ref_laenge',item['length_mm'])]:
            expressions[name]=create('%s = %.12g'%(name,val),p.UnitCollection.GetBase('Length'))
        _,outer=cylinder(p,NXOpen,evidence,'ref_aussendurchmesser','ref_laenge',0,'Aussenhuelle_Nennmass')
        _,inner=cylinder(p,NXOpen,evidence,'ref_bohrungsdurchmesser','ref_laenge+2',-1,'Bohrwerkzeug_Nennmass')
        final,body=subtract(p,NXOpen,evidence,outer,inner);body.SetName(item['id']+'_KEINE_SX_FREIGABE')
        actual=volume(p,body,evidence)
        if not math.isfinite(actual) or abs(actual-nominal)>max(0.002,nominal*1e-5):
            raise RuntimeError('NX-Volumen stimmt nicht mit Nenngeometrie ueberein: '+item['id'])
        # Actual parametric-update test in NX, without altering any source part.
        mark=session.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible,'BF20 Referenz-Parametertest')
        base=item['length_mm'];restore_ok=False
        try:
            expressions['ref_laenge'].RightHandSide='%.12g'%(base+1.0)
            errors=session.UpdateManager.DoUpdate(mark)
            if errors:raise RuntimeError('NX-Update meldet Fehler im Laengentest')
            changed=volume(p,final.GetBodies()[0],evidence)
            wanted=sleeve_volume(item['outer_d_mm'],item['inner_d_mm'],base+1)
            if abs(changed-wanted)>max(0.002,wanted*1e-5):raise RuntimeError('Parameteraenderung wirkt nicht korrekt')
        finally:
            expressions['ref_laenge'].RightHandSide='%.12g'%base
            errors=session.UpdateManager.DoUpdate(mark)
            if errors:raise RuntimeError('Ruecksetzen auf Quellnennmass fehlgeschlagen')
            restore_ok=True
        restored=volume(p,final.GetBodies()[0],evidence)
        if abs(restored-nominal)>max(0.002,nominal*1e-5):raise RuntimeError('Rueckgesetztes Volumen falsch')
        warnings=[]
        for key,val in [('CNC_STATUS','BF20_REFERENZ_NICHT_SX_FREIGEGEBEN'),('CNC_QUELLE',item['source']),('CNC_PASSUNG',item['bore_fit'] or 'keine Angabe in Zeichnung'),('CNC_GRENZEN','Nur Nennzylinder; Kanten, Material, Toleranzen nicht freigegeben')]:
            try:p.SetUserAttribute(key,-1,val,NXOpen.Update.Option.Now)
            except Exception as exc:warnings.append(key+': '+str(exc))
        filename=owned.save(p)
        rows.append(dict(item,filename=filename,volume_mm3=restored,nx_parametric_length_test='PASSED',
                         source_nominal_restored=restore_ok,metadata_warnings=warnings,
                         sx_installation_checked=False,manufacturing_released=False))
        write_json_new(Path(directory)/(item['id']+'_Pruefung.json'),rows[-1])
    report={'status':'BF20_REFERENCE_PARTS_CREATED_IN_NX','not_cnc_conversion':True,
            'native_execution':True,'manufacturing_released':False,'parts':rows}
    write_json_new(Path(directory)/'NX_Referenzteile_BF20.json',report)
    log('Sechs BF20-Referenzhuelsen erzeugt; NICHT an SX3.5Z montiert und NICHT freigegeben.')
    return report
