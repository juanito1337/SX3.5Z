"""Nine *actual NX* classification probes. Author has NOT run this in NX.
No UF result numbers or undocumented call variants are guessed. A compatible
live Python declaration AND distinguishable measured probe cases are required.
All parts are new diagnostic geometry, not machine or purchase components.
"""
import math
from pathlib import Path
from validation.geometry03 import bounds,transform_bounds
from .interference05 import KernelBinding,temporary_occurrences
from .build03 import calibrate as calibrate_placement,add_component,exact_bounds
from .parts02 import DraftBuilder
from .native import NewParts,volume
from .runtime import write_json_new,sha256_file

I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
RZ=[[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]]
NATIVE_EXECUTED_BY_AUTHOR=False


def fixture_contracts():
    return {'cube':dict(bounds_mm=[0,0,0,10,10,10],volume_mm3=1000.),
            'hole':dict(bounds_mm=[0,0,0,20,20,20],volume_mm3=8000-500*math.pi),
            'rod':dict(bounds_mm=[-2,-2,0,2,2,20],volume_mm3=80*math.pi)}


def fixture_cases():
    rows=[]
    for name,t,state in [('gap',[12,0,0],'SEPARATE'),('touch',[10,0,0],'TOUCH'),
                         ('overlap',[5,0,0],'INTERSECT'),('coincident',[0,0,0],'INTERSECT')]:
        rows.append(dict(case=name,a='cube',b='cube',rotation=I,origin_mm=t,expected=state))
    for name,t,state in [('hole_clear',[10,10,0],'SEPARATE'),('hole_hit',[14,10,0],'INTERSECT')]:
        rows.append(dict(case=name,a='hole',b='rod',rotation=I,origin_mm=t,expected=state))
    for name,t,state in [('rotated_gap',[22,0,0],'SEPARATE'),('rotated_touch',[20,0,0],'TOUCH'),
                         ('rotated_overlap',[15,0,0],'INTERSECT')]:
        rows.append(dict(case=name,a='cube',b='cube',rotation=RZ,origin_mm=t,expected=state))
    return rows


def assert_bounds(actual,expected,tolerance=.005):
    a=bounds(actual);b=bounds(expected)
    if any(abs(x-y)>tolerance for x,y in zip(a,b)):
        raise RuntimeError('NX occurrence bounds mismatch: actual=%r expected=%r'%(a,b))


def insert_body(assembly,nx,evidence,path,name,body,R,t,mode,prototype_bounds):
    comp=add_component(assembly,nx,evidence,path,name,R,t,mode)
    occ=evidence.require('Component.FindOccurrence',comp.FindOccurrence)(body)
    if occ is None:raise RuntimeError('No solid occurrence: '+name)
    bb=exact_bounds(assembly,occ,evidence)
    assert_bounds(bb,transform_bounds(prototype_bounds,R,t))
    return occ,bb


def _fixtures(session,nx,directory,log,evidence):
    directory.mkdir(exist_ok=False);owner=NewParts(session,nx,directory,log,evidence)
    result={};contracts=fixture_contracts()
    for key in ('cube','hole','rod'):
        part=owner.create('PRUEF05_'+key.upper());b=DraftBuilder(part,nx,evidence)
        if key=='cube':final,body=b.block(['0','0','0'],['10','10','10'],'PRUEF_Wuerfel10')
        elif key=='hole':
            final,body=b.block(['0','0','0'],['20','20','20'],'PRUEF_Block20')
            _,tool=b.cylinder(['10','10','-1'],'10','22','PRUEF_Durchbohrung')
            final,body=b.cut(body,tool,'PRUEF_Block_mit_Durchgang')
        else:final,body=b.cylinder(['0','0','0'],'4','20','PRUEF_Stift4')
        if not body.IsSolidBody:raise RuntimeError('Calibration body is not a solid')
        bb=exact_bounds(part,body,evidence);v=volume(part,body,evidence)
        assert_bounds(bb,contracts[key]['bounds_mm']);b.assert_volume(v,contracts[key]['volume_mm3'])
        body.SetName('DIAGNOSE_KEIN_MASCHINENTEIL_'+key)
        path=owner.save(part)
        result[key]=dict(part=part,body=body,path=path,bounds_mm=bb,volume_mm3=v,sha256=sha256_file(path))
    return result


def calibrate_backend(session,nx,directory,log,evidence):
    """Returns only after all nine native probes and symmetric queries pass.
    Any unsupported signature, result, placement or rollback aborts the journal.
    """
    import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Assemblies,NXOpen.UF
    directory=Path(directory);directory.mkdir(exist_ok=False)
    uf=NXOpen.UF.UFSession.GetUFSession()
    binding=KernelBinding(uf,evidence)  # live help checked BEFORE creating test geometry
    mode=calibrate_placement(session,nx,directory/'Matrix',log,evidence)
    fixtures=_fixtures(session,nx,directory/'Pruefteile',log,evidence)
    ad=directory/'Pruefbaugruppe';ad.mkdir()
    owner=NewParts(session,nx,ad,log,evidence);assembly=owner.create('KOLLISIONSTEST_05_KEINE_MASCHINE')
    rows=[];completed=False
    try:
        for case in fixture_cases():
            log('NX-Kollisionsprobe: '+case['case'])
            a=fixtures[case['a']];b=fixtures[case['b']]
            with temporary_occurrences(session,nx,assembly,owner,evidence):
                oa,ba=insert_body(assembly,nx,evidence,a['path'],'A',a['body'],I,[0,0,0],mode,a['bounds_mm'])
                ob,bb=insert_body(assembly,nx,evidence,b['path'],'B',b['body'],case['rotation'],case['origin_mm'],mode,b['bounds_mm'])
                code=binding.raw(oa.Tag,ob.Tag);reverse=binding.raw(ob.Tag,oa.Tag)
                rows.append(dict(case=case['case'],expected=case['expected'],raw_code=code,reverse_raw_code=reverse,
                                 measured_bounds_a_mm=ba,measured_bounds_b_mm=bb))
        binding.complete(rows);completed=True
    finally:
        write_json_new(directory/'NX_Kollisionskalibrierung_05.json',dict(
            status='CALIBRATED_IN_THIS_NX_RUN' if completed else 'FAILED_OR_INCOMPLETE',
            native_execution=True,passed=completed,probes=rows,method=binding.name,
            numeric_return_codes={str(k):v for k,v in (binding.mapping or {}).items()},
            fixture_contracts=fixture_contracts(),matrix_convention=mode,
            minimum_distance_measured=False,manufacturing_released=False,
            note='Only coarse body classification. No clearance distance or safety release.'))
    # Retain an explicit diagnostic scene: three pair examples, not machine geometry.
    for name,key,t in [('HOLE','hole',[0,0,0]),('ROD_CLEAR','rod',[10,10,0]),
                       ('TOUCH_A','cube',[40,0,0]),('TOUCH_B','cube',[50,0,0]),
                       ('HIT_A','cube',[80,0,0]),('HIT_B','cube',[85,0,0])]:
        f=fixtures[key];insert_body(assembly,nx,evidence,f['path'],name,f['body'],I,t,mode,f['bounds_mm'])
    path=owner.save(assembly)
    report=dict(status='NATIVE_COLLISION_SELFTEST_PASSED_IN_THIS_RUN',native_execution=True,
                probe_count=len(rows),query_count=2*len(rows),assembly_file=path,assembly_sha256=sha256_file(path),
                matrix_convention=mode,physical_machine_verified=False,manufacturing_released=False,
                prototype_files={k:{n:v for n,v in f.items() if n not in ('part','body')} for k,f in fixtures.items()},
                note='Dummy diagnostic solids only. Does not validate a machine or other NX versions.')
    write_json_new(directory/'NX_Kollisionstest_05.json',report)
    log('Neun native Klassifikationsproben bestanden; Diagnosebaugruppe: '+path)
    return binding,mode,report


def run(session,NXOpen,directory,log,evidence,config):
    _,_,report=calibrate_backend(session,NXOpen,Path(directory)/'Kalibrierung05',log,evidence)
    write_json_new(Path(directory)/'NX_Kollisionstest_05.json',report)
    return report
