"""Dimensions transcribed from supplied BF20 drawings, not from the common BOM.
Nominal geometry only. H7 is documented, not an invented numerical tolerance.
No inference of suitability for SX3.5Z.
"""
SPACERS = [
 {'id':'BF20_NEU_09_X','outer_d_mm':16,'inner_d_mm':10,'length_mm':15,'bore_fit':'H7','source':'BF20_neu/BF20_neu.pdf, PDF-Seite 8, BF20-09'},
 {'id':'BF20_NEU_11_Y','outer_d_mm':16,'inner_d_mm':10,'length_mm':22,'bore_fit':'H7','source':'BF20_neu/BF20_neu.pdf, PDF-Seite 10, BF20-11'},
 {'id':'BF20_NEU_14_Z','outer_d_mm':20,'inner_d_mm':10,'length_mm':11.5,'bore_fit':'H7','source':'BF20_neu/BF20_neu.pdf, PDF-Seite 13, BF20-14'},
 {'id':'BF20_ALT_09_X','outer_d_mm':13.4,'inner_d_mm':10,'length_mm':11.3,'bore_fit':'H7','source':'BF20_alt/BF20alt_Paulimot_HBM.pdf, PDF-Seite 8, BF20-09'},
 {'id':'BF20_ALT_11_Y','outer_d_mm':13.4,'inner_d_mm':10,'length_mm':15,'bore_fit':'H7','source':'BF20_alt/BF20alt_Paulimot_HBM.pdf, PDF-Seite 10, BF20-11'},
 {'id':'BF20_ALT_14_Z','outer_d_mm':20,'inner_d_mm':17,'length_mm':11.3,'bore_fit':None,'source':'BF20_alt/BF20alt_Paulimot_HBM.pdf, PDF-Seite 13, BF20-14'}
]
