"""Native catalogue envelope pairs, source-bound and never a final CNC axis.

All CAD creation is NX Open via existing adapters. This module has NOT been run
in NX by the author. Standalone study frames are not machine coordinates.
"""
from collections import Counter
from pathlib import Path
import os

from construction.ballscrew09 import reference_set,contract
from construction.recipes03 import I
from engineering.ballscrew09 import ROOT,load_registry,load_cases
from validation.geometry03 import bounds,transform_bounds
from cnc_nx.build03 import RecipeBuilder,calibrate,add_component,exact_bounds
from cnc_nx.native import NewParts
from cnc_nx.runtime import sha256_file,write_json_new
from cnc_nx.interference05 import temporary_occurrences

NATIVE_EXECUTED_BY_AUTHOR=False


def capture_sources(paths):
    if not paths:raise ValueError('No catalogue/configuration sources supplied')
    rows=[]
    for raw in paths:
        p=Path(os.path.abspath(raw))
        if not p.is_file() or p.is_symlink():raise ValueError('Missing or symbolic source: '+str(p))
        rows.append(dict(path=str(p),sha256=sha256_file(p)))
    return rows


def verify_sources(rows):
    if not rows:raise ValueError('Empty source guard')
    for row in rows:
        p=Path(row['path'])
        if not p.is_file() or p.is_symlink() or sha256_file(p)!=row['sha256']:
            raise RuntimeError('Catalogue/configuration changed during generation: '+str(p))
    return True


def _assert_bounds(actual,expected):
    a=bounds(actual);b=bounds(expected)
    if any(abs(x-y)>.005 for x,y in zip(a,b)):
        raise RuntimeError('Unexpected nominal envelope bounds: '+repr(a)+' / '+repr(b))
    return a


def validate_axial_sample(pair,sample,screw_bounds,nut_bounds):
    if sample not in pair['axial_samples']:raise ValueError('Unrecognized or changed axial sample')
    spec=pair['resolved'];d=spec['screw_diameter_mm'];D=spec['nut']['outer_diameter_mm']
    shaft=_assert_bounds(screw_bounds,[-d/2,-d/2,0,d/2,d/2,spec['stock_length_mm']])
    nut=_assert_bounds(nut_bounds,[-D/2,-D/2,sample['nut_start_mm'],D/2,D/2,sample['nut_end_mm']])
    return dict(sample=sample['name'],status='PASSED_NOMINAL_ENVELOPE_POSITION',
                measured_screw_bounds_mm=shaft,measured_nut_bounds_mm=nut,
                measured_nut_center_mm=(nut[2]+nut[5])/2.,
                measured_left_axial_space_mm=nut[2]-shaft[2],
                measured_right_axial_space_mm=shaft[5]-nut[5],
                collision_checked=False,physical_machine_verified=False,
                scope='AXIAL_ENVELOPE_PLACEMENT_NOT_BALL_CONTACT_OR_REAL_MACHINE_TRAVEL')


def source_registry(data,rows):
    from analysis.bom_registry07 import check_file,validate_registry
    recipe_map={r['id']:r for r in data['parts']}
    if len(rows)!=len(recipe_map) or {x['id'] for x in rows}!=set(recipe_map):
        raise ValueError('Catalogue prototype list mismatch')
    entries=[]
    for row in rows:
        r=recipe_map[row['id']]
        if row.get('source')!=r['source']:raise ValueError('Wrong source for generated catalogue part')
        if check_file(row['path'],row['sha256'],'.prt')!='FILE_IDENTITY_CHECKED_NOT_APPROVED':
            raise ValueError('New native catalogue file missing or changed')
        n=r['role']=='nut';catalogue=r['catalogue']
        entries.append(dict(prototype_path=row['path'],prototype_sha256=row['sha256'],item_id=r['id'],
            revision='CATALOGUE_APR2025_ENVELOPE09',kind='PURCHASE',
            description=('Katalog-Rundmutter-Huelle' if n else 'Unbearbeiteter Spindelrohling-Huelle'),
            manufacturer=catalogue['manufacturer'],model=catalogue['configuration'],
            order_number=catalogue['article_number'],dimension_status=r['dimensions_status'],
            material='16MnCr5' if n else 'CF 53',source_refs=[r['source']],documents=[],
            blockers=['CATALOGUE_CANDIDATE_NOT_MACHINE_SELECTION','NO_ORIGINAL_SUPPLIER_CAD',
                      'INTERNAL_GEOMETRY_SIMPLIFIED_NO_CONTACT_CHECK','END_MACHINING_AND_SUPPORTS_NOT_DEFINED',
                      'MANUFACTURER_DRAWING_VISUAL_VERIFICATION_OUTSTANDING'],
            order_released=False,manufacturing_released=False))
    result=dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=entries,
                scope='GENERATED_CATALOGUE_REFERENCES_NOT_MACHINE_ORDER_LIST',review='NOT_APPROVED')
    validate_registry(result)
    return result


def _insert(assembly,nx,evidence,item,made,bodies,recipes,mode,origin=None):
    t=item['origin_mm'] if origin is None else origin
    comp=add_component(assembly,nx,evidence,made[item['part_id']],item['id'],item['rotation'],t,mode)
    occ=evidence.require('Component.FindOccurrence',comp.FindOccurrence)(bodies[item['part_id']])
    if occ is None:raise RuntimeError('No catalogue occurrence body: '+item['id'])
    bb=exact_bounds(assembly,occ,evidence)
    _assert_bounds(bb,transform_bounds(contract(recipes[item['part_id']])['bounds_mm'],item['rotation'],t))
    return bb


def run(session,NXOpen,directory,log,evidence,config):
    import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Assemblies
    root=Path(directory)
    sources=capture_sources([ROOT/'config'/'ballscrews09.json',ROOT/'reference'/'Quellen_09.json',
                             ROOT/'engineering'/'ballscrew09.py',ROOT/'construction'/'ballscrew09.py'])
    data=reference_set(cases=load_cases(),registry=load_registry())
    for r in data['parts']:contract(r)
    mode=calibrate(session,NXOpen,root/'_Kalibrierung',log,evidence)
    pd=root/'NX_PARTS';ad=root/'NX_ASSEMBLY';pd.mkdir();ad.mkdir()
    po=NewParts(session,NXOpen,pd,log,evidence);ao=NewParts(session,NXOpen,ad,log,evidence)
    made={};bodies={};rows=[];pairs=[];complete=False
    recipes={r['id']:r for r in data['parts']}
    try:
        for r in data['parts']:
            verify_sources(sources);log('Katalogbauteil: '+r['id'])
            part=po.create(r['id']);builder=RecipeBuilder(part,NXOpen,evidence)
            final,body,measurement=builder.build_recipe(r)
            param=builder.test_parameter(session,r,final);body=final.GetBodies()[0]
            warnings=[]
            try:
                dm=session.DisplayManager.NewDisplayModification()
                try:dm.ApplyToAllFaces=True;dm.NewColor=int(r['color_index']);dm.Apply([body])
                finally:dm.Dispose()
            except Exception as exc:warnings.append('Farbe nicht angewandt: '+str(exc))
            path=po.save(part);made[r['id']]=path;bodies[r['id']]=body
            row=dict(id=r['id'],path=path,sha256=sha256_file(path),source=r['source'],catalogue=r['catalogue'],
                     geometry_check=measurement,parameter_check=param,parameter_provenance=r['parameter_provenance'],
                     warnings=warnings,manufacturer_original_cad=False,contact_geometry_verified=False,
                     physical_mass_verified=False,machine_fit_verified=False,manufacturing_released=False)
            rows.append(row);write_json_new(pd/(r['id']+'_Nachweis.json'),row)
        # Empty, newly owned scratch assembly. Each pose is rolled back, never applied
        # to existing source occurrences; prototype files were loaded before the marks.
        scratch=ao.create('PRUEF09_NUR_AXIALE_HUELLEN')
        axial_results={}
        for pair in data['pairs']:
            checked=[]
            for sample in pair['axial_samples']:
                log('Axiale Lageprobe '+pair['id']+' / '+sample['name'])
                with temporary_occurrences(session,NXOpen,scratch,ao,evidence):
                    shaft_item=next(c for c in pair['components'] if c['role']=='screw')
                    nut_item=next(c for c in pair['components'] if c['role']=='nut')
                    sb=_insert(scratch,NXOpen,evidence,shaft_item,made,bodies,recipes,mode)
                    nb=_insert(scratch,NXOpen,evidence,nut_item,made,bodies,recipes,mode,[0.,0.,sample['nut_start_mm']])
                    checked.append(validate_axial_sample(pair,sample,sb,nb))
            axial_results[pair['id']]=checked
        # Finish every scratch probe while it is still the current work/display part.
        # Only then create the retained subassemblies. No undocumented SetWork call.
        for pair in data['pairs']:
            asm=ao.create('KATALOGPAAR_'+pair['id']+'_NICHT_MASCHINENPASSEND')
            inserted=[]
            for item in pair['components']:
                bb=_insert(asm,NXOpen,evidence,item,made,bodies,recipes,mode)
                inserted.append(dict(item,actual_nx_bounds_mm=bb))
            path=ao.save(asm)
            pairs.append(dict(id=pair['id'],assembly_file=path,assembly_sha256=sha256_file(path),
                              components=inserted,axial_samples=axial_results[pair['id']],axial_plan=pair['resolved']['window'],
                              complete_drive=False,machine_fit_verified=False))
        gallery=ao.create('KUGELGEWINDE_REFERENZEN09_KEINE_CNC_MASCHINE')
        for index,pair in enumerate(pairs):
            add_component(gallery,NXOpen,evidence,pair['assembly_file'],pair['id'],I,[index*80.,0.,0.],mode)
        assemblypath=ao.save(gallery);assemblyhash=sha256_file(assemblypath)
        registry=source_registry(data,rows)
        write_json_new(root/'Kaufteilzuordnung_09.json',registry)
        from cnc_nx.bom07 import run_report
        expected=Counter(item['part_id'] for pair in data['pairs'] for item in pair['components'])
        bom=run_report(session,root,log,evidence,registry,expected_quantities=expected)
        actual=Counter({r['item_id']:r['quantity'] for r in bom['rows']})
        if not bom['inventory_complete'] or not bom['source_binding_complete'] or not bom['assignment_complete'] or actual!=expected:
            raise RuntimeError('Live catalogue assembly BOM differs from planned occurrences')
        verify_sources(sources)
        for row in rows:
            if sha256_file(row['path'])!=row['sha256']:
                raise RuntimeError('Generated part changed after its validation: '+row['id'])
        for pair in pairs:
            if sha256_file(pair['assembly_file'])!=pair['assembly_sha256']:
                raise RuntimeError('Generated catalogue subassembly changed')
        if sha256_file(assemblypath)!=assemblyhash:
            raise RuntimeError('Generated catalogue overview changed during report generation')
        report=dict(schema='CNC_CATALOGUE_NX_RESULT_09',status='NATIVE_CATALOGUE_REFERENCES_CREATED_NOT_MACHINE_FITTED',
                    native_execution=True,assembly_file=assemblypath,assembly_sha256=assemblyhash,
                    prototype_count=len(rows),paired_assembly_count=len(pairs),leaf_occurrence_count=sum(actual.values()),
                    native_axial_sample_count=sum(len(p['axial_samples']) for p in pairs),
                    parts=rows,pairs=pairs,sources=sources,bom_report='NX_Stueckliste_07.json',
                    geometry_scope='NOMINAL_EXTERIOR_ENVELOPES_ONLY',manufacturer_original_cad=False,
                    native_parameter_tests=sum(len(r['parameter_check']['probes']) for r in rows),
                    physical_mass_verified=False,contact_geometry_verified=False,bearing_support_verified=False,
                    machine_travel_verified=False,full_collision_checked=False,machine_fit_verified=False,
                    manufacturing_released=False,order_released=False,limitations=data['limitations'])
        complete=True
    finally:
        verify_sources(sources)
        write_json_new(root/'Quellschutz_09.json',dict(source_inputs_unchanged=True,sources=sources,
                    catalogue_build_completed=complete,original_machine_parts_not_used=True))
    # No successful result file before catalogue inputs and outputs are rechecked.
    write_json_new(root/'NX_Kugelgewinde_Referenzen_09.json',report)
    log('Katalogreferenzen gespeichert: '+assemblypath)
    log('Nur nominale Aussenhuellen/axiale Positionen. Kein kompletter Antrieb, keine Maschinenmontage oder Bestellfreigabe.')
    return report
