"""Evidence inventory only. Not an engineering approval or CAD builder."""
REQUIRED = ('axis_line_in_machine_frame','fixed_bearing_interface','nut_interface',
            'available_nut_envelope','mounting_hole_pattern','usable_travel',
            'moving_mass','friction_force','cutting_force_design','rapid_feed',
            'acceleration','motor_torque_curve','screw_selection',
            'screw_end_machining','bearing_selection','coupling_or_belt_selection',
            'manufacturer_cad_revision')

def axis_readiness(axis, data):
    if axis not in ('X','Y','Z'):
        raise ValueError('Only X, Y, Z are in scope')
    required = REQUIRED + (('gravity_hold_concept',) if axis=='Z' else ())
    missing=[]
    for key in required:
        row=data.get(key)
        if (not isinstance(row,dict) or row.get('status')!='CONFIRMED' or
            row.get('value') is None or not str(row.get('evidence','')).strip()):
            missing.append(key)
    return {'axis':axis,'status':'BLOCKED' if missing else 'EVIDENCE_ENTRIES_PRESENT',
            'missing':missing,'manufacturing_released':False,
            'note':'Presence of CONFIRMED entries is not content validation, collision clearance, strength proof or NX acceptance.'}
