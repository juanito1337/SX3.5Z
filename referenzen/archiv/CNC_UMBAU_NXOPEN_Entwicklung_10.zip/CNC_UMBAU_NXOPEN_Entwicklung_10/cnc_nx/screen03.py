"""Static conservative screening of NX-measured AABBs. NOT exact collision detection."""
import json,itertools
from pathlib import Path
from assembly.manifest03 import checked_file
from validation.geometry03 import screen_pair
from .assembly03 import load_config
from .runtime import write_json_new

def run(session,NXOpen,directory,log,evidence,config):
 cfg=load_config('screen03.json');path=checked_file(cfg['aabb_path'],cfg['aabb_sha256'],'.json')
 with open(path,encoding='utf-8-sig') as f:data=json.load(f)
 rows=data['bounds']
 if len(rows)<2:raise ValueError('At least two measured body bounds needed')
 checks=[]
 for a,b in itertools.combinations(rows,2):
  if a['component']==b['component']:continue
  r=screen_pair(a['bounds_mm'],b['bounds_mm'],cfg['clearance_mm'])
  checks.append(dict(a=a['component'],a_body=a['body_index'],b=b['component'],b_body=b['body_index'],**r))
 report=dict(status='STATIC_AABB_SCREEN_ONLY',checks=checks,exact_collision_checked=False,
             travel_sweep_performed=False,manufacturing_released=False,
             note='Overlap may be intended contact or actual interference. No automatic exclusion of bearings/nuts/mating parts.')
 write_json_new(Path(directory)/'AABB_Vorpruefung.json',report);return report
