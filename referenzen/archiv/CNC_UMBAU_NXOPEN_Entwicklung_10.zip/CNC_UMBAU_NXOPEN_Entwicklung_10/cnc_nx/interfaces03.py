import json
from pathlib import Path
from assembly.manifest03 import checked_file
from analysis.interfaces03 import derive_frames,candidate_faces
from .assembly03 import load_config
from .runtime import write_json_new

def run(session,NXOpen,directory,log,evidence,config):
 cfg=load_config('interface_requests03.json')
 path=checked_file(cfg['audit_path'],cfg['audit_sha256'],'.json')
 with open(path,encoding='utf-8-sig') as f:audit=json.load(f)
 write_json_new(Path(directory)/'Flaechenkandidaten.json',candidate_faces(audit))
 rows=derive_frames(audit,cfg.get('requests',[]))
 report=dict(status='CAD_AXIS_REFERENCES_NOT_PHYSICALLY_MEASURED',frames=rows,manufacturing_released=False)
 write_json_new(Path(directory)/'NX_Achsbezuege.json',report);return report
