from pathlib import Path
from .assembly03 import load_config
from .runtime import write_json_new
from construction.axis_native03 import validate_axis_design

def run(session,NXOpen,directory,log,evidence,config):
 import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Assemblies
 data=load_config('axes03.json');axes=data.get('axes',[])
 if not axes:raise ValueError('config/axes03.json: No reviewed axis data. Use reference motor carrier independently; do not invent machine coordinates.')
 if len({a['axis'] for a in axes})!=len(axes):raise ValueError('Duplicate axes')
 for axis in axes:validate_axis_design(axis)
 rows=[]
 for axis in axes:
  from importlib import import_module
  mod=import_module('construction.create_'+axis['axis'].lower()+'_axis')
  out=Path(directory)/axis['axis'];out.mkdir()
  rows.append(mod.build_native(session,NXOpen,out,log,evidence,axis))
 report=dict(status='NATIVE_AXIS_LAYOUTS_NOT_MACHINE_RELEASE',axes=rows,manufacturing_released=False)
 write_json_new(Path(directory)/'NX_Achsmodule.json',report);return report
