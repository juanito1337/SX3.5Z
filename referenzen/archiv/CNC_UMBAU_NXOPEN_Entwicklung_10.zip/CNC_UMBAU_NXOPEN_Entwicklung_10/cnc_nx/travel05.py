"""Inspect rigid translation poses in NEW scratch assemblies; no source movement.
Only a hash-bound native Journal10 layout and reviewed explicit motion can run.
Author tests are offline; native execution occurs only in the user's NX process.
"""
from contextlib import contextmanager
from pathlib import Path
from validation.motion05 import translation,shift_bounds,origin_at
from validation.motion_input05 import load_reviewed
from validation.scan05 import plan,evaluate,finish
from .runtime import write_json_new,sha256_file
from .assembly03 import load_config,open_source
from .native import NewParts
from .build03 import add_component,exact_bounds
from .collision05 import calibrate_backend,assert_bounds
from .interference05 import temporary_occurrences

NATIVE_EXECUTED_BY_AUTHOR=False


@contextmanager
def protect_sources(states,directory):
    """Detect changes in memory or on disk even on failure; never repair/save."""
    try:yield
    finally:
        checks=[]
        for path,state in states.items():
            row=dict(path=path,hash_before=state['sha256'])
            try:
                row.update(hash_after=sha256_file(path),modified_after=bool(state['part'].IsModified))
                row['unchanged']=row['hash_before']==row['hash_after'] and not row['modified_after']
            except Exception as exc:
                row.update(unchanged=False,error=type(exc).__name__+': '+str(exc))
            checks.append(row)
        okay=all(r['unchanged'] for r in checks)
        write_json_new(Path(directory)/'Quellschutz_05.json',dict(unchanged=okay,sources=checks,saved_by_this_journal=False))
        if not okay:raise RuntimeError('Source integrity changed during inspection; no repair or save attempted')


def solid_inventory(part):
    rows=list(enumerate(part.Bodies))
    if not rows:raise RuntimeError('Prototype has no bodies; coverage cannot be complete')
    if any(not body.IsSolidBody for _,body in rows):
        raise RuntimeError('Non-solid bodies present; sheet geometry is not silently omitted')
    return rows


def place_pose(cfg,pose,sources,assembly,nx,evidence,mode):
    rows=[];handles={}
    for c in cfg['components']:
        comp=add_component(assembly,nx,evidence,c['path'],c['id'],c['rotation'],origin_at(cfg,c,pose),mode)
        for index,body in solid_inventory(sources[c['path']]['part']):
            occ=evidence.require('Component.FindOccurrence',comp.FindOccurrence)(body)
            if occ is None:raise RuntimeError('No body occurrence in pose: '+c['id'])
            bb=exact_bounds(assembly,occ,evidence)
            rows.append(dict(component=c['id'],body_index=index,bounds_mm=bb))
            handles[(c['id'],index)]=occ
    return rows,handles


def check_pose_bounds(cfg,pose,baseline,current):
    expected={(r['component'],r['body_index']):r for r in baseline}
    got={(r['component'],r['body_index']):r for r in current}
    if len(got)!=len(current) or set(got)!=set(expected):raise RuntimeError('Pose body inventory differs from reference')
    by_id={c['id']:c for c in cfg['components']}
    for key,ref in expected.items():
        wanted=shift_bounds(ref['bounds_mm'],translation(cfg,by_id[key[0]],pose))
        assert_bounds(got[key]['bounds_mm'],wanted,cfg['tolerance_mm'])


def run(session,NXOpen,directory,log,evidence,config):
    cfg=load_reviewed(load_config('travel05.json'))  # no native changes before evidence/source checks
    root=Path(directory);write_json_new(root/'Verfahrweg_Eingaben_05.json',cfg)
    sources={}
    # Loaded source prototypes remain outside all Undo scopes.
    for c in cfg['components']:
        if c['path'] not in sources:
            part=open_source(session,NXOpen,c['path'],evidence);solid_inventory(part)
            sources[c['path']]=dict(part=part,sha256=sha256_file(c['path']))
            if sources[c['path']]['sha256'].lower()!=c['sha256'].lower():
                raise RuntimeError('Source changed while opening: '+c['id'])
    with protect_sources(sources,root):
        binding,mode,calibration=calibrate_backend(session,NXOpen,root/'Kalibrierung05',log,evidence)
        pd=root/'NX_INSPECTION';pd.mkdir();owner=NewParts(session,NXOpen,pd,log,evidence)
        scratch=owner.create('PRUEFRAUM_05_KEINE_MASCHINENAENDERUNG')
        ref={k:a['reference_mm'] for k,a in cfg['axes'].items()}
        with temporary_occurrences(session,NXOpen,scratch,owner,evidence):
            baseline,_=place_pose(cfg,ref,sources,scratch,NXOpen,evidence,mode)
        work=plan(cfg,baseline)
        write_json_new(root/'NX_Verfahrweg_Pruefplan_05.json',dict(
            native_reference_bounds=True,reference_coordinates_mm=ref,bodies=baseline,
            poses=work['poses'],pairs=work['pairs'],numerical_model='Fixed orientations, rigid independent translations',
            same_component_solid_pairs_checked=False,physical_machine_verified=False))
        poses_dir=root/'Posen';poses_dir.mkdir();results=[];cache={};completed=False
        try:
            for index,pose in enumerate(work['poses'],1):
                log('NX-Verfahrwegpose %s/%s: %s'%(index,len(work['poses']),pose))
                with temporary_occurrences(session,NXOpen,scratch,owner,evidence):
                    actual,handles=place_pose(cfg,pose,sources,scratch,NXOpen,evidence,mode)
                    check_pose_bounds(cfg,pose,baseline,actual)
                    def query(a,b):return binding.check(handles[a].Tag,handles[b].Tag)
                    row=evaluate(cfg,work,pose,query,cache)
                    row.update(native_execution=True,actual_nx_bounds=actual)
                # A pose only counts AFTER successful removal of temporary components.
                results.append(row);write_json_new(poses_dir/('Pose_%05d.json'%index),row)
            summary=finish(work,results);completed=True
        finally:
            write_json_new(root/'NX_Verfahrweg_Fortschritt_05.json',dict(
                native_execution=True,all_requested_poses_completed=completed,
                requested_pose_count=len(work['poses']),completed_pose_count=len(results),
                status='POSE_LOOP_COMPLETED' if completed else 'FAILED_OR_PARTIAL',
                continuous_collision_free=False,manufacturing_released=False,
                note='Completion alone is not a clearance result. Final result requires NX_Verfahrwegpruefung_05.json.'))
        # Store only the EMPTY owned inspection part. Source prototypes are never saved.
        empty_path=owner.save(scratch)
    # Final success report only after the source guard also passes.
    summary.update(native_execution=True,calibration_report=calibration,
                   source_layout=cfg['input_layout'],inspection_part=empty_path,
                   source_files_unchanged=True,manufacturing_released=False,
                   moving_source_components=False,minimum_distance_measured=False,
                   all_requested_poses_completed=True,
                   limitations=['Source layout may itself contain photo assumptions.',
                     'No exact continuous collision solve for moving candidate pairs.',
                     'No cable, bellows, deformation, backlash, dynamics or overrun simulation.',
                     'No intra-prototype body intersections; only cross-occurrence solid pairs.',
                     'Contact policy is component-pair level, not an individual mating-face check.',
                     'No numerical minimum separation from UF classification.'])
    write_json_new(root/'NX_Verfahrwegpruefung_05.json',summary)
    log('Prueflauf beendet: '+summary['status']+'; durchgehend nachgewiesen='+str(summary['continuous_collision_free']))
    log('Kein physischer Maschinennachweis, keine Fertigungs- oder Sicherheitsfreigabe.')
    return summary
