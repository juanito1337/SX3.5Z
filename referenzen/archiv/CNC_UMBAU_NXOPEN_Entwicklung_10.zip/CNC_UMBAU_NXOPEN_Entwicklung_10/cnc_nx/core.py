"""Pure numeric helpers. No NX, CAD engine, or machine geometry assumptions."""
import math

def positive(value, name):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError(name + ': finite positive number required')
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError(name + ': finite positive number required')
    return value

def sleeve_volume(outer, inner, length):
    d, b, h = positive(outer,'outer'), positive(inner,'inner'), positive(length,'length')
    if b >= d:
        raise ValueError('inner diameter must be smaller than outer diameter')
    return math.pi * (d*d-b*b) * h / 4.0

def steps_per_mm(full_steps, microsteps, motor_rev_per_screw_rev, lead_mm):
    return (positive(full_steps,'full_steps') * positive(microsteps,'microsteps') *
            positive(motor_rev_per_screw_rev,'ratio') / positive(lead_mm,'lead'))

def unit(vector):
    if len(vector) != 3 or any(isinstance(x,bool) for x in vector):
        raise ValueError('3-vector required')
    v = [float(x) for x in vector]
    if not all(math.isfinite(x) for x in v):
        raise ValueError('nonfinite vector')
    n = math.sqrt(sum(x*x for x in v))
    if n <= 1e-12:
        raise ValueError('zero vector')
    return [x/n for x in v]

def rotation_quality(matrix):
    if len(matrix)!=3 or any(len(row)!=3 for row in matrix):
        raise ValueError('3x3 matrix required')
    if any(isinstance(v,bool) for row in matrix for v in row):raise ValueError("Boolean matrix entries not allowed")
    m = [[float(v) for v in row] for row in matrix]
    if any(not math.isfinite(v) for row in m for v in row):
        raise ValueError('nonfinite matrix')
    det = (m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1]) -
           m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0]) +
           m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]))
    err = max(abs(sum(m[i][k]*m[j][k] for k in range(3))-(1 if i==j else 0))
              for i in range(3) for j in range(3))
    return {'determinant':det,'orthonormal_error':err,
            'proper_rotation':abs(det-1)<1e-7 and err<1e-7}
