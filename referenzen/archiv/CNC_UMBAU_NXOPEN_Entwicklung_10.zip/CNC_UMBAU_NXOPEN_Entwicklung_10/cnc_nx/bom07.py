"""Read-only NX occurrence capture. No loading, Save, suppression or setters.

This reader uses the same NX Component/Part members as the existing audit. Its
NX2406 execution has not been performed by the author; runtime failures remain
explicit. Quantities are occurrences, not NX/PLM material quantity attributes.
"""
from pathlib import Path
from analysis.bom07 import path_key
from cnc_nx.runtime import sha256_file, write_json_new


def capture(session, evidence, log, max_occurrences=100000, max_depth=200):
    if type(max_occurrences) is not int or max_occurrences < 1:
        raise ValueError('Positive occurrence limit required')
    if type(max_depth) is not int or max_depth < 0:
        raise ValueError('Nonnegative depth limit required')
    displayed = session.Parts.Display
    if displayed is None:
        raise RuntimeError('Zuerst eine gespeicherte Baugruppe oder ein Einzelteil in NX anzeigen.')
    s = dict(schema='SX35Z_BOM_SNAPSHOT_7', origin='LIVE_NX_READ', root='0000',
             prototypes=[], occurrences=[], issues=[], integrity_failure=False,
             original_write_operations=0, quantity_basis='ONE_PER_ACTIVE_LEAF_OCCURRENCE',
             arrangement_scope='CURRENTLY_LOADED_ARRANGEMENT',
             reference_set_policy='Visibility/reference set does not remove an active occurrence')
    identities = {}; handles = {}; prototype_rows = {}; issue_seq = 0

    def fault(where, exc):
        nonlocal issue_seq
        issue_seq += 1
        s['issues'].append(dict(code='NX_READ_FAILED', where=where, severity='ERROR',
            exception=type(exc).__name__, message=str(exc)))
        log('Nicht gelesen: ' + where + ' / ' + str(exc))

    def read(where, fn):
        try:
            return fn()
        except Exception as exc:
            fault(where, exc); return None

    def flag(where, fn):
        value = read(where, fn)
        if type(value) is not bool:
            fault(where, ValueError('Boolean not read; no truth-value coercion'))
            return None
        return value

    def identity(obj):
        try:
            return ('tag', int(obj.Tag))
        except Exception:
            return ('object', id(obj))

    def file_hash(path):
        path_key(path)
        p = Path(path)
        if not p.is_absolute() or p.is_symlink() or not p.is_file() or p.suffix.lower() != '.prt':
            raise ValueError('Saved local non-symlink .prt required; no PDM path guessing')
        return sha256_file(p)

    def prototype(part):
        if part is None:
            raise ValueError('Prototype is not loaded')
        key = identity(part)
        if key in identities:
            return identities[key]
        pid = 'PROTO_%04d' % (len(identities) + 1)
        identities[key] = pid; handles[pid] = part
        row = dict(id=pid, name=read(pid+'.Name', lambda: part.Name),
            path=read(pid+'.FullPath', lambda: part.FullPath),
            fully_loaded=flag(pid+'.IsFullyLoaded', lambda: part.IsFullyLoaded),
            modified_before=flag(pid+'.IsModified', lambda: part.IsModified),
            body_count=None, solid_body_count=None, non_solid_body_count=None)
        row['sha256_before'] = read(pid+'.sha256_before', lambda: file_hash(row['path']))
        if row['fully_loaded'] is True:
            bodies = read(pid+'.Bodies', lambda: list(part.Bodies))
            if bodies is not None:
                states = [flag(pid+'.body%d.IsSolidBody'%i, lambda b=b: b.IsSolidBody)
                          for i,b in enumerate(bodies)]
                if all(type(x) is bool for x in states):
                    row.update(body_count=len(bodies), solid_body_count=states.count(True),
                               non_solid_body_count=states.count(False))
        s['prototypes'].append(row); prototype_rows[pid] = row
        return pid

    root = read('Displayed.ComponentAssembly.RootComponent', lambda: displayed.ComponentAssembly.RootComponent)
    # A genuine part has RootComponent=None. An API failure must not be misclassified.
    root_read_failed = any(x['where'] == 'Displayed.ComponentAssembly.RootComponent' for x in s['issues'])
    if root is None:
        pid = read('Displayed.Prototype', lambda: prototype(displayed))
        s['occurrences'].append(dict(path='0000', parent=None, name=getattr(displayed,'Name',''),
            prototype_id=pid, suppressed=False, children_count=None if root_read_failed else 0,
            reference_set='DISPLAYED_PART'))
    else:
        stack = [('0000', None, root, (), 0)]
        while stack:
            path, parent, comp, ancestors, depth = stack.pop()
            if len(s['occurrences']) >= max_occurrences:
                fault(path, RuntimeError('Occurrence limit reached; remaining branches unread')); break
            key = identity(comp)
            row = dict(path=path, parent=parent, name=read(path+'.Name',lambda: comp.Name),
                       prototype_id=None, suppressed=None, children_count=None, reference_set=None)
            s['occurrences'].append(row)
            if key in ancestors or depth > max_depth:
                fault(path, RuntimeError('Cycle/depth limit; branch not traversed')); continue
            row['suppressed'] = flag(path+'.IsSuppressed',lambda: comp.IsSuppressed)
            if row['suppressed'] is not False:
                continue  # A suppressed branch is intentionally not loaded or traversed.
            row['reference_set'] = read(path+'.ReferenceSet',lambda: comp.ReferenceSet)
            part = read(path+'.Prototype',lambda: comp.Prototype)
            row['prototype_id'] = read(path+'.prototype',lambda: prototype(part))
            if row['prototype_id'] is None:
                continue
            p = prototype_rows[row['prototype_id']]
            if p['fully_loaded'] is not True:
                continue  # GetChildren on an unloaded prototype could falsely appear empty.
            fn = evidence.record('Component.GetChildren',getattr(comp,'GetChildren',None))
            children = read(path+'.GetChildren', lambda: list(fn()))
            if children is None:
                continue
            row['children_count'] = len(children)
            for index in reversed(range(len(children))):
                stack.append((path+'/'+str(index).zfill(4), path, children[index], ancestors+(key,), depth+1))
    for row in s['prototypes']:
        part = handles[row['id']]
        after = read(row['id']+'.sha256_after', lambda r=row: file_hash(r['path']))
        dirty = flag(row['id']+'.IsModified_after', lambda p=part: p.IsModified)
        path_after = read(row['id']+'.FullPath_after', lambda p=part: p.FullPath)
        row.update(sha256_after=after, modified_after=dirty, path_after=path_after)
        try:
            path_changed = path_key(row['path']) != path_key(path_after)
        except ValueError:
            path_changed = row['path'] != path_after
        if (path_changed or (row['sha256_before'] is not None and row['sha256_before'] != after)
                or (row['modified_before'] is False and dirty is not False)):
            s['integrity_failure'] = True
            fault(row['id'], RuntimeError('Original file/memory state changed or became unreadable during capture'))
    evidence.record('Part.IsFullyLoaded', getattr(displayed,'IsFullyLoaded',None))
    evidence.record('Part.IsModified', getattr(displayed,'IsModified',None))
    return s


def run_report(session, directory, log, evidence, registry, expected_quantities=None):
    from analysis.bom07 import summarize
    from analysis.bom_registry07 import apply_registry, validate_registry
    from exports.bom07 import export_report, assignment_template
    validate_registry(registry)
    snapshot = capture(session, evidence, log)
    write_json_new(Path(directory)/'NX_Stuecklistenaufnahme_07.json', snapshot)
    if snapshot['integrity_failure']:
        raise RuntimeError('Quellschutz fehlgeschlagen. Keine vollstaendige Stueckliste ausgegeben.')
    report = apply_registry(summarize(snapshot), registry)
    report['native_read_in_this_run'] = True
    report['geometry_created_in_this_bom_read'] = False
    if expected_quantities is not None:
        from collections import Counter
        actual = Counter({row['item_id']: row['quantity'] for row in report['rows']})
        if (not report['inventory_complete'] or not report['source_binding_complete']
                or not report['assignment_complete'] or actual != Counter(expected_quantities)):
            raise RuntimeError('Live-Referenzstueckliste stimmt nicht mit dem erwarteten Rezeptbestand ueberein.')
        report['reference_quantity_contract'] = dict(status='MATCHED_IN_THIS_NX_READ',
            expected=dict(expected_quantities), actual=dict(actual))
    export_report(Path(directory)/'BOM', report)
    write_json_new(Path(directory)/'Zuordnung_Vorlage_07.json', assignment_template(report))
    write_json_new(Path(directory)/'NX_Stueckliste_07.json', report)
    log('Stuecklistenstatus: '+report['status'])
    log('%d aktive Blattvorkommen, %d unterschiedliche native Teile' %
        (report['counts']['active_leaf_occurrences'], report['counts']['distinct_part_rows']))
    log('Keine Bestell-/Fertigungsfreigabe. Unterdrueckte Zweige und offene Zuordnungen separat.')
    return report


def run(session, NXOpen, directory, log, evidence, config):
    import json
    root = Path(__file__).resolve().parents[1]
    with open(root/'config'/'bom07.json',encoding='utf-8-sig') as f:
        registry = json.load(f)
    return run_report(session,directory,log,evidence,registry)
