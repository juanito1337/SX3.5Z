"""Engineering report (no CAD). Callable in NX or in normal Python."""
import json,os
from pathlib import Path
from engineering.scenarios import evaluate
from exports.export_bom import write_csv
from construction.part_contracts import validate_part
from validation.check_travel_limits import sample_grid
from .runtime import write_json_new

def reports(directory):
    root=Path(os.path.abspath(__file__)).parents[1];out=Path(directory)
    def read(name):
        with open(root/'config'/name,encoding='utf-8-sig') as f:return json.load(f)
    calc=evaluate(read('design_scenarios.json'))
    write_json_new(out/'Auslegungsszenarien.json',calc)
    bom=read('bom_concept.json');write_csv(out/'Stueckliste_KONZEPT.csv',bom['items'])
    parts=[validate_part(p) for p in read('design_parts.json')['parts']]
    write_json_new(out/'Sonderteile_Analytische_Pruefung.json',dict(status='MATHEMATICS_ONLY',parts=parts,nx_executed=False))
    # Sample poses are intentionally normalized; no fabricated SX travel limits.
    grid=sample_grid({'X':[0,1],'Y':[0,1],'Z':[0,1]},5)
    grid['coordinate_meaning']='Fractions of LATER VERIFIED axis travel; not machine mm'
    write_json_new(out/'Pruefposen_NORMALISIERT.json',grid)
    return dict(status='CONCEPT_REPORTS_CREATED',calculations=len(calc['scenarios']),
                sample_poses=len(grid['poses']),bom_rows=len(bom['items']),
                nx_geometry_created=False,manufacturing_released=False)

def run(session,NXOpen,directory,log,evidence,config):
    result=reports(directory);log('Konzeptberichte geschrieben. NX-Geometrie/Kollisionen NICHT geprueft.');return result
