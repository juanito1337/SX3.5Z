"""Creates a NEW native project container referencing the intact original assembly.
Not the finished CNC conversion. No suppression, interpart edits or source saves.
"""
from pathlib import Path
from .native import NewParts,identity,require_saved_source
from .audit import walk_tree,object_key,encode_position
from .runtime import sha256_file,write_json_new


def run(session,NXOpen,directory,log,evidence,config):
    import NXOpen.Assemblies
    original=session.Parts.Display
    if original is None:raise RuntimeError('Zuerst gespeicherte Hauptbaugruppe oeffnen')
    root=original.ComponentAssembly.RootComponent
    if root is None or not root.GetChildren():raise RuntimeError('Keine bestehende Hauptbaugruppe erkannt')
    sources={}
    # Fail closed if ANY prototype is unloaded, unsaved or modified.
    for path,comp in walk_tree(root):
        proto=comp.Prototype
        if proto is None or not hasattr(proto,'Bodies'):raise RuntimeError('Prototyp nicht geladen: '+path)
        key=object_key(proto)
        if key not in sources:
            if not bool(proto.IsFullyLoaded):raise RuntimeError('Prototyp nicht voll geladen: '+path)
            sources[key]={'part':proto,'before':require_saved_source(proto)}
    original_state=require_saved_source(original)
    owned=NewParts(session,NXOpen,directory,log,evidence)
    container=owned.create('FRAESMASCHINE_CNC_PROJEKTSTART_NICHT_FERTIG')
    insert=evidence.require('ComponentAssembly.AddComponent',container.ComponentAssembly.AddComponent)
    result=insert(original_state['path'],'Entire Part','BESTAND_UNVERAENDERT',NXOpen.Point3d(0.,0.,0.),identity(NXOpen),1)
    if isinstance(result,tuple):
        component=result[0]
        for status in result[1:]:
            try:
                if int(status.NumberUnloadedParts):raise RuntimeError('Bestandskomponente nicht voll geladen')
            finally:status.Dispose()
    else:component=result
    if component is None:raise RuntimeError('Keine Bestandskomponente eingefuegt')
    position=encode_position(component.GetPosition())
    if any(abs(x)>1e-7 for x in position['origin_raw']):raise RuntimeError('Bestandskomponente nicht am Ursprung')
    if any(abs(position['matrix_raw'][i][j]-(1.0 if i==j else 0.0))>1e-7 for i in range(3) for j in range(3)):
        raise RuntimeError('Unerwartete Bestandsorientierung')
    filename=owned.save(container)
    checks=[]
    for value in sources.values():
        p=value['part'];before=value['before'];after=sha256_file(before['path'])
        same=after==before['sha256'];modified=bool(p.IsModified)
        checks.append({'path':before['path'],'sha256_before':before['sha256'],'sha256_after':after,
                       'source_bytes_unchanged':same,'modified_after':modified})
        if not same or modified:raise RuntimeError('Bestandszustand waehrend Containeraufbau geaendert')
    report={'status':'REFERENCE_CONTAINER_ONLY','native_execution':True,
            'not_final_cnc_assembly':True,'assembly_file':filename,
            'original_reference':original_state,'component_position':position,'source_checks':checks,
            'automatic_modification_of_originals':False,
            'not_performed':['CNC axis construction','manual-drive suppression','collision/travel tests','manufacturing drawings']}
    write_json_new(Path(directory)/'NX_Projektcontainer.json',report)
    log('Referenzcontainer gespeichert; vorhandene Komponenten weiterhin unveraendert.')
    log('Dies ist NICHT FRAESMASCHINE_CNC_UMBAU.prt und kein abgeschlossener Umbau.')
    return report
