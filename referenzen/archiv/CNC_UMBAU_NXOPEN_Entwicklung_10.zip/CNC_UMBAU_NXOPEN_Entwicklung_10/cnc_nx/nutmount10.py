"""NX-only construction of matched round-nut main-body reference units.

No NX execution by the author. Only new parts are saved. Catalogue holes and
retention details not supported by drawings are not invented.
"""
from collections import Counter
from pathlib import Path
import json
from construction.nutmount10 import reference_set
from construction.recipes03 import I,validate_recipe
from engineering.ballscrew09 import ROOT
from validation.geometry03 import bounds,transform_bounds
from validation.nutmount10 import verify_interfaces
from cnc_nx.build03 import RecipeBuilder,calibrate,add_component,exact_bounds
from cnc_nx.native import NewParts
from cnc_nx.runtime import sha256_file,write_json_new
from cnc_nx.interference05 import temporary_occurrences
from cnc_nx.audit import encode_face_data,encode_position
from cnc_nx.inspection08 import _face_method
from cnc_nx.ballscrew09 import capture_sources,verify_sources,source_registry as pair_registry
NATIVE_EXECUTED_BY_AUTHOR=False


def read_faces(body,evidence):
 fn=_face_method(evidence)
 faces=evidence.require('Body.GetFaces',body.GetFaces)()
 rows=[encode_face_data(fn(f.Tag)) for f in faces]
 if not rows:raise RuntimeError('No NX face data on main body')
 json.dumps(rows,allow_nan=False)
 return rows


def source_registry(data,rows):
 from analysis.bom_registry07 import check_file,validate_registry
 recipes={r['id']:r for r in data['parts']}
 if len(rows)!=len(recipes) or {x['id'] for x in rows}!=set(recipes):raise ValueError('Native prototype registry mismatch')
 pair_ids={r['id'] for r in data['parts'] if r['kind']=='supplier_envelope09'}
 base=pair_registry({'parts':[r for r in data['parts'] if r['id'] in pair_ids]},[r for r in rows if r['id'] in pair_ids])
 for row in rows:
  r=recipes[row['id']]
  if r['kind']!='supplier_mount10':continue
  validate_recipe(r)
  if row['source']!=r['source'] or check_file(row['path'],row['sha256'],'.prt')!='FILE_IDENTITY_CHECKED_NOT_APPROVED':
   raise ValueError('Mount prototype file/source changed')
  base['entries'].append(dict(prototype_path=row['path'],prototype_sha256=row['sha256'],item_id=r['id'],
    revision='CATALOGUE_APR2025_MAIN_BODY10',kind='PURCHASE',description='Spannblock-Hauptkoerper vereinfacht',
    manufacturer=r['manufacturer'],model='Fuss-Spannblock '+r['article_number'],order_number=r['article_number'],
    dimension_status=r['dimensions_status'],material='Stahl, brüniert',source_refs=[r['source']],documents=[],
    blockers=['CATALOGUE_CANDIDATE_NOT_MACHINE_SELECTION','NO_ORIGINAL_SUPPLIER_CAD',
              'FOOT_HOLES_AND_RETENTION_NOT_MODELLED','AXIAL_NUT_OFFSET_STUDY_ONLY',
              'H1_INTERPRETATION_AND_DRAWING_REVIEW_PENDING','NOT_FULL_HARDWARE_ENVELOPE'],
    order_released=False,manufacturing_released=False))
 base['scope']='MATCHED_NUT_MAIN_BODY_REFERENCES_NOT_MACHINE_ORDER_LIST'
 validate_registry(base);return base


def _insert(asm,nx,evidence,item,made,bodies,recipes,mode,origin=None):
 t=item['origin_mm'] if origin is None else origin
 comp=add_component(asm,nx,evidence,made[item['part_id']],item['id'],item['rotation'],t,mode)
 pos=encode_position(evidence.require('Component.GetPosition',comp.GetPosition)())
 if any(abs(pos['matrix_raw'][i][j]-I[i][j])>1e-8 for i in range(3) for j in range(3)):
  raise RuntimeError('Main-body reference interfaces require identity orientation')
 if any(abs(a-b)>1e-6 for a,b in zip(pos['origin_raw'],t)):raise RuntimeError('Unexpected measured component origin')
 occ=evidence.require('Component.FindOccurrence',comp.FindOccurrence)(bodies[item['part_id']])
 if occ is None:raise RuntimeError('No occurrence body')
 actual=bounds(exact_bounds(asm,occ,evidence))
 expected=transform_bounds(validate_recipe(recipes[item['part_id']])['bounds_mm'],item['rotation'],t)
 if any(abs(a-b)>.005 for a,b in zip(actual,expected)):raise RuntimeError('Unexpected inserted main-body bounds')
 return dict(actual_nx_bounds_mm=actual,actual_nx_origin_mm=pos['origin_raw'])


def run(session,NXOpen,directory,log,evidence,config):
 import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Assemblies
 root=Path(directory)
 source_files=['config/nutmounts10.json','config/ballscrews09.json','reference/Quellen_10.json',
   'reference/Quellen_09.json','engineering/nutmount10.py','engineering/ballscrew09.py',
   'construction/nutmount10.py','construction/ballscrew09.py','construction/recipes03.py',
   'cnc_nx/nutmount10.py','cnc_nx/build03.py','validation/nutmount10.py']
 sources=capture_sources([ROOT/f for f in source_files]);data=reference_set()
 for r in data['parts']:validate_recipe(r)
 complete=False;rows=[];groups=[]
 try:
  mode=calibrate(session,NXOpen,root/'_Kalibrierung',log,evidence)
  pd=root/'NX_PARTS';ad=root/'NX_ASSEMBLY';pd.mkdir();ad.mkdir()
  po=NewParts(session,NXOpen,pd,log,evidence);ao=NewParts(session,NXOpen,ad,log,evidence)
  recipes={r['id']:r for r in data['parts']};made={};bodies={};faces={}
  for r in data['parts']:
   verify_sources(sources);log('Rundmutter-Aufnahme: '+r['id'])
   p=po.create(r['id']);b=RecipeBuilder(p,NXOpen,evidence)
   final,body,measurement=b.build_recipe(r);probe=b.test_parameter(session,r,final);body=final.GetBodies()[0]
   faces[r['id']]=read_faces(body,evidence)
   warnings=[]
   try:
    dm=session.DisplayManager.NewDisplayModification()
    try:dm.ApplyToAllFaces=True;dm.NewColor=int(r.get('color_index',36));dm.Apply([body])
    finally:dm.Dispose()
   except Exception as exc:warnings.append('Farbe nicht angewandt: '+str(exc))
   path=po.save(p);made[r['id']]=path;bodies[r['id']]=body
   row=dict(id=r['id'],path=path,sha256=sha256_file(path),source=r['source'],geometry_check=measurement,
       parameter_check=probe,actual_nx_prototype_faces=faces[r['id']],warnings=warnings,
       machine_fit_verified=False,retention_verified=False,manufacturing_released=False)
   rows.append(row);write_json_new(pd/(r['id']+'_Nachweis.json'),row)
  scratch=ao.create('PRUEF10_AXIALE_HAUPTKOERPER');pose_results={}
  # All pose rollbacks finish before retained assemblies change the displayed part.
  for group in data['groups']:
   samples=[]
   for sample in group['resolved']['samples']:
    with temporary_occurrences(session,NXOpen,scratch,ao,evidence):
     measured={}
     for item in group['components']:
      z={'screw':0.,'nut':sample['nut_start_mm'],'block':sample['block_start_mm']}[item['role']]
      measured[item['role']]=_insert(scratch,NXOpen,evidence,item,made,bodies,recipes,mode,[0.,0.,z])
     lo=min(measured['nut']['actual_nx_bounds_mm'][2],measured['block']['actual_nx_bounds_mm'][2])
     hi=max(measured['nut']['actual_nx_bounds_mm'][5],measured['block']['actual_nx_bounds_mm'][5])
     if abs(lo-sample['known_body_start_mm'])>.005 or abs(hi-sample['known_body_end_mm'])>.005:
      raise RuntimeError('Measured union of known axial bodies differs')
     samples.append(dict(sample=sample['name'],measured=measured,actual_known_body_interval_mm=[lo,hi],
              status='PASSED_MODEL_BOUNDS_ONLY',full_collision_checked=False,machine_travel_verified=False))
   pose_results[group['id']]=samples
  for group in data['groups']:
   asm=ao.create('RUNDMT_'+group['id']+'_NICHT_MASCHINENPASSEND');measure={};inserted=[]
   for item in group['components']:
    pos=_insert(asm,NXOpen,evidence,item,made,bodies,recipes,mode)
    measure[item['role']]=dict(faces=faces[item['part_id']],translation_mm=pos['actual_nx_origin_mm'])
    inserted.append(dict(item,**pos))
   checks=verify_interfaces(group,measure)
   path=ao.save(asm)
   groups.append(dict(id=group['id'],assembly_file=path,assembly_sha256=sha256_file(path),
       components=inserted,model_interface_checks=checks,axial_samples=pose_results[group['id']],
       resolved=group['resolved'],retention_verified=False,manufacturer_assembly_verified=False))
  gallery=ao.create('RUNDMUTTER_AUFNAHMEN10_KEINE_CNC_MASCHINE')
  for index,g in enumerate(groups):
   add_component(gallery,NXOpen,evidence,g['assembly_file'],g['id'],I,[index*100.,0.,0.],mode)
  ap=ao.save(gallery);ah=sha256_file(ap)
  registry=source_registry(data,rows);write_json_new(root/'Kaufteilzuordnung_10.json',registry)
  expected=Counter(c['part_id'] for g in data['groups'] for c in g['components'])
  from cnc_nx.bom07 import run_report
  bom=run_report(session,root,log,evidence,registry,expected_quantities=expected)
  actual=Counter()
  for row in bom['rows']:
   if row['item_id'] in actual:raise RuntimeError('Duplicate live BOM item')
   actual[row['item_id']]=row['quantity']
  if not all(bom.get(k) is True for k in ('inventory_complete','source_binding_complete','assignment_complete')) or actual!=expected:
   raise RuntimeError('Live mount-unit BOM differs from planned instances')
  for row in rows:
   if sha256_file(row['path'])!=row['sha256']:raise RuntimeError('Generated part changed after validation')
  for g in groups:
   if sha256_file(g['assembly_file'])!=g['assembly_sha256']:raise RuntimeError('Generated group changed')
  if sha256_file(ap)!=ah:raise RuntimeError('Generated overview changed')
  verify_sources(sources)
  report=dict(schema='CNC_NUTMOUNT_NX_RESULT_10',status='NATIVE_MAIN_BODY_REFERENCES_CREATED_NOT_MACHINE_FITTED',
      native_execution=True,assembly_file=ap,assembly_sha256=ah,prototype_count=len(rows),
      group_count=len(groups),leaf_occurrence_count=sum(actual.values()),bom_quantities=dict(actual),
      native_parameter_tests=sum(len(r['parameter_check']['probes']) for r in rows),
      native_axial_sample_count=sum(len(g['axial_samples']) for g in groups),
      model_interface_check_count=sum(len(g['model_interface_checks']) for g in groups),
      parts=rows,groups=groups,sources=sources,source_scope='TABLE_MAIN_BODIES_DRAWING_REVIEW_PENDING',
      retention_verified=False,machine_fit_verified=False,machine_travel_verified=False,
      full_collision_checked=False,foot_holes_modelled=False,manufacturer_original_cad=False,
      manufacturing_released=False,order_released=False,limitations=data['limitations'])
  complete=True
 finally:
  verify_sources(sources)
  write_json_new(root/'Quellschutz_10.json',dict(source_inputs_unchanged=True,sources=sources,
      construction_completed=complete,original_machine_parts_not_used=True))
 write_json_new(root/'NX_Rundmutter_Aufnahmen_10.json',report)
 log('Rundmutter-Aufnahmestudien gespeichert: '+ap)
 log('Keine Maschinenmontage. Klemmfunktion, Fusslochbild und vollstaendige Aussenkontur sind nicht verifiziert.')
 return report
