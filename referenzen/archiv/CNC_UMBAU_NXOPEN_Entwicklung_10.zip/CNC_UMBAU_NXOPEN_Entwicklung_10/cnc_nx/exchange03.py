"""Checked STEP exchange into NEW NX parts. Optional, NOT executed in NX by author.
Uses named NX Step214 translator interfaces; runtime presence is logged, not
misrepresented as tested compatibility. Manufacturer CAD bytes must be supplied separately.
"""
from pathlib import Path
import math,os
from urllib.parse import urlparse
from assembly.manifest03 import checked_file,idcheck
from validation.geometry03 import bounds,vec,scalar
from .runtime import write_json_new,sha256_file
from .native import NewParts,volume
from .build03 import exact_bounds
from .assembly03 import load_config

def step_header(path):
 p=Path(path)
 with open(p,'rb') as f:
  head=f.read(262144);f.seek(max(0,p.stat().st_size-1024));tail=f.read()
 if not head.lstrip().startswith(b'ISO-10303-21;') or b'END-ISO-10303-21;' not in tail:raise ValueError('Not a complete STEP exchange file')
 return True

def validate_imports(items):
 if not isinstance(items,list) or not items:raise ValueError('No supplier STEP files configured; no downloaded files are claimed')
 seen=set()
 for item in items:
  idcheck(item['id'])
  if item['id'] in seen:raise ValueError('Duplicate import ID')
  seen.add(item['id']);ext=Path(item['path']).suffix.lower()
  if ext not in ('.stp','.step'):raise ValueError('STEP extension required')
  checked_file(item['path'],item['sha256'],ext);step_header(item['path'])
  if not item.get('manufacturer') or not item.get('part_number') or urlparse(item.get('source_url','')).scheme not in ('http','https'):
   raise ValueError('Supplier identity and source URL required')
  size=item.get('expected_size_mm')
  if size is not None:
   if any(x<=0 for x in vec(size)):raise ValueError('Positive supplier envelope required')
 return items

def check_size(actual_bounds,expected,tolerance):
 b=bounds(actual_bounds);tol=scalar(tolerance)
 if tol<0:raise ValueError('Negative tolerance')
 if expected is None:return 'NOT_CHECKED_NO_SUPPLIER_ENVELOPE'
 e=sorted(vec(expected));actual=sorted(b[i+3]-b[i] for i in range(3))
 if any(x<=0 for x in e) or any(abs(a-v)>tol for a,v in zip(actual,e)):raise ValueError('Supplier envelope mismatch: '+repr(actual)+' vs '+repr(e))
 return 'NOMINAL_ENVELOPE_MATCH_ONLY'

def _owned_target(part,owned):
 record=owned.records.get(int(part.Tag))
 if record is None:raise RuntimeError('STEP target was not created by this run')
 actual=os.path.normcase(os.path.abspath(str(part.FullPath)))
 wanted=os.path.normcase(os.path.abspath(str(record['path'])))
 if actual!=wanted:raise RuntimeError('STEP target path changed; no source write permitted')
 if Path(record['path']).is_symlink():raise RuntimeError('STEP target is a symlink')
 return record

def configure_owned_import(importer,nx,session,part,owned,source_step,settings):
 """No translator-default output path: only this run's new native target."""
 record=_owned_target(part,owned)
 if session.Parts.Work is None or session.Parts.Work.Tag!=part.Tag:
  raise RuntimeError('New import target is not the work part')
 enum=getattr(getattr(nx,'Step214Importer',None),'ImportToOption',None)
 if enum is None or not hasattr(enum,'WorkPart'):
  raise RuntimeError('NX Step214Importer.ImportToOption.WorkPart not exposed')
 importer.InputFile=str(source_step)
 importer.OutputFile=str(record['path'])
 importer.ImportTo=enum.WorkPart
 importer.FileOpenFlag=False;importer.ProcessHoldFlag=True;importer.ObjectTypes.Solids=True
 if settings:
  if not Path(settings).is_file():raise ValueError('Translator settings file missing')
  importer.SettingsFile=settings

def acknowledge_owned_import_output(part,owned):
 """The successful translator is allowed to write ONLY its assigned owned path.
 Call only after Commit returned. It may write the new .prt itself, or may
 leave it unsaved; neither case authorizes adopting another file as owned.
 """
 record=_owned_target(part,owned);path=Path(record['path'])
 if path.exists():
  if not path.is_file() or path.stat().st_size==0:raise RuntimeError('Invalid translator output at owned path')
  record['disk_hash']=sha256_file(path)

def run(session,NXOpen,directory,log,evidence,config):
 cfg=load_config('purchased03.json');items=validate_imports(cfg.get('imports',[]))
 factory=evidence.require('DexManager.CreateStep214Importer',getattr(session.DexManager,'CreateStep214Importer',None))
 out=Path(directory)/'NX_PURCHASE_PARTS';out.mkdir();owned=NewParts(session,NXOpen,out,log,evidence);rows=[]
 for item in items:
  before=sha256_file(item['path']);part=owned.create('KAUF_'+item['id'])
  importer=factory()
  try:
   configure_owned_import(importer,NXOpen,session,part,owned,item['path'],cfg.get('settings_file',''))
   evidence.require('Step214Importer.Commit',importer.Commit)()
   acknowledge_owned_import_output(part,owned)
  finally:
   importer.Destroy()
   if sha256_file(item['path'])!=before:raise RuntimeError('Supplier source bytes changed')
  bodies=[b for b in part.Bodies if b.IsSolidBody]
  if not bodies:raise RuntimeError('STEP import returned no solid bodies')
  boxes=[exact_bounds(part,b,evidence) for b in bodies]
  box=[min(b[i] for b in boxes) for i in range(3)]+[max(b[i] for b in boxes) for i in range(3,6)]
  check=check_size(box,item.get('expected_size_mm'),item.get('size_tolerance_mm',.1))
  measures=[volume(part,b,evidence) for b in bodies]
  if any(not math.isfinite(v) or v<=0 for v in measures):raise RuntimeError('Invalid imported solid volume')
  filename=owned.save(part)
  row=dict(id=item['id'],manufacturer=item['manufacturer'],part_number=item['part_number'],source_url=item['source_url'],
      supplier_path=item['path'],supplier_sha256=before,nx_path=filename,nx_sha256=sha256_file(filename),
      solid_count=len(bodies),bounds_mm=box,volume_mm3=sum(measures),size_check=check,
      coordinate_registration='NOT_REVIEWED',machine_fit_verified=False,manufacturing_released=False)
  rows.append(row);write_json_new(out/(item['id']+'_Importnachweis.json'),row)
 report=dict(status='NATIVE_PURCHASE_IMPORTS_NOT_POSITIONED',native_execution=True,parts=rows,manufacturing_released=False)
 write_json_new(Path(directory)/'NX_Kaufteile.json',report);return report

def export_run(session,NXOpen,directory,log,evidence,config):
 cfg=load_config('export03.json');path=checked_file(cfg['source_prt'],cfg['source_sha256']);before=sha256_file(path)
 # Exact saved source on disk, no implicit SaveAll or update of source components.
 for p in session.Parts:
  if str(p.FullPath)==path and bool(p.IsModified):raise RuntimeError('Save/export source is modified; exporter does not save it')
 outdir=Path(directory)/'STEP';outdir.mkdir();target=outdir/'CNC_MONTAGEENTWURF_NICHT_FREIGEGEBEN.stp'
 factory=evidence.require('DexManager.CreateStep214Creator',getattr(session.DexManager,'CreateStep214Creator',None))
 exporter=factory()
 try:
  enum=getattr(getattr(NXOpen,'Step214Creator',None),'ExportFromOption',None)
  if enum is None or not hasattr(enum,'ExistingPart'):raise RuntimeError('NX Step214Creator.ExportFromOption.ExistingPart not exposed')
  exporter.ExportFrom=enum.ExistingPart;exporter.InputFile=path;exporter.OutputFile=str(target)
  exporter.ObjectTypes.Solids=True;exporter.ProcessHoldFlag=True
  settings=cfg.get('settings_file','')
  if settings:
   if not Path(settings).is_file():raise ValueError('Translator settings missing')
   exporter.SettingsFile=settings
  evidence.require('Step214Creator.Commit',exporter.Commit)()
 finally:
  exporter.Destroy()
  if sha256_file(path)!=before:raise RuntimeError('Export source bytes changed')
 if not target.is_file() or target.stat().st_size<100:raise RuntimeError('No nonempty STEP output')
 step_header(target)
 report=dict(status='STEP_FILE_WRITTEN_REIMPORT_NOT_PERFORMED',source=path,source_sha256=before,
             path=str(target),sha256=sha256_file(target),native_execution=True,
             body_count_roundtrip_checked=False,manufacturing_released=False)
 write_json_new(Path(directory)/'STEP_Exportnachweis.json',report);return report
