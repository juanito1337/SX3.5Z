"""New native housing prototype library. Run exclusively inside Siemens NX.
Geometry uses the existing NX primitives and NewParts ownership/save guard.
This module is NOT a claim of NX runtime verification by the author.
"""
from pathlib import Path
from construction.library04 import reference_library,check_cover_pair
from construction.housing04 import contract,bore_schedule
from .build03 import RecipeBuilder,calibrate,add_component,exact_bounds
from .native import NewParts
from .runtime import write_json_new,sha256_file

NATIVE_EXECUTED_BY_AUTHOR=False


def run(session,NXOpen,directory,log,evidence,config):
    import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Assemblies
    import csv
    data=reference_library()  # entire catalogue/assembly checks BEFORE any NX edit
    root=Path(directory)
    write_json_new(root/'Halter_Eingaben_Snapshot.json',data)
    mode=calibrate(session,NXOpen,root/'_Kalibrierung',log,evidence)
    pd=root/'NX_PARTS';pd.mkdir();ad=root/'NX_ASSEMBLY';ad.mkdir()
    owned=NewParts(session,NXOpen,pd,log,evidence)
    rows=[];made={};bodies={}
    for recipe in data['parts']:
        log('Gestuftes Bauteil: '+recipe['id'])
        part=owned.create(recipe['id'])
        builder=RecipeBuilder(part,NXOpen,evidence)
        final,body,measurement=builder.build_recipe(recipe)
        paramtest=builder.test_parameter(session,recipe,final)
        body=final.GetBodies()[0];warnings=[]
        try:
            dm=session.DisplayManager.NewDisplayModification()
            try:
                dm.ApplyToAllFaces=True;dm.NewColor=int(recipe.get('color_index',36));dm.Apply([body])
            finally:dm.Dispose()
        except Exception as exc:
            warnings.append('Farbe nicht angewandt: '+str(exc))
        path=owned.save(part);made[recipe['id']]=path;bodies[recipe['id']]=body
        row=dict(id=recipe['id'],path=path,sha256=sha256_file(path),source=recipe['source'],
                 nominal_contract=contract(recipe),geometry_check=measurement,parameter_test=paramtest,
                 warnings=warnings,limitations=recipe['limitations'],manufacturing_released=False)
        rows.append(row);write_json_new(pd/(recipe['id']+'_Nachweis.json'),row)
    assemblyfiles=NewParts(session,NXOpen,ad,log,evidence)
    assembly=assemblyfiles.create('HALTERBIBLIOTHEK_04_NICHT_MASCHINENPASSEND')
    from validation.geometry03 import transform_bounds
    inserted=[];partmap={p['id']:p for p in data['parts']}
    for item in data['components']:
        comp=add_component(assembly,NXOpen,evidence,made[item['part_id']],item['id'],item['rotation'],item['origin_mm'],mode)
        occ=evidence.require('Component.FindOccurrence',comp.FindOccurrence)(bodies[item['part_id']])
        if occ is None:raise RuntimeError('No body occurrence for '+item['id'])
        bounds=exact_bounds(assembly,occ,evidence)
        expected=transform_bounds(contract(partmap[item['part_id']])['bounds_mm'],item['rotation'],item['origin_mm'])
        if any(abs(a-b)>.005 for a,b in zip(bounds,expected)):
            raise RuntimeError('Placed housing bounds differ: '+item['id'])
        inserted.append(dict(item,actual_nx_occurrence_bounds_mm=bounds))
    assemblypath=assemblyfiles.save(assembly)
    holes=[row for recipe in data['parts'] for row in bore_schedule(recipe)]
    with open(root/'NX_Bohrungstabelle_04.csv','x',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(holes[0]),delimiter=';');writer.writeheader();writer.writerows(holes)
    report=dict(status='NATIVE_HOUSING_LIBRARY_CREATED_IN_THIS_RUN',native_execution=True,
                assembly_file=assemblypath,assembly_sha256=sha256_file(assemblypath),prototype_count=len(rows),
                occurrence_count=len(inserted),parts=rows,components=inserted,
                cover_pair=check_cover_pair(data['parts'],data['components']),
                position_semantics=data['position_semantics'],manufacturer_original_cad=False,
                machine_fit_verified=False,manufacturing_released=False,
                exact_collision_checked=False,missing=data['missing'])
    write_json_new(root/'NX_Halterbibliothek_04.json',report)
    log('Native Halterbibliothek gespeichert: '+assemblypath)
    log('Keine ausgewaehlten Lager/Kugelmuttern, kein SX-Maschinenanschluss, keine Fertigungsfreigabe.')
    return report
