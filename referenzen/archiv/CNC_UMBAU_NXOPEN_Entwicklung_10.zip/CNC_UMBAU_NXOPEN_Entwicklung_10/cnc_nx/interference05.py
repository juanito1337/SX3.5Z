"""Optional native UF classification, gated by LIVE NX Python help + calibration.
No installed NX runtime or official NX2406 reference was available to the author.
The candidate call is not used unless its embedded signature matches, and its
return codes are learned from actual separated/touching/intersecting NX bodies.
No distance, penetration-volume or mechanical safety result is inferred.
"""
from contextlib import contextmanager
import operator
import re

EXPECTED_CASES={
    'gap':'SEPARATE','touch':'TOUCH','overlap':'INTERSECT','coincident':'INTERSECT',
    'hole_clear':'SEPARATE','hole_hit':'INTERSECT',
    'rotated_gap':'SEPARATE','rotated_touch':'TOUCH','rotated_overlap':'INTERSECT'}


def declaration_compatible(doc):
    for match in re.finditer(r'CheckInterference\s*\(([^)]*)\)',str(doc)):
        args=[v.strip().replace(' ','').lower() for v in match.group(1).split(',')]
        if len(args)==3 and args[0] in ('targ','target','targetbody') and args[1] in (
                'num_tools','numtools','ntool','n_tools','numtool') and args[2] in ('tools','toolbodies'):
            return True
    return False


def single_code(result):
    if not isinstance(result,(list,tuple)) or len(result)!=1 or isinstance(result[0],bool):
        raise RuntimeError('Unexpected NX interference result; exactly one integer array element required: '+repr(result))
    try:return operator.index(result[0])
    except TypeError as exc:raise RuntimeError('NX result is not an integer: '+repr(result)) from exc


def calibration_map(rows):
    if len(rows)!=len(EXPECTED_CASES) or {r['case'] for r in rows}!=set(EXPECTED_CASES):
        raise RuntimeError('Incomplete/duplicate NX collision calibration cases')
    code_to_kind={};kind_to_code={}
    for row in rows:
        expected=EXPECTED_CASES[row['case']]
        if row['expected']!=expected:raise RuntimeError('Changed calibration expectation')
        code=single_code([row['raw_code']]);reverse=single_code([row['reverse_raw_code']])
        if reverse!=code:raise RuntimeError('NX pair classification changes when target/tool are exchanged')
        if code in code_to_kind and code_to_kind[code]!=expected:
            raise RuntimeError('NX does not distinguish contact/separation/penetration in these probes')
        if expected in kind_to_code and kind_to_code[expected]!=code:
            raise RuntimeError('NX code not consistent across box/hole/rotated occurrence cases')
        code_to_kind[code]=expected;kind_to_code[expected]=code
    if len(code_to_kind)!=3:raise RuntimeError('Three distinguishable geometry states required')
    return code_to_kind


class KernelBinding:
    def __init__(self,uf,evidence):
        self.evidence=evidence;self.fn=None;self.name=None;self.mapping=None;diagnostics=[]
        names=list(dict.fromkeys(['Modl','ModlGeneral','Modeling']+[k for k in dir(uf) if k.startswith('Modl')]))
        for name in names:
            group=getattr(uf,name,None);fn=getattr(group,'CheckInterference',None)
            key='UF.'+name+'.CheckInterference';evidence.record(key,fn)
            if not callable(fn):continue
            if declaration_compatible(getattr(fn,'__doc__','')):
                self.fn=fn;self.name=key;break
            diagnostics.append(key+': live Python declaration does not match the three-argument candidate')
        if self.fn is None:
            raise RuntimeError('No documented compatible CheckInterference in this NX Python binding. '
                               'No guessed invocation/no collision PASS. Upload NX_API_Befund.json. '+ '; '.join(diagnostics))

    def raw(self,target,tool):
        if isinstance(target,bool) or isinstance(tool,bool):
            raise ValueError('Two distinct positive integer body tags required')
        try:target=operator.index(target);tool=operator.index(tool)
        except TypeError as exc:raise ValueError('NX tags must be integers, not converted guesses') from exc
        if target<=0 or tool<=0 or target==tool:
            raise ValueError('Two distinct positive body tags required')
        return single_code(self.fn(target,1,[tool]))

    def complete(self,rows):
        self.mapping=calibration_map(rows)
        self.evidence.rows[self.name]['verification']='CALIBRATED_ON_NINE_NATIVE_CASES_IN_THIS_RUN'
        self.evidence.rows[self.name]['calibrated_return_codes']={str(k):v for k,v in self.mapping.items()}

    def classify_code(self,code):
        if self.mapping is None:raise RuntimeError('Native collision backend has not passed calibration')
        if code not in self.mapping:raise RuntimeError('Unknown native collision return code: '+repr(code))
        return self.mapping[code]

    def check(self,target,tool):return self.classify_code(self.raw(target,tool))


def children(part):
    root=part.ComponentAssembly.RootComponent
    return list(root.GetChildren()) if root is not None else []


@contextmanager
def temporary_occurrences(session,nx,part,owner,evidence):
    """Undo only additions to an empty, newly owned inspection assembly.
    Source prototypes must be loaded outside this scope. Cleanup errors are fatal.
    """
    if int(part.Tag) not in owner.records or owner.records[int(part.Tag)]['part'] is not part:
        raise RuntimeError('Inspection part is not owned by this run')
    if children(part):raise RuntimeError('Inspection assembly is not empty before pose; original occurrences are never moved')
    set_mark=evidence.require('Session.SetUndoMark',getattr(session,'SetUndoMark',None))
    undo=evidence.require('Session.UndoToMark',getattr(session,'UndoToMark',None))
    delete=evidence.require('Session.DeleteUndoMark',getattr(session,'DeleteUndoMark',None))
    mark=set_mark(nx.Session.MarkVisibility.Invisible,'CNC05 Temporaere Pruefpose')
    try:
        yield
    finally:
        undo(mark,None)
        if children(part):raise RuntimeError('NX pose rollback left components in the inspection assembly')
        delete(mark,None)
