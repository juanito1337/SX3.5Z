"""Native recipes and measured component placement, targeted at NX2406.
Not run in NX by the author. New calls are recorded from the live Python binding.
Only newly created parts are saved. No other CAD kernel is used.
"""
import itertools,math
from pathlib import Path
from construction.recipes03 import validate_recipe,reference_carrier,I
from assembly.position_components import validated
from validation.geometry03 import vec,transform_bounds
from .parts02 import DraftBuilder,arithmetic
from .native import NewParts,volume
from .runtime import write_json_new,sha256_file
NATIVE_EXECUTED_BY_AUTHOR=False

def numeric_operations(recipe):
 validate_recipe(recipe);p=recipe['parameters'];rows=[]
 for op in recipe['ops']:
  n=dict(kind=op['kind'],operation=op['operation'],name=op['name'],origin=[arithmetic(x,p) for x in op['origin']])
  if op['kind']=='box':n['size']=[arithmetic(x,p) for x in op['size']]
  else:n.update(diameter=arithmetic(op['diameter'],p),height=arithmetic(op['height'],p))
  rows.append(n)
 return rows

def matrix_fields(R,mode):
 validated(R)
 if mode=='ROWS':return [float(R[i][j]) for i in range(3) for j in range(3)]
 if mode=='TRANSPOSE':return [float(R[j][i]) for i in range(3) for j in range(3)]
 raise ValueError('Uncalibrated matrix convention')

def nx_matrix(nx,R,mode):
 m=nx.Matrix3x3()
 for name,value in zip(('Xx','Xy','Xz','Yx','Yy','Yz','Zx','Zy','Zz'),matrix_fields(R,mode)):setattr(m,name,value)
 return m

def exact_bounds(part,body,evidence):
 import NXOpen.UF
 uf=NXOpen.UF.UFSession.GetUFSession();fn=None
 for groupname in ('Modl','ModlGeneral','Modeling'):
  group=getattr(uf,groupname,None);candidate=getattr(group,'AskBoundingBoxExact',None)
  evidence.record('UF.'+groupname+'.AskBoundingBoxExact',candidate)
  if callable(candidate):fn=candidate;break
 if fn is None:raise RuntimeError('AskBoundingBoxExact unavailable; no approximate replacement')
 corner,directions,lengths=fn(body.Tag,part.WCS.CoordinateSystem.Tag)
 if len(directions)==9 and not hasattr(directions[0],'__len__'):directions=[directions[i:i+3] for i in (0,3,6)]
 corners=[[float(corner[i])+sum(bits[j]*float(directions[j][i])*float(lengths[j]) for j in range(3)) for i in range(3)] for bits in itertools.product((0,1),repeat=3)]
 result=[min(v[i] for v in corners) for i in range(3)]+[max(v[i] for v in corners) for i in range(3)]
 if not all(math.isfinite(x) for x in result):raise RuntimeError('Nonfinite NX bounds')
 return result

def unite(part,nx,evidence,target,tool):
 b=evidence.require('Features.CreateBooleanBuilder',part.Features.CreateBooleanBuilder)(nx.Features.BooleanFeature.Null)
 try:
  b.Operation=nx.Features.Feature.BooleanType.Unite;b.Target=target;b.Tools.Add(tool)
  b.RetainTarget=False;b.RetainTool=False;b.CopyTargets=False;b.CopyTools=False;b.Tolerance=.001
  f=b.CommitFeature();bodies=f.GetBodies()
  if len(bodies)!=1:raise RuntimeError('Union did not create exactly one solid')
  return f,bodies[0]
 finally:b.Destroy()

class RecipeBuilder(DraftBuilder):
 def build_recipe(self,r):
  expected=validate_recipe(r);body=final=None
  operation_checks=[];schedule=None
  if r['kind']=='stepped_housing04':
   from construction.housing04 import operation_volumes
   schedule=operation_volumes(r)
  elif r['kind']=='supplier_mount10':
   from construction.nutmount10 import operation_volumes
   schedule=operation_volumes(r)
  elif r['kind']=='supplier_envelope09':
   from construction.ballscrew09 import operation_volumes
   schedule=operation_volumes(r)
  for name,value in r['parameters'].items():self.expression(name,value)
  for index,op in enumerate(r['ops'],1):
   before=volume(self.part,body,self.evidence) if body is not None else None
   name='%03d_%s'%(index,op['name'])
   if op['kind']=='box':f,tool=self.block(op['origin'],op['size'],name+'_Rohkoerper')
   else:f,tool=self.cylinder(op['origin'],op['diameter'],op['height'],name+'_Rohkoerper')
   if body is None:final,body=f,tool
   elif op['operation']=='cut':final,body=self.cut(body,tool,name)
   else:
    final,body=unite(self.part,self.nx,self.evidence,body,tool);final.SetName(name)
    if volume(self.part,body,self.evidence)<=before+1e-6:raise RuntimeError(name+': union adds no material')
   if schedule is not None:
    actual_step=volume(self.part,body,self.evidence)
    self.assert_volume(actual_step,schedule[index-1]['volume_after_mm3'])
    operation_checks.append(dict(index=index,name=name,actual_nx_volume_mm3=actual_step,expected_volume_mm3=schedule[index-1]['volume_after_mm3'],status='PASSED_IN_THIS_NX_RUN'))
  measured=volume(self.part,body,self.evidence);self.assert_volume(measured,expected['expected_volume_mm3'])
  bb=exact_bounds(self.part,body,self.evidence)
  if any(abs(x-y)>.005 for x,y in zip(bb,expected['bounds_mm'])):raise RuntimeError('Unexpected recipe body bounds '+r['id']+': '+repr(bb))
  if not body.IsSolidBody:raise RuntimeError('Not a solid body')
  body.SetName(r['id']+'_REFERENZ_NICHT_FERTIGEN')
  return final,body,dict(actual_nx_volume_mm3=measured,actual_nx_bounds_mm=bb,solid_body=True,operation_checks=operation_checks)
 def test_parameter(self,session,r,final):
  if r['kind']=='stepped_housing04':return self.test_stepped_parameters(session,r,final)
  if r['kind']=='supplier_envelope09':return self.test_catalogue_parameters09(session,r,final)
  if r['kind']=='supplier_mount10':return self.test_mount_parameters10(session,r,final)
  p=r['parameters']
  key='motor_length' if r['kind']=='motor_envelope' else ('length' if r['kind']=='sleeve' else 'thickness')
  old=p[key];expected=r['expected_volume_mm3']
  delta=p['body_w']**2 if key=='motor_length' else expected/old
  mark=session.SetUndoMark(self.nx.Session.MarkVisibility.Invisible,'CNC03 Parameterprobe')
  try:
   self.expressions[key].RightHandSide=str(old+1)
   if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Parameter update error')
   self.assert_volume(volume(self.part,final.GetBodies()[0],self.evidence),expected+delta)
  finally:
   self.expressions[key].RightHandSide=str(old)
   if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Parameter restore error')
  self.assert_volume(volume(self.part,final.GetBodies()[0],self.evidence),expected)
  return dict(parameter=key,status='PASSED_IN_THIS_NX_RUN')

 def test_mount_parameters10(self,session,r,final):
  from construction.nutmount10 import contract,parameter_probes
  nominal=contract(r);results=[]
  def verify(expected):
   bodies=final.GetBodies()
   if len(bodies)!=1:raise RuntimeError('Mount must remain a single body')
   self.assert_volume(volume(self.part,bodies[0],self.evidence),expected['expected_volume_mm3'])
   bb=exact_bounds(self.part,bodies[0],self.evidence)
   if any(abs(a-b)>.005 for a,b in zip(bb,expected['bounds_mm'])):
    raise RuntimeError('Mount probe: unexpected body bounds')
  verify(nominal)
  for probe in parameter_probes(r):
   k=probe['parameter'];expression=self.expressions[k];old=expression.RightHandSide
   mark=session.SetUndoMark(self.nx.Session.MarkVisibility.Invisible,'CNC10 Aufnahme-Parameterprobe')
   try:
    expression.RightHandSide=str(probe['changed_value'])
    if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Mount parameter update error: '+k)
    verify(dict(expected_volume_mm3=probe['changed_volume_mm3'],bounds_mm=probe['changed_bounds_mm']))
   finally:
    expression.RightHandSide=old
    if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Mount parameter restore error: '+k)
    verify(nominal)
   results.append(dict(probe,status='PASSED_IN_THIS_NX_RUN'))
  return dict(status='PASSED_IN_THIS_NX_RUN',probes=results,restored_to_nominal=True,
              scope='MAIN_BODY_ONLY_NOT_CLAMPING_MECHANICS')

 def test_catalogue_parameters09(self,session,r,final):
  from construction.ballscrew09 import contract,parameter_probes
  nominal=contract(r);results=[]
  def verify(expected):
   body=final.GetBodies()[0]
   self.assert_volume(volume(self.part,body,self.evidence),expected['expected_volume_mm3'])
   bb=exact_bounds(self.part,body,self.evidence)
   if any(abs(a-b)>.005 for a,b in zip(bb,expected['bounds_mm'])):
    raise RuntimeError('Catalogue envelope probe: wrong NX body bounds')
  verify(nominal)
  for probe in parameter_probes(r):
   key=probe['parameter'];expression=self.expressions[key];rhs=expression.RightHandSide
   mark=session.SetUndoMark(self.nx.Session.MarkVisibility.Invisible,'CNC09 Kataloghuellen-Parameterprobe')
   try:
    expression.RightHandSide=str(probe['changed_value'])
    if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Catalogue parameter update error: '+key)
    verify(dict(expected_volume_mm3=probe['changed_volume_mm3'],bounds_mm=probe['changed_bounds_mm']))
   finally:
    expression.RightHandSide=rhs
    if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Catalogue parameter restore error: '+key)
    verify(nominal)
   results.append(dict(probe,status='PASSED_IN_THIS_NX_RUN'))
  return dict(status='PASSED_IN_THIS_NX_RUN',probes=results,restored_to_nominal=True,
              scope='NOMINAL_ENVELOPE_PARAMETERS_NOT_PHYSICAL_COMPONENT_MASS_OR_CONTACT')

 def test_stepped_parameters(self,session,r,final):
  from construction.housing04 import contract,parameter_probes
  nominal=contract(r);probes=parameter_probes(r);results=[]
  def verify(expected):
   body=final.GetBodies()[0]
   self.assert_volume(volume(self.part,body,self.evidence),expected['expected_volume_mm3'])
   bounds=exact_bounds(self.part,body,self.evidence)
   if any(abs(a-b)>.005 for a,b in zip(bounds,expected['bounds_mm'])):
    raise RuntimeError('Stepped-housing parameter probe: wrong body bounds')
  verify(nominal)
  for probe in probes:
   key=probe['parameter'];expression=self.expressions[key];original_rhs=expression.RightHandSide
   mark=session.SetUndoMark(self.nx.Session.MarkVisibility.Invisible,'CNC04 Schulter-/Dickenprobe')
   try:
    expression.RightHandSide=str(probe['changed_value'])
    if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Parameter update error: '+key)
    verify(dict(expected_volume_mm3=probe['changed_volume_mm3'],bounds_mm=probe['changed_bounds_mm']))
   finally:
    expression.RightHandSide=original_rhs
    if session.UpdateManager.DoUpdate(mark):raise RuntimeError('Parameter restore error: '+key)
    verify(nominal)
   results.append(dict(probe,status='PASSED_IN_THIS_NX_RUN'))
  return dict(status='PASSED_IN_THIS_NX_RUN',probes=results,restored_to_nominal=True)

def add_component(part,nx,evidence,path,name,R,t,mode):
 result=evidence.require('ComponentAssembly.AddComponent',part.ComponentAssembly.AddComponent)(str(path),'Entire Part',name,nx.Point3d(*vec(t)),nx_matrix(nx,R,mode),1)
 if not isinstance(result,tuple) or len(result)!=2:raise RuntimeError('Unexpected AddComponent return; no success assumed')
 component,status=result
 try:
  if int(status.NumberUnloadedParts):raise RuntimeError('Inserted component not fully loaded')
 finally:status.Dispose()
 if component is None:raise RuntimeError('No component returned')
 pos,rot=component.GetPosition();actual=[pos.X,pos.Y,pos.Z]
 if any(abs(a-b)>1e-6 for a,b in zip(actual,t)):raise RuntimeError('Inserted translation differs')
 raw=[getattr(rot,k) for k in ('Xx','Xy','Xz','Yx','Yy','Yz','Zx','Zy','Zz')]
 if any(abs(a-b)>1e-6 for a,b in zip(raw,matrix_fields(R,mode))):raise RuntimeError('Inserted orientation differs')
 return component

def calibrate(session,nx,directory,log,evidence):
 """Measure a non-symmetric real NX occurrence; never guess row/column convention."""
 directory=Path(directory);directory.mkdir(exist_ok=False)
 owned=NewParts(session,nx,directory,log,evidence)
 p=owned.create('CAL03_BLOCK');b=DraftBuilder(p,nx,evidence)
 _,body=b.block(['4','5','6'],['1','2','3'],'Kalibrierkoerper');path=owned.save(p)
 R=[[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]];t=[40.,50.,60.]
 expected=transform_bounds([4,5,6,5,7,9],R,t);matches=[];rows=[]
 for mode in ('ROWS','TRANSPOSE'):
  root=owned.create('CAL03_'+mode)
  component=add_component(root,nx,evidence,path,'CALIBRATION',R,t,mode)
  occurrence=evidence.require('Component.FindOccurrence',component.FindOccurrence)(body)
  if occurrence is None:raise RuntimeError('Cannot locate occurrence body for orientation verification')
  actual=exact_bounds(root,occurrence,evidence)
  passed=all(abs(a-b)<.005 for a,b in zip(actual,expected))
  rows.append(dict(mode=mode,actual_bounds=actual,expected_bounds=expected,matches=passed))
  if passed:matches.append(mode)
 if len(matches)!=1:raise RuntimeError('No unambiguous measured NX matrix mapping: '+repr(rows))
 report=dict(status='MEASURED_IN_THIS_NX_RUN',mode=matches[0],probes=rows)
 write_json_new(directory/'Matrixkalibrierung.json',report);log('NX-Matrixabbildung am Koerper gemessen: '+matches[0])
 return matches[0]

def build_reference(session,nx,directory,log,evidence,config):
 import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Assemblies
 data=reference_carrier()
 for r in data['parts']:validate_recipe(r)
 mode=calibrate(session,nx,Path(directory)/'_Kalibrierung',log,evidence)
 pd=Path(directory)/'NX_PARTS';pd.mkdir();ad=Path(directory)/'NX_ASSEMBLY';ad.mkdir()
 owned=NewParts(session,nx,pd,log,evidence);made={};rows=[]
 for r in data['parts']:
  log('Bauteil '+r['id']);part=owned.create(r['id']);builder=RecipeBuilder(part,nx,evidence)
  final,body,measures=builder.build_recipe(r);test=builder.test_parameter(session,r,final)
  warnings=[]
  try:
   dm=session.DisplayManager.NewDisplayModification()
   try:dm.ApplyToAllFaces=True;dm.NewColor=int(r.get('color_index',36));dm.Apply([final.GetBodies()[0]])
   finally:dm.Dispose()
  except Exception as exc:warnings.append('Color not applied: '+str(exc))
  filename=owned.save(part);made[r['id']]=filename
  rows.append(dict(id=r['id'],path=filename,sha256=sha256_file(filename),source=r['source'],
                   geometry_check=measures,parameter_check=test,warnings=warnings,manufacturing_released=False))
 asmfiles=NewParts(session,nx,ad,log,evidence);assembly=asmfiles.create('MOTORTRAEGER_CAT2022_REFERENZ_NICHT_MASCHINENPASSEND')
 inserted=[]
 for item in data['components']:
  comp=add_component(assembly,nx,evidence,made[item['part_id']],item['id'],item['rotation'],item['origin_mm'],mode)
  inserted.append(dict(item))
 assemblypath=asmfiles.save(assembly)
 report=dict(status='NATIVE_REFERENCE_ASSEMBLY_CREATED_IN_THIS_RUN',native_execution=True,assembly_file=assemblypath,
             prototype_count=len(rows),occurrence_count=len(inserted),parts=rows,components=inserted,
             manufacturer_original_cad=False,machine_fit_verified=False,manufacturing_released=False,
             exact_collision_checked=False,missing=data['missing'])
 write_json_new(Path(directory)/'NX_Motortraeger_Referenz.json',report)
 log('Referenzbaugruppe gespeichert: '+assemblypath)
 log('Keine Maschinenmontage, keine vollstaendige Antriebsauslegung oder Fertigungsfreigabe.')
 return report

def run(session,NXOpen,directory,log,evidence,config):return build_reference(session,NXOpen,directory,log,evidence,config)
