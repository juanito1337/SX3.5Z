"""Output and diagnostics only. No CAD API is imported outside NX execution.
Uses an independent local output root; never overwrites an existing file.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from datetime import datetime
from uuid import uuid4


def sha256_file(path):
    digest=hashlib.sha256()
    with open(path,'rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def write_json_new(path,data):
    # Serialize before opening, so invalid data cannot leave an empty report.
    text=json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    with open(path,'x',encoding='utf-8') as handle:handle.write(text)


def create_run_directory(root,kind):
    if not re.fullmatch(r'[A-Za-z0-9_\-]+',kind):raise ValueError('Ungueltige Laufbezeichnung')
    root=Path(os.path.expandvars(os.path.expanduser(str(root))))
    if not root.is_absolute():raise ValueError('Ausgabeordner muss absolut sein')
    root.mkdir(parents=True,exist_ok=True)
    run=root/(datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+kind+'_'+uuid4().hex[:10])
    run.mkdir(exist_ok=False)
    # Test only newly created files owned by this run.
    first=run/('_io_'+uuid4().hex+'.tmp');second=run/(first.stem+'_renamed.tmp')
    content=uuid4().hex.encode('ascii')
    try:
        with open(first,'xb') as handle:
            handle.write(content);handle.flush();os.fsync(handle.fileno())
        if first.read_bytes()!=content:raise OSError('Ausgabeverzeichnis: Ruecklesepruefung fehlgeschlagen')
        first.rename(second)
        if second.read_bytes()!=content:raise OSError('Ausgabeverzeichnis: Umbenennung fehlgeschlagen')
    finally:
        for owned in (first,second):
            if owned.exists():owned.unlink()
    return run


def configured_output(project_dir):
    path=Path(project_dir)/'config'/'project.json'
    with open(path,encoding='utf-8-sig') as f:cfg=json.load(f)
    root=cfg.get('output_root','')
    if not isinstance(root,str):raise ValueError('output_root muss Text sein')
    if not root:
        local=os.environ.get('LOCALAPPDATA')
        root=str(Path(local)/'SX35Z_CNC'/'Projekt10') if local else str(Path.home()/'SX35Z_CNC'/'Projekt10')
    return root,cfg


class RunLog:
    def __init__(self,session,directory):
        self.path=Path(directory)/'NX_Protokoll.txt'
        self.handle=open(self.path,'x',encoding='utf-8')
        self.window=session.ListingWindow
        self.window.Open()
    def __call__(self,message):
        line=str(message)
        self.handle.write(line+'\n');self.handle.flush()
        try:self.window.WriteLine(line)
        except Exception:pass  # Text file is the authoritative error log.
    def close(self):self.handle.close()


class ApiEvidence:
    """Records the live binding, not a claim that a call worked."""
    def __init__(self):self.rows={}
    def record(self,name,value):
        if name not in self.rows:
            self.rows[name]={'available':value is not None,'callable':callable(value),
                             'python_type':type(value).__name__,
                             'docstring':str(getattr(value,'__doc__',''))[:16000],
                             'verification':'RUNTIME_PRESENCE_ONLY'}
        return value
    def require(self,name,value):
        self.record(name,value)
        if not callable(value):raise RuntimeError('NX-Aufruf nicht vorhanden: '+name)
        return value
    def environment(self,NXOpen):
        return {'python':sys.version,'nxopen_module':str(getattr(NXOpen,'__file__','unknown')),
                'module_methods':self.rows,'nx_version_target':'2406',
                'official_2406_reference_access':'Not available to author; see docs/API_PRUEFSTAND_03.md'}
