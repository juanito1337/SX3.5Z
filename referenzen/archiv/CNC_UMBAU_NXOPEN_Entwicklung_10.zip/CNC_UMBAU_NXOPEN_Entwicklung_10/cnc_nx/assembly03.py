"""Create NEW native subassemblies from an explicit reviewed manifest.
Source parts are never edited, suppressed or saved. Omission applies only to new structure.
No mounting constraints, dynamics or engineering release are claimed.
"""
import json,os
from pathlib import Path
from assembly.manifest03 import validate_manifest
from .native import NewParts,require_saved_source
from .build03 import calibrate,add_component,exact_bounds
from .runtime import write_json_new,sha256_file

def project_root():return Path(os.path.abspath(__file__)).parents[1]
def load_config(name):
 with open(project_root()/'config'/name,encoding='utf-8-sig') as f:return json.load(f)
def norm(path):return os.path.normcase(os.path.abspath(str(path)))

def open_source(session,nx,path,evidence):
 matches=[p for p in session.Parts if str(p.FullPath) and norm(p.FullPath)==norm(path)]
 if len(matches)>1:raise RuntimeError('Ambiguous loaded source')
 if matches:part=matches[0]
 else:
  result=evidence.require('Parts.OpenBaseDisplay',session.Parts.OpenBaseDisplay)(str(path))
  if not isinstance(result,tuple) or len(result)!=2:raise RuntimeError('Unexpected OpenBaseDisplay result')
  part,status=result
  try:
   if int(status.NumberUnloadedParts):raise RuntimeError('Source not fully loaded')
  finally:status.Dispose()
 if part.PartUnits!=nx.BasePart.Units.Millimeters or not bool(part.IsFullyLoaded):raise RuntimeError('Source must be fully loaded millimetre part')
 require_saved_source(part)
 if part.ComponentAssembly.RootComponent is not None and part.ComponentAssembly.RootComponent.GetChildren():
  raise RuntimeError('Manifest expects native leaf parts, not nested external assemblies')
 return part

def build_manifest(session,nx,directory,log,evidence,manifest):
 import NXOpen.Features,NXOpen.GeometricUtilities,NXOpen.Assemblies
 cfg=validate_manifest(manifest) # all filenames, hashes and decisions before native writes
 protected={}
 for c in cfg['components']:
  if c['path'] not in protected:
   part=open_source(session,nx,c['path'],evidence)
   protected[c['path']]={'part':part,'sha256':sha256_file(c['path'])}
 mode=calibrate(session,nx,Path(directory)/'_Kalibrierung',log,evidence)
 d=Path(directory)/'NX_ASSEMBLY';d.mkdir();owned=NewParts(session,nx,d,log,evidence)
 groups={};rows=[];bounds=[]
 try:
  for group in cfg['groups']:
   p=owned.create('GRUPPE_'+group)
   for c in [v for v in cfg['components'] if v['group']==group]:
    comp=add_component(p,nx,evidence,c['path'],c['id'],c['rotation'],c['origin_mm'],mode)
    proto=protected[c['path']]['part'];solid_count=0
    for i,body in enumerate(proto.Bodies):
     if not body.IsSolidBody:continue
     solid_count+=1
     occurrence=evidence.require('Component.FindOccurrence',comp.FindOccurrence)(body)
     if occurrence is None:raise RuntimeError('Cannot measure occurrence: '+c['id'])
     bounds.append(dict(component=c['id'],body_index=i,group=group,bounds_mm=exact_bounds(p,occurrence,evidence),frame='ROOT_ABSOLUTE_ALL_GROUPS_IDENTITY'))
    if not solid_count:raise RuntimeError('Component has no solid bodies: '+c['id'])
    rows.append(dict(c,actual_nx_solid_count=solid_count))
   groups[group]=owned.save(p)
  root=owned.create('FRAESMASCHINE_CNC_MONTAGEENTWURF_NICHT_FREIGEGEBEN')
  identity=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
  for g,path in groups.items():add_component(root,nx,evidence,path,g,identity,[0.,0.,0.],mode)
  assembly_path=owned.save(root)
 finally:
  # Report source integrity on error as well; never try to repair/save a changed source.
  checks=[]
  for path,state in protected.items():
   checks.append(dict(path=path,hash_before=state['sha256'],hash_after=sha256_file(path),modified_after=bool(state['part'].IsModified)))
  write_json_new(Path(directory)/'Quellschutz.json',checks)
  if any(x['hash_before']!=x['hash_after'] or x['modified_after'] for x in checks):raise RuntimeError('Source changed during assembly build')
 report=dict(status='NATIVE_REVIEWED_LAYOUT_CREATED_NOT_RELEASED',native_execution=True,assembly_file=assembly_path,
             groups=groups,components=rows,original_reuse_decisions=cfg.get('source_inventory'),
             manufacturing_released=False,exact_collision_checked=False,motion_constraints_created=False,
             changes_to_original_files=False)
 write_json_new(Path(directory)/'NX_Montageentwurf.json',report)
 write_json_new(Path(directory)/'NX_Montage_AABB.json',dict(bounds=bounds,exact_collision_checked=False))
 log('Native Montagebaugruppe gespeichert, nicht fertigungstechnisch freigegeben: '+assembly_path)
 return report

def run(session,NXOpen,directory,log,evidence,config):
 return build_manifest(session,NXOpen,directory,log,evidence,load_config('assembly03.json'))
