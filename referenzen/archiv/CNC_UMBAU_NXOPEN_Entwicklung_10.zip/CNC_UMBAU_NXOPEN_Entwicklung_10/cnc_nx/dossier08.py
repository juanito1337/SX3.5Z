"""Current-assembly dossier and independent reference-carrier inspection pipeline.
Originals are read only. All source states are captured again before publication.
No NX execution by author; see API_PRUEFSTAND_08.md.
"""
import json
from collections import Counter
from pathlib import Path
from construction.recipes03 import reference_carrier
from validation.interfaces08 import reference_checks,evaluate_reference
from validation.dossier08 import subject_from_snapshot,build_dossier,digest,verify_subject
from exports.dossier08 import export_dossier
from cnc_nx.inspection08 import capture_with_positions,read_reference_faces
from cnc_nx.runtime import write_json_new,sha256_file


def _spec(role,path):return dict(role=role,path=str(path),sha256=sha256_file(path))


def run_for_current(session,nx,directory,log,evidence,artifacts,registry,built=None):
    from cnc_nx.bom07 import run_report
    root=Path(directory)
    before=capture_with_positions(session,nx,evidence,log)
    write_json_new(root/'NX_Pruefaufnahme_08.json',before)
    subject=subject_from_snapshot(before)
    specs=list(artifacts)
    expected=None
    if built is not None:
        measured=read_reference_faces(session,nx,built,evidence,log)
        evaluation=evaluate_reference(measured)
        result=dict(schema='SX35Z_NATIVE_INTERFACES_8',native_execution=True,
            subject_fingerprint=subject['fingerprint'],scope='REFERENCE_CARRIER_ONLY',
            contract_sha256=digest(reference_checks()),measurements=measured,evaluation=evaluation,
            status='WITHIN_NUMERIC_MODEL_LIMITS' if evaluation['all_within_limits'] else 'FAILED_OR_INCOMPLETE',
            physical_measurement=False,manufacturing_released=False,
            limits_are_manufacturing_tolerances=False)
        path=root/'NX_Schnittstellen_08.json';write_json_new(path,result);specs.append(_spec('interfaces',path))
        expected=Counter(c['part_id'] for c in reference_carrier()['components'])
    run_report(session,root,log,evidence,registry,expected_quantities=expected)
    specs.append(_spec('bom',root/'NX_Stueckliste_07.json'))
    # Source capture is deliberately repeated after every native read, not just
    # inferred from a successful Python return. Never save/repair a changed part.
    after=capture_with_positions(session,nx,evidence,log)
    write_json_new(root/'NX_Pruefaufnahme_08_nachher.json',after)
    try:
        after_subject=subject_from_snapshot(after)
        unchanged=subject['fingerprint']==after_subject['fingerprint']
        write_json_new(root/'Quellschutz_08.json',dict(unchanged=unchanged,
            before=subject['fingerprint'],after=after_subject['fingerprint'],original_write_operations=0))
        if not unchanged:raise RuntimeError('Original file, configuration or position changed during inspection')
    except Exception as exc:
        if not (root/'Quellschutz_08.json').exists():
            write_json_new(root/'Quellschutz_08.json',dict(unchanged=False,error=str(exc),original_write_operations=0))
        raise
    report=build_dossier(after,specs)
    report['native_read_in_this_run']=True
    report['new_reference_built_before_inspection']=built is not None
    export_dossier(root/'PRUEFDOSSIER',report)
    verify_subject(subject)
    final_snapshot=capture_with_positions(session,nx,evidence,log)
    write_json_new(root/'NX_Pruefaufnahme_08_abschluss.json',final_snapshot)
    final_guard=dict(unchanged=False,original_write_operations=0)
    try:
        final_subject=subject_from_snapshot(final_snapshot)
        final_guard['unchanged']=final_subject['fingerprint']==subject['fingerprint']
        if not final_guard['unchanged']:raise RuntimeError('Source changed during report export')
    except Exception as exc:
        final_guard['error']=str(exc);raise
    finally:
        write_json_new(root/'Quellschutz_08_Abschluss.json',final_guard)
    write_json_new(root/'NX_Pruefdossier_08.json',report)
    log('Prüfdossier: '+report['status']+'; keine Maschinen-/Fertigungsfreigabe.')
    return report


def run(session,NXOpen,directory,log,evidence,config):
    project=Path(__file__).resolve().parents[1]
    with (project/'config'/'dossier08.json').open(encoding='utf-8-sig') as f:job=json.load(f)
    if job.get('schema')!='SX35Z_DOSSIER_JOB_8' or set(job)!={'schema','artifacts'}:
        raise ValueError('Invalid dossier08 configuration')
    with (project/'config'/'bom07.json').open(encoding='utf-8-sig') as f:registry=json.load(f)
    return run_for_current(session,NXOpen,directory,log,evidence,job['artifacts'],registry)


def run_reference(session,NXOpen,directory,log,evidence,config):
    from cnc_nx.build03 import build_reference
    from cnc_nx.bom_reference07 import reference_registry
    built=build_reference(session,NXOpen,directory,log,evidence,config)
    registry=reference_registry(built)
    write_json_new(Path(directory)/'Referenzzuordnung_08.json',registry)
    artifacts=[_spec('native_geometry',Path(directory)/'NX_Motortraeger_Referenz.json')]
    return run_for_current(session,NXOpen,directory,log,evidence,artifacts,registry,built)
