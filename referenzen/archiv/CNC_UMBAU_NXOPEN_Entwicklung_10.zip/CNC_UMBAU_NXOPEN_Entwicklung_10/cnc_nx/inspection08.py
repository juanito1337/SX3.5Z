"""Read-only surface measurements using existing project NX API families.

No source loading, Save, suppression or setter. The reference inspector supports
only the explicit seven-part carrier at identity rotations. Prototype surfaces are
translated by measured component origins and checked against measured occurrence
bounds; no inferred global transform of an arbitrary nested machine assembly.
Not executed in NX by the author.
"""
import json
from pathlib import Path
from construction.recipes03 import reference_carrier,I
from analysis.bom07 import path_key
from validation.geometry03 import transform_bounds
from validation.dossier08 import _file
from cnc_nx.audit import encode_position,encode_face_data,_uf_method
from cnc_nx.bom07 import capture
from cnc_nx.build03 import exact_bounds


def capture_with_positions(session,nx,evidence,log):
    snap=capture(session,evidence,log)
    snap['positions_complete']=True
    nodes={n['path']:n for n in snap['occurrences']}
    partrows={path_key(p['path']):p for p in snap['prototypes'] if p.get('path')}
    def failure(where,exc):
        snap['positions_complete']=False
        snap['issues'].append(dict(code='POSE_OR_UNIT_NOT_READ',severity='ERROR',where=where,message=str(exc)))
        log('Nicht gelesen: '+where+' / '+str(exc))
    def partunit(part):
        key=path_key(part.FullPath)
        if key not in partrows:raise RuntimeError('Prototype set changed during capture')
        mm=part.PartUnits==nx.BasePart.Units.Millimeters
        if type(mm) is not bool:raise ValueError('Unit comparison did not return Boolean')
        partrows[key]['unit_mm']=mm
    displayed=session.Parts.Display
    try:
        partunit(displayed)
        root=displayed.ComponentAssembly.RootComponent
        if root is None:
            nodes['0000']['position_raw']=dict(origin_raw=[0.,0.,0.],matrix_raw=I,
                frame_status='ROOT_LOCAL_IDENTITY_NOT_MACHINE_REGISTRATION')
        else:
            stack=[('0000',root)];seen=set()
            while stack:
                path,comp=stack.pop()
                if path in seen or path not in nodes:raise RuntimeError('Changed occurrence tree')
                seen.add(path);row=nodes[path]
                if row['suppressed'] is not False:continue
                try:
                    partunit(comp.Prototype)
                    fn=evidence.require('Component.GetPosition',getattr(comp,'GetPosition',None))
                    row['position_raw']=encode_position(fn())
                    # Do not query children of a partially loaded prototype.
                    if row.get('children_count') is None:raise RuntimeError('Unknown child count')
                    children=list(comp.GetChildren())
                    if len(children)!=row['children_count']:raise RuntimeError('Children changed during capture')
                    for i,c in enumerate(children):stack.append((path+'/'+str(i).zfill(4),c))
                except Exception as exc:failure(path,exc)
    except Exception as exc:failure('root/positions',exc)
    for row in snap['prototypes']:
        if 'unit_mm' not in row:failure(row['id'],RuntimeError('Units not read'))
    return snap


def _face_method(evidence):
    import NXOpen.UF
    uf=NXOpen.UF.UFSession.GetUFSession()
    fn=_uf_method(uf,'AskFaceData',evidence)
    if fn is None:raise RuntimeError('AskFaceData unavailable; no synthetic measurement substitute')
    return fn


def read_reference_faces(session,nx,built,evidence,log):
    displayed=session.Parts.Display
    if displayed is None or path_key(displayed.FullPath)!=path_key(built['assembly_file']):
        raise RuntimeError('Displayed root is not the generated reference assembly')
    if displayed.IsModified is not False or displayed.IsFullyLoaded is not True:
        raise RuntimeError('Root must be saved, clean and fully loaded')
    data=reference_carrier();recipes={r['id']:r for r in data['parts']}
    files={r['id']:r for r in built['parts']}
    if set(files)!=set(recipes):raise ValueError('Unexpected reference prototype set')
    children=list(displayed.ComponentAssembly.RootComponent.GetChildren())
    expected={c['id']:c for c in data['components']}
    if len(children)!=len(expected) or {c.Name for c in children}!=set(expected):
        raise RuntimeError('Exactly the seven named reference occurrences are required')
    facefn=_face_method(evidence);measurements=[]
    for comp in children:
        if comp.IsSuppressed is not False:
            raise RuntimeError('Suppressed or unknown reference occurrence is not inspected')
        c=expected[comp.Name];p=comp.Prototype;f=files[c['part_id']]
        if (path_key(p.FullPath)!=path_key(f['path']) or p.IsModified is not False or p.IsFullyLoaded is not True
            or p.PartUnits!=nx.BasePart.Units.Millimeters):
            raise RuntimeError('Reference prototype is wrong, dirty, not loaded or not in mm: '+comp.Name)
        _file(p.FullPath,f['sha256'],'.prt')
        pos=encode_position(evidence.require('Component.GetPosition',comp.GetPosition)())
        if any(abs(pos['matrix_raw'][i][j]-I[i][j])>1e-8 for i in range(3) for j in range(3)):
            raise RuntimeError('Reference surface adapter supports identity rotations only')
        if c['rotation']!=I:raise RuntimeError('Reference recipe changed to nonidentity orientation')
        bodies=list(p.Bodies)
        if len(bodies)!=1 or bodies[0].IsSolidBody is not True:raise RuntimeError('Expected single solid in '+comp.Name)
        body=bodies[0]
        occurrence=evidence.require('Component.FindOccurrence',comp.FindOccurrence)(body)
        if occurrence is None:raise RuntimeError('Missing occurrence body')
        actual=exact_bounds(displayed,occurrence,evidence)
        nominal=transform_bounds(recipes[c['part_id']]['bounds_mm'],I,pos['origin_raw'])
        if any(abs(a-b)>.005 for a,b in zip(actual,nominal)):
            raise RuntimeError('Measured occurrence bounds do not match measured placement: '+comp.Name)
        faces=[]
        for face in evidence.require('Body.GetFaces',body.GetFaces)():
            encoded=encode_face_data(facefn(face.Tag))
            encoded['journal_id']=str(face.JournalIdentifier)
            json.dumps(encoded,allow_nan=False)
            faces.append(encoded)
        if not faces:raise RuntimeError('No measured faces: '+comp.Name)
        _file(p.FullPath,f['sha256'],'.prt')
        if p.IsModified is not False:raise RuntimeError('Part modified during face read')
        measurements.append(dict(id=comp.Name,prototype_path=p.FullPath,prototype_sha256=f['sha256'],
            translation_mm=pos['origin_raw'],rotation=I,faces=faces,
            actual_nx_occurrence_bounds_mm=actual,measurement_origin='NX_PROTOTYPE_FACES_PLUS_MEASURED_TRANSLATION',
            prototype_units='mm',original_writes=0))
        log('Schnittstellenflächen gelesen: '+comp.Name+' / '+str(len(faces)))
    return measurements
