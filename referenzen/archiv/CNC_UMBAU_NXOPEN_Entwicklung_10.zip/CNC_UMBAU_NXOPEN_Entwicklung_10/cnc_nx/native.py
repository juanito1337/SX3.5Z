"""Small native NX adapter. Author did NOT execute this in NX 2406.
Factories follow the prior NX2406 journal's documented/runtime-exercised patterns.
New calls are recorded and must pass on the user's NX installation.
"""
import os
from pathlib import Path
import re
from uuid import uuid4
from .runtime import sha256_file


def identity(NXOpen):
    m=NXOpen.Matrix3x3()
    m.Xx=1.;m.Xy=0.;m.Xz=0.;m.Yx=0.;m.Yy=1.;m.Yz=0.;m.Zx=0.;m.Zy=0.;m.Zz=1.
    return m


def require_saved_source(part):
    path=str(part.FullPath)
    if not path or not os.path.isabs(path) or not os.path.isfile(path):
        raise RuntimeError('Bestandsbaugruppe muss als lokale native Datei gespeichert sein; keine PDM-/Teamcenter-Aufloesung.')
    if bool(part.IsModified):raise RuntimeError('Bestandsbaugruppe hat ungespeicherte Aenderungen. Journal speichert Originale nicht.')
    return {'path':path,'sha256':sha256_file(path)}


class NewParts:
    """Only parts created by this object can be saved. SaveComponents=False."""
    def __init__(self,session,NXOpen,directory,log,evidence):
        self.session=session;self.nx=NXOpen;self.directory=Path(directory)
        self.log=log;self.evidence=evidence;self.records={};self.token=uuid4().hex[:10]
    def path(self,stem):
        if not re.fullmatch(r'[A-Za-z0-9_\-]+',stem):raise ValueError('Ungueltiger Teilname')
        return self.directory/(stem+'__'+self.token+'.prt')
    def create(self,stem):
        NXOpen=self.nx;path=self.path(stem)
        if path.exists() or path.is_symlink():raise FileExistsError(str(path))
        for part in self.session.Parts:
            existing=str(part.FullPath)
            if existing and os.path.basename(existing).casefold()==path.name.casefold():
                raise RuntimeError('Dateiname bereits in NX geladen: '+path.name)
        create=self.evidence.require('PartCollection.NewDisplay',self.session.Parts.NewDisplay)
        p=create(str(path),NXOpen.Part.Units.Millimeters)
        if os.path.normcase(os.path.abspath(str(p.FullPath)))!=os.path.normcase(os.path.abspath(str(path))):
            raise RuntimeError('NX hat unerwarteten Zielpfad gesetzt')
        if p.PartUnits!=NXOpen.BasePart.Units.Millimeters:raise RuntimeError('Neues Teil ist kein Millimeterteil')
        if not p.Preferences.Modeling.GetHistoryMode():raise RuntimeError('History-Modus fuer native Parametrik erforderlich')
        p.WCS.SetOriginAndMatrix(NXOpen.Point3d(0.,0.,0.),identity(NXOpen))
        self.records[int(p.Tag)]={'part':p,'path':path,'disk_hash':sha256_file(path) if path.exists() else None}
        self.log('Neues Teil: '+str(path));return p
    def save(self,part):
        record=self.records.get(int(part.Tag))
        if record is None:raise RuntimeError('Speichern verweigert: Teil ist nicht Eigentum dieses Laufs')
        path=record['path']
        if os.path.normcase(os.path.abspath(str(part.FullPath)))!=os.path.normcase(os.path.abspath(str(path))):
            raise RuntimeError('Teilpfad geaendert; fremde Datei wird nicht gespeichert')
        if path.is_symlink():raise RuntimeError('Symlink-Ziel verweigert')
        if path.exists() and (record['disk_hash'] is None or sha256_file(path)!=record['disk_hash']):
            raise RuntimeError('Zieldatei wurde ausserhalb des Journals angelegt/geaendert')
        save=self.evidence.require('BasePart.Save',part.Save)
        status=save(self.nx.BasePart.SaveComponents.FalseValue,self.nx.BasePart.CloseAfterSave.FalseValue)
        if status is None:raise RuntimeError('Kein NX-Speicherstatus erhalten; kein Erfolg behauptet')
        try:
            count=int(status.NumberUnsavedParts)
            objects=int(getattr(status,'NumberUnsavedObjects',0))
            if count or objects:raise RuntimeError('NX meldet ungespeicherte Teile/Objekte: %s/%s'%(count,objects))
        finally:status.Dispose()
        if not path.is_file() or path.stat().st_size==0:raise RuntimeError('Keine nichtleere native Datei erzeugt')
        record['disk_hash']=sha256_file(path)
        self.log('Neue native Datei gespeichert: '+str(path));return str(path)


def cylinder(part,NXOpen,evidence,diameter_formula,height_formula,z,name):
    factory=evidence.require('Features.CreateCylinderBuilder',part.Features.CreateCylinderBuilder)
    builder=factory(NXOpen.Features.Feature.Null)
    try:
        builder.Type=NXOpen.Features.CylinderBuilder.Types.AxisDiameterAndHeight
        builder.Diameter.RightHandSide=diameter_formula;builder.Height.RightHandSide=height_formula
        builder.Origin=NXOpen.Point3d(0.,0.,float(z));builder.Direction=NXOpen.Vector3d(0.,0.,1.)
        builder.ReverseDirection=False
        origin=part.Points.CreatePoint(NXOpen.Point3d(0.,0.,float(z)))
        update=NXOpen.SmartObject.UpdateOption.WithinModeling
        direction=part.Directions.CreateDirection(NXOpen.Point3d(0.,0.,0.),NXOpen.Vector3d(0.,0.,1.),update)
        axis=part.Axes.CreateAxis(origin,direction,update);axis.Evaluate()
        builder.Axis=axis;builder.ParentAssociativity=True
        builder.BooleanOption.Type=NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
        feat=builder.CommitFeature();feat.SetName(name)
        bodies=feat.GetBodies()
        if len(bodies)!=1:raise RuntimeError('Zylinder liefert nicht genau einen Koerper')
        return feat,bodies[0]
    finally:builder.Destroy()


def subtract(part,NXOpen,evidence,target,tool):
    factory=evidence.require('Features.CreateBooleanBuilder',part.Features.CreateBooleanBuilder)
    builder=factory(NXOpen.Features.BooleanFeature.Null)
    try:
        builder.Operation=NXOpen.Features.Feature.BooleanType.Subtract
        builder.Target=target;builder.Tools.Add(tool)
        builder.RetainTarget=False;builder.RetainTool=False
        builder.CopyTargets=False;builder.CopyTools=False;builder.Tolerance=0.001
        feat=builder.CommitFeature();feat.SetName('Bohrung_Nennmass_KEINE_PASSUNGSFREIGABE')
        bodies=feat.GetBodies()
        if len(bodies)!=1:raise RuntimeError('Huelse liefert nicht genau einen Koerper')
        return feat,bodies[0]
    finally:builder.Destroy()


def volume(part,body,evidence):
    units=[part.UnitCollection.FindObject(n) for n in
           ('SquareMilliMeter','CubicMilliMeter','Kilogram','MilliMeter','Newton')]
    create=evidence.require('MeasureManager.NewMassProperties',part.MeasureManager.NewMassProperties)
    result=None
    try:
        result=create(units,0.999999,[body])
        return float(result.Volume)
    finally:
        if result is not None:result.Dispose()
