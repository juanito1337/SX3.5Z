"""Read-only inventory of the CURRENT DISPLAYED native NX assembly.
No Save, setters, loading, suppression, attribute editing or CAD creation.
Raw positions and prototype face data are NOT approved physical interfaces.
"""
import math
from pathlib import Path
from .core import rotation_quality
from .runtime import sha256_file,write_json_new


def finite_vector(values,count):
    if len(values)!=count:raise ValueError('Unerwartete Vektorlaenge')
    result=[float(x) for x in values]
    if not all(math.isfinite(x) for x in result):raise ValueError('Nicht endliche Koordinaten')
    return result


def xyz(p):return finite_vector([p.X,p.Y,p.Z],3)


def matrix_rows(m):
    return [finite_vector([getattr(m,a) for a in names],3)
            for names in [('Xx','Xy','Xz'),('Yx','Yy','Yz'),('Zx','Zy','Zz')]]


def encode_position(result):
    if not isinstance(result,(tuple,list)) or len(result)!=2:raise ValueError('GetPosition: unerwartete Rueckgabe')
    rows=matrix_rows(result[1])
    return {'origin_raw':xyz(result[0]),'matrix_raw':rows,'rotation_check':rotation_quality(rows),
            'frame_status':'RAW_NX_NOT_YET_VALIDATED',
            'note':'GetPosition unveraendert. Bezug zum Parent/root vor Montage nachweisen; keine automatisch kumulierten Maschinenkoordinaten.'}


def encode_face_data(result):
    if not isinstance(result,(tuple,list)) or len(result)!=7:raise ValueError('AskFaceData erwartet 7 Rueckgabewerte')
    typ,point,direction,bounds,radius,extra,norm=result
    return {'uf_type_code':int(typ),'point_raw':finite_vector(point,3),'direction_raw':finite_vector(direction,3),
            'bounds_raw':finite_vector(bounds,6),'radius_part_units':float(radius),
            'rad_data_raw':float(extra),'normal_direction_raw':int(norm),
            'coordinate_frame':'PROTOTYPE_ABSOLUTE','interface_status':'CANDIDATE_NOT_IDENTIFIED',
            'note':'Zylinder ist nicht automatisch Bohrung/Lagersitz. Bauteileinheit und Maschinenbezug separat pruefen.'}


class Reader:
    def __init__(self,log):self.log=log;self.issues=[]
    def get(self,label,function):
        try:return function()
        except Exception as exc:
            row={'where':label,'status':'NOT_READ','exception':type(exc).__name__,'message':str(exc)}
            self.issues.append(row);self.log('Nicht gelesen: '+label+' / '+str(exc));return None


def object_key(obj):
    try:return ('tag',int(obj.Tag))
    except Exception:return ('python_object',id(obj))


def walk_tree(root,ancestor_keys=(),path='0000'):
    """Every occurrence is retained; only ancestor cycles are rejected."""
    key=object_key(root)
    if key in ancestor_keys:raise RuntimeError('Zyklische Komponentenreferenz bei '+path)
    yield path,root
    children=root.GetChildren()
    for index,child in enumerate(children):
        yield from walk_tree(child,ancestor_keys+(key,),path+'/'+str(index).zfill(4))


def _uf_method(uf,name,evidence):
    for group_name in ('Modl','ModlGeneral','Modeling'):
        group=getattr(uf,group_name,None)
        fn=getattr(group,name,None) if group is not None else None
        evidence.record('UF.'+group_name+'.'+name,fn)
        if callable(fn):return fn
    return None


def run(session,NXOpen,directory,log,evidence,config):
    import NXOpen.UF
    reader=Reader(log)
    displayed=session.Parts.Display
    if displayed is None:raise RuntimeError('Bitte zuerst die originale Hauptbaugruppe vollstaendig in NX oeffnen.')
    root=displayed.ComponentAssembly.RootComponent
    if root is None:raise RuntimeError('Angezeigtes Teil hat keine Baugruppenwurzel; keine Maschinenbaugruppe erkannt.')
    uf=NXOpen.UF.UFSession.GetUFSession()
    face_fn=_uf_method(uf,'AskFaceData',evidence)
    bounds_fn=_uf_method(uf,'AskBoundingBox',evidence)
    report={'schema':'SX35Z_NX_AUDIT_1','native_execution':True,
            'purpose':'DESIGN_INVENTORY_NOT_PHYSICAL_MEASUREMENT',
            'final_cnc_assembly':False,'manufacturing_released':False,
            'prototypes':[],'occurrences':[],
            'coordinate_policy':'Raw NX transforms only; geometric face data in prototype absolute coordinates.',
            'checks_not_performed':['collision','travel_sweep','coaxiality','bearing_fit','safety','machine_measurement'],
            'issues':reader.issues}
    file_hashes={};prototypes={}
    max_faces=int(config.get('max_faces_per_body',50000))
    if max_faces<1:raise ValueError('max_faces_per_body muss positiv sein')
    if not face_fn:reader.get('UF.AskFaceData',lambda:(_ for _ in ()).throw(RuntimeError('API nicht verfuegbar')))
    if not bounds_fn:reader.get('UF.AskBoundingBox',lambda:(_ for _ in ()).throw(RuntimeError('API nicht verfuegbar')))

    def part_info(part):
        key=object_key(part)
        if key in prototypes:return prototypes[key]
        pid='PROTO_%04d'%(len(prototypes)+1);prototypes[key]=pid
        row={'id':pid,'name':reader.get(pid+'.Name',lambda:part.Name),
             'path':reader.get(pid+'.FullPath',lambda:part.FullPath),
             'part_units_raw':reader.get(pid+'.PartUnits',lambda:str(part.PartUnits)),
             'is_modified_before':reader.get(pid+'.IsModified',lambda:bool(part.IsModified)),
             'is_fully_loaded':reader.get(pid+'.IsFullyLoaded',lambda:bool(part.IsFullyLoaded)),
             'bodies':[],'features':[],'expressions':[],'datum_coordinate_systems':[]}
        report['prototypes'].append(row)
        try:
            row['unit_mm']=part.PartUnits==NXOpen.BasePart.Units.Millimeters
            row['unit_inch']=part.PartUnits==NXOpen.BasePart.Units.Inches
        except Exception as exc:
            reader.get(pid+'.unit_comparison',lambda:(_ for _ in ()).throw(exc))
        path=row['path']
        if path:
            h=reader.get(pid+'.source_SHA256',lambda:sha256_file(path));file_hashes[path]=h
            row['source_sha256_before']=h
        else:reader.get(pid+'.source_path',lambda:(_ for _ in ()).throw(RuntimeError('Teil nicht gespeichert')))
        if row['is_fully_loaded'] is False:
            reader.get(pid+'.load',lambda:(_ for _ in ()).throw(RuntimeError('Teil nicht voll geladen; keine Geometrieinterpretation')))
        wcs=reader.get(pid+'.WCS',lambda:part.WCS.CoordinateSystem)
        if wcs:
            row['wcs']={'origin':reader.get(pid+'.WCS.Origin',lambda:xyz(wcs.Origin)),
                        'orientation':reader.get(pid+'.WCS.Orientation',lambda:matrix_rows(wcs.Orientation.Element)),
                        'frame':'PROTOTYPE_ABSOLUTE'}
        coords=reader.get(pid+'.CoordinateSystems',lambda:list(part.CoordinateSystems)) or []
        for cs in coords:
            row['datum_coordinate_systems'].append({'name':reader.get(pid+'.CS.Name',lambda:cs.Name),
                'journal_id':reader.get(pid+'.CS.JournalIdentifier',lambda:cs.JournalIdentifier),
                'origin':reader.get(pid+'.CS.Origin',lambda:xyz(cs.Origin)),
                'orientation':reader.get(pid+'.CS.Orientation',lambda:matrix_rows(cs.Orientation.Element))})
        expressions=reader.get(pid+'.Expressions',lambda:list(part.Expressions)) or []
        for exp in expressions:
            row['expressions'].append({'name':reader.get(pid+'.Exp.Name',lambda:exp.Name),
                'formula':reader.get(pid+'.Exp.RightHandSide',lambda:exp.RightHandSide),
                'equation':reader.get(pid+'.Exp.Equation',lambda:exp.Equation)})
        features=reader.get(pid+'.Features',lambda:list(part.Features)) or []
        for feature in features:
            row['features'].append({'name':reader.get(pid+'.Feature.Name',lambda:feature.Name),
                'type':reader.get(pid+'.Feature.FeatureType',lambda:feature.FeatureType),
                'journal_id':reader.get(pid+'.Feature.JournalIdentifier',lambda:feature.JournalIdentifier)})
        bodies=reader.get(pid+'.Bodies',lambda:list(part.Bodies)) or []
        for bi,body in enumerate(bodies):
            blabel=pid+'.body'+str(bi)
            b={'index':bi,'name':reader.get(blabel+'.Name',lambda:body.Name),
               'is_solid':reader.get(blabel+'.IsSolidBody',lambda:bool(body.IsSolidBody)),
               'journal_id':reader.get(blabel+'.JournalIdentifier',lambda:body.JournalIdentifier),
               'frame':'PROTOTYPE_ABSOLUTE','faces':[]}
            if bounds_fn:b['bounds_part_units']=reader.get(blabel+'.bounds',lambda:finite_vector(bounds_fn(body.Tag),6))
            faces=reader.get(blabel+'.GetFaces',body.GetFaces) or []
            b['face_count_total']=len(faces);b['faces_truncated']=len(faces)>max_faces
            if b['faces_truncated']:
                reader.get(blabel+'.limit',lambda:(_ for _ in ()).throw(RuntimeError('Flaechenlimit erreicht')))
            for fi,face in enumerate(faces[:max_faces]):
                flabel=blabel+'.face'+str(fi)
                f={'index':fi,'journal_id':reader.get(flabel+'.JournalIdentifier',lambda:face.JournalIdentifier),
                   'type_raw':reader.get(flabel+'.SolidFaceType',lambda:str(face.SolidFaceType))}
                if face_fn:f['uf_data']=reader.get(flabel+'.AskFaceData',lambda:encode_face_data(face_fn(face.Tag)))
                b['faces'].append(f)
            row['bodies'].append(b)
        return pid

    report['root_prototype']=part_info(displayed)
    def visit(comp,path,ancestor_keys):
        key=object_key(comp)
        if key in ancestor_keys:
            reader.get(path+'.cycle',lambda:(_ for _ in ()).throw(RuntimeError('Zyklus in Baugruppe')));return
        label='occurrence/'+path
        proto=reader.get(label+'.Prototype',lambda:comp.Prototype)
        entry={'path':path,'name':reader.get(label+'.Name',lambda:comp.Name),
               'display_name':reader.get(label+'.DisplayName',lambda:comp.DisplayName),
               'suppressed':reader.get(label+'.IsSuppressed',lambda:bool(comp.IsSuppressed)),
               'reference_set':reader.get(label+'.ReferenceSet',lambda:comp.ReferenceSet),
               'prototype_id':part_info(proto) if proto is not None and hasattr(proto,'Bodies') else None}
        report['occurrences'].append(entry)
        evidence.record('Component.GetPosition',getattr(comp,'GetPosition',None))
        entry['position']=reader.get(label+'.GetPosition',lambda:encode_position(comp.GetPosition()))
        children=reader.get(label+'.GetChildren',comp.GetChildren)
        if children is not None:
            entry['children_count']=len(children)
            for index,child in enumerate(children):visit(child,path+'/'+str(index).zfill(4),ancestor_keys+(key,))
    visit(root,'0000',())
    changed=[]
    for row in report['prototypes']:
        path=row['path'];before=row.get('source_sha256_before')
        after=reader.get(row['id']+'.hash_after',lambda:sha256_file(path)) if path else None
        row['source_sha256_after']=after
        row['source_bytes_unchanged']=before==after if before and after else None
        if row['source_bytes_unchanged'] is False:changed.append(path)
    if changed:raise RuntimeError('Quelldateien waehrend Aufnahme geaendert: '+repr(changed))
    report['status']='PARTIAL' if reader.issues else 'INVENTORY_READ_NO_ENGINEERING_RELEASE'
    report['counts']={'prototype_parts':len(report['prototypes']),
                     'occurrences_including_root':len(report['occurrences']),
                     'solid_bodies_in_prototypes':sum(b.get('is_solid') is True for p in report['prototypes'] for b in p['bodies']),
                     'issues':len(reader.issues)}
    path=Path(directory)/'NX_Bestandsaufnahme.json';write_json_new(path,report)
    log('Bestandsaufnahme: '+str(path));log('Status: '+report['status']);log('Keine Konstruktions-/Fertigungsfreigabe.')
    return report
