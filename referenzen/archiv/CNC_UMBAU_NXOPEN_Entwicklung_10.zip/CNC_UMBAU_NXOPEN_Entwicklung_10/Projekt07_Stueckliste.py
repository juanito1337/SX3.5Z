# -*- coding: utf-8 -*-
"""Offline recipe preview or re-evaluation of a saved native BOM snapshot.
No NX module, CAD creation or native execution claim in this CLI.
"""
import argparse,json
from pathlib import Path
from analysis.bom07 import summarize
from analysis.bom_registry07 import apply_registry
from exports.bom07 import recipe_preview,export_report,assignment_template
from cnc_nx.runtime import sha256_file,write_json_new


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--preview',action='store_true',help='Recipe quantities only, NOT native geometry')
    group.add_argument('--snapshot',help='NX_Stuecklistenaufnahme_07.json from journal18/19')
    p.add_argument('--registry',help='Explicit path/hash-bound assignments; optional')
    p.add_argument('--output',required=True,help='New absolute output directory')
    args=p.parse_args(argv)
    out=Path(args.output)
    if not out.is_absolute():raise ValueError('Absolute output required')
    if out.exists():raise FileExistsError(str(out))
    if args.preview:
        if args.registry:raise ValueError('Registry not applicable to a non-native recipe preview')
        report=recipe_preview()
    else:
        source=Path(args.snapshot)
        with source.open(encoding='utf-8-sig') as f:snapshot=json.load(f)
        if snapshot.get('integrity_failure') is True:raise ValueError('Snapshot source integrity failed; no BOM export')
        registry=dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=[])
        if args.registry:
            with open(args.registry,encoding='utf-8-sig') as f:registry=json.load(f)
        report=apply_registry(summarize(snapshot),registry)
        report.update(native_read_in_this_run=False,replayed_snapshot=str(source.absolute()),
                      replayed_snapshot_sha256=sha256_file(source))
    export_report(out,report)
    write_json_new(out/'Zuordnung_Vorlage_07.json',assignment_template(report))
    print('Stuecklistenbericht: '+str(out));print(report['status'])
    print('Kein NX-Lauf in diesem CLI; keine Bestell-/Fertigungsfreigabe.')
    return report

if __name__=='__main__':main()
