"""Offline: python Projekt03_Eingaben_vorbereiten.py --audit <JSON> --out <NEW folder>.
Creates templates from the real audit without guessing root-frame placements.
"""
import argparse,json
from pathlib import Path
from cnc_nx.runtime import write_json_new,sha256_file
from analysis.interfaces03 import candidate_faces

def prepare(audit_path,out):
 audit_path=Path(audit_path).absolute();out=Path(out)
 with open(audit_path,encoding='utf-8-sig') as f:audit=json.load(f)
 if audit.get('schema')!='SX35Z_NX_AUDIT_1':raise ValueError('NX audit required')
 out.mkdir(parents=True,exist_ok=False)
 ps={p['id']:p for p in audit['prototypes']};components=[];decisions=[]
 for occ in audit['occurrences']:
  p=ps.get(occ.get('prototype_id'))
  if not p or occ.get('suppressed') or occ.get('children_count',0)>0:continue
  if not any(b.get('is_solid') is True for b in p.get('bodies',[])):continue
  key=occ['path'];id_='O_'+key.replace('/','_')
  decisions.append(dict(occurrence_path=key,action='REUSE',reason='Default keeps original; review explicit exclusions'))
  components.append(dict(id=id_,group='BESTAND',kind='ORIGINAL',path=p['path'],sha256=p.get('source_sha256_before'),
       origin_mm=None,rotation=None,source='Actual NX audit occurrence '+key,dimensions_status='MODEL_ONLY_REVIEWED',
       occurrence_path=key,raw_position_NOT_REGISTRATION=occ.get('position')))
 manifest=dict(schema='SX35Z_ASSEMBLY_3',review={'status':'NOT_REVIEWED','evidence':''},groups=['BESTAND'],
      source_inventory=dict(path=str(audit_path),sha256=sha256_file(audit_path),decisions=decisions),components=components)
 write_json_new(out/'assembly03_ENTWURF.json',manifest)
 write_json_new(out/'Flaechenkandidaten.json',candidate_faces(audit))
 write_json_new(out/'interface_requests03_ENTWURF.json',dict(audit_path=str(audit_path),audit_sha256=sha256_file(audit_path),requests=[]))
 return dict(original_candidates=len(components),status='INPUT_TEMPLATES_NOT_REVIEWED')
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--audit',required=True);parser.add_argument('--out',required=True)
 args=parser.parse_args();print(json.dumps(prepare(args.audit,args.out),indent=2))
