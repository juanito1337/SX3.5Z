"""Explicit column-vector frame contract: p_parent = R @ p_local + t.
NOT a claim about the raw NX GetPosition matrix layout. Conversion from raw NX
must be calibrated against three known basis points before an actual assembly.
"""
import math
from cnc_nx.core import rotation_quality

def vector(v):
    if len(v)!=3 or any(isinstance(x,bool) for x in v):raise ValueError('3-vector required')
    r=[float(x) for x in v]
    if not all(math.isfinite(x) for x in r):raise ValueError('Finite vector required')
    return r

def validated(R):
    if not rotation_quality(R)['proper_rotation']:raise ValueError('Proper orthonormal rotation required')
    return R

def transform_point(R,t,p):
    R=validated(R);t=vector(t);p=vector(p)
    return [sum(R[j][k]*p[k] for k in range(3))+t[j] for j in range(3)]

def inverse_point(R,t,p):
    R=validated(R);t=vector(t);p=vector(p)
    return [sum(R[k][j]*(p[k]-t[k]) for k in range(3)) for j in range(3)]

def compose(R1,t1,R2,t2):
    validated(R1);validated(R2)
    R=[[sum(R1[i][k]*R2[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    return R,transform_point(R1,t1,t2)
