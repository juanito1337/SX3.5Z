"""Explicit reviewed layouts. All coordinates use p_machine = R @ p_local + t.
No name-based guessing of original machine components or manufacturing release.
"""
import copy,json,os,re
from pathlib import Path
from cnc_nx.runtime import sha256_file
from assembly.position_components import validated,compose
from validation.geometry03 import vec

def checked_file(path,digest,extension='.prt'):
 p=Path(path)
 if not p.is_absolute() or not p.is_file() or p.is_symlink() or p.suffix.lower()!=extension:raise ValueError('Existing absolute '+extension+' file required: '+str(p))
 if not isinstance(digest,str) or not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('SHA256 required')
 if sha256_file(p)!=digest:raise ValueError('Source file hash changed: '+str(p))
 return str(p)

def idcheck(s):
 if not isinstance(s,str) or not re.fullmatch('[A-Za-z][A-Za-z0-9_]*',s):raise ValueError('Invalid ID: '+str(s))

def place_axis_component(frame,component):
 R,t=compose(frame['rotation'],vec(frame['origin_mm']),component['rotation'],vec(component['origin_mm']))
 return dict(rotation=R,origin_mm=t)

def validate_manifest(config):
 c=copy.deepcopy(config)
 if c.get('schema')!='SX35Z_ASSEMBLY_3':raise ValueError('Wrong manifest schema')
 review=c.get('review',{})
 if review.get('status')!='MODEL_LAYOUT_REVIEWED' or not review.get('evidence'):raise ValueError('Explicit reviewed layout evidence required')
 groups=c.get('groups',[])
 if not groups or len(set(groups))!=len(groups):raise ValueError('Unique groups required')
 for group in groups:idcheck(group)
 components=c.get('components',[])
 if not components:raise ValueError('No components: no native assembly will be declared complete')
 seen=set()
 for d in components:
  idcheck(d['id'])
  if d['id'] in seen:raise ValueError('Duplicate occurrence ID')
  seen.add(d['id'])
  if d.get('group') not in groups:raise ValueError('Unknown group')
  if d.get('kind') not in ('ORIGINAL','PURCHASE','GENERATED'):raise ValueError('Unknown component kind')
  if not d.get('source') or not d.get('dimensions_status'):raise ValueError('Source/dimension evidence missing')
  if d['dimensions_status'] not in ('CATALOGUE_REFERENCE','MANUFACTURER_CONFIRMED','MEASURED_AND_REVIEWED','MODEL_ONLY_REVIEWED','DESIGN_NOMINAL'):
   raise ValueError('Unsupported dimension evidence status')
  d['path']=checked_file(d['path'],d['sha256']);d['origin_mm']=vec(d['origin_mm']);validated(d['rotation'])
 originals=[d for d in components if d['kind']=='ORIGINAL']
 inv=c.get('source_inventory')
 if originals and not inv:raise ValueError('Original reuse requires audited inventory and complete inclusion/exclusion decisions')
 if inv:
  ip=checked_file(inv['path'],inv['sha256'],'.json')
  with open(ip,encoding='utf-8-sig') as f:audit=json.load(f)
  if audit.get('schema')!='SX35Z_NX_AUDIT_1':raise ValueError('Unknown inventory format')
  protos={p['id']:p for p in audit['prototypes']};eligible={}
  for occurrence in audit['occurrences']:
   p=protos.get(occurrence.get('prototype_id'))
   if occurrence.get('suppressed') is None:raise ValueError('Unknown suppression state')
   if occurrence.get('suppressed'):continue
   if not p:raise ValueError('Unloaded prototype in inventory')
   if p.get('unit_mm') is not True or p.get('is_fully_loaded') is not True or p.get('is_modified_before') is not False:
    raise ValueError('Unloaded/modified/non-mm source part')
   child_count=occurrence.get('children_count')
   if isinstance(child_count,bool) or not isinstance(child_count,int) or child_count<0:
    raise ValueError('Unknown child count; original cannot be silently classified as a leaf')
   if any(b.get('is_solid') not in (True,False) for b in p.get('bodies',[])):
    raise ValueError('Unknown original solid state')
   if p.get('bodies') and not any(b.get('is_solid') is True for b in p['bodies']):
    raise ValueError('Sheet-only original prototype requires explicit supported integration; not silently omitted')
   solid=any(b.get('is_solid') is True for b in p.get('bodies',[]))
   if solid:
    if occurrence.get('children_count',0)>0:raise ValueError('Mixed body-plus-subassembly prototype unsupported; explicit decomposition required')
    eligible[occurrence['path']]=p
  decisions=inv.get('decisions',[])
  if len({d['occurrence_path'] for d in decisions})!=len(decisions):raise ValueError('Duplicate original decision')
  if set(d['occurrence_path'] for d in decisions)!=set(eligible):raise ValueError('Every original solid occurrence needs an explicit decision')
  reused={d.get('occurrence_path'):d for d in originals}
  if len(reused)!=len(originals):raise ValueError('Original occurrence reused twice')
  expected=set()
  for decision in decisions:
   key=decision['occurrence_path'];proto=eligible[key]
   if decision['action']=='EXCLUDE':
    if not decision.get('reason'):raise ValueError('Exclusion reason missing')
    if key in reused:raise ValueError('Excluded original also inserted')
   elif decision['action']=='REUSE':
    expected.add(key)
    if key not in reused:raise ValueError('Missing reused original')
    obj=reused[key]
    if obj['sha256']!=proto.get('source_sha256_before') or os.path.normcase(obj['path'])!=os.path.normcase(proto['path']):
     raise ValueError('Original source does not match audited prototype')
   else:raise ValueError('Unknown original decision')
  if set(reused)!=expected:raise ValueError('Unexpected original reuse')
 c.update(status='REVIEWED_LAYOUT_NOT_ENGINEERING_RELEASE',manufacturing_released=False,exact_collision_checked=False)
 return c
