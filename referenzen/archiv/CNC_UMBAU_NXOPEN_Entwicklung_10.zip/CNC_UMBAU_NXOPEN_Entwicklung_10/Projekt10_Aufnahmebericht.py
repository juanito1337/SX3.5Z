# -*- coding: utf-8 -*-
"""Reproduce catalogue and axial-space reports. No CAD and no NX measurement."""
import argparse
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from engineering.ballscrew09 import ROOT,read_json
from exports.nutmount10 import export_report

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--config',type=Path);parser.add_argument('--output',type=Path)
 args=parser.parse_args();cases=None
 if args.config:
  c=read_json(args.config)
  if c.get('schema')!='CNC_NUTMOUNT_STUDIES_10':parser.error('Unexpected mount schema')
  cases=c['cases']
 out=args.output or ROOT/'reports'/'generated10'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:8])
 d=export_report(out,cases)
 print('Aufnahmebericht: '+str(out.absolute()))
 print(str(d['prototype_count'])+' Hauptkoerperrezepte; KEIN NX-Lauf, KEINE Maschinen- oder Klemmfreigabe.')

if __name__=='__main__':main()
