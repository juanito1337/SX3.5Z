# -*- coding: utf-8 -*-
"""Offline check-plan preview or replay of an existing NX_Pruefaufnahme_08.json.
No NX invocation and no creation of native CAD. New output directories only.
"""
import argparse
from pathlib import Path
from cnc_nx.runtime import sha256_file
from validation.dossier08 import preview,build_dossier,checked_json
from exports.dossier08 import export_dossier


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--preview',action='store_true')
    mode.add_argument('--snapshot')
    parser.add_argument('--config');parser.add_argument('--output',required=True)
    args=parser.parse_args(argv)
    if args.preview:
        if args.config:raise ValueError('Preview does not consume actual evidence files')
        report=preview()
    else:
        path=Path(args.snapshot).absolute()
        snapshot=checked_json(dict(path=str(path),sha256=sha256_file(path)))
        artifacts=[]
        if args.config:
            cfgpath=Path(args.config).absolute()
            job=checked_json(dict(path=str(cfgpath),sha256=sha256_file(cfgpath)))
            if job.get('schema')!='SX35Z_DOSSIER_JOB_8' or set(job)!={'schema','artifacts'}:
                raise ValueError('Invalid dossier job')
            artifacts=job['artifacts']
        report=build_dossier(snapshot,artifacts)
        report['source_replay_file']=str(path)
    export_dossier(Path(args.output),report)
    print('Prüfdossier: '+report['status'])
    print('Offline-Auswertung, KEIN neuer NX-Lauf und KEINE Fertigungsfreigabe.')
    return report

if __name__=='__main__':main()
