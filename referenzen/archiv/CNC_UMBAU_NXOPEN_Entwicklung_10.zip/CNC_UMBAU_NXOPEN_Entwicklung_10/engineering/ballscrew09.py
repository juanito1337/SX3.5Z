"""Catalogue selection and one-dimensional axial planning, never machine approval.

Source: isel April2025 catalogue, p6 (RAW screw lengths), p8 (round nuts).
NO CAD kernel is used here. The nominal screw envelope is not its raceway surface.
The illustrated nut bore is not a manufacturer dimension.
"""
import copy
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).absolute().parents[1]
SOURCE = 'https://www.isel.com/fileadmin/user_upload/Kataloge/20250403_Katalog_Kugelgewindespindeln_de.pdf'
# Locked transcriptions prevent a configuration edit masquerading as supplier evidence.
CATALOGUE_NUTS = {
    '213514': (16., 4., 28., 50., 4600., 7200.),
    '213505': (16., 5., 28., 50., 4600., 7200.),
    '213420 0005': (20., 5., 33., 50., 5000., 9000.),
}
CASE_KEYS = {'id', 'nut_article', 'screw_diameter_mm', 'screw_lead_mm',
             'stock_length_mm', 'reserve_start_mm', 'reserve_end_mm',
             'nut_center_mm', 'requested_stroke_mm'}


def number(value, *, positive=False, nonnegative=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError('Finite numeric dimension required; unknown values cannot be zero-filled')
    x = float(value)
    if positive and x <= 0 or nonnegative and x < 0:
        raise ValueError('Dimension is outside its positive/nonnegative range')
    return x


def _unique(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('Duplicate JSON key: ' + key)
        obj[key] = value
    return obj


def read_json(path):
    def reject(value):
        raise ValueError('Nonfinite JSON token: ' + value)
    with open(path, encoding='utf-8-sig') as f:
        return json.load(f, object_pairs_hook=_unique, parse_constant=reject)


def validate_registry(reg):
    if not isinstance(reg, dict) or reg.get('schema') != 'CNC_SUPPLIER_CATALOGUE_09':
        raise ValueError('Unsupported catalogue registry')
    if reg.get('source_url') != SOURCE or reg.get('catalogue_revision') != 'April 2025':
        raise ValueError('This adapter supports exactly the cited catalogue revision')
    if reg.get('manufacturer') != 'isel Germany GmbH':
        raise ValueError('Manufacturer mismatch')
    if set(reg.get('nuts', {})) != set(CATALOGUE_NUTS):
        raise ValueError('Unknown or missing catalogue nut')
    fields = ('screw_diameter_mm', 'lead_mm', 'outer_diameter_mm', 'length_mm',
              'dynamic_rating_N', 'static_rating_N')
    for code, values in CATALOGUE_NUTS.items():
        n = reg['nuts'][code]
        if n.get('article_number') != code or tuple(number(n.get(k), positive=True) for k in fields) != values:
            raise ValueError('Catalogue dimensions/identity changed: ' + code)
        if n.get('source_page') != 8 or n.get('outer_fit_label') != 'h7' or n.get('material_label') != '16MnCr5':
            raise ValueError('Catalogue source metadata changed: ' + code)
    families = reg.get('raw_screw_families', {})
    if set(families) != {'16', '20'}:
        raise ValueError('Unreviewed screw family')
    for key, diameter, minimum, leads in [('16',16,352,[4,5]), ('20',20,252,[5])]:
        f = families[key]
        if (number(f.get('diameter_mm'), positive=True) != diameter
                or number(f.get('stock_min_mm'), positive=True) != minimum
                or number(f.get('stock_max_mm'), positive=True) != 3052
                or number(f.get('stock_step_mm'), positive=True) != 100
                or f.get('leads_mm') != leads or f.get('end_condition') != 'UNMACHINED'
                or f.get('screw_order_code') is not None or f.get('source_page') != 6):
            raise ValueError('Unreviewed raw stock range or invented order code')
    ev = reg.get('evidence', {})
    for key in ('original_cad_obtained', 'pdf_bytes_obtained', 'drawing_visually_verified', 'physical_part_measured'):
        if ev.get(key) is not False:
            raise ValueError('Unsupported evidence promotion: '+key)
    return reg


def load_registry(root=None):
    return validate_registry(read_json(Path(root or ROOT)/'reference'/'Quellen_09.json'))


def load_cases(root=None):
    data = read_json(Path(root or ROOT)/'config'/'ballscrews09.json')
    if data.get('schema') != 'CNC_BALLSCREW_STUDIES_09':
        raise ValueError('Unsupported case schema')
    return data['cases']


def minimum_length(stroke, nut_length, unusable_start, unusable_end, reserve_start, reserve_end):
    """Axial sum only. Both unusable ends must be explicitly known, not None."""
    s = number(stroke, nonnegative=True); n = number(nut_length, positive=True)
    ends = [number(x, nonnegative=True) for x in (unusable_start,unusable_end,reserve_start,reserve_end)]
    result = s+n+sum(ends)
    return number(result, positive=True)


def axial_window(total_length, nut_length, unusable_start, unusable_end,
                 reserve_start, reserve_end, reference_center=None, requested_stroke=None):
    """Nut-centre interval with full nut length retained, not half a nut at each end.

    z=0 is the start of the screw envelope. Positive z is along the screw.
    Zero unusable end lengths are correct ONLY for an unmachined raw-stock study.
    This calculation contains no bearing support, runout, stopping or sensor margin.
    """
    length=number(total_length,positive=True); nut=number(nut_length,positive=True)
    a,b,ma,mb=[number(x,nonnegative=True) for x in (unusable_start,unusable_end,reserve_start,reserve_end)]
    lo=a+ma+nut/2.; hi=length-b-mb-nut/2.
    if not math.isfinite(lo) or not math.isfinite(hi) or hi<lo:
        raise ValueError('Screw too short for nut and explicit end allowances')
    center=(lo+hi)/2. if reference_center is None else number(reference_center)
    if not lo <= center <= hi:
        raise ValueError('Nut centre is outside the admissible axial interval')
    wanted=None if requested_stroke is None else number(requested_stroke,nonnegative=True)
    span=hi-lo
    return dict(center_min_mm=lo,center_max_mm=hi,span_mm=span,reference_center_mm=center,
                nut_start_mm=center-nut/2.,nut_end_mm=center+nut/2.,
                negative_from_reference_mm=center-lo,positive_from_reference_mm=hi-center,
                requested_stroke_mm=wanted,requested_stroke_fits_axially=None if wanted is None else wanted<=span,
                missing_length_mm=None if wanted is None else max(0.,wanted-span),
                machine_travel_verified=False,bearing_support_verified=False,
                scope='AXIAL_ENVELOPE_ONLY_NOT_MACHINE_STROKE')


def turns_for_distance(distance_mm, lead_mm):
    return number(distance_mm)/number(lead_mm,positive=True)


def resolve_pair(case, registry):
    validate_registry(registry)
    if not isinstance(case,dict) or set(case)!=CASE_KEYS:
        raise ValueError('All and only the documented case keys are required')
    if not isinstance(case['id'],str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,40}',case['id']):
        raise ValueError('Invalid reference ID')
    code=case['nut_article']
    if not isinstance(code,str) or code not in registry['nuts']:
        raise ValueError('Unknown catalogue nut article')
    nut=registry['nuts'][code]
    diameter=number(case['screw_diameter_mm'],positive=True)
    lead=number(case['screw_lead_mm'],positive=True)
    if diameter!=nut['screw_diameter_mm']:
        raise ValueError('Nut and screw diameter mismatch')
    if lead!=nut['lead_mm']:
        raise ValueError('Nut and screw pitch/lead mismatch')
    family=registry['raw_screw_families'][str(int(diameter))]
    length=number(case['stock_length_mm'],positive=True)
    grid=(length-family['stock_min_mm'])/family['stock_step_mm']
    if not family['stock_min_mm']<=length<=family['stock_max_mm'] or abs(grid-round(grid))>1e-10:
        raise ValueError('Raw stock length outside the cited catalogue grid')
    window=axial_window(length,nut['length_mm'],0,0,case['reserve_start_mm'],case['reserve_end_mm'],
                        case['nut_center_mm'],case['requested_stroke_mm'])
    return dict(id=case['id'],manufacturer=registry['manufacturer'],nut_article=code,nut=copy.deepcopy(nut),
                screw_diameter_mm=diameter,screw_lead_mm=lead,stock_length_mm=length,
                reserve_start_mm=number(case['reserve_start_mm'],nonnegative=True),
                reserve_end_mm=number(case['reserve_end_mm'],nonnegative=True),
                screw_order_code=None,end_condition='UNMACHINED',source_url=SOURCE,
                window=window,source_revision=registry['catalogue_revision'],
                machine_fit_verified=False,order_released=False,manufacturing_released=False,
                status='CATALOGUE_ENVELOPE_STUDY_ONLY',
                limitation='Nut bore/raceways not reproduced; raw stock needs end machining and supports before any powered use')


def validate_cases(cases, registry):
    if not isinstance(cases,list) or not cases:
        raise ValueError('A nonempty case list is required')
    if len(cases)>12:
        raise ValueError('At most twelve standalone reference cases in one run')
    result=[];seen=set()
    for case in cases:
        pair=resolve_pair(case,registry)
        if pair['id'] in seen:
            raise ValueError('Duplicate case ID')
        seen.add(pair['id']);result.append(pair)
    return result
