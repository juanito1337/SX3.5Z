"""Design scenarios only; values are NOT measurements of the user's machine."""
from .sizing import transmission,load_case,motor_check,stopping_distance

def evaluate(config):
    rows=[]
    for s in config['scenarios']:
        motion=transmission(s['lead_mm'],s['ratio'],s['feed_mm_min'],s['full_steps'],s['microsteps'])
        fields=('mass_kg','accel_mm_s2','cut_force_n','friction_n','lead_mm','ratio','screw_efficiency',
                'transmission_efficiency','screw_inertia_kg_m2','motor_inertia_kg_m2','vertical')
        mechanical=load_case(**{k:s[k] for k in fields})
        check=motor_check(mechanical['motor_torque_nm'],motion['motor_rpm'],s.get('verified_motor_curve'),s['torque_margin'])
        stop=stopping_distance(s['feed_mm_min']/60,s['accel_mm_s2'],s['assumed_response_delay_s'],s['assumed_extra_reserve_mm'])
        rows.append(dict(id=s['id'],axis=s['axis'],basis='DESIGN_SCENARIO_NOT_MEASURED',
                         inputs=s,motion=motion,mechanics=mechanical,motor_check=check,
                         illustrative_stopping_reserve_mm=stop,
                         safety_stop_verified=False,manufacturing_released=False))
    return {'status':'ILLUSTRATIVE_CALCULATIONS_ONLY','scenarios':rows,'nx_executed':False,'design_released':False}
