"""Catalogue main-body mounts and 1-D space study. NOT physical retention proof.

Source: isel April 2025 catalogue p9 table (not a visually verified drawing).
L/B/H/M/H1 are used; ambiguous foot-hole placements are deliberately not derived.
"""
import copy
import math
from pathlib import Path
from engineering.ballscrew09 import (SOURCE,ROOT,read_json,number,resolve_pair,
                                     load_cases as load_pairs,load_registry as load_nuts)

BLOCKS={
 '213500': dict(article_number='213500',screw_diameter_mm=16,bore_d_mm=28,
               length_mm=54,width_mm=47,height_mm=33,axis_height_mm=16.5,
               bore_fit_label='H7',material_label='Stahl, brüniert',foot_holes=None,
               source_page=9),
 '213600': dict(article_number='213600',screw_diameter_mm=20,bore_d_mm=33,
               length_mm=61.5,width_mm=53,height_mm=40,axis_height_mm=20,
               bore_fit_label='H7',material_label='Stahl, brüniert',foot_holes=None,
               source_page=9),
}
KEYS={'id','pair_id','block_article','nut_offset_mm','reference_block_center_mm','requested_body_stroke_mm'}
EVIDENCE_FLAGS=('original_cad_obtained','pdf_bytes_obtained','drawing_visually_verified',
                'foot_hole_positions_verified','retention_geometry_verified','physical_part_measured')


def validate_registry(reg):
 if not isinstance(reg,dict) or reg.get('schema')!='CNC_NUTMOUNT_CATALOGUE_10':
  raise ValueError('Unsupported mount registry')
 if (reg.get('source_url')!=SOURCE or reg.get('catalogue_revision')!='April 2025'
     or reg.get('manufacturer')!='isel Germany GmbH'):
  raise ValueError('Unreviewed catalogue source')
 blocks=reg.get('blocks')
 if blocks!=BLOCKS:
  raise ValueError('Catalogue block dimensions/metadata changed; separate review required')
 if any(reg.get('evidence',{}).get(k) is not False for k in EVIDENCE_FLAGS):
  raise ValueError('Unsupported source-evidence promotion')
 return reg


def load_registry(root=None):
 return validate_registry(read_json(Path(root or ROOT)/'reference'/'Quellen_10.json'))


def load_cases(root=None):
 data=read_json(Path(root or ROOT)/'config'/'nutmounts10.json')
 if data.get('schema')!='CNC_NUTMOUNT_STUDIES_10' or not isinstance(data.get('cases'),list):
  raise ValueError('Unsupported mount cases')
 return data['cases']


def main_body_window(length,nut_length,block_length,nut_offset,reserve_start,reserve_end,
                     reference_center=None,requested_stroke=None):
 """Reference = block midplane. Union of known nut/block axial MAIN bodies only.
 Unknown projecting adjusting screws/nipples and bearings are NOT certified free.
 """
 L,N,B=[number(x,positive=True) for x in (length,nut_length,block_length)]
 delta=number(nut_offset)
 r0,r1=[number(x,nonnegative=True) for x in (reserve_start,reserve_end)]
 low=min(-B/2,delta-N/2);high=max(B/2,delta+N/2)
 lo=r0-low;hi=L-r1-high
 if not all(math.isfinite(x) for x in (low,high,lo,hi)) or hi<lo:
  raise ValueError('Known bodies and reserves do not fit raw screw')
 c=(lo+hi)/2 if reference_center is None else number(reference_center)
 if not lo<=c<=hi:raise ValueError('Reference block centre outside known-body interval')
 wanted=None if requested_stroke is None else number(requested_stroke,nonnegative=True)
 span=hi-lo
 return dict(relative_low_mm=low,relative_high_mm=high,known_body_length_mm=high-low,
             center_min_mm=lo,center_max_mm=hi,reference_center_mm=c,span_mm=span,
             requested_stroke_mm=wanted,requested_stroke_fits=None if wanted is None else wanted<=span,
             missing_length_mm=None if wanted is None else max(0.,wanted-span),
             required_raw_length_mm=None if wanted is None else wanted+(high-low)+r0+r1,
             scope='KNOWN_MAIN_BODY_AXIAL_SPACE_NOT_MACHINE_TRAVEL_OR_FULL_HARDWARE_CLEARANCE',
             full_envelope_known=False,machine_travel_verified=False)


def resolve(case,pairs=None,nuts=None,registry=None):
 import re
 registry=validate_registry(registry if registry is not None else load_registry())
 pairs=load_pairs() if pairs is None else pairs
 nuts=load_nuts() if nuts is None else nuts
 if not isinstance(case,dict) or set(case)!=KEYS:
  raise ValueError('All and only documented mount-case keys required')
 if not isinstance(case['id'],str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,40}',case['id']):
  raise ValueError('Invalid mount case ID')
 candidates=[c for c in pairs if isinstance(c,dict) and c.get('id')==case['pair_id']]
 if len(candidates)!=1:raise ValueError('Missing/ambiguous screw-pair reference')
 original=copy.deepcopy(candidates[0]);pair=resolve_pair(original,nuts)
 code=case['block_article']
 if not isinstance(code,str) or code not in registry['blocks']:raise ValueError('Unknown block article')
 b=copy.deepcopy(registry['blocks'][code])
 if b['screw_diameter_mm']!=pair['screw_diameter_mm'] or b['bore_d_mm']!=pair['nut']['outer_diameter_mm']:
  raise ValueError('Block and nut family/nominal diameter mismatch')
 delta=number(case['nut_offset_mm'])
 w=main_body_window(pair['stock_length_mm'],pair['nut']['length_mm'],b['length_mm'],delta,
       original['reserve_start_mm'],original['reserve_end_mm'],
       case['reference_block_center_mm'],case['requested_body_stroke_mm'])
 samples=[]
 for label,c in [('MIN',w['center_min_mm']),('REFERENCE',w['reference_center_mm']),('MAX',w['center_max_mm'])]:
  samples.append(dict(name=label,block_center_mm=c,block_start_mm=c-b['length_mm']/2,
      block_end_mm=c+b['length_mm']/2,nut_center_mm=c+delta,
      nut_start_mm=c+delta-pair['nut']['length_mm']/2,nut_end_mm=c+delta+pair['nut']['length_mm']/2,
      known_body_start_mm=c+w['relative_low_mm'],known_body_end_mm=c+w['relative_high_mm']))
 return dict(id=case['id'],pair=pair,pair_case=original,block=b,block_article=code,
             nut_article=pair['nut_article'],nut_offset_mm=delta,window=w,samples=samples,
             source_url=SOURCE,axial_position_basis='EXPLICIT_STUDY_OFFSET_NOT_MANUFACTURER_ASSEMBLY_DIMENSION',
             machine_fit_verified=False,retention_verified=False,contact_verified=False,
             order_released=False,manufacturing_released=False,foot_holes_modelled=False,
             full_external_envelope_verified=False)


def resolve_all(cases=None,pairs=None,nuts=None,registry=None):
 cases=load_cases() if cases is None else cases
 if not isinstance(cases,list) or not 1<=len(cases)<=12:raise ValueError('One to twelve explicit cases required')
 out=[resolve(c,pairs,nuts,registry) for c in cases]
 if len({c['id'] for c in out})!=len(out):raise ValueError('Duplicate case IDs')
 return out
