"""Preliminary mechanics in SI internally. No machine-specific defaults.
Motoring uphill/against cutting force only; NOT a brake or safety proof.
"""
import math

def number(value,name,minimum=0.,strict=False):
    if isinstance(value,bool) or not isinstance(value,(int,float)):
        raise ValueError(name+': number required')
    v=float(value)
    if not math.isfinite(v) or (v<=minimum if strict else v<minimum):
        raise ValueError(name+': invalid range')
    return v

def positive(v,name):return number(v,name,0,True)

def efficiency(v,name):
    v=positive(v,name)
    if v>1:raise ValueError(name+': must be <=1')
    return v

def transmission(lead_mm,ratio,feed_mm_min,full_steps,microsteps):
    p=positive(lead_mm,'lead_mm');i=positive(ratio,'motor_rev_per_screw_rev')
    v=number(feed_mm_min,'feed_mm_min');fs=positive(full_steps,'full_steps');ms=positive(microsteps,'microsteps')
    if not fs.is_integer() or not ms.is_integer():raise ValueError('Step counts must be integers')
    n=v/p;scale=fs*ms*i/p
    return dict(screw_rpm=n,motor_rpm=n*i,steps_per_mm=scale,pulse_hz=v/60*scale,
                command_increment_mm=1/scale,increment_is_accuracy=False)

def load_case(mass_kg,accel_mm_s2,cut_force_n,friction_n,lead_mm,ratio,
              screw_efficiency,transmission_efficiency,screw_inertia_kg_m2,
              motor_inertia_kg_m2,vertical=False):
    m=positive(mass_kg,'mass');a=number(accel_mm_s2,'acceleration')/1000
    fc=number(cut_force_n,'cut_force');ff=number(friction_n,'friction')
    p=positive(lead_mm,'lead')/1000;i=positive(ratio,'ratio')
    es=efficiency(screw_efficiency,'screw_efficiency');et=efficiency(transmission_efficiency,'transmission_efficiency')
    js=number(screw_inertia_kg_m2,'screw_and_screw_side_inertia');jm=number(motor_inertia_kg_m2,'motor_and_motor_side_inertia')
    if not isinstance(vertical,bool):raise ValueError('vertical must be boolean')
    fg=m*9.80665 if vertical else 0.
    force=fc+ff+m*a+fg
    angular_acc=2*math.pi*a/p
    torque_screw_load=force*p/(2*math.pi*es)
    torque_screw_inertia=js*angular_acc
    torque_motor_inertia=jm*angular_acc*i
    torque=(torque_screw_load+torque_screw_inertia)/(i*et)+torque_motor_inertia
    return dict(axial_force_n=force,gravity_n=fg,screw_load_torque_nm=torque_screw_load,
                screw_inertia_torque_nm=torque_screw_inertia,motor_inertia_torque_nm=torque_motor_inertia,
                motor_torque_nm=torque,case='MOTORING_AGAINST_LOAD_ONLY',
                braking_regeneration_evaluated=False,safety_approved=False)

def curve_torque(points,rpm):
    n=number(rpm,'rpm')
    if not isinstance(points,list) or len(points)<2:raise ValueError('At least two torque curve points required')
    values=[]
    for row in points:
        if len(row)!=2:raise ValueError('Curve point must be rpm,torque')
        values.append((number(row[0],'rpm'),number(row[1],'torque')))
    if any(values[j][0]>=values[j+1][0] for j in range(len(values)-1)):raise ValueError('rpm must strictly increase')
    if n<values[0][0] or n>values[-1][0]:raise ValueError('No extrapolation of torque curve')
    for (n0,t0),(n1,t1) in zip(values,values[1:]):
        if n0<=n<=n1:return t0+(t1-t0)*(n-n0)/(n1-n0)
    raise ValueError('Curve not bracketed')

def motor_check(required_nm,rpm,curve,margin):
    required=number(required_nm,'required_nm');margin=positive(margin,'margin')
    if margin<1:raise ValueError('margin must be >=1')
    if curve is None:return dict(status='NOT_EVALUATED',reason='Manufacturer torque curve / matching drive voltage missing',motor_selected=False)
    available=curve_torque(curve,rpm)
    return dict(status='SCENARIO_MARGIN_MET' if available>=required*margin else 'SCENARIO_MARGIN_NOT_MET',
                required_with_margin_nm=required*margin,available_nm=available,motor_selected=False,
                note='Only this operating point; no thermal, transient or complete axis approval.')

def stopping_distance(speed_mm_s,decel_mm_s2,delay_s,extra_mm):
    v=number(speed_mm_s,'speed');a=positive(decel_mm_s2,'deceleration')
    t=number(delay_s,'delay');e=number(extra_mm,'extra')
    return v*t+v*v/(2*a)+e

def screw_thread_length(travel_mm,nut_envelope_mm,end_reserve_each_mm):
    return positive(travel_mm,'travel')+positive(nut_envelope_mm,'nut_length')+2*number(end_reserve_each_mm,'reserve')
