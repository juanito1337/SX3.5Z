# -*- coding: utf-8 -*-
"""Run inside NX 2406 via Journal > Play; see LIESMICH.md."""
import importlib.util
import os

def main():
    path=os.path.join(os.path.dirname(os.path.abspath(__file__)),'main.py')
    spec=importlib.util.spec_from_file_location('sx35z_cnc_entry',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.main('housings04')

if __name__=='__main__':main()
