# CNC-Umbau SX3.5Z — Entwicklung 10

**Ziel: Siemens NX 2406 / NX Open Python 3.10. Kein NX-Lauf durch den Autor.**
Vollständiges Projekt einschließlich Journale 01–22, neu: Journal 23.

## Neu: passende Rundmutter-Aufnahmen als Hauptkörperstudie

Die drei isel-Spindel/Mutterreferenzen aus Entwicklung09 werden mit den
katalogseitig zugeordneten Fuß-Spannblöcken 213500 / 213600 kombiniert.
Es entstehen bei erfolgreicher Ausführung acht unterschiedliche native Teile,
drei Unterbaugruppen und neun Blattvorkommen. Der 16-mm-Spannblock wird zweimal
verwendet, nicht zweimal als unterschiedlicher Artikel erfunden.

**Keine fertige Maschinenachse.** Fußlochbild, Schlitze, Spann-/Fixierschrauben,
Schmiernippel und Spannmutter sind nicht nachgebildet. Die Katalogzeichnung konnte
nicht als Bild beschafft werden. H1 wird als Achshöhe interpretiert, ist jedoch
noch an der Originalzeichnung zu bestätigen. Die axiale Mutterposition ist eine
explizite, änderbare Studienannahme, keine Hersteller-Montageangabe.

## Start in NX

1. Dieses ZIP in einen neuen, beschreibbaren Ordner entpacken. Dateien zusammenlassen.
2. NX 2406: Journal wiedergeben / Play Journal → `NX_23_Rundmutter_Aufnahmen.py`.
3. Keine geöffnete Originalmaschine nötig. Nur neu erstellte Dateien werden gespeichert.

Standard-Ausgabe:

```
%LOCALAPPDATA%\SX35Z_CNC\Projekt10\<Zeitstempel>_nutmount10_<Kennung>\
  NX_PARTS\
  NX_ASSEMBLY\
  Kaufteilzuordnung_10.json
  NX_Stueckliste_07.json
  BOM\
  Quellschutz_10.json
  NX_Rundmutter_Aufnahmen_10.json
  NX_Protokoll.txt
  NX_API_Befund.json
  LAUFSTATUS.json
```

Ein anderes absolutes Ziel lässt sich in `config/project.json` als `output_root`
angeben. Alte Ausgaben werden nicht gelöscht. Auch die erhaltenen früheren Journale
benutzen in diesem Paket standardmäßig Projekt10.

Die Hauptbaugruppe heißt `RUNDMUTTER_AUFNAHMEN10_KEINE_CNC_MASCHINE__<Kennung>.prt`.
Sie ordnet die Alternativen nebeneinander an, nicht an geschätzten Maschinenkoordinaten.
Keine Montagezwangsbedingungen oder Bewegungsanimation. Nach Änderungen an den
Eingaben neu aufbauen; manuelle PRT-Änderungen nicht automatisch rückübertragen.

## Was die neue Prüfung abdeckt

Vorgesehen sind 18 temporäre Parameteränderungen mit Wiederherstellung, neun
axiale Hauptkörper-Lageproben, zwölf aus NX-Flächen ausgewertete Modell-Schnittstellen
und ein live gelesener Stückzahlvergleich. Diese Prüfungen sind implementiert, aber
in NX noch nicht durch den Autor ausgeführt. Offline-Simulationen sind kein Ersatz.

Ein erfolgreicher Journalabschluss bedeutet nur:
`NATIVE_MAIN_BODY_REFERENCES_CREATED_NOT_MACHINE_FITTED`.
Keine Bestell-/Fertigungsfreigabe, keine Bestätigung der Klemmfunktion.

## Eingaben und lesbare Vorschau

- `config/ballscrews09.json`: unveränderte Spindel-/Mutterfälle.
- `config/nutmounts10.json`: zugeordneter Block, expliziter axialer Versatz,
  Block-Referenzmitte und optional gewünschter Hauptkörper-Bewegungsbereich.
- `reference/Quellen_10.json`: Herstellerdaten und ausdrücklich fehlende Nachweise.
- `reports/10_Rundmutter_Aufnahmen/Vorschau/Rundmutteraufnahmen_10.html`: vorhandene
  Offline-Tabellenvorschau, keine NX-Messung.

Berichte ohne NX reproduzieren:

```
python Projekt10_Aufnahmebericht.py
python Projekt10_Aufnahmebericht.py --config "C:\NX_Daten\eigene_faelle.json" --output "C:\NX_Daten\neuer_bericht"
```

Der zweite Aufruf verlangt einen noch nicht bestehenden Ausgabeordner.
Er erzeugt JSON/CSV/HTML, keine CAD-Dateien.

## Fehler und Grenzen

Ein Fehler beendet den nativen Ablauf. Teilstände bleiben ggf. im eigenen Laufordner,
sind aber kein Abschlussnachweis. Maßgeblich sind `LAUFSTATUS.json` und der vollständige
`NX_Rundmutter_Aufnahmen_10.json` nach bestandenem Quellschutz. Bei Abbruch Protokoll,
API-Befund und `LAUF_FEHLER.json` beachten.

Die finale `FRAESMASCHINE_CNC_UMBAU.prt`, passende Maschinenanschlüsse, ausgelegte
Fest-/Loslagerung, Endenbearbeitung und fertigungsgerechte Zeichnungen fehlen weiterhin.
Details: `docs/ENTWICKLUNG_10.md` und `docs/API_PRUEFSTAND_10.md`.
