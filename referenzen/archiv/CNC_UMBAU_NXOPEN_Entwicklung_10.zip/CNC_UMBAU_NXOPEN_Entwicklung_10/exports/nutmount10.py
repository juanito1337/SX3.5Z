"""Reproducible catalogue main-body and space report. NO native CAD claims."""
import json,html
from collections import Counter
from pathlib import Path
from construction.nutmount10 import reference_set
from engineering.ballscrew09 import SOURCE
from engineering.nutmount10 import load_registry
from exports.ballscrew09 import _table,_csv


def report_data(cases=None):
 d=reference_set(cases=cases);qty=Counter(c['part_id'] for g in d['groups'] for c in g['components'])
 parts=[];ax=[]
 for r in d['parts']:
  p=r['parameters'];is_block=r['kind']=='supplier_mount10'
  parts.append(dict(part_id=r['id'],role=r['role'],quantity=qty[r['id']],
      article=r.get('article_number') if is_block else r['catalogue']['article_number'],
      length_mm=p['length'],width_mm=p.get('width'),height_mm=p.get('height'),
      outside_d_mm=p.get('outer_d'),bore_mm=p.get('bore_d'),axis_height_mm=p.get('axis_height'),
      source=r['source'],manufacturing_released=False))
 for g in d['groups']:
  p=g['resolved'];w=p['window'];n=p['pair']
  ax.append(dict(case_id=g['id'],nut_article=p['nut_article'],block_article=p['block_article'],
      raw_length_mm=n['stock_length_mm'],nut_length_mm=n['nut']['length_mm'],block_length_mm=p['block']['length_mm'],
      nut_offset_mm=p['nut_offset_mm'],known_body_length_mm=w['known_body_length_mm'],
      known_body_span_mm=w['span_mm'],nut_only_span_mm=n['window']['span_mm'],
      block_center_min_mm=w['center_min_mm'],block_center_max_mm=w['center_max_mm'],
      reference_block_center_mm=w['reference_center_mm'],requested_body_stroke_mm=w['requested_stroke_mm'],
      request_fits=w['requested_stroke_fits'],missing_length_mm=w['missing_length_mm']))
 return dict(schema='CNC_NUTMOUNT_OFFLINE_REPORT_10',status='CALCULATED_MAIN_BODY_STUDY_NOT_NX_EXECUTION',
      native_execution=False,prototype_count=len(parts),group_count=len(d['groups']),occurrence_count=sum(qty.values()),
      parts=parts,axial_rows=ax,groups=d['groups'],source_url=SOURCE,source_evidence=load_registry()['evidence'],
      limitations=d['limitations'],order_released=False,manufacturing_released=False,
      machine_fit_verified=False,retention_verified=False,full_envelope_verified=False)


def html_report(d):
 e=lambda x:html.escape(str(x),quote=True)
 partcols=[('part_id','Teil'),('article','Artikel'),('quantity','Menge'),('length_mm','Länge mm'),
  ('width_mm','Breite mm'),('height_mm','Höhe mm'),('outside_d_mm','Außen-Ø mm'),('bore_mm','Aufnahme-Ø mm')]
 axcols=[('case_id','Studie'),('block_article','Spannblock'),('raw_length_mm','Rohling mm'),
  ('known_body_length_mm','Gemeinsame Hauptkörperlänge mm'),('nut_only_span_mm','Nur Mutter: Bereich mm'),
  ('known_body_span_mm','Mit Block: Bereich mm'),('nut_offset_mm','Studienversatz mm')]
 return '''<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entwicklung 10 · Rundmutter-Aufnahmen</title><style>
body{margin:0;background:#eef2f5;color:#22313f;font:16px/1.55 system-ui,sans-serif}main{max-width:1180px;margin:32px auto;padding:36px;background:white}h1{font-size:32px;line-height:1.2}h2{font-size:23px;margin-top:30px}.eyebrow{font-weight:bold;color:#125469}.warn{border-left:5px solid #bd7b13;padding:15px 18px;background:#fff2d5}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;padding:10px;border-bottom:1px solid #ccd5dd;vertical-align:top;overflow-wrap:anywhere}th{background:#e5edf3}code{padding:2px 5px;background:#edf1f4}footer{margin-top:30px;border-top:1px solid #ccd5dd;padding-top:16px;font-size:13px}@media print{main{margin:0;padding:10px}tr{break-inside:avoid}}
</style><main><div class="eyebrow">SX3.5Z · ENTWICKLUNG 10</div><h1>Rundmutter und passende Aufnahme</h1>
<p class="warn"><strong>STUDIE – NICHT ZUR FERTIGUNG. KEIN NX-LAUF.</strong><br>Hersteller-Tabellenmaße, explizite axiale Studienpositionen und rechnerische Raumbereiche. Keine Maschinenmontage oder Bestellfreigabe.</p>
<h2>1 · Zugeordnete Hauptkörper</h2><p>'''+str(d['prototype_count'])+''' verschiedene Teile und '''+str(d['occurrence_count'])+''' Vorkommen. Der Spannblock für 16 mm wird in zwei getrennten Steigungsvarianten wiederverwendet.</p>
<div class="scroll">'''+_table(d['parts'],partcols)+'''</div>
<p>Die isel-Blocknummern stammen aus der Tabelle zur Fußbefestigung. <strong>Fußbohrungen, Schlitze, Fixier-/Stellschrauben, Spannmutter und Schmieranschlüsse sind nicht modelliert.</strong> Die Tabellenzeichnung war nicht bildlich abrufbar. H1 wird als Abstand der Achse zur Fußfläche interpretiert und muss an der Originalzeichnung geprüft werden.</p>
<h2>2 · Der mitbewegte Block benötigt zusätzlichen Raum</h2><p>Die Rechnung verwendet die Vereinigung der axialen Hauptkörper von Mutter und Block. Ein außermittiger Studienversatz wird berücksichtigt; er ist keine Hersteller-Montagevorgabe.</p>
<div class="scroll">'''+_table(d['axial_rows'],axcols)+'''</div>
<p>Unbearbeitete Rohlinge, jeweils 10 mm Studienreserve an beiden Enden im Standardfall. Die Zahlen sind <strong>keine erreichbaren Maschinenhübe</strong>. Bearbeitete Enden, Lager, Anschläge, Vorspannung sowie überstehende Schrauben/Nippel fehlen.</p>
<h2>3 · Native Modellbildung</h2><p><code>NX_23_Rundmutter_Aufnahmen.py</code> erzeugt bei erfolgreichem Lauf acht native Teile und drei Referenz-Unterbaugruppen. Benannte Ausdrücke steuern den Aufbau. Standardumfang: 18 temporäre Parameteränderungen, neun axiale Lageproben und zwölf Schnittstellenprüfungen an gelesenen NX-Flächen.</p>
<p>H7/h7 bleiben Quellenbezeichnungen, keine berechnete Passungsfreigabe. Volumen- und Flächenprüfungen gelten nur für die vereinfachten Modellkörper. Die Darstellungsbohrung der Kugelmutter ist keine echte Laufbahn. Das Bauteilvolumen ist keine Grundlage für die Masse der realen Kaufteile.</p>
<h2>4 · Noch zu schließen</h2><p>Originalzeichnung/Hersteller-CAD, gesamte Klemm- und Befestigungsgeometrie, tatsächliche axiale Mutterposition, Anschluss an die Maschine, Lagerung und Endenbearbeitung. Der D04-Flanschhalter wird nicht als kompatible Aufnahme umgedeutet.</p>
<footer>Quelle: <a href="'''+e(d['source_url'])+'''">isel-Katalog April 2025</a>, Druckseiten 6, 8 und 9. Texttabellen abrufbar; Screenshots/Dateidownload und Original-CAD nicht erhalten. Dieser HTML-Bericht wird ohne NX aus den Projektparametern erzeugt.</footer></main></html>'''


def export_report(directory,cases=None):
 d=report_data(cases);out=Path(directory).absolute();out.mkdir(parents=True,exist_ok=False)
 with (out/'Rundmutterbericht_10.json').open('x',encoding='utf8') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False)
 _csv(out/'Bauteile_10.csv',d['parts']);_csv(out/'Axialraum_10.csv',d['axial_rows'])
 with (out/'Rundmutteraufnahmen_10.html').open('x',encoding='utf8') as f:f.write(html_report(d))
 return d
