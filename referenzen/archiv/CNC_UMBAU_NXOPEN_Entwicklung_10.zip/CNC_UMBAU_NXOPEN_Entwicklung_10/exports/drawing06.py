"""Nominal drawing specifications from existing recipes (no CAD kernel).

The bore datum is the part's local XYZ: front face z=0, rear z=thickness.
All dimensions are snapshots, not associative drafting dimensions. This module
cannot grant a manufacturing release or invent a material/tolerance/thread.
"""
import copy
import hashlib
import json
import math
from construction.housing04 import contract, bore_schedule, finite

SCHEMA = 'SX35Z_NOMINAL_DRAWING_06'
WARNING = 'ENTWURF - NICHT ZUR FERTIGUNG'


def fingerprint(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True,
                     separators=(',', ':'), allow_nan=False).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def fmt(number):
    return format(float(number), '.9g')


def project(point, view):
    if len(point) != 3:
        raise ValueError('XYZ point required')
    x, y, z = [finite(v) for v in point]
    if view == 'rear':
        return [x, y]
    if view == 'front':
        return [-x, y]
    if view == 'side':
        return [z, y]
    raise ValueError('Unknown view: ' + str(view))


def drawing_spec(recipe):
    checked = contract(recipe)  # validates finite numbers and all wall/step restrictions
    p = recipe['parameters']
    w, h, t = [p[k] for k in ('width', 'height', 'thickness')]
    if w>88 or h>84 or t>45 or checked['hole_count']>9:
        raise ValueError('Part exceeds admitted A3 drawing layout; change layout explicitly')
    holes = []
    for idx, row in enumerate(bore_schedule(recipe), 1):
        fdepth = row['front_depth_mm'] or 0.
        rdepth = row['rear_depth_mm'] or 0.
        profile = []
        if fdepth:
            profile.append(dict(z0=0., z1=fdepth, diameter=row['front_d_mm']))
        profile.append(dict(z0=fdepth, z1=t-rdepth, diameter=row['through_d_mm']))
        if rdepth:
            profile.append(dict(z0=t-rdepth, z1=t, diameter=row['rear_d_mm']))
        holes.append(dict(label='H%02d' % idx, id=row['hole_id'], x=row['x_mm'],
                          y=row['y_mm'], edge_x=row['x_mm']+w/2, edge_y=row['y_mm']+h/2,
                          through_d=row['through_d_mm'], front_d=row['front_d_mm'],
                          front_depth=row['front_depth_mm'], rear_d=row['rear_d_mm'],
                          rear_depth=row['rear_depth_mm'], axial_through_section_mm=t-fdepth-rdepth,
                          remaining_shoulder_mm=t-fdepth-rdepth if fdepth or rdepth else None,
                          axial_profile=profile, fit_note=row['fit_note'], role=row['role']))
    return dict(schema=SCHEMA, part_id=recipe['id'], recipe_sha256=fingerprint(recipe),
                parameters=copy.deepcopy(p), width=w, height=h, thickness=t,
                holes=holes, source=recipe['source'], dimension_sources=copy.deepcopy(recipe['dimension_sources']),
                material=recipe['material'], limitations=recipe['limitations'], nominal_contract=checked,
                units='mm', tolerances=None, threads=None,
                open_items=['Werkstoffsorte', 'Passungen', 'Toleranzen', 'Oberflaechen',
                            'Befestigungsauslegung', 'Maschinenanschluss'],
                datum='Bauteilmitte X/Y; Vorderseite z=0, Rueckseite z=t',
                warning=WARNING, native_execution=False, manufacturing_released=False,
                annotations='NOMINAL_SNAPSHOT_NOT_ASSOCIATIVE_NX_DIMENSIONS',
                sheet_mm=[420., 297.], scale=1.,
                projected_views=[dict(id='rear', name='Rueckansicht +Z', origin_mm=[77.,211.]),
                                 dict(id='front', name='Vorderansicht -Z', origin_mm=[183.,211.]),
                                 dict(id='side', name='Seitenansicht -X', origin_mm=[77.,99.])])


def section_bands(spec, cut_y):
    """Analytic XZ section of the recipe; not a section extracted from NX.

    The projected void of each circular bore is its chord at cut_y. Bands are
    split at ALL recess depths, so back counterbores cannot turn into blind holes.
    """
    cut_y = finite(cut_y)
    if abs(cut_y) >= spec['height']/2:
        raise ValueError('Section must be inside body')
    zbreaks = {0., spec['thickness']}
    for hole in spec['holes']:
        for step in hole['axial_profile']:
            zbreaks.update([step['z0'], step['z1']])
    zbreaks = sorted(zbreaks)
    rows = []
    for z0, z1 in zip(zbreaks, zbreaks[1:]):
        mid = (z0+z1)/2
        intervals = []
        for hole in spec['holes']:
            step = next(s for s in hole['axial_profile'] if s['z0'] <= mid < s['z1'])
            r, dy = step['diameter']/2, cut_y-hole['y']
            if abs(dy) < r:
                half = math.sqrt(r*r-dy*dy)
                intervals.append([hole['x']-half, hole['x']+half])
        merged = []
        for lo, hi in sorted(intervals):
            if merged and lo <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], hi)
            else:
                merged.append([lo, hi])
        material, cursor = [], -spec['width']/2
        for lo, hi in merged:
            if lo > cursor:
                material.append([cursor, lo])
            cursor = max(cursor, hi)
        if cursor < spec['width']/2:
            material.append([cursor, spec['width']/2])
        rows.append(dict(z0=z0, z1=z1, void_x=merged, material_x=material))
    return rows


def note_lines(spec):
    """Compact complete nominal hole/depth schedule for native notes."""
    out = [spec['warning'], 'Bauteil: '+spec['part_id'],
           'Nennmasse mm: B %s / H %s / T %s' % tuple(fmt(spec[k]) for k in ('width','height','thickness')),
           'Mitte X/Y=0; Vorderseite z=0; Rueckseite z=t.',
           'V = Senkung ab z=0; R = Senkung ab z=t; Tiefe nach innen.',
           'Koordinaten in Bauteilachsen, NICHT gespiegelten Blattachsen.',
           'ID: X / Y / durch D / V D x Tiefe / R D x Tiefe']
    for h in spec['holes']:
        front = '%s x %s' % (fmt(h['front_d']),fmt(h['front_depth'])) if h['front_d'] else '-'
        rear = '%s x %s' % (fmt(h['rear_d']),fmt(h['rear_depth'])) if h['rear_d'] else '-'
        out.append('%s (%s): %s / %s / %s / %s / %s' %
                   (h['label'],h['id'],fmt(h['x']),fmt(h['y']),fmt(h['through_d']),front,rear))
    out += ['Werkstoff: '+spec['material'], 'Passungen/Toleranzen/Oberflaechen: OFFEN.',
            'Alle dargestellten Bohrungen ohne Gewinde.',
            'Snapshot-Nennmasse: nach Modellaenderung neu ableiten.',
            'Keine assoziativen NX-Massobjekte; kein nativer Schnitt.',
            'Rezept: '+spec['recipe_sha256'][:20]]
    return out


def section_outline(spec, cut_y):
    """Boundary of the analytic material region; shared band edges are omitted."""
    bands = section_bands(spec, cut_y)
    lines = []
    for b in bands:
        for lo, hi in b['material_x']:
            lines += [[[lo,b['z0']],[lo,b['z1']]], [[hi,b['z0']],[hi,b['z1']]]]
    for i in range(len(bands)+1):
        before = bands[i-1]['material_x'] if i else []
        after = bands[i]['material_x'] if i < len(bands) else []
        z = bands[i]['z0'] if i < len(bands) else bands[-1]['z1']
        points = sorted({p for iv in before+after for p in iv})
        spans=[]
        for lo,hi in zip(points,points[1:]):
            mid=(lo+hi)/2
            left=any(a < mid < b for a,b in before)
            right=any(a < mid < b for a,b in after)
            if left != right:
                if spans and abs(spans[-1][1]-lo)<1e-10:spans[-1][1]=hi
                else:spans.append([lo,hi])
        lines += [[[lo,z],[hi,z]] for lo,hi in spans]
    return lines
