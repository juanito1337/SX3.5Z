"""Source-linked BOM draft export. Unknown items never become purchase releases."""
import csv
from pathlib import Path

def write_csv(path,rows):
    path=Path(path)
    fields=['id','assembly','kind','quantity','description','candidate','source_ids','selection_status','blockers','order_released']
    with path.open('x',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields,delimiter=';');w.writeheader()
        for row in rows:
            data={k:row.get(k,'') for k in fields}
            data['order_released']=False
            if isinstance(data['source_ids'],list):data['source_ids']=','.join(data['source_ids'])
            w.writerow(data)
