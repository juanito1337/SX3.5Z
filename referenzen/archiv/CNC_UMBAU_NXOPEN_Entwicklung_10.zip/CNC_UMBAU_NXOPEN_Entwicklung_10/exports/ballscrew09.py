"""Source/numerical catalogue reports. Never a substitute for NX-generated CAD."""
import csv
import html
import json
from pathlib import Path
from construction.ballscrew09 import reference_set
from engineering.ballscrew09 import load_registry


def report_data(cases=None,registry=None):
    reg=load_registry() if registry is None else registry
    data=reference_set(cases=cases,registry=reg);cat=[];ax=[];samples=[]
    for p in data['parts']:
        cat.append(dict(part_id=p['id'],role=p['role'],manufacturer=p['catalogue']['manufacturer'],
            article_number=p['catalogue']['article_number'],outer_diameter_mm=p['parameters']['outer_d'],
            length_mm=p['parameters']['length'],lead_mm=p['parameters']['lead_mm'],
            visual_bore_mm=p['parameters'].get('visual_bore_d'),
            visual_bore_status='DISPLAY_ONLY_NOT_MANUFACTURER_DIMENSION' if p['role']=='nut' else 'NOT_APPLICABLE',
            source=p['source'],supplier_original_cad=False,order_released=False))
    for p in data['pairs']:
        r=p['resolved'];w=r['window']
        ax.append(dict(case_id=p['id'],nut_article=r['nut_article'],stock_length_mm=r['stock_length_mm'],
            nut_length_mm=r['nut']['length_mm'],reserve_start_mm=r['reserve_start_mm'],reserve_end_mm=r['reserve_end_mm'],
            end_condition='UNMACHINED',**w))
        samples.extend(dict(case_id=p['id'],native_measured=False,**s) for s in p['axial_samples'])
    return dict(schema='CNC_CATALOGUE_OFFLINE_REPORT_09',status='CALCULATED_ENVELOPES_ONLY_NO_NATIVE_EXECUTION',
                native_execution=False,part_count=len(data['parts']),pair_count=len(data['pairs']),
                source_url=data['source_url'],source_evidence=reg['evidence'],catalogue_revision=reg['catalogue_revision'],
                catalogue_rows=cat,axial_rows=ax,axial_samples=samples,
                original_cad_obtained=False,order_released=False,manufacturing_released=False,
                machine_fit_verified=False,machine_travel_verified=False,
                unknowns=['Finished screw ends and non-traversable lengths','Bearing, coupling and clamp selection',
                          'Machine coordinates, real stroke and all fixing interfaces','Physical load and motion duty',
                          'Manufacturer drawing visual check, exact stock/order confirmation'],
                limitations=data['limitations'])


def _csv(path,rows):
    with path.open('x',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader()
        for row in rows:
            cleaned={}
            for k,v in row.items():
                if v is None:v=''
                if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')):v="'"+v
                cleaned[k]=v
            w.writerow(cleaned)


def _text(value):
    if value is None:return 'offen'
    if type(value) is bool:return 'ja' if value else 'nein'
    if isinstance(value,(int,float)):return format(value,'.8g')
    return str(value)


def _table(rows,columns):
    e=lambda x:html.escape(_text(x))
    return '<table><thead><tr>'+''.join('<th>'+e(title)+'</th>' for key,title in columns)+'</tr></thead><tbody>'+''.join(
        '<tr>'+''.join('<td>'+e(row.get(key))+'</td>' for key,title in columns)+'</tr>' for row in rows)+'</tbody></table>'


def html_report(r):
    catcols=[('part_id','Referenzteil'),('article_number','Mutter-Artikel'),('outer_diameter_mm','Außen-Ø mm'),
             ('length_mm','Länge mm'),('lead_mm','Steigung mm'),('visual_bore_mm','Darstellungsbohrung mm')]
    axcols=[('case_id','Paar'),('stock_length_mm','Rohling mm'),('nut_length_mm','Mutter mm'),('reserve_start_mm','Reserve links mm'),('reserve_end_mm','Reserve rechts mm'),
            ('center_min_mm','Mitte min. mm'),('center_max_mm','Mitte max. mm'),('span_mm','Axialer Bereich mm'),
            ('requested_stroke_mm','Gewünschter Bereich mm'),('missing_length_mm','Fehlende Länge mm')]
    source=html.escape(r['source_url'],quote=True)
    return '''<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entwicklung 09 · Kugelgewinde-Katalogreferenzen</title>
<style>body{font:16px/1.55 system-ui,sans-serif;background:#f3f5f7;color:#1e2a35;margin:0}main{max-width:1160px;margin:34px auto;padding:36px;background:white}h1{line-height:1.2;font-size:32px}h2{margin-top:32px;font-size:23px}.label{font-weight:700;color:#12556a;letter-spacing:.04em}.warn{padding:16px 20px;background:#fff1d7;border-left:5px solid #b66c00}table{border-collapse:collapse;width:100%;font-size:13px;margin:18px 0}th,td{padding:10px;border-bottom:1px solid #ccd3d9;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#e8eff4}code{background:#eef2f5;padding:2px 4px}a{color:#075974}.scroll{overflow-x:auto}footer{border-top:1px solid #ccd3d9;margin-top:32px;padding-top:18px;font-size:13px}@media print{body{background:white}main{margin:0;padding:12px}h2{break-after:avoid}tr{break-inside:avoid}}</style><main>
<div class="label">SX3.5Z · ENTWICKLUNG 09</div><h1>Kugelgewinde: Katalogdaten und axialer Platzbedarf</h1>
<p class="warn"><strong>KEIN NX-LAUF · KEINE BESTELL- ODER FERTIGUNGSFREIGABE.</strong><br>
Dieser Bericht ist aus Katalogtabellen und Studienparametern berechnet. Er enthält keine gemessenen NX-Körper und keinen Nachweis für die reale Fräse.</p>
<h2>1 · Konkrete Katalogpaarungen</h2><p>Hersteller: isel Germany GmbH. Katalogstand April 2025. '''+str(r['part_count'])+''' getrennte Referenzteile in '''+str(r['pair_count'])+''' Paaren; die baugleichen Außenformen 16×4 und 16×5 behalten getrennte Steigungsdaten.</p>
<div class="scroll">'''+_table(r['catalogue_rows'],catcols)+'''</div>
<p><strong>Nur die Außenabmessungen sind als Katalog-Nennmaße übernommen.</strong> Die Darstellungsbohrung der Mutter entspricht zum Anzeigen dem nominellen Spindeldurchmesser. Sie ist <strong>keine Herstellerbohrung, Passung oder Kugellaufbahn</strong>. Volumina dienen ausschließlich den Modelltests, nicht der Bestimmung der realen Masse.</p>
<h2>2 · Längenkette, nicht Maschinenverfahrweg</h2><p>Alle Spindeln dieser Studie: <strong>UNBEARBEITET</strong>. Z = 0 ist der Anfang des Rohlings. Die eingestellten Reserven stehen in der Tabelle; sie sind Entwurfswerte, keine vom Hersteller vorgegebenen Sicherheitsabstände.</p>
<p><code>axialer Bereich = Rohlinglänge − Mutterlänge − Reserve links − Reserve rechts</code></p>
<div class="scroll">'''+_table(r['axial_rows'],axcols)+'''</div>
<p>Für bearbeitete Spindeln sind zusätzlich die nicht befahrbaren Enden, Ausläufe, Lager, Halter und Anschläge zu berücksichtigen. Unbekannte Endlängen dürfen nicht als null eingesetzt werden. Der Wunschhub bleibt in der Standardkonfiguration offen.</p>
<h2>3 · Native Erzeugung in NX</h2><p><code>NX_22_Kugelgewindetriebe_Katalog.py</code> erzeugt bei erfolgreichem Lauf sechs parametrische Einzelteile, drei Paar-Unterbaugruppen und eine Übersicht. Die lokale Studienachse liegt in Z; die drei Paare stehen getrennt nebeneinander. Keine Montage an erfundenen X-/Y-/Z-Maschinenanschlüssen.</p>
<p>Vorgesehen: zwölf temporäre Parameteränderungen mit Rückstellung, neun axiale Lageproben, Quellschutz und Stückzahlvergleich aus der tatsächlich erzeugten Baugruppe. Ein unabhängiger NX-2406-Lauf steht aus.</p>
<h2>4 · Noch nicht modelliert oder bestätigt</h2><p>Kugellaufbahnen, Umlenkungen, Abstreifer, Schmierung, Klemm-/Vorspanngeometrie, Lager- und Kupplungszapfen, vollständige Lagerung, Motoranbindung, Festigkeit und Einpassung in die Maschine. Ein fehlerfreier Hüllkörper darf diese Nachweise nicht ersetzen.</p>
<footer>Quelle: <a href="'''+source+'''">isel-Katalog April 2025</a>, Druckseiten 6 und 8. Texttabellen ausgelesen; PDF-Bilddarstellung nicht verfügbar. Kein Hersteller-STEP und keine lokale Original-PDF-Datei beschafft. Maße vor Bestellung anhand Originalzeichnung bestätigen. Bericht erzeugt mit <code>Projekt09_Kugelgewindebericht.py</code>.</footer></main></html>'''


def export_report(directory,cases=None,registry=None):
    r=report_data(cases,registry) # Validate before writing anything.
    out=Path(directory).absolute();out.mkdir(parents=True,exist_ok=False)
    with (out/'Kugelgewindebericht_09.json').open('x',encoding='utf8') as f:json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False)
    _csv(out/'Katalogzuordnung_09.csv',r['catalogue_rows'])
    _csv(out/'Axialplan_09.csv',r['axial_rows']);_csv(out/'Axialproben_PLAN_09.csv',r['axial_samples'])
    with (out/'Kugelgewinde_09.html').open('x',encoding='utf8') as f:f.write(html_report(r))
    return r
