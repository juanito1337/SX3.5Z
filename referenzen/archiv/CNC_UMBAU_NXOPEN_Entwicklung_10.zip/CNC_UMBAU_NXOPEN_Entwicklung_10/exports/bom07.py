"""BOM reports, explicit unreviewed assignment template and recipe-only preview.
Uses Python standard library; no spreadsheet/CAD engine needed inside NX.
"""
from collections import Counter
from copy import deepcopy
import csv
import hashlib
import html
import json
from pathlib import Path
from cnc_nx.runtime import sha256_file, write_json_new

FIELDS = ['row_id', 'item_id', 'revision', 'kind', 'quantity', 'unit', 'description',
          'manufacturer', 'model', 'order_number', 'dimension_status', 'material',
          'prototype_path', 'prototype_sha256', 'source_refs', 'blockers',
          'order_released', 'manufacturing_released']


def csv_value(value):
    if value is None:
        return ''
    if isinstance(value, (list, dict)):
        value = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if isinstance(value, str):
        stripped = value.lstrip(' \t\r\n')
        if value.startswith(('\t','\r','\n')) or stripped.startswith(('=', '+', '-', '@')):
            return "'" + value
    return value


def _csv(path, fields, rows):
    with Path(path).open('x', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields, delimiter=';')
        writer.writeheader()
        for row in rows:
            writer.writerow({k: csv_value(row.get(k)) for k in fields})


def assignment_template(report):
    entries = []; unresolved = []
    for row in report['rows']:
        if not row['source_bound'] or not row.get('prototype_path') or not row.get('prototype_sha256'):
            unresolved.append(row['row_id']); continue
        entries.append(dict(prototype_path=row['prototype_path'], prototype_sha256=row['prototype_sha256'],
            item_id=None, revision='UNREVIEWED', kind='UNASSIGNED', description=row.get('name',''),
            manufacturer=None, model=None, order_number=None, dimension_status=None, material=None,
            source_refs=[], documents=[], blockers=[], observed_quantity=row['quantity']))
    return dict(schema='SX35Z_BOM_ASSIGNMENTS_7', review='NOT_REVIEWED', entries=entries,
        unresolved_rows=unresolved, note='Menge kommt ausschliesslich aus Vorkommen. observed_quantity ist nur Lesehilfe. '
        'Artikel-/Herstellerzuordnung pruefen; Dokumente mit Datei-SHA256 und model_sha256 binden. Keine Freigabe.')


def recipe_metadata(recipe):
    """Labels/provenance, NOT an assertion of a physical purchase or machine fit."""
    digest = hashlib.sha256(json.dumps(recipe, sort_keys=True, allow_nan=False).encode()).hexdigest()
    motor = recipe['kind'] == 'motor_envelope'
    blockers = ['REFERENCE_NOT_MACHINE_FITTED', 'ENGINEERING_REVIEW_REQUIRED']
    if motor:
        blockers += ['CATALOGUE_LENGTH_103_MM_VS_PRODUCT_PAGE_104_MM_UNRESOLVED',
                     'ORDER_IDENTIFIER_NOT_SPECIFIED']
    else:
        blockers += ['MATERIAL_NOT_SPECIFIED', 'DRAWING_NOT_LINKED']
    return dict(item_id=recipe['id'], revision='R03_'+digest[:12],
        kind='PURCHASE' if motor else 'MANUFACTURED',
        description=('Vereinfachte CS-M22326-Referenz, Katalogstand 2022' if motor else
            {'D03_MOTOR_PLATE':'Motortraeger-Rohplatte','D03_SPACER':'Distanzhuelse',
             'D03_INTERFACE_BLANK':'Maschinenseitige Rohplatte'}.get(recipe['id'],recipe['id'])),
        manufacturer=recipe.get('manufacturer'), model=recipe.get('manufacturer_model'),
        order_number=None, dimension_status=recipe.get('dimensions_status'), material=None,
        source_refs=[recipe['source']], documents=[], blockers=blockers,
        recipe_sha256=digest, order_released=False, manufacturing_released=False)


def recipe_preview():
    from construction.recipes03 import reference_carrier
    data = reference_carrier()
    quantities = Counter(c['part_id'] for c in data['components'])
    rows = []; occurrences = [dict(path='RECIPE_ROOT',parent=None,name='Motortraeger_Rezept',
        prototype_id=None,disposition='ASSEMBLY_CONTAINER_NOT_COUNTED',row_id=None)]
    for i, recipe in enumerate(sorted(data['parts'],key=lambda r:r['id']),1):
        row = recipe_metadata(recipe)
        row.update(row_id='B%04d'%i, quantity=quantities[recipe['id']], unit='Stueck', name=recipe['id'],
            prototype_path=None, prototype_sha256=None, source_bound=False, prototype_ids=[],
            occurrence_paths=[c['id'] for c in data['components'] if c['part_id']==recipe['id']],
            document_checks=[], model_file_check='NOT_CREATED', identity_status='RECIPE_ONLY',
            solid_body_count=None, non_solid_body_count=None)
        rows.append(row)
        for path in row['occurrence_paths']:
            occurrences.append(dict(path=path,parent='RECIPE_ROOT',name=path,prototype_id=recipe['id'],
                disposition='RECIPE_COMPONENT_NOT_NX_READ',row_id=row['row_id']))
    return dict(schema='SX35Z_BOM_REPORT_7', status='RECIPE_PREVIEW_NOT_NATIVE_INVENTORY',
        source_origin='RECIPE_PREVIEW', native_read_in_this_run=False,
        inventory_complete=False, source_binding_complete=False, assignment_complete=False,
        document_link_complete=False, file_check_mode='NO_NATIVE_FILES_EXIST',
        order_released=False, manufacturing_released=False, rows=rows, occurrences=occurrences,
        issues=[dict(code='RECIPE_ONLY',where='reference_carrier()',severity='NOTICE',
                     message='Vorschau aus Rezeptdaten; keine NX-Dateien gelesen oder erzeugt.')],
        counts=dict(active_leaf_occurrences=sum(quantities.values()),distinct_part_rows=len(rows),
                    assembly_occurrences=1,suppressed_branches=0,unresolved_occurrences=0,
                    occurrences_including_root=len(occurrences)),
        source_files=[],source_file_checks=[],unused_assignments=[],
        limitations=['Rezeptmengen, keine gemessene oder fertig montierte Maschine',
                     'Kupplung, Lager, Schrauben, Kabel und Maschinenanschluss fehlen im Referenzrezept',
                     'Kein neuer Kaufteil-/Lieferbarkeitsnachweis'])


def _validate_report(r):
    if r.get('schema') != 'SX35Z_BOM_REPORT_7':
        raise ValueError('Unsupported BOM report')
    rows = r['rows']
    if len({x['row_id'] for x in rows}) != len(rows):
        raise ValueError('Duplicate BOM row')
    if any(type(x['quantity']) is not int or x['quantity'] <= 0 for x in rows):
        raise ValueError('BOM quantities must be positive integer occurrence counts')
    if sum(x['quantity'] for x in rows) != r['counts']['active_leaf_occurrences']:
        raise ValueError('BOM row total differs from counted leaves')
    if len(rows) != r['counts']['distinct_part_rows']:
        raise ValueError('BOM part count differs from rows')
    if r.get('order_released') is not False or r.get('manufacturing_released') is not False:
        raise ValueError('This exporter cannot publish a released order/manufacturing BOM')
    if any(x.get('order_released') is not False or x.get('manufacturing_released') is not False for x in rows):
        raise ValueError('Released item unsupported')
    json.dumps(r,allow_nan=False)


def _html(r):
    esc = lambda x: html.escape('' if x is None else str(x), quote=True)
    body = []
    labels={'MANUFACTURED':'Fertigung','PURCHASE':'Kaufteil','ORIGINAL':'Bestand','REFERENCE':'Referenz','UNASSIGNED':'Unzugeordnet'}
    for row in r['rows']:
        source = '<br>'.join(esc(x) for x in (row.get('source_refs') or []))
        blockers = '<br>'.join(esc(x) for x in row.get('blockers', [])) or 'Keine weitere Angabe'
        body.append('<tr><td>%s</td><td><strong>%s</strong><br><small>%s</small></td>'
            '<td>%s</td><td class="qty">%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' %
            (esc(row['row_id']),esc(row.get('item_id') or row.get('name') or 'UNASSIGNED'),esc(row.get('revision')),
             ('<span title="'+esc(row['kind'])+'">'+esc(labels.get(row['kind'],row['kind']))+'</span>'),esc(row['quantity']),esc(row.get('description')),source,blockers))
    issues=''.join('<li>%s — %s</li>'%(esc(x.get('where')),esc(x.get('message'))) for x in r.get('issues',[]))
    docs = ''.join('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' %
        (esc(row['row_id']),esc(d.get('role')),esc(d.get('path')),esc(d.get('status')))
        for row in r['rows'] for d in row.get('document_checks',[]))
    label = 'REZEPTVORSCHAU – KEINE NX-BESTANDSAUFNAHME' if r['source_origin']=='RECIPE_PREVIEW' else 'BAUGRUPPENSTÜCKLISTE – NICHT FREIGEGEBEN'
    return '''<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Stückliste | Entwicklung 07</title><style>
body{font:15px/1.5 system-ui,sans-serif;background:#f2f4f7;color:#1c2939;margin:0}main{max-width:1460px;margin:auto;padding:32px}
h1{font-size:30px;margin:8px 0}h2{font-size:21px}.kicker{letter-spacing:.15em;color:#52667d;font-size:12px;font-weight:700}
.notice{border-left:5px solid #b77320;background:#fff3d8;padding:15px;margin:20px 0}.metrics{display:flex;gap:16px;flex-wrap:wrap}
.metric{background:white;padding:18px 28px;border-radius:6px;min-width:170px}.metric strong{display:block;font-size:30px}
.tablewrap{overflow:auto;background:white;border:1px solid #d6dde5;border-radius:6px}table{border-collapse:collapse;width:100%;font-size:13px}
th{background:#20384f;color:white;text-align:left;padding:12px}td{padding:12px;vertical-align:top;border-bottom:1px solid #dce3ea;overflow-wrap:anywhere;max-width:310px}
td:first-child{white-space:nowrap;min-width:48px}td:nth-child(3){min-width:90px}tr:nth-child(even){background:#f8fafc}.qty{text-align:right;font-weight:700;font-size:17px}small{color:#607084}code{background:#e6ebf0;padding:3px 5px}
footer{margin-top:30px;font-size:13px;color:#52667d}@media print{main{padding:0}.tablewrap{overflow:visible}th{color:black;background:#eee}}
</style><main><div class="kicker">SX3.5Z / NX OPEN / ENTWICKLUNG 07</div><h1>Stückliste und Dateinachweise</h1>
<div class="notice"><strong>'''+label+'''</strong><br>Keine Bestell- oder Fertigungsfreigabe. Leere Filterlisten bedeuten nicht, dass eine vollständige Maschine keine solchen Teile benötigt.</div>
<div class="metrics"><div class="metric"><strong>'''+str(r['counts']['active_leaf_occurrences'])+'''</strong>Blattvorkommen / Rezeptmengen</div>
<div class="metric"><strong>'''+str(len(r['rows']))+'''</strong>unterschiedliche Teile</div>
<div class="metric"><strong>'''+str(r['counts'].get('suppressed_branches',0))+'''</strong>unterdrückte Zweige</div></div>
<p>Status: <code>'''+esc(r['status'])+'''</code><br>Quelle: <code>'''+esc(r['source_origin'])+'''</code> · Nativer Lesevorgang in diesem Lauf: '''+('JA' if r['native_read_in_this_run'] else 'NEIN')+'''</p>
<h2>Teile und Mengen</h2><div class="tablewrap"><table><thead><tr><th>Pos.</th><th>Teil / Revision</th><th>Art</th><th>Menge</th><th>Beschreibung</th><th>Quelle</th><th>Offene Punkte</th></tr></thead><tbody>'''+''.join(body)+'''</tbody></table></div>
<h2>Dokumentverknüpfungen</h2><div class="tablewrap"><table><thead><tr><th>Pos.</th><th>Rolle</th><th>Datei</th><th>Identitätsprüfung</th></tr></thead><tbody>'''+(docs or '<tr><td colspan="4">Keine Zeichnungs-/Exportdateien verknüpft.</td></tr>')+'''</tbody></table></div>
<h2>Hinweise zur Aufnahme</h2><ul>'''+(issues or '<li>Keine zusätzlichen Aufnahmefehler protokolliert. Dies ist keine technische Freigabe.</li>')+'''</ul>
<footer>Gezählt werden aktive Blattvorkommen, nicht Volumenkörper oder Dateien im Ordner. Sichtbarkeit/Reference Set sind kein Ausschlussgrund.
Unterdrückte Zweige gelten nur für die geladene Konfiguration. Preis, Verfügbarkeit, Toleranzen, Passung und Sicherheit sind nicht geprüft.</footer></main></html>'''


def export_report(directory, report):
    _validate_report(report)
    directory = Path(directory)
    if not directory.is_absolute():
        raise ValueError('New absolute report directory required')
    directory.mkdir(parents=True,exist_ok=False)
    _csv(directory/'Gesamtstueckliste_07.csv',FIELDS,report['rows'])
    for name,kind in [('Kaufteile_KEINE_BESTELLFREIGABE','PURCHASE'),('Fertigungsteile_NICHT_FREIGEGEBEN','MANUFACTURED'),
                      ('Bestand_07','ORIGINAL'),('Referenzteile_07','REFERENCE'),('Unzugeordnet_07','UNASSIGNED')]:
        _csv(directory/(name+'.csv'),FIELDS,[row for row in report['rows'] if row['kind']==kind])
    _csv(directory/'Vorkommnisse_07.csv',['path','parent','name','prototype_id','disposition','row_id'],report['occurrences'])
    docs = [dict(d,row_id=row['row_id']) for row in report['rows'] for d in row.get('document_checks',[])]
    _csv(directory/'Dokumente_07.csv',['row_id','role','path','sha256','model_sha256','status'],docs)
    unresolved = [dict(row_id=row['row_id'],item_id=row.get('item_id'),blocker=b)
                  for row in report['rows'] for b in row.get('blockers',[])]
    _csv(directory/'Offene_Punkte_07.csv',['row_id','item_id','blocker'],unresolved)
    with (directory/'Stueckliste_07.html').open('x',encoding='utf-8') as f:
        f.write(_html(report))
    write_json_new(directory/'Stueckliste_07.json',report)
    checks={p.name:sha256_file(p) for p in sorted(directory.iterdir()) if p.is_file()}
    write_json_new(directory/'Export_SHA256_07.json',dict(schema='SX35Z_BOM_EXPORT_7',export_complete=True,files=checks,
        native_read_in_this_run=report['native_read_in_this_run'],order_released=False,manufacturing_released=False))
    return checks
