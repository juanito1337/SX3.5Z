"""Source-based 2D review artifacts. NOT a CAD model and NOT an NX export.
ReportLab is optional for the offline PDF; native NX journals don't import it.
DXF contains overlaid nominal bore-level contours, not a machining program or
sheet-metal development. Every file is created exclusively; nothing overwritten.
"""
import csv
import json
from pathlib import Path
from construction.library04 import reference_library
from cnc_nx.runtime import write_json_new, sha256_file
from .drawing06 import drawing_spec, section_bands, section_outline, project, fmt


def dxf_text(s):
    rows = []
    def tag(code, value):
        rows.extend([str(code), str(value)])
    def entity(name, layer):
        tag(0,name);tag(8,layer)
    tag(0,'SECTION');tag(2,'HEADER');tag(9,'$ACADVER');tag(1,'AC1015')
    tag(9,'$INSUNITS');tag(70,4);tag(9,'$MEASUREMENT');tag(70,1);tag(0,'ENDSEC')
    tag(0,'SECTION');tag(2,'TABLES');tag(0,'TABLE');tag(2,'LAYER');tag(5,'1');tag(70,5)
    for layer in ('OUTLINE','THROUGH_BORE','FRONT_RECESS','REAR_RECESS','NOTICE'):
        tag(0,'LAYER');tag(2,layer);tag(70,0);tag(62,7);tag(6,'CONTINUOUS')
    tag(0,'ENDTAB');tag(0,'ENDSEC');tag(0,'SECTION');tag(2,'ENTITIES')
    w,h=s['width']/2,s['height']/2
    corners=[[-w,-h],[w,-h],[w,h],[-w,h]]
    for a,b in zip(corners,corners[1:]+corners[:1]):
        entity('LINE','OUTLINE');tag(10,fmt(a[0]));tag(20,fmt(a[1]));tag(30,0)
        tag(11,fmt(b[0]));tag(21,fmt(b[1]));tag(31,0)
    for hole in s['holes']:
        for layer,key in [('THROUGH_BORE','through_d'),('FRONT_RECESS','front_d'),('REAR_RECESS','rear_d')]:
            if hole[key] is None:continue
            entity('CIRCLE',layer);tag(10,fmt(hole['x']));tag(20,fmt(hole['y']));tag(30,0);tag(40,fmt(hole[key]/2))
    for i,line in enumerate([s['part_id'],s['warning'], 'mm / KEIN_CAM / KEINE_ABWICKLUNG / KEIN_NX_EXPORT',
                             'V=ab z0, R=ab zt; Stufentiefen siehe Bohrungstabelle',
                             'Rezept '+s['recipe_sha256'][:20]]):
        entity('TEXT','NOTICE');tag(10,fmt(-w));tag(20,fmt(-h-8-i*5));tag(30,0);tag(40,2.5);tag(1,line)
    tag(0,'ENDSEC');tag(0,'EOF')
    return '\n'.join(rows)+'\n'


def write_dxf(path, spec):
    text=dxf_text(spec)
    with open(path,'x',encoding='ascii') as f:f.write(text)
    return dict(path=str(path),sha256=sha256_file(path),units='mm',native_execution=False,
                is_sheet_metal_development=False,is_cam_ready=False)


def validate_pdf_file(path):
    raw=Path(path).read_bytes()
    if not raw.startswith(b'%PDF-') or b'%%EOF' not in raw[-4096:]:
        raise ValueError('Missing complete PDF header/trailer: '+str(path))
    return {'path':str(path),'bytes':len(raw),'sha256':sha256_file(path),
            'validation':'HEADER_TRAILER_ONLY_NOT_RENDERING_OR_DRAWING_ACCURACY'}


def write_preview_pdf(path, specs):
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import mm
    from reportlab.lib.utils import simpleSplit
    path=Path(path)
    # Open ourselves in exclusive mode: Canvas normally overwrites existing files.
    with open(path,'xb') as handle:
        c=canvas.Canvas(handle,pagesize=(420*mm,297*mm))
        c.setTitle('Nennmassblaetter Entwicklung06 - kein NX-Export - nicht zur Fertigung')
        def text(x,y,s,size=8,bold=False):
            c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
            c.drawString(x*mm,y*mm,str(s))
        def line(x1,y1,x2,y2,dash=False,width=.22):
            c.setLineWidth(width*mm);c.setDash([1.8*mm,1.*mm] if dash else [])
            c.line(x1*mm,y1*mm,x2*mm,y2*mm);c.setDash([])
        def rect(x,y,w,h):
            c.setLineWidth(.25*mm);c.rect(x*mm,y*mm,w*mm,h*mm)
        def arrow(x,y,dx,dy):
            line(x,y,x+dx*2-dy*.65,y+dy*2+dx*.65)
            line(x,y,x+dx*2+dy*.65,y+dy*2-dx*.65)
        def hdim(x1,x2,y,body_y,value):
            line(x1,body_y,x1,y-2);line(x2,body_y,x2,y-2);line(x1,y,x2,y)
            arrow(x1,y,1,0);arrow(x2,y,-1,0);text((x1+x2)/2-3,y+1.5,fmt(value),8)
        def vdim(x,y1,y2,body_x,value):
            line(body_x,y1,x+2,y1);line(body_x,y2,x+2,y2);line(x,y1,x,y2)
            arrow(x,y1,0,1);arrow(x,y2,0,-1);text(x-9,(y1+y2)/2,fmt(value),8)
        def paragraph(x,y,content,width=170,size=8,leading=4.2):
            for s in simpleSplit(content,'Helvetica',size,width*mm):
                text(x,y,s,size);y-=leading
            return y
        for page_no,s in enumerate(specs,1):
            rect(8,8,404,281)
            text(14,280,'SX3.5Z / CNC-Umbau / Entwicklung 06',11,True)
            text(14,272,s['part_id'],15,True)
            text(265,281,s['warning'],11,True)
            text(265,274,'QUELLBASIERTE VORSCHAU - KEIN NX-EXPORT',8,True)
            line(8,265,412,265)
            for view,cx,cy in [('rear',75,211),('front',180,211)]:
                w,h=s['width'],s['height'];rect(cx-w/2,cy-h/2,w,h)
                line(cx-w/2-4,cy,cx+w/2+4,cy,True,.12);line(cx,cy-h/2-4,cx,cy+h/2+4,True,.12)
                for ho in s['holes']:
                    xx,yy=project([ho['x'],ho['y'],0],view);xx+=cx;yy+=cy
                    visible='rear_d' if view=='rear' else 'front_d'
                    other='front_d' if view=='rear' else 'rear_d'
                    for key in ['through_d',visible,other]:
                        if ho[key] is None:continue
                        c.setLineWidth(.2*mm);c.setDash([1*mm,.7*mm] if key==other else [])
                        c.circle(xx*mm,yy*mm,ho[key]*mm/2,stroke=1,fill=0)
                    c.setDash([])
                    # Rear is the reference direction for the coordinate table.
                    if view=='rear':
                        text(xx+ho['through_d']/2+1,yy+1,ho['label'],6.5)
                caption='Rueckansicht +Z / X nach rechts' if view=='rear' else 'Vorderansicht -Z / X nach links'
                text(cx-41,cy-h/2-17,caption,8,True)
                hdim(cx-w/2,cx+w/2,cy-h/2-9,cy-h/2,w)
                if view=='rear':vdim(cx-w/2-10,cy-h/2,cy+h/2,cx-w/2,h)
            text(245,253,'BOHRUNGEN / NENNMASSE [mm]',10,True)
            text(245,246,'X/Y ab Mitte; V ab z=0; R ab z=t.',8)
            cols=[245,260,278,296,312,356]
            for x,h in zip(cols,['ID','X','Y','D durch','V: D x Tiefe','R: D x Tiefe']):text(x,237,h,7.5,True)
            line(244,234,405,234)
            for i,ho in enumerate(s['holes']):
                yy=228-i*7
                f='-' if ho['front_d'] is None else fmt(ho['front_d'])+' x '+fmt(ho['front_depth'])
                r='-' if ho['rear_d'] is None else fmt(ho['rear_d'])+' x '+fmt(ho['rear_depth'])
                for x,val in zip(cols,[ho['label'],fmt(ho['x']),fmt(ho['y']),fmt(ho['through_d']),f,r]):text(x,yy,val,7.5)
                line(244,yy-2.5,405,yy-2.5,False,.08)
            yy=228-len(s['holes'])*7-3
            yy=paragraph(245,yy,'Alle Bohrungen ohne Gewinde. Passungen und Toleranzen sind nicht festgelegt.',155)
            paragraph(245,yy-2,'Werkstoff: '+('OFFEN (kein Werkstoff festgelegt)' if s['material']=='UNSPECIFIED_DESIGN' else s['material']),155)
            # Analytic XZ section through the first bore, not a native section view.
            cut_y=s['holes'][0]['y'];bands=section_bands(s,cut_y);scale=1.5;ox,oy=112,105
            for b in bands:
                y0=oy-b['z1']*scale;hh=(b['z1']-b['z0'])*scale
                for lo,hi in b['material_x']:
                    x0=ox+lo*scale;ww=(hi-lo)*scale
                    c.saveState();p=c.beginPath();p.rect(x0*mm,y0*mm,ww*mm,hh*mm);c.clipPath(p,stroke=0,fill=0)
                    for k in range(-160,241,3):line(ox+k,oy-80,ox+k+100,oy+20,False,.08)
                    c.restoreState()
            for a,b in section_outline(s,cut_y):
                line(ox+a[0]*scale,oy-a[1]*scale,ox+b[0]*scale,oy-b[1]*scale)
            text(14,122,'SCHNITTSCHEMA / X-Z / y = '+fmt(cut_y)+' mm',9,True)
            text(14,116,'Analytisch aus dem Rezept, keine NX-Schnittansicht. Darstellung 1,5:1.',7.5)
            vdim(ox+s['width']*scale/2+9,oy-s['thickness']*scale,oy,ox+s['width']*scale/2,s['thickness'])
            text(ox+s['width']*scale/2+20,oy-1,'z=0 / V',7)
            text(ox+s['width']*scale/2+20,oy-s['thickness']*scale+1,'z=t / R',7)
            hole=s['holes'][0]
            chain=' + '.join(fmt(b['z1']-b['z0']) for b in hole['axial_profile'])+' = '+fmt(s['thickness'])+' mm'
            text(14,53,'Axiale Masskette '+hole['label']+': '+chain,9,True)
            text(14,47,'Stufentiefen nach innen; Mittelabschnitt = verbleibende Schulter.' if hole['remaining_shoulder_mm'] is not None else 'Reine Durchgangsbohrung; keine Sitzschulter vorhanden.',7.5)
            y=110
            y=paragraph(245,y,'Quelle: '+s['source'],157,7.5,4)
            y=paragraph(245,y-4,'Modellgrenzen: '+s['limitations'],157,7.5,4)
            line(8,38,412,38)
            text(14,31,'Masse als Snapshot; nach Modellaenderung neu erzeugen. Kein Bestell- oder Fertigungsdatensatz.',8,True)
            text(14,24,'OFFEN: Werkstoffsorte, Passungen, Toleranzen, Oberflaechen, Befestigung und Maschinenanschluss.',8)
            text(14,17,'Rezept SHA256: '+s['recipe_sha256'],7)
            text(338,17,'A3 / Ansichten 1:1 / Blatt %s/%s'%(page_no,len(specs)),7)
            c.showPage()
        c.save()
    return validate_pdf_file(path)


def write_bundle(directory, catalogue=None):
    data=reference_library(catalogue)
    specs=[drawing_spec(r) for r in data['parts']]
    root=Path(directory)
    if not root.is_absolute():raise ValueError('Absolute new output directory required')
    root.mkdir(parents=True,exist_ok=False)
    rows=[]
    for s in specs:
        write_json_new(root/(s['part_id']+'_Spezifikation.json'),s)
        write_dxf(root/(s['part_id']+'_PRUEFKONTUR_KEIN_CAM.dxf'),s)
        rows.extend(dict(part=s['part_id'],hole=h['label'],id=h['id'],x_mm=h['x'],y_mm=h['y'],
                         x_from_left_mm=h['edge_x'],y_from_bottom_mm=h['edge_y'],through_d_mm=h['through_d'],
                         front_d_mm=h['front_d'],front_depth_mm=h['front_depth'],rear_d_mm=h['rear_d'],
                         rear_depth_mm=h['rear_depth'],axial_through_section_mm=h['axial_through_section_mm'],
                         remaining_shoulder_mm=h['remaining_shoulder_mm'],
                         fit='OFFEN',thread='NONE',recipe_sha256=s['recipe_sha256']) for h in s['holes'])
    with open(root/'Bohrungstabelle_06.csv','x',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)
    pdf=write_preview_pdf(root/'Nennmassblaetter_KEIN_NX_EXPORT.pdf',specs)
    pdf['path']=Path(pdf['path']).name
    report=dict(status='SOURCE_BASED_2D_REVIEW_ONLY',part_count=len(specs),native_execution=False,
                manufacturing_released=False,source='Existing development04 recipe catalogue',
                geometry_created=False,pdf=pdf,files={p.name:sha256_file(p) for p in root.iterdir() if p.is_file()})
    write_json_new(root/'Vorschau_Bericht_06.json',report)
    return report
