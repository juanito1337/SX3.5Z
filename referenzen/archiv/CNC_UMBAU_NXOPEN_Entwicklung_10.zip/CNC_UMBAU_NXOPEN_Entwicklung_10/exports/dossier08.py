"""Portable check dossier: JSON, escaped HTML and spreadsheet-safe CSV; no CAD."""
import html
import json
from pathlib import Path
from cnc_nx.runtime import write_json_new,sha256_file
from exports.bom07 import _csv


def _validate(report):
    if report.get('schema')!='SX35Z_DOSSIER_8':raise ValueError('Unknown dossier schema')
    for key in ('manufacturing_released','order_released','final_cnc_assembly_accepted','physical_machine_verified'):
        if report.get(key) is not False:raise ValueError('Dossier cannot publish engineering release: '+key)
    json.dumps(report,allow_nan=False)


def html_report(report):
    _validate(report)
    e=lambda v:html.escape('' if v is None else str(v),quote=True)
    subject=report.get('subject') or {}
    rows=''.join('<tr><td><b>%s</b></td><td><code>%s</code></td><td>%s</td></tr>'%(e(c['title']),e(c['status']),e(c['message'])) for c in report['categories'])
    arts=''.join('<tr><td>%s</td><td>%s<br><small>%s</small></td><td><code>%s</code><br>%s</td></tr>'%(e(a['role']),e(a['path']),e(a['sha256']),e(a['status']),e(a['message'])) for a in report['artifacts'])
    interfaces=[]
    for a in report['artifacts']:
        interfaces.extend(a.get('evaluation',{}).get('checks',[]))
    for c in report.get('planned_interface_checks',[]):
        interfaces.append(dict(id=c['id'],kind=c['kind'],status='NOT_RUN',expected=c['expected']))
    checks=''.join('<tr><td>%s<br><small>%s</small></td><td>%s</td><td>%s</td></tr>'%(e(c['id']),e(c['kind']),e(c['status']),e(json.dumps(c.get('measured',{}),ensure_ascii=False))) for c in interfaces)
    limits=''.join('<li>%s</li>'%e(v) for v in report.get('limitations',[]))
    label='PRÜFPLANVORSCHAU – KEIN NX-LAUF' if subject=={} else 'MODELLPRÜFDOSSIER – KEINE FREIGABE'
    return '''<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Prüfdossier | Entwicklung 08</title><style>
body{margin:0;background:#f2f4f7;color:#223244;font:15px/1.5 system-ui,sans-serif}main{max-width:1250px;margin:auto;padding:28px}
h1{font-size:32px;margin:6px 0}h2{font-size:22px;margin-top:32px}.kicker{font-size:12px;letter-spacing:.15em;color:#52667d;font-weight:700}
.notice{background:#fff2d5;border-left:5px solid #b27525;padding:16px;margin:20px 0}.identity{padding:18px;background:white;border:1px solid #d8dfe5;overflow-wrap:anywhere}
.wrap{overflow:auto;background:white;border:1px solid #d8dfe5}table{border-collapse:collapse;width:100%;font-size:13px}th{background:#20384f;color:white;text-align:left;padding:12px}td{padding:12px;vertical-align:top;border-bottom:1px solid #dce2e8;overflow-wrap:anywhere;max-width:600px}tr:nth-child(even){background:#f7f9fb}small{color:#52667d}code{font-size:11px;white-space:normal}.footer{color:#52667d;margin-top:24px}
@media print{main{padding:0}body{background:white}.wrap{overflow:visible}tr{break-inside:avoid}h2{break-after:avoid}th{background:#ddd;color:#000}}
</style><main><div class="kicker">SX3.5Z / NX-OPEN / ENTWICKLUNG 08</div><h1>Geometrisches Prüfdossier</h1>
<div class="notice"><b>'''+e(label)+'''</b><br>'''+e(report['status'])+'''<br>Numerische Modellprüfungen sind keine Passungs-, Sicherheits- oder Fertigungsfreigabe.</div>
<div class="identity"><b>Bezugsbaugruppe</b><br>'''+e(subject.get('root_path','Keine native Baugruppe in der Vorschau'))+'''<br><small>Modell-/Vorkommnis-Fingerabdruck: '''+e(subject.get('fingerprint','NOT_RUN'))+'''</small></div>
<h2>Prüfumfang und fehlende Nachweise</h2><div class="wrap"><table><tr><th>Prüfpunkt</th><th>Status</th><th>Bedeutung</th></tr>'''+rows+'''</table></div>
<h2>Schnittstellen: tatsächliche Messwerte oder offener Prüfplan</h2><div class="wrap"><table><tr><th>Prüfung</th><th>Status</th><th>Messwerte</th></tr>'''+checks+'''</table></div>
<h2>Gebundene Ergebnisdateien</h2><div class="wrap"><table><tr><th>Rolle</th><th>Datei / SHA256</th><th>Auswertung</th></tr>'''+arts+'''</table></div>
<h2>Grenzen</h2><ul>'''+limits+'''</ul><p class="footer">Dateihashes prüfen Identität, nicht Echtheit oder fachliche Richtigkeit eines Berichts. Fehlende Prüfungen werden nicht als bestanden gewertet.</p></main></html>'''


def export_dossier(directory,report):
    _validate(report);text=html_report(report);directory=Path(directory)
    if not directory.is_absolute():raise ValueError('Absolute new export directory required')
    directory.mkdir(parents=True,exist_ok=False)
    write_json_new(directory/'Pruefdossier_08.json',report)
    with (directory/'Pruefdossier_08.html').open('x',encoding='utf-8') as f:f.write(text)
    _csv(directory/'Pruefmatrix_08.csv',['id','title','status','message'],report['categories'])
    _csv(directory/'Nachweisdateien_08.csv',['role','path','sha256','status','message'],report['artifacts'])
    checks=[]
    for a in report['artifacts']:
        checks.extend(dict(c,source_artifact=a['path']) for c in a.get('evaluation',{}).get('checks',[]))
    _csv(directory/'Schnittstellen_Messwerte_08.csv',['id','kind','status','expected','measured','limits','message','source_artifact'],checks)
    files=[dict(path=p.name,sha256=sha256_file(p)) for p in sorted(directory.iterdir()) if p.is_file()]
    write_json_new(directory/'Export_SHA256_08.json',dict(export_complete=True,files=files,manufacturing_released=False))
    return files
