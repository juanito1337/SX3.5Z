# -*- coding: utf-8 -*-
"""Offline catalogue/envelope report. Does not create CAD or import NXOpen."""
import argparse
from datetime import datetime
from pathlib import Path
import uuid
from engineering.ballscrew09 import ROOT,read_json
from exports.ballscrew09 import export_report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,help='Optional alternative case JSON; reviewed catalogue remains locked.')
    parser.add_argument('--output',type=Path,help='New output directory; existing targets are never overwritten.')
    args=parser.parse_args();cases=None
    if args.config:
        d=read_json(args.config)
        if d.get('schema')!='CNC_BALLSCREW_STUDIES_09':parser.error('Unsupported case schema')
        cases=d['cases']
    target=args.output or ROOT/'reports'/'generated09'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    r=export_report(target,cases=cases)
    print('Katalog-/Axialbericht: '+str(target.absolute()))
    print(str(r['pair_count'])+' Studienpaare. KEIN NX-Lauf, KEINE Bestellung oder Maschinenfreigabe.')

if __name__=='__main__':main()
