# -*- coding: utf-8 -*-
"""Create a new, deliberately incomplete review form from a real NX layout report.
Run with ordinary Python3.10+; does NOT create CAD or certify machine kinematics.
Never overwrites an existing form. Copy the reviewed file to config/travel05.json.
"""
import argparse
from pathlib import Path
from validation.motion_input05 import prepare
from cnc_nx.runtime import write_json_new


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--layout',required=True,help='Absolute path to NX_Montageentwurf.json from journal10')
    parser.add_argument('--output',required=True,help='Absolute path to a NEW review JSON file')
    args=parser.parse_args(argv)
    src=Path(args.layout);dst=Path(args.output)
    if not src.is_absolute() or not dst.is_absolute():raise ValueError('Both paths must be absolute')
    if not src.is_file():raise FileNotFoundError(src)
    if not dst.parent.is_dir():raise FileNotFoundError(dst.parent)
    if dst.exists():raise FileExistsError(dst)
    cfg=prepare(src);write_json_new(dst,cfg)
    print('Neue, UNGEPRUEFTE Vorlage: '+str(dst))
    print('Richtungen, Referenzposition, Grenzen und moving_axes explizit pruefen; []=fest, null=unbekannt.')
    return str(dst)


if __name__=='__main__':main()
