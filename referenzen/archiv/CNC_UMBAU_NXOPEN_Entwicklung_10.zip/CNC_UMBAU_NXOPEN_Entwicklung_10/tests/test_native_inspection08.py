"""Fakes at NX boundary only. Actual numeric inspection, BOM and dossier logic run.
None of these tests proves NX runtime/API compatibility or CAD creation.
"""
import copy,importlib,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from construction.recipes03 import reference_carrier
from cnc_nx.runtime import ApiEvidence,sha256_file
from test_native_bom07 import FakePart,FakeComp
from test_interfaces08 import synthetic_measurements
from validation.geometry03 import transform_bounds

I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
FAKENX=NS(BasePart=NS(Units=NS(Millimeters=1)))


def position(t,R=I):
    return NS(X=t[0],Y=t[1],Z=t[2]),NS(**dict(zip(('Xx','Xy','Xz','Yx','Yy','Yz','Zx','Zy','Zz'),sum(R,[]))))


def fixture(folder):
    data=reference_carrier();mes={r['id']:r for r in synthetic_measurements()};parts={};raw={};bounds={}
    for r in data['parts']:
        p=FakePart(folder,r['id'],[True]);p.PartUnits=1;parts[r['id']]=p
    asm=FakePart(folder,'reference_root',[]);asm.PartUnits=1
    root=FakeComp(asm);root.GetPosition=lambda:position([0.,0.,0.]);asm.ComponentAssembly.RootComponent=root
    for i,c in enumerate(data['components']):
        p=parts[c['part_id']];comp=FakeComp(p);comp.Name=c['id'];comp.t=list(c['origin_mm'])
        comp.GetPosition=lambda comp=comp:position(comp.t)
        comp.FindOccurrence=lambda body,comp=comp:NS(Tag=comp.Tag)
        rec=next(r for r in data['parts'] if r['id']==c['part_id'])
        bounds[comp.Tag]=transform_bounds(rec['bounds_mm'],I,c['origin_mm'])
        body=p.Bodies[0]
        if not hasattr(body,'GetFaces'):
            faces=[]
            for f in mes[c['id']]['faces']:
                tag=len(raw)+100;obj=NS(Tag=tag,JournalIdentifier=f['journal_id']);faces.append(obj)
                raw[tag]=(f['uf_type_code'],f['point_raw'],f['direction_raw'],f['bounds_raw'],f['radius_part_units'],0.,1)
            body.GetFaces=lambda faces=faces:faces
        root.children.append(comp)
    built=dict(status='NATIVE_REFERENCE_ASSEMBLY_CREATED_IN_THIS_RUN',native_execution=True,assembly_file=asm.FullPath,
        parts=[dict(id=r['id'],path=parts[r['id']].FullPath,sha256=sha256_file(parts[r['id']].FullPath),source=r['source'],
          geometry_check=dict(actual_nx_volume_mm3=r['expected_volume_mm3'],actual_nx_bounds_mm=r['bounds_mm'],solid_body=True),
          parameter_check=dict(parameter='thickness',status='PASSED_IN_THIS_NX_RUN')) for r in data['parts']],components=data['components'])
    return NS(Parts=NS(Display=asm)),built,raw,bounds


class NativeInspection08Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.d=Path(self.tmp.name)
        self.session,self.built,self.raw,self.bounds=fixture(self.d)
    def m(self):
        try:return importlib.import_module('cnc_nx.inspection08')
        except ImportError:self.fail('Native inspection adapter missing')
    def capture(self):return self.m().capture_with_positions(self.session,FAKENX,ApiEvidence(),lambda _:None)
    def test_captures_positions_without_save(self):
        s=self.capture();self.assertTrue(s['positions_complete']);self.assertEqual(len(s['occurrences']),8)
        self.assertTrue(all(p['unit_mm'] for p in s['prototypes']))
    def test_raw_position_failure_stays_incomplete(self):
        self.session.Parts.Display.ComponentAssembly.RootComponent.children[0].GetPosition=lambda:(_ for _ in ()).throw(RuntimeError('no pose'))
        s=self.capture();self.assertFalse(s['positions_complete'])
    def test_units_not_assumed(self):
        self.session.Parts.Display.PartUnits=2;s=self.capture();self.assertFalse(s['prototypes'][0]['unit_mm'])
    def test_saved_bytes_unchanged(self):
        before={p.name:p.read_bytes() for p in self.d.glob('*.prt')};self.capture()
        self.assertEqual(before,{p.name:p.read_bytes() for p in self.d.glob('*.prt')})
    def measurements(self):
        with patch('cnc_nx.inspection08._face_method',return_value=lambda tag:self.raw[tag]),patch('cnc_nx.inspection08.exact_bounds',side_effect=lambda part,body,ev:self.bounds[body.Tag]):
            return self.m().read_reference_faces(self.session,FAKENX,self.built,ApiEvidence(),lambda _:None)
    def test_reads_real_boundary_fields_not_recipe_measures(self):
        m=self.m();rows=self.measurements();self.assertEqual(len(rows),7)
        self.assertTrue(all(r['prototype_sha256'] for r in rows));self.assertEqual(rows[0]['id'],'motor')
        self.assertEqual(rows[0]['faces'][0]['journal_id'],'pilot')
    def test_changed_measured_radius_reaches_evaluator(self):
        m=self.m();key=next(k for k,v in self.raw.items() if v[0]==16 and abs(v[4]-19.05)<1e-6)
        v=list(self.raw[key]);v[4]=19.1;self.raw[key]=tuple(v)
        from validation.interfaces08 import evaluate_reference
        self.assertFalse(evaluate_reference(self.measurements())['all_within_limits'])
    def test_malformed_api_result_fails(self):
        m=self.m();key=next(iter(self.raw));self.raw[key]=(16,)
        with self.assertRaises((RuntimeError,ValueError)):self.measurements()
    def test_extra_component_not_silently_dropped(self):
        m=self.m();root=self.session.Parts.Display.ComponentAssembly.RootComponent;root.children.append(root.children[0])
        with self.assertRaises((ValueError,RuntimeError)):self.measurements()
    def test_changed_source_hash_stops_before_faces(self):
        m=self.m();Path(self.built['parts'][0]['path']).write_bytes(b'changed')
        with self.assertRaises((ValueError,RuntimeError)):self.measurements()
    def test_modified_part_not_saved_or_accepted(self):
        m=self.m();self.session.Parts.Display.ComponentAssembly.RootComponent.children[0].Prototype.IsModified=True
        with self.assertRaises((ValueError,RuntimeError)):self.measurements()
    def test_actual_occurrence_bounds_checked(self):
        m=self.m();self.bounds[next(iter(self.bounds))][0]+=1
        with self.assertRaises((ValueError,RuntimeError)):self.measurements()
    def test_mismatched_root_not_guessed(self):
        m=self.m();self.built['assembly_file']=str(self.d/'unknown.prt')
        with self.assertRaises((ValueError,RuntimeError)):self.measurements()
    def test_unknown_rotation_rejected_in_reference_path(self):
        m=self.m();self.session.Parts.Display.ComponentAssembly.RootComponent.children[0].GetPosition=lambda:position([0,0,12],[[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]])
        with self.assertRaises((ValueError,RuntimeError)):self.measurements()


class NativeDossierPipeline08Tests(unittest.TestCase):
    def m(self):
        try:return importlib.import_module('cnc_nx.dossier08')
        except ImportError:self.fail('Native dossier pipeline missing')
    def test_read_only_dossier_with_no_artifacts_has_missing_tests(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,built,raw,bb=fixture(d);out=d/'output';out.mkdir()
            r=self.m().run_for_current(session,FAKENX,out,lambda _:None,ApiEvidence(),[],dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=[]))
            self.assertTrue(r['native_read_in_this_run']);self.assertFalse(r['manufacturing_released'])
            self.assertTrue((out/'NX_Pruefdossier_08.json').exists());self.assertEqual(r['status'],'INCOMPLETE_NO_RELEASE')
    def test_reference_pipeline_geometry_and_bom_are_bound(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,built,raw,bb=fixture(d);out=d/'output';out.mkdir()
            def fakebuild(*args):
                (out/'NX_Motortraeger_Referenz.json').write_text(json.dumps(built));return built
            self.m()
            with patch('cnc_nx.build03.build_reference',side_effect=fakebuild),patch('cnc_nx.inspection08._face_method',return_value=lambda t:raw[t]),patch('cnc_nx.inspection08.exact_bounds',side_effect=lambda p,b,e:bb[b.Tag]):
                r=self.m().run_reference(session,FAKENX,out,lambda _:None,ApiEvidence(),{})
            self.assertEqual(r['status'],'INCOMPLETE_NO_RELEASE');self.assertFalse(r['final_cnc_assembly_accepted'])
            self.assertTrue(any(x['status']=='LIMITED_REFERENCE_CHECKS_RECORDED' for x in r['artifacts']))
    def test_dirty_source_no_completed_report(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,built,raw,bb=fixture(d);session.Parts.Display.IsModified=True;out=d/'output';out.mkdir()
            with self.assertRaises((ValueError,RuntimeError)):
                self.m().run_for_current(session,FAKENX,out,lambda _:None,ApiEvidence(),[],dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=[]))
            self.assertFalse((out/'NX_Pruefdossier_08.json').exists())
    def test_journal_routing(self):
        root=Path(__file__).resolve().parents[1]
        for f,mode in [('NX_20_Pruefdossier.py','dossier08'),('NX_21_Motortraeger_Prueflauf.py','reference_inspection08')]:
            self.assertTrue((root/f).is_file(),f);self.assertIn("'"+mode+"'",(root/f).read_text())
            self.assertIn("'"+mode+"'",(root/'main.py').read_text())
    def test_default_dossier_config_not_preapproved(self):
        p=Path(__file__).resolve().parents[1]/'config'/'dossier08.json';self.assertTrue(p.exists())
        self.assertEqual(json.loads(p.read_text())['artifacts'],[])
