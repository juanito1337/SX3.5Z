import unittest
from analysis import interfaces03
class Interface03Tests(unittest.TestCase):
 def api(self,n):
  f=getattr(interfaces03,n,None);self.assertTrue(callable(f),'Missing '+n);return f
 def audit(self):
  return dict(schema='SX35Z_NX_AUDIT_1',prototypes=[dict(id='P',unit_mm=True,path='/example.prt',source_sha256_before='a'*64,bodies=[dict(is_solid=True,faces=[
   dict(journal_id='CYL',uf_data=dict(uf_type_code=16,point_raw=[3,4,10],direction_raw=[0,0,1],radius_part_units=5)),
   dict(journal_id='PLANE',uf_data=dict(uf_type_code=22,point_raw=[0,0,2],direction_raw=[0,0,1]))])])])
 def req(self):return dict(axis='X',prototype_id='P',cylinder_face='CYL',plane_face='PLANE',axis_sign=1,roll_hint=[1,0,0])
 def test_frame_derived_from_faces_not_assumed_origin(self):
  r=self.api('derive_frames')(self.audit(),[self.req()])[0];self.assertEqual(r['origin_mm'],[3.,4.,2.]);self.assertEqual(r['diameter_mm'],10.)
 def test_prototype_frame_not_machine_frame(self):
  r=self.api('derive_frames')(self.audit(),[self.req()])[0];self.assertEqual(r['coordinate_frame'],'PROTOTYPE_ABSOLUTE');self.assertFalse(r['physical_measurement_verified'])
 def test_inches_not_silently_mm(self):
  a=self.audit();a['prototypes'][0]['unit_mm']=False
  with self.assertRaises(ValueError):self.api('derive_frames')(a,[self.req()])
 def test_face_missing_rejected(self):
  r=self.req();r['cylinder_face']='missing'
  with self.assertRaises(ValueError):self.api('derive_frames')(self.audit(),[r])
 def test_plane_not_interpreted_as_bore(self):
  r=self.req();r['cylinder_face']='PLANE'
  with self.assertRaises(ValueError):self.api('derive_frames')(self.audit(),[r])
 def test_duplicate_axes_rejected(self):
  with self.assertRaises(ValueError):self.api('derive_frames')(self.audit(),[self.req(),self.req()])
 def test_sign_must_be_explicit(self):
  r=self.req();r['axis_sign']=0
  with self.assertRaises(ValueError):self.api('derive_frames')(self.audit(),[r])
 def test_empty_requests_no_false_success(self):
  with self.assertRaises(ValueError):self.api('derive_frames')(self.audit(),[])
if __name__=='__main__':unittest.main()
