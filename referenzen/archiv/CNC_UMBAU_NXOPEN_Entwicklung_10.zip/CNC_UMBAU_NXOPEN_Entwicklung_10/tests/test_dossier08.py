"""Report tests use explicit text .prt fixtures, not real CAD or native execution."""
import copy, importlib, json, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace as NS
from cnc_nx.runtime import ApiEvidence, sha256_file
from cnc_nx.bom07 import capture
from test_native_bom07 import FakePart,FakeComp
from test_interfaces08 import synthetic_measurements


def snapshot_fixture(folder):
    root=FakePart(folder,'root',[]);leaf=FakePart(folder,'leaf',[True])
    root.ComponentAssembly.RootComponent=FakeComp(root,[FakeComp(leaf),FakeComp(leaf)])
    snap=capture(NS(Parts=NS(Display=root)),ApiEvidence(),lambda _:None)
    snap['positions_complete']=True
    for p in snap['prototypes']:p['unit_mm']=True
    for n in snap['occurrences']:
        n['position_raw']=dict(origin_raw=[0.,0.,0.],matrix_raw=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]])
    return snap


class Dossier08Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.folder=Path(self.tmp.name)
        self.snap=snapshot_fixture(self.folder)
    def m(self):
        try:return importlib.import_module('validation.dossier08')
        except ImportError:self.fail('Missing model-bound dossier implementation')
    def subject(self):return self.m().subject_from_snapshot(self.snap)
    def artifact(self,role,data,name='evidence.json'):
        p=self.folder/name;p.write_text(json.dumps(data),encoding='utf-8')
        return dict(role=role,path=str(p),sha256=sha256_file(p))
    def geom(self):
        p=self.snap['prototypes'][1]
        return dict(status='NATIVE_REFERENCE_ASSEMBLY_CREATED_IN_THIS_RUN',native_execution=True,
          parts=[dict(id='leaf',path=p['path'],sha256=p['sha256_before'],
              geometry_check=dict(actual_nx_volume_mm3=100.,actual_nx_bounds_mm=[0,0,0,10,10,1],solid_body=True),
              parameter_check=dict(parameter='thickness',status='PASSED_IN_THIS_NX_RUN'))])
    def test_subject_fingerprint_repeatable(self):self.assertEqual(self.subject(),self.subject())
    def test_pose_change_changes_subject(self):
        old=self.subject()['fingerprint'];self.snap['occurrences'][1]['position_raw']['origin_raw'][0]=1
        self.assertNotEqual(self.subject()['fingerprint'],old)
    def test_unloaded_inventory_cannot_be_subject(self):
        self.snap['prototypes'][1]['fully_loaded']=False
        with self.assertRaises(ValueError):self.subject()
    def test_dirty_inventory_cannot_be_subject(self):
        self.snap['prototypes'][1]['modified_before']=True
        with self.assertRaises(ValueError):self.subject()
    def test_positions_missing_not_ignored(self):
        self.snap['positions_complete']=False
        with self.assertRaises(ValueError):self.subject()
    def test_pose_nonfinite_rejected(self):
        self.snap['occurrences'][1]['position_raw']['origin_raw'][0]=float('nan')
        with self.assertRaises(ValueError):self.subject()
    def test_nonmillimetre_source_rejected(self):
        self.snap['prototypes'][1]['unit_mm']=False
        with self.assertRaises(ValueError):self.subject()
    def test_offline_recipe_not_native_subject(self):
        self.snap['origin']='RECIPE_PREVIEW'
        with self.assertRaises(ValueError):self.subject()
    def test_missing_prototype_bytes_rejected(self):
        Path(self.snap['prototypes'][1]['path']).unlink()
        with self.assertRaises(ValueError):self.subject()
    def test_source_hash_changed_rejected(self):
        Path(self.snap['prototypes'][1]['path']).write_bytes(b'changed')
        with self.assertRaises(ValueError):self.subject()
    def test_empty_artifact_list_keeps_missing_checks(self):
        d=self.m().build_dossier(self.snap,[])
        self.assertEqual(d['status'],'INCOMPLETE_NO_RELEASE');self.assertFalse(d['manufacturing_released'])
        self.assertTrue(any(c['status']=='NOT_RUN' for c in d['categories']));self.assertEqual(d['artifacts'],[])
    def test_bound_native_geometry_remains_part_scope(self):
        d=self.m().build_dossier(self.snap,[self.artifact('native_geometry',self.geom())]);a=d['artifacts'][0]
        self.assertEqual(a['status'],'PART_CHECKS_RECORDED');self.assertFalse(d['final_cnc_assembly_accepted'])
    def test_geometry_parameter_failure_not_lost(self):
        g=self.geom();g['parts'][0]['parameter_check']['status']='FAILED'
        a=self.m().build_dossier(self.snap,[self.artifact('native_geometry',g)])
        self.assertEqual(a['status'],'BLOCKED');self.assertEqual(a['artifacts'][0]['status'],'FAILED')
    def test_negative_volume_not_pass(self):
        g=self.geom();g['parts'][0]['geometry_check']['actual_nx_volume_mm3']=-1
        d=self.m().build_dossier(self.snap,[self.artifact('native_geometry',g)]);self.assertEqual(d['status'],'BLOCKED')
    def test_bad_bounds_not_pass(self):
        g=self.geom();g['parts'][0]['geometry_check']['actual_nx_bounds_mm']=[0,0,0,-1,2,3]
        d=self.m().build_dossier(self.snap,[self.artifact('native_geometry',g)]);self.assertEqual(d['status'],'BLOCKED')
    def test_stale_part_report_rejected(self):
        g=self.geom();g['parts'][0]['sha256']='f'*64
        d=self.m().build_dossier(self.snap,[self.artifact('native_geometry',g)]);self.assertEqual(d['artifacts'][0]['status'],'STALE_OR_OTHER_MODEL')
    def test_native_execution_false_does_not_pass(self):
        g=self.geom();g['native_execution']=False
        d=self.m().build_dossier(self.snap,[self.artifact('native_geometry',g)]);self.assertEqual(d['artifacts'][0]['status'],'NOT_NATIVE_EVIDENCE')
    def test_changed_report_bytes_not_read_as_success(self):
        spec=self.artifact('native_geometry',self.geom());Path(spec['path']).write_text('{}')
        d=self.m().build_dossier(self.snap,[spec]);self.assertEqual(d['artifacts'][0]['status'],'UNREADABLE_OR_CHANGED')
    def test_duplicate_artifact_rejected(self):
        a=self.artifact('native_geometry',self.geom())
        with self.assertRaises(ValueError):self.m().build_dossier(self.snap,[a,a])
    def test_unknown_role_rejected(self):
        with self.assertRaises(ValueError):self.m().build_dossier(self.snap,[dict(role='guess')])
    def test_duplicate_json_keys_rejected(self):
        p=self.folder/'double.json';p.write_text('{"status":"A","status":"B"}')
        with self.assertRaises(ValueError):self.m().checked_json(dict(path=str(p),sha256=sha256_file(p)))
    def test_nan_json_rejected(self):
        p=self.folder/'nan.json';p.write_text('{"value":NaN}')
        with self.assertRaises(ValueError):self.m().checked_json(dict(path=str(p),sha256=sha256_file(p)))
    def test_diagnostic_collision_is_not_machine_proof(self):
        data=dict(status='NATIVE_COLLISION_SELFTEST_PASSED_IN_THIS_RUN',native_execution=True,probe_count=9)
        d=self.m().build_dossier(self.snap,[self.artifact('collision_selftest',data)])
        self.assertEqual(d['artifacts'][0]['status'],'DIAGNOSTIC_ONLY')
        self.assertEqual(next(c for c in d['categories'] if c['id']=='collision')['status'],'NOT_RUN')
    def test_unbound_old_travel_report_cannot_green_machine(self):
        data=dict(native_execution=True,all_requested_poses_completed=True,continuous_collision_free=True,status='CLEAR')
        d=self.m().build_dossier(self.snap,[self.artifact('travel',data)])
        self.assertEqual(d['artifacts'][0]['status'],'SCOPE_UNBOUND_LEGACY')
    def test_preview_always_not_run(self):
        d=self.m().preview();self.assertFalse(d['native_read_in_this_run'])
        self.assertTrue(all(c['status']=='NOT_RUN' for c in d['categories']))
        self.assertEqual(d['subject'],None)
    def test_bom_counts_must_match_current_inventory(self):
        from analysis.bom07 import summarize
        r=summarize(self.snap);r['native_read_in_this_run']=True;r['rows'][0]['quantity']=99
        d=self.m().build_dossier(self.snap,[self.artifact('bom',r)])
        self.assertEqual(d['artifacts'][0]['status'],'FAILED')
    def test_matching_bom_is_count_only_not_release(self):
        from analysis.bom07 import summarize
        r=summarize(self.snap);r['native_read_in_this_run']=True
        d=self.m().build_dossier(self.snap,[self.artifact('bom',r)])
        self.assertEqual(d['artifacts'][0]['status'],'BOM_COUNTS_RECORDED_UNASSIGNED')
    def test_interfaces_recomputed_not_accept_all_pass_flag(self):
        m=importlib.import_module('validation.interfaces08');measures=synthetic_measurements();measures[0]['translation_mm'][0]=.1
        data=dict(schema='SX35Z_NATIVE_INTERFACES_8',native_execution=True,subject_fingerprint=self.subject()['fingerprint'],
                  contract_sha256=self.m().digest(m.reference_checks()),measurements=measures,
                  evaluation=dict(all_within_limits=True),scope='REFERENCE_CARRIER_ONLY')
        d=self.m().build_dossier(self.snap,[self.artifact('interfaces',data)])
        self.assertEqual(d['artifacts'][0]['status'],'FAILED')
    def test_interfaces_wrong_subject_stale(self):
        data=dict(schema='SX35Z_NATIVE_INTERFACES_8',native_execution=True,subject_fingerprint='f'*64)
        d=self.m().build_dossier(self.snap,[self.artifact('interfaces',data)])
        self.assertEqual(d['artifacts'][0]['status'],'STALE_OR_OTHER_MODEL')
    def test_step_other_root_not_current_export(self):
        data=dict(status='STEP_FILE_WRITTEN_REIMPORT_NOT_PERFORMED',native_execution=True,source='/elsewhere.prt',source_sha256='a'*64)
        d=self.m().build_dossier(self.snap,[self.artifact('step',data)])
        self.assertEqual(d['artifacts'][0]['status'],'STALE_OR_OTHER_MODEL')
    def test_false_success_string_is_unsupported(self):
        d=self.m().build_dossier(self.snap,[self.artifact('native_geometry',dict(status='PASS',native_execution=True))])
        self.assertEqual(d['artifacts'][0]['status'],'UNSUPPORTED_SCHEMA')
    def test_report_does_not_modify_input(self):
        s=copy.deepcopy(self.snap);self.m().build_dossier(self.snap,[]);self.assertEqual(self.snap,s)


class DossierExport08Tests(unittest.TestCase):
    def m(self):
        try:return importlib.import_module('exports.dossier08')
        except ImportError:self.fail('Dossier exporter missing')
    def report(self):return importlib.import_module('validation.dossier08').preview()
    def test_html_json_csv_export_without_fake_native_files(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'dossier';files=self.m().export_dossier(out,self.report())
            self.assertTrue((out/'Pruefdossier_08.html').exists());self.assertTrue((out/'Pruefdossier_08.json').exists())
            self.assertFalse(list(out.rglob('*.prt')));self.assertGreaterEqual(len(files),3)
    def test_existing_target_refused(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(FileExistsError):self.m().export_dossier(Path(td),self.report())
    def test_html_escaped_and_csv_formula_guard(self):
        with tempfile.TemporaryDirectory() as td:
            r=self.report();r['categories'][0]['message']='=<script>alert(1)</script>'
            out=Path(td)/'out';self.m().export_dossier(out,r)
            text=(out/'Pruefdossier_08.html').read_text();self.assertNotIn('<script>',text);self.assertIn('&lt;script&gt;',text)
            self.assertIn("'=<script>",(out/'Pruefmatrix_08.csv').read_text(encoding='utf-8-sig'))
    def test_no_release_allowed_by_exporter(self):
        with tempfile.TemporaryDirectory() as td:
            r=self.report();r['manufacturing_released']=True
            with self.assertRaises(ValueError):self.m().export_dossier(Path(td)/'out',r)
