"""Shipping and form-generation behavior; no NX or actual CAD files."""
import importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]

class Entrypoints05Tests(unittest.TestCase):
 def m(self):
  path=ROOT/'Projekt05_Pruefung_vorbereiten.py'
  self.assertTrue(path.is_file(),'input-preparation entry point missing')
  spec=importlib.util.spec_from_file_location('prepare05_tool',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
 def report(self,td):
  p=Path(td)/'NX_Montageentwurf.json'
  I=[[1,0,0],[0,1,0],[0,0,1]]
  p.write_text(json.dumps(dict(native_execution=True,status='NATIVE_REVIEWED_LAYOUT_CREATED_NOT_RELEASED',components=[dict(id=k,path=str(Path(td)/(k+'.prt')),sha256='1'*64,rotation=I,origin_mm=[0,0,0]) for k in ['A','B']])))
  return p
 def test_new_forms_are_not_auto_reviewed(self):
  with tempfile.TemporaryDirectory() as td:
   p=self.report(td);o=Path(td)/'review.json';self.m().main(['--layout',str(p),'--output',str(o)])
   c=json.loads(o.read_text());self.assertEqual(c['review']['status'],'NOT_REVIEWED')
   self.assertIsNone(c['axes']['X']['direction']);self.assertIsNone(c['components'][0]['moving_axes'])
 def test_no_overwrite_existing_review(self):
  with tempfile.TemporaryDirectory() as td:
   p=self.report(td);o=Path(td)/'review.json';o.write_text('my existing values')
   with self.assertRaises(FileExistsError):self.m().main(['--layout',str(p),'--output',str(o)])
   self.assertEqual(o.read_text(),'my existing values')
 def test_relative_output_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(ValueError):self.m().main(['--layout',str(self.report(td)),'--output','relative.json'])
 def test_bad_layout_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   p=self.report(td);p.write_text('{"native_execution":false}')
   with self.assertRaises(ValueError):self.m().main(['--layout',str(p),'--output',str(Path(td)/'out.json')])
 def test_journals_and_router_actions(self):
  for filename,action in [('NX_15_Kollisionstest.py','collision05'),('NX_16_Verfahrwegpruefung.py','travel05')]:
   self.assertTrue((ROOT/filename).is_file(),filename)
   self.assertIn("'"+action+"'",(ROOT/filename).read_text())
   self.assertIn("'"+action+"'",(ROOT/'main.py').read_text())
 def test_shipped_motion_config_fails_until_review(self):
  p=ROOT/'config'/'travel05.json';self.assertTrue(p.is_file())
  from validation.motion05 import validate
  with self.assertRaises(ValueError):validate(json.loads(p.read_text()))
if __name__=='__main__':unittest.main()
