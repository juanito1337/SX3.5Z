import hashlib,tempfile,unittest
from pathlib import Path
from cnc_nx import exchange03
class Exchange03Tests(unittest.TestCase):
 def api(self,n):
  f=getattr(exchange03,n,None);self.assertTrue(callable(f),'Missing '+n);return f
 def entry(self,p):return dict(id='MOTOR',path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),manufacturer='Example',part_number='TEST',source_url='https://example.invalid/source',expected_size_mm=None)
 def test_step_payload_and_checksum(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'motor.step';p.write_text("ISO-10303-21;\nHEADER;ENDSEC;DATA;ENDSEC;END-ISO-10303-21;")
   self.assertEqual(self.api('validate_imports')([self.entry(p)])[0]['id'],'MOTOR')
 def test_html_disguised_as_step_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'motor.step';p.write_text('<html>login</html>')
   with self.assertRaises(ValueError):self.api('validate_imports')([self.entry(p)])
 def test_empty_batch_no_success(self):
  with self.assertRaises(ValueError):self.api('validate_imports')([])
 def test_size_mismatch_detected(self):
  with self.assertRaises(ValueError):self.api('check_size')([0,0,0,10,20,30],[10,20,40],.05)
 def test_orientation_independent_size_check(self):
  self.assertEqual(self.api('check_size')([0,0,0,20,30,10],[10,20,30],.01),'NOMINAL_ENVELOPE_MATCH_ONLY')
 def test_missing_size_never_passed(self):
  self.assertEqual(self.api('check_size')([0,0,0,10,20,30],None,.01),'NOT_CHECKED_NO_SUPPLIER_ENVELOPE')
 def test_step_ending_required(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'motor.stp';p.write_text('ISO-10303-21;')
   with self.assertRaises(ValueError):self.api('validate_imports')([self.entry(p)])
if __name__=='__main__':unittest.main()
