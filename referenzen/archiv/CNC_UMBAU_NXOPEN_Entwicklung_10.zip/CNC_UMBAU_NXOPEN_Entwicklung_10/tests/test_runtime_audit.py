import importlib, json, os, pathlib, tempfile, unittest
from types import SimpleNamespace as NS

class RuntimeTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('cnc_nx.runtime')
        except ImportError:self.fail('runtime module missing: safe exclusive output not implemented')
    def test_repeated_runs_have_distinct_paths(self):
        r=self.module()
        with tempfile.TemporaryDirectory() as d:
            a=r.create_run_directory(d,'test');b=r.create_run_directory(d,'test')
            self.assertNotEqual(a,b);self.assertTrue(a.is_dir());self.assertTrue(b.is_dir())
    def test_json_never_overwrites_existing(self):
        r=self.module()
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'a.json';r.write_json_new(p,{'value':1})
            with self.assertRaises(FileExistsError):r.write_json_new(p,{'value':2})
            self.assertEqual(json.loads(p.read_text())['value'],1)
    def test_nonfinite_json_rejected(self):
        r=self.module()
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):r.write_json_new(pathlib.Path(d)/'a.json',{'x':float('nan')})
    def test_source_hash_detects_change(self):
        r=self.module()
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'a.prt';p.write_bytes(b'abc');before=r.sha256_file(p)
            p.write_bytes(b'abd');self.assertNotEqual(before,r.sha256_file(p))
    def test_output_parent_file_rejected(self):
        r=self.module()
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'a';p.write_text('do not overwrite')
            with self.assertRaises((FileExistsError,NotADirectoryError,OSError)):r.create_run_directory(p,'test')
            self.assertEqual(p.read_text(),'do not overwrite')
    def test_run_kind_cannot_escape(self):
        r=self.module()
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):r.create_run_directory(d,'../escape')

class AuditTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('cnc_nx.audit')
        except ImportError:self.fail('audit module missing: read-only traversal not implemented')
    def test_raw_matrix_not_assumed_machine_coordinate(self):
        a=self.module();p=NS(X=1.,Y=2.,Z=3.)
        m=NS(Xx=1.,Xy=0.,Xz=0.,Yx=0.,Yy=1.,Yz=0.,Zx=0.,Zy=0.,Zz=1.)
        value=a.encode_position((p,m))
        self.assertEqual(value['origin_raw'],[1.,2.,3.])
        self.assertEqual(value['frame_status'],'RAW_NX_NOT_YET_VALIDATED')
        self.assertNotIn('origin_machine',value)
    def test_incomplete_read_recorded_not_passed(self):
        a=self.module();reader=a.Reader(lambda x:None)
        def fail():raise RuntimeError('unloaded prototype')
        self.assertIsNone(reader.get('part.Bodies',fail))
        self.assertEqual(reader.issues[0]['status'],'NOT_READ')
    def test_collect_repeated_prototype_keeps_occurrences(self):
        a=self.module()
        class C:
            def __init__(self,name,children=()):self.Name=name;self.children=children
            def GetChildren(self):return self.children
        leaf=C('identical prototype');root=C('root',[leaf,leaf])
        rows=list(a.walk_tree(root))
        self.assertEqual(len(rows),3)
        self.assertEqual(len({r[0] for r in rows}),3)
    def test_cycle_raises_instead_of_hanging(self):
        a=self.module()
        class C:
            def GetChildren(self):return [self]
        with self.assertRaises(RuntimeError):list(a.walk_tree(C()))
    def test_face_result_in_prototype_frame(self):
        a=self.module();v=a.encode_face_data((16,[1,2,3],[0,0,1],[0,0,0,5,5,5],5,0,1))
        self.assertEqual(v['coordinate_frame'],'PROTOTYPE_ABSOLUTE')
        self.assertEqual(v['radius_part_units'],5)
        self.assertEqual(v['interface_status'],'CANDIDATE_NOT_IDENTIFIED')
    def test_face_malformed_rejected(self):
        a=self.module()
        with self.assertRaises(ValueError):a.encode_face_data((16,[1,2],[],[],5))


class InventoryIntegrationTests(unittest.TestCase):
    """Fakes validate Python data/control flow only, NEVER real NX binding behavior."""
    def scenario(self,missing_faces=False,unloaded=False):
        import sys,types
        from unittest.mock import patch
        from cnc_nx import audit
        from cnc_nx.runtime import ApiEvidence
        temporary=tempfile.TemporaryDirectory();d=pathlib.Path(temporary.name)
        file=d/'original.prt';file.write_bytes(b'original native bytes placeholder')
        matrix=NS(Xx=1.,Xy=0.,Xz=0.,Yx=0.,Yy=1.,Yz=0.,Zx=0.,Zy=0.,Zz=1.)
        point=NS(X=0.,Y=0.,Z=0.)
        face=NS(Tag=3,JournalIdentifier='FAKE_FACE_1',SolidFaceType='Cylindrical')
        body=NS(Tag=2,Name='fake body',IsSolidBody=True,JournalIdentifier='FAKE_BODY',GetFaces=lambda:[face])
        coord=NS(Name='WCS',JournalIdentifier='FAKE_WCS',Origin=point,Orientation=NS(Element=matrix))
        part=NS(Tag=1,Name='fake machine',FullPath=str(file),PartUnits='mm',IsModified=False,
                IsFullyLoaded=not unloaded,Bodies=[body],WCS=NS(CoordinateSystem=coord),CoordinateSystems=[coord],
                Features=[NS(Name='fake feature',FeatureType='CYLINDER',JournalIdentifier='FAKE_FEATURE')],
                Expressions=[NS(Name='d',RightHandSide='10',Equation='d=10')])
        component=NS(Tag=4,Name='root',DisplayName='root',IsSuppressed=False,ReferenceSet='Entire Part',
                     Prototype=part,GetChildren=lambda:[],GetPosition=lambda:(point,matrix))
        part.ComponentAssembly=NS(RootComponent=component)
        part.Save=lambda *a:self.fail('READ-ONLY AUDIT TRIED TO SAVE ORIGINAL')
        nx=types.ModuleType('NXOpen');uf=types.ModuleType('NXOpen.UF');nx.UF=uf
        nx.BasePart=NS(Units=NS(Millimeters='mm',Inches='inch'))
        modl=NS(AskBoundingBox=lambda tag:[-5,-5,0,5,5,20])
        if not missing_faces:modl.AskFaceData=lambda tag:(16,[0,0,0],[0,0,1],[-5,-5,0,5,5,20],5,0,1)
        uf.UFSession=NS(GetUFSession=lambda:NS(Modl=modl))
        with patch.dict(sys.modules,{'NXOpen':nx,'NXOpen.UF':uf}):
            result=audit.run(NS(Parts=NS(Display=part)),nx,d,lambda _:None,ApiEvidence(),{})
        data=json.loads((d/'NX_Bestandsaufnahme.json').read_text())
        original=file.read_bytes()
        temporary.cleanup();return result,data,original
    def test_inventory_round_trip_and_source_unchanged(self):
        result,data,original=self.scenario()
        self.assertEqual(result['status'],'INVENTORY_READ_NO_ENGINEERING_RELEASE')
        self.assertEqual(data['counts']['prototype_parts'],1)
        self.assertEqual(original,b'original native bytes placeholder')
        self.assertTrue(data['prototypes'][0]['source_bytes_unchanged'])
        self.assertFalse(data['manufacturing_released'])
    def test_missing_face_api_partial(self):
        result,_,_=self.scenario(missing_faces=True)
        self.assertEqual(result['status'],'PARTIAL')
        self.assertTrue(result['issues'])
    def test_unloaded_prototype_partial(self):
        result,_,_=self.scenario(unloaded=True)
        self.assertEqual(result['status'],'PARTIAL')
        self.assertTrue(any('nicht voll geladen' in x['message'] for x in result['issues']))

if __name__=='__main__':unittest.main()
