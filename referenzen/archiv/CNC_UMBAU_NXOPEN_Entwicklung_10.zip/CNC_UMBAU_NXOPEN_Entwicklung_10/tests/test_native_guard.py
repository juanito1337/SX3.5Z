import importlib, pathlib, tempfile, unittest
from types import SimpleNamespace as NS

class NativeGuardTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('cnc_nx.native')
        except ImportError:self.fail('native guard missing')
    def test_unowned_part_cannot_be_saved(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d:
            guard=m.NewParts(NS(Parts=[]),None,pathlib.Path(d),lambda _:None,NS())
            original=NS(Tag=123,Save=lambda *a:self.fail('source Save called'))
            with self.assertRaises(RuntimeError):guard.save(original)
    def test_filename_escape_rejected(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d:
            guard=m.NewParts(NS(Parts=[]),None,pathlib.Path(d),lambda _:None,NS())
            with self.assertRaises(ValueError):guard.path('../source')
    def test_source_state_unsaved_rejected(self):
        m=self.module()
        with self.assertRaises(RuntimeError):m.require_saved_source(NS(FullPath='',IsModified=False))
    def test_source_state_modified_rejected(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'source.prt';p.write_bytes(b'original')
            with self.assertRaises(RuntimeError):m.require_saved_source(NS(FullPath=str(p),IsModified=True))
    def test_source_state_unchanged_returns_hash(self):
        m=self.module()
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'source.prt';p.write_bytes(b'original')
            state=m.require_saved_source(NS(FullPath=str(p),IsModified=False))
            self.assertEqual(len(state['sha256']),64)
            self.assertEqual(p.read_bytes(),b'original')

if __name__=='__main__':unittest.main()
