"""Offline full-run orchestration with simulated NX boundaries. Not a CAD test."""
import importlib,json,tempfile,unittest
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch
from test_travel05 import example
from cnc_nx.runtime import ApiEvidence,sha256_file
from validation.motion05 import translation,shift_bounds

class Pipeline05Tests(unittest.TestCase):
 def fixture(self,td):
  cfg=example();cfg['axes']['X']['samples']=3;cfg['input_layout']={'path':'fixture.json','sha256':'1'*64}
  for c in cfg['components']:
   path=Path(td)/(c['id']+'.prt');path.write_bytes(b'FAKE_TEST_FILE_NOT_NX');c['path']=str(path);c['sha256']=sha256_file(path)
  return cfg
 def invoke(self,td,fail_query=False,fail_undo=False):
  m=importlib.import_module('cnc_nx.travel05');cfg=self.fixture(td);out=Path(td)/'out';out.mkdir();events=[]
  holder={}
  class Owner:
   def __init__(self,*args):self.records={}
   def create(self,stem):
    p=N(Tag=5,ComponentAssembly=N(RootComponent=N(GetChildren=lambda:holder['children'])))
    holder.update(part=p,children=[]);self.records[5]={'part':p};return p
   def save(self,p):
    events.append('save_owned');path=out/'dummy.prt';path.write_bytes(b'FAKE_TEST_FILE_NOT_NX');return str(path)
  def undo(*a):
   if fail_undo:raise RuntimeError('simulated undo failure')
   holder['children'].clear()
  s=N(SetUndoMark=lambda *a:1,UndoToMark=undo,DeleteUndoMark=lambda *a:None)
  nx=N(Session=N(MarkVisibility=N(Invisible=0)))
  proto=N(IsModified=False,Bodies=[N(IsSolidBody=True)])
  def place(c,pose,*a):
   events.append(('pose',dict(pose)));holder['children'].append('inspection-only')
   rows=[];handles={}
   for i,comp in enumerate(c['components']):
    bb=[0,0,0,1,1,1] if i==0 else [10,0,0,11,1,1]
    rows.append(dict(component=comp['id'],body_index=0,bounds_mm=shift_bounds(bb,translation(c,comp,pose))))
    handles[(comp['id'],0)]=N(Tag=i+100)
   return rows,handles
  def query(*a):
   if fail_query:raise RuntimeError('simulated kernel failure')
   return 'INTERSECT'
  with ExitStack() as stack:
   for name,value in [('load_config',cfg),('load_reviewed',cfg),('open_source',proto),('calibrate_backend',(N(check=query),'ROWS',{'simulation':True}))]:
    stack.enter_context(patch.object(m,name,return_value=value))
   stack.enter_context(patch.object(m,'NewParts',Owner));stack.enter_context(patch.object(m,'place_pose',side_effect=place))
   try:result=m.run(s,nx,out,lambda text:None,ApiEvidence(),{})
   except Exception as exc:return None,exc,out,events,holder
  return result,None,out,events,holder
 def test_whole_orchestration_preserves_collision_status(self):
  with tempfile.TemporaryDirectory() as td:
   r,error,out,e,h=self.invoke(td)
   self.assertIsNone(error);self.assertEqual(r['status'],'ISSUES_FOUND');self.assertFalse(r['continuous_collision_free'])
   self.assertEqual(r['pose_count'],3);self.assertFalse(r['manufacturing_released']);self.assertEqual(h['children'],[])
   self.assertTrue((out/'NX_Verfahrwegpruefung_05.json').is_file())
 def test_failed_query_no_final_success_and_rollback(self):
  with tempfile.TemporaryDirectory() as td:
   r,error,out,e,h=self.invoke(td,fail_query=True)
   self.assertIsInstance(error,RuntimeError);self.assertFalse((out/'NX_Verfahrwegpruefung_05.json').exists())
   self.assertEqual(h['children'],[]);self.assertNotIn('save_owned',e)
   progress=json.loads((out/'NX_Verfahrweg_Fortschritt_05.json').read_text());self.assertEqual(progress['completed_pose_count'],1)
   self.assertFalse(progress['all_requested_poses_completed'])
 def test_undo_failure_no_final_success(self):
  with tempfile.TemporaryDirectory() as td:
   r,error,out,e,h=self.invoke(td,fail_undo=True)
   self.assertIsInstance(error,RuntimeError);self.assertFalse((out/'NX_Verfahrwegpruefung_05.json').exists())
   self.assertNotIn('save_owned',e);self.assertTrue((out/'Quellschutz_05.json').is_file())
if __name__=='__main__':unittest.main()
