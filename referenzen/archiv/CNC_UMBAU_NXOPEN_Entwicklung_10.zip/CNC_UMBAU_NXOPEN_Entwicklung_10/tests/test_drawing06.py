"""Real specification/projection tests, independent of NX or a CAD kernel."""
import copy, importlib, importlib.util, math, unittest
from construction.library04 import reference_library

class Drawing06Tests(unittest.TestCase):
 def module(self):
  self.assertIsNotNone(importlib.util.find_spec('exports.drawing06'),'drawing specification module not implemented')
  return importlib.import_module('exports.drawing06')
 def recipe(self,name='D04_LAGERAUFNAHME'):
  return next(x for x in reference_library()['parts'] if x['id']==name)
 def test_all_four_recipes_keep_identity(self):
  m=self.module();rs=reference_library()['parts'];ss=[m.drawing_spec(r) for r in rs]
  self.assertEqual([s['part_id'] for s in ss],[r['id'] for r in rs])
  self.assertEqual([len(s['holes']) for s in ss],[9,5,5,2])
 def test_no_automatic_manufacturing_release(self):
  s=self.module().drawing_spec(self.recipe());self.assertFalse(s['manufacturing_released']);self.assertFalse(s['native_execution'])
  self.assertIn('Passungen',s['open_items']);self.assertIn('Werkstoffsorte',s['open_items']);self.assertIsNone(s['tolerances'])
 def test_bearing_depth_chain_front_at_zero(self):
  h=self.module().drawing_spec(self.recipe())['holes'][0]
  self.assertEqual(h['axial_profile'],[{'z0':0.,'z1':16.,'diameter':32.},{'z0':16.,'z1':21.,'diameter':22.},{'z0':21.,'z1':24.,'diameter':26.}])
  self.assertEqual(h['remaining_shoulder_mm'],5.)
 def test_front_rear_are_not_same_projection(self):
  m=self.module();self.assertEqual(m.project([12,7,4],'rear'),[12.,7.]);self.assertEqual(m.project([12,7,4],'front'),[-12.,7.]);self.assertEqual(m.project([12,7,4],'side'),[4.,7.])
 def test_invalid_projection_rejected(self):
  with self.assertRaises(ValueError):self.module().project([0,0,0],'guess')
 def test_nonfinite_point_rejected(self):
  with self.assertRaises(ValueError):self.module().project([math.nan,0,0],'rear')
 def test_source_snapshot_independent(self):
  r=self.recipe();s=self.module().drawing_spec(r);r['parameters']['width']=99
  self.assertEqual(s['parameters']['width'],80.)
 def test_hash_changes_on_geometry(self):
  m=self.module();r=self.recipe();a=m.drawing_spec(r);r['parameters']['thickness']+=1;b=m.drawing_spec(r)
  self.assertNotEqual(a['recipe_sha256'],b['recipe_sha256'])
 def test_source_change_changes_hash(self):
  m=self.module();r=self.recipe();a=m.drawing_spec(r);r['source']+=' modified';b=m.drawing_spec(r);self.assertNotEqual(a['recipe_sha256'],b['recipe_sha256'])
 def test_nominal_spec_is_json_serializable(self):
  import json
  s=self.module().drawing_spec(self.recipe());self.assertEqual(s,json.loads(json.dumps(s,allow_nan=False)))
 def test_bore_coordinates_also_from_edges(self):
  h=self.module().drawing_spec(self.recipe())['holes'][1]
  self.assertEqual([h['edge_x'],h['edge_y']],[12.,12.])
 def test_section_uses_full_step_profile(self):
  m=self.module();s=m.drawing_spec(self.recipe());bands=m.section_bands(s,0.)
  area=sum((b['z1']-b['z0'])*sum(hi-lo for lo,hi in b['material_x']) for b in bands)
  self.assertAlmostEqual(area,1220.)
 def test_off_axis_section_uses_chord_not_diameter(self):
  m=self.module();s=m.drawing_spec(self.recipe());bands=m.section_bands(s,1.)
  self.assertAlmostEqual(bands[0]['void_x'][0][1],math.sqrt(16**2-1))
 def test_section_outside_body_rejected(self):
  m=self.module();s=m.drawing_spec(self.recipe())
  with self.assertRaises(ValueError):m.section_bands(s,100.)
 def test_plain_bore_profile(self):
  s=self.module().drawing_spec(self.recipe('D04_LAGERDECKEL'));self.assertEqual(s['holes'][0]['axial_profile'],[{'z0':0.,'z1':6.,'diameter':26.}])
 def test_notes_explicitly_name_non_association(self):
  m=self.module();notes='\n'.join(m.note_lines(m.drawing_spec(self.recipe())))
  self.assertIn('NICHT ZUR FERTIGUNG',notes);self.assertIn('Snapshot',notes);self.assertIn('z=0',notes);self.assertIn('z=t',notes)
 def test_unsupported_recipe_rejected(self):
  r=self.recipe();r['kind']='other'
  with self.assertRaises(ValueError):self.module().drawing_spec(r)
 def test_corrupted_step_rejected(self):
  r=self.recipe();r['parameters']['hole_seat_front_depth']=22.
  with self.assertRaises(ValueError):self.module().drawing_spec(r)

if __name__=='__main__':unittest.main()

class SectionOutline06Tests(unittest.TestCase):
 def test_no_false_horizontal_interfaces_in_material(self):
  from exports import drawing06 as m
  self.assertTrue(hasattr(m,'section_outline'),'section boundary extractor missing')
  r=next(x for x in reference_library()['parts'] if x['id']=='D04_LAGERAUFNAHME')
  lines=m.section_outline(m.drawing_spec(r),0.)
  self.assertFalse(any(a[1]==b[1]==6.4 for a,b in lines))
  self.assertIn([[-16.,16.],[-11.,16.]],lines)
  self.assertNotIn([[-40.,16.],[-11.,16.]],lines)

class DrawingLayout06Tests(unittest.TestCase):
 def test_oversized_recipe_is_rejected_before_rendering(self):
  from exports.drawing06 import drawing_spec
  r=next(x for x in reference_library()['parts'] if x['id']=='D04_MUTTERTRAEGER')
  r['parameters']['width']=300
  with self.assertRaisesRegex(ValueError,'layout'):drawing_spec(r)

class DrawingReview06Tests(unittest.TestCase):
 def test_plain_through_bore_has_no_physical_shoulder(self):
  from exports.drawing06 import drawing_spec
  s=drawing_spec(next(x for x in reference_library()['parts'] if x['id']=='D04_LAGERDECKEL'))
  self.assertIsNone(s['holes'][0]['remaining_shoulder_mm'])
  self.assertEqual(s['holes'][0]['axial_through_section_mm'],6.)
 def test_fixed_layout_rejects_more_than_nine_bore_rows(self):
  from construction.housing04 import make_recipe
  from exports.drawing06 import drawing_spec
  r=make_recipe(dict(id='TEST_DENSE',width=80,height=60,thickness=6,minimum_wall=1,
          source='TEST INPUT ONLY',holes=[dict(id='h'+str(i),x=-30+i*6,y=0,through_d=2) for i in range(10)]))
  with self.assertRaisesRegex(ValueError,'layout'):drawing_spec(r)
