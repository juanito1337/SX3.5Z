"""Offline report tests: numerical/source information, never native NX evidence."""
import copy
import csv
import importlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from engineering.ballscrew09 import load_cases,load_registry,ROOT


def module():return importlib.import_module('exports.ballscrew09')

class Report09Tests(unittest.TestCase):
    def test_default_report_has_six_envelopes_three_pairs_not_native(self):
        r=module().report_data()
        self.assertEqual(r['part_count'],6);self.assertEqual(r['pair_count'],3)
        self.assertFalse(r['native_execution']);self.assertFalse(r['original_cad_obtained'])
        self.assertFalse(r['order_released']);self.assertFalse(r['machine_fit_verified'])
    def test_axial_intervals_are_mathematical_only(self):
        r=module().report_data()
        self.assertEqual([c['span_mm'] for c in r['axial_rows']],[282.,282.,182.])
        self.assertEqual([c['center_min_mm'] for c in r['axial_rows']],[35.,35.,35.])
        self.assertEqual([c['center_max_mm'] for c in r['axial_rows']],[317.,317.,217.])
        self.assertTrue(all(not c['machine_travel_verified'] for c in r['axial_rows']))
    def test_native_run_evidence_cannot_be_inferred_from_expected_samples(self):
        r=module().report_data()
        self.assertEqual(len(r['axial_samples']),9)
        self.assertTrue(all(x['native_measured'] is False for x in r['axial_samples']))
    def test_unknown_requested_stroke_stays_unknown(self):
        r=module().report_data()
        self.assertTrue(all(c['requested_stroke_fits_axially'] is None for c in r['axial_rows']))
    def test_oversized_requested_stroke_reports_shortfall_no_false_success(self):
        c=load_cases();c[0]['requested_stroke_mm']=300
        r=module().report_data(cases=c)
        self.assertFalse(r['axial_rows'][0]['requested_stroke_fits_axially'])
        self.assertEqual(r['axial_rows'][0]['missing_length_mm'],18)
    def test_longer_catalogue_blank_changes_interval_without_inventing_ends(self):
        c=load_cases();c[0]['stock_length_mm']=852;c[0]['nut_center_mm']=426
        r=module().report_data(cases=c)
        self.assertEqual(r['axial_rows'][0]['span_mm'],782)
        self.assertEqual(r['axial_rows'][0]['end_condition'],'UNMACHINED')
    def test_source_table_retains_codes_and_visual_bore_disclaimer(self):
        r=module().report_data();n=[p for p in r['catalogue_rows'] if p['role']=='nut']
        self.assertEqual([p['article_number'] for p in n],['213514','213505','213420 0005'])
        self.assertTrue(all(p['visual_bore_status']=='DISPLAY_ONLY_NOT_MANUFACTURER_DIMENSION' for p in n))
    def test_changed_registry_cannot_enter_report_as_verified(self):
        reg=load_registry();reg['nuts']['213514']['length_mm']=52
        with self.assertRaises(ValueError):module().report_data(registry=reg)
    def test_export_creates_readable_csv_json_html_no_prt(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'new';module().export_report(p)
            j=json.loads((p/'Kugelgewindebericht_09.json').read_text())
            self.assertFalse(j['native_execution'])
            with (p/'Katalogzuordnung_09.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f,delimiter=';'))
            self.assertEqual(len(rows),6)
            html=(p/'Kugelgewinde_09.html').read_text(encoding='utf8')
            for marker in ['KEIN NX-LAUF','213514','213505','213420 0005','282','182','Darstellungsbohrung','UNBEARBEITET']:
                self.assertIn(marker,html)
            self.assertFalse(list(p.rglob('*.prt')))
    def test_custom_reserves_are_reported_without_fixed_ten_mm_claim(self):
        c=load_cases();c[0]['reserve_start_mm']=17;c[0]['reserve_end_mm']=23
        r=module().report_data(cases=c);page=module().html_report(r)
        self.assertEqual(r['axial_rows'][0]['reserve_start_mm'],17)
        self.assertEqual(r['axial_rows'][0]['reserve_end_mm'],23)
        self.assertNotIn('An jedem Ende sind 10 mm',page)
        self.assertIn('Reserve links',page);self.assertIn('Reserve rechts',page)
    def test_existing_export_directory_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'protected';p.mkdir();(p/'keep.txt').write_text('original')
            with self.assertRaises(FileExistsError):module().export_report(p)
            self.assertEqual((p/'keep.txt').read_text(),'original')
    def test_invalid_catalogue_does_not_leave_partial_output(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad';c=load_cases();c[0]['screw_lead_mm']=5
            with self.assertRaises(ValueError):module().export_report(p,cases=c)
            self.assertFalse(p.exists())
    def test_cli_works_without_importing_nxopen(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'report'
            cmd=[sys.executable,str(ROOT/'Projekt09_Kugelgewindebericht.py'),'--output',str(out)]
            result=subprocess.run(cmd,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertTrue((out/'Kugelgewindebericht_09.json').exists())
    def test_cli_uses_supplied_case_configuration(self):
        with tempfile.TemporaryDirectory() as d:
            inp=Path(d)/'config.json';c=load_cases();c[0]['requested_stroke_mm']=500
            inp.write_text(json.dumps({'schema':'CNC_BALLSCREW_STUDIES_09','cases':c}))
            out=Path(d)/'report';cmd=[sys.executable,str(ROOT/'Projekt09_Kugelgewindebericht.py'),'--config',str(inp),'--output',str(out)]
            result=subprocess.run(cmd,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            j=json.loads((out/'Kugelgewindebericht_09.json').read_text())
            self.assertEqual(j['axial_rows'][0]['missing_length_mm'],218)

if __name__=='__main__':unittest.main()
