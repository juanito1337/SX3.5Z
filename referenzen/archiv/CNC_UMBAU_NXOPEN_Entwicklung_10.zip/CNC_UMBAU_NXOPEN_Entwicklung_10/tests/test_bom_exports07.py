import copy,csv,importlib,json,tempfile,unittest
from pathlib import Path
from analysis.bom07 import summarize
from analysis.bom_registry07 import apply_registry
from test_bom07 import snapshot

class ExportTests(unittest.TestCase):
    def m(self):
        try:return importlib.import_module('exports.bom07')
        except ImportError:self.fail('BOM exports/template/recipe preview are missing')
    def report(self):
        return apply_registry(summarize(snapshot()),dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=[]),verify_files=False)
    def test_csv_json_html_created(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'out';self.m().export_report(out,self.report())
            for name in ['Stueckliste_07.json','Gesamtstueckliste_07.csv','Vorkommnisse_07.csv','Stueckliste_07.html','Export_SHA256_07.json']:
                self.assertTrue((out/name).is_file(),name)
    def test_json_round_trip_preserves_quantity(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'out';self.m().export_report(p,self.report());r=json.loads((p/'Stueckliste_07.json').read_text())
            self.assertEqual(r['rows'][0]['quantity'],2);self.assertFalse(r['native_read_in_this_run'])
    def test_csv_quantity_numeric_and_utf8(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'out';r=self.report();r['rows'][0]['description']='Frästräger'
            self.m().export_report(p,r)
            with (p/'Gesamtstueckliste_07.csv').open(encoding='utf-8-sig') as f:row=list(csv.DictReader(f,delimiter=';'))[0]
            self.assertEqual(row['quantity'],'2');self.assertEqual(row['description'],'Frästräger')
    def test_html_escapes_untrusted_description(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'out';r=self.report();r['rows'][0]['description']='<script>attack()</script>'
            self.m().export_report(p,r);html=(p/'Stueckliste_07.html').read_text()
            self.assertNotIn('<script>',html);self.assertIn('&lt;script&gt;',html)
    def test_csv_formula_text_escaped(self):
        m=self.m()
        for text in ['=1+1','+cmd','-cmd','@cmd',' \t=1+1','\n=1']:
            with self.subTest(text=text):self.assertTrue(m.csv_value(text).startswith("'"))
        self.assertEqual(m.csv_value(2),2)
    def test_existing_output_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(FileExistsError):self.m().export_report(Path(td),self.report())
            self.assertEqual(list(Path(td).iterdir()),[])
    def test_relative_output_rejected(self):
        with self.assertRaises(ValueError):self.m().export_report(Path('relative'),self.report())
    def test_template_has_no_automatic_part_selection(self):
        t=self.m().assignment_template(self.report());self.assertEqual(t['entries'][0]['kind'],'UNASSIGNED')
        self.assertIsNone(t['entries'][0]['item_id']);self.assertEqual(t['entries'][0]['documents'],[])
    def test_template_uses_model_hash_and_path(self):
        r=self.report();t=self.m().assignment_template(r)
        self.assertEqual(t['entries'][0]['prototype_sha256'],r['rows'][0]['prototype_sha256'])
    def test_unbound_rows_not_filled_with_invented_path(self):
        r=self.report();r['rows'][0]['source_bound']=False;t=self.m().assignment_template(r)
        self.assertEqual(t['entries'],[]);self.assertTrue(t['unresolved_rows'])
    def test_recipe_preview_counts_4_types_7_occurrences(self):
        r=self.m().recipe_preview();self.assertEqual(r['counts']['distinct_part_rows'],4)
        self.assertEqual(r['counts']['active_leaf_occurrences'],7)
        sleeve=[row for row in r['rows'] if row['item_id']=='D03_SPACER'][0];self.assertEqual(sleeve['quantity'],4)
    def test_recipe_preview_does_not_forge_native_files(self):
        r=self.m().recipe_preview();self.assertFalse(r['native_read_in_this_run']);self.assertEqual(r['source_origin'],'RECIPE_PREVIEW')
        self.assertTrue(all(row['prototype_path'] is None for row in r['rows']))
        self.assertFalse(r['source_binding_complete'])
    def test_recipe_revision_conflict_stays_visible(self):
        r=self.m().recipe_preview();motor=[row for row in r['rows'] if row['kind']=='PURCHASE'][0]
        self.assertTrue(any('103' in b and '104' in b for b in motor['blockers']))
    def test_bad_total_rejected_before_file_creation(self):
        r=self.report();r['counts']['active_leaf_occurrences']=999
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'bad'
            with self.assertRaises(ValueError):self.m().export_report(p,r)
            self.assertFalse(p.exists())
    def test_bool_quantity_rejected(self):
        r=self.report();r['rows'][0]['quantity']=True
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):self.m().export_report(Path(td)/'bad',r)
    def test_empty_buy_list_is_not_claimed_complete(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'out';self.m().export_report(p,self.report())
            with (p/'Kaufteile_KEINE_BESTELLFREIGABE.csv').open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f,delimiter=';'))
            self.assertEqual(rows,[]);self.assertIn('UNASSIGNED',(p/'Stueckliste_07.html').read_text())
    def test_export_does_not_mutate_report(self):
        r=self.report();before=copy.deepcopy(r)
        with tempfile.TemporaryDirectory() as td:self.m().export_report(Path(td)/'out',r)
        self.assertEqual(r,before)
