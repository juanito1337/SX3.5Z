import copy,hashlib,json,tempfile,unittest
from pathlib import Path
from assembly.manifest03 import validate_manifest
class SourceCoverage03Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);p=self.root/'original.prt';p.write_bytes(b'synthetic-test-native-file');self.p=p
  self.h=hashlib.sha256(p.read_bytes()).hexdigest()
  self.audit=dict(schema='SX35Z_NX_AUDIT_1',native_execution=True,prototypes=[dict(id='P',path=str(p),source_sha256_before=self.h,unit_mm=True,is_fully_loaded=True,is_modified_before=False,bodies=[dict(is_solid=True)])],occurrences=[dict(path='0000/0001',prototype_id='P',suppressed=False,children_count=0)])
 def tearDown(self):self.tmp.cleanup()
 def cfg(self,audit=None):
  ap=self.root/'audit.json';ap.write_text(json.dumps(audit or self.audit));ah=hashlib.sha256(ap.read_bytes()).hexdigest()
  return dict(schema='SX35Z_ASSEMBLY_3',review=dict(status='MODEL_LAYOUT_REVIEWED',evidence='synthetic fixture'),groups=['G'],source_inventory=dict(path=str(ap),sha256=ah,decisions=[dict(occurrence_path='0000/0001',action='REUSE')]),components=[dict(id='ORIGINAL',kind='ORIGINAL',group='G',path=str(self.p),sha256=self.h,origin_mm=[0,0,0],rotation=[[1,0,0],[0,1,0],[0,0,1]],source='test',dimensions_status='MODEL_ONLY_REVIEWED',occurrence_path='0000/0001')])
 def test_complete_original_reuse(self):self.assertFalse(validate_manifest(self.cfg())['manufacturing_released'])
 def test_omitted_original_decision_rejected(self):
  c=self.cfg();c['source_inventory']['decisions']=[]
  with self.assertRaises(ValueError):validate_manifest(c)
 def test_unknown_original_solid_status_rejected(self):
  a=copy.deepcopy(self.audit);a['prototypes'][0]['bodies'][0]['is_solid']=None;c=self.cfg(a)
  # Remove original entry and decision as an accidental omission would do.
  c['source_inventory']['decisions']=[];c['components'][0]['kind']='GENERATED';c['components'][0]['dimensions_status']='DESIGN_NOMINAL'
  with self.assertRaises(ValueError):validate_manifest(c)
 def test_unknown_children_count_rejected(self):
  a=copy.deepcopy(self.audit);del a['occurrences'][0]['children_count']
  with self.assertRaises(ValueError):validate_manifest(self.cfg(a))
 def test_original_hash_matches_audit(self):
  c=self.cfg();self.p.write_bytes(b'new bytes');c['components'][0]['sha256']=hashlib.sha256(self.p.read_bytes()).hexdigest()
  with self.assertRaises(ValueError):validate_manifest(c)
 def test_mixed_geometry_subassembly_rejected(self):
  a=copy.deepcopy(self.audit);a['occurrences'][0]['children_count']=2
  with self.assertRaises(ValueError):validate_manifest(self.cfg(a))
 def test_sheet_only_original_is_not_silently_omitted(self):
  a=copy.deepcopy(self.audit);a['prototypes'][0]['bodies'][0]['is_solid']=False;c=self.cfg(a)
  c['source_inventory']['decisions']=[];c['components'][0]['kind']='GENERATED';c['components'][0]['dimensions_status']='DESIGN_NOMINAL'
  with self.assertRaises(ValueError):validate_manifest(c)
 def test_unloaded_original_rejected(self):
  a=copy.deepcopy(self.audit);a['prototypes'][0]['is_fully_loaded']=False
  with self.assertRaises(ValueError):validate_manifest(self.cfg(a))
if __name__=='__main__':unittest.main()
