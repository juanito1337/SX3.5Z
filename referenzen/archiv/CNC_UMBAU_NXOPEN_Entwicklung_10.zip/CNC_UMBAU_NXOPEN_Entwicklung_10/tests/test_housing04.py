import copy, importlib, math, unittest

class Housing04ContractTests(unittest.TestCase):
    def api(self):
        try: return importlib.import_module('construction.housing04')
        except ImportError: self.fail('Missing stepped-housing implementation')
    def sample(self):
        return {'id':'TEST04','width':80,'height':60,'thickness':24,'minimum_wall':1,
                'source':'Own test design; no supplier or machine fit',
                'holes':[{'id':'seat','x':0,'y':0,'through_d':22,
                          'front_d':32,'front_depth':16,'rear_d':26,'rear_depth':3},
                         {'id':'bolt','x':28,'y':18,'through_d':6.6,'front_d':11,'front_depth':6.4}]}
    def test_analytic_volume_and_bounds(self):
        m=self.api();r=m.make_recipe(self.sample());c=m.contract(r)
        expected=80*60*24-math.pi/4*(22**2*24+(32**2-22**2)*16+(26**2-22**2)*3+6.6**2*24+(11**2-6.6**2)*6.4)
        self.assertAlmostEqual(c['expected_volume_mm3'],expected)
        self.assertEqual(c['bounds_mm'],[-40,-30,0,40,30,24])
    def test_every_cut_has_exact_positive_removed_volume(self):
        m=self.api();r=m.make_recipe(self.sample());rows=m.operation_volumes(r)
        self.assertEqual(len(rows),len(r['ops']))
        for prev,row in zip(rows,rows[1:]):self.assertLess(row['volume_after_mm3'],prev['volume_after_mm3'])
        self.assertAlmostEqual(rows[-1]['volume_after_mm3'],m.contract(r)['expected_volume_mm3'])
    def test_parameter_change_depth_is_annulus_not_full_circle(self):
        m=self.api();r=m.make_recipe(self.sample());p=copy.deepcopy(r['parameters']);p['hole_seat_front_depth']+=.5
        self.assertAlmostEqual(m.contract(r,p)['expected_volume_mm3']-m.contract(r)['expected_volume_mm3'],-math.pi/4*(32**2-22**2)*.5)
    def test_thickness_probe_uses_through_area_not_total_volume_ratio(self):
        m=self.api();r=m.make_recipe(self.sample());p=copy.deepcopy(r['parameters']);p['thickness']+=1
        delta=m.contract(r,p)['expected_volume_mm3']-m.contract(r)['expected_volume_mm3']
        self.assertAlmostEqual(delta,80*60-math.pi/4*(22**2+6.6**2))
    def test_rear_cut_moves_with_thickness(self):
        m=self.api();r=m.make_recipe(self.sample());from cnc_nx.parts02 import arithmetic
        op=next(x for x in r['ops'] if x['name']=='seat_Rueckstufe');p=r['parameters']
        self.assertEqual(arithmetic(op['origin'][2],p),21)
        p['thickness']=25;self.assertEqual(arithmetic(op['origin'][2],p),22)
    def test_counterbore_not_smaller_than_through_hole(self):
        s=self.sample();s['holes'][0]['front_d']=20
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_front_and_rear_shoulders_cannot_overlap(self):
        s=self.sample();s['holes'][0]['rear_depth']=8
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_fastener_counterbore_must_not_break_seat(self):
        s=self.sample();s['holes'][1].update(x=18,y=0)
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_counterbore_edge_break_rejected(self):
        s=self.sample();s['holes'][1]['x']=38
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_bool_nan_and_negative_rejected(self):
        m=self.api()
        for v in [True,math.nan,math.inf,-1,0]:
            s=self.sample();s['thickness']=v
            with self.assertRaises(ValueError):m.make_recipe(s)
    def test_duplicate_hole_ids_rejected(self):
        s=self.sample();s['holes'][1]['id']='seat'
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_unpaired_counterbore_fields_rejected(self):
        s=self.sample();del s['holes'][0]['front_depth']
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_missing_source_rejected(self):
        s=self.sample();s['source']=''
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_no_hidden_manufacturing_release(self):
        r=self.api().make_recipe(self.sample());self.assertFalse(r['manufacturing_released']);self.assertFalse(r['machine_fit_verified'])
    def test_canonical_ops_cannot_silently_change(self):
        m=self.api();r=m.make_recipe(self.sample());r['ops'][1]['diameter']='1'
        with self.assertRaises(ValueError):m.contract(r)
    def test_unknown_dimension_parameter_rejected(self):
        m=self.api();r=m.make_recipe(self.sample());r['parameters']['typo_depth']=2
        with self.assertRaises(ValueError):m.contract(r)
    def test_geometry_from_current_parameters_not_stale_expected_value(self):
        m=self.api();r=m.make_recipe(self.sample());r['expected_volume_mm3']=1
        self.assertGreater(m.contract(r)['expected_volume_mm3'],1000)
    def test_no_holes_rejected(self):
        s=self.sample();s['holes']=[]
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_partial_source_metadata_cannot_claim_measured(self):
        s=self.sample();s['machine_fit_verified']=True
        with self.assertRaises(ValueError):self.api().make_recipe(s)
    def test_probe_plan_contains_depth_and_thickness(self):
        m=self.api();r=m.make_recipe(self.sample());probes=m.parameter_probes(r)
        self.assertEqual([x['parameter'] for x in probes],['thickness','hole_seat_front_depth'])
        self.assertTrue(all(x['changed_volume_mm3']>0 for x in probes))
if __name__=='__main__':unittest.main()
