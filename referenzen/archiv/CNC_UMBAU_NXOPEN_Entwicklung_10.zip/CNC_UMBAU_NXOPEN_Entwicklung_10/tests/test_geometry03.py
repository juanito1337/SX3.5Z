import unittest,math
from validation import geometry03
I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
class Geometry03Tests(unittest.TestCase):
 def api(self,n):
  f=getattr(geometry03,n,None);self.assertTrue(callable(f),'Missing '+n);return f
 def test_axis_frame_line_plane_intersection(self):
  f=self.api('axis_frame')([1,2,10],[0,0,-1],[0,0,3],[0,0,1],[1,0,0])
  self.assertEqual(f['origin_mm'],[1.,2.,3.]);self.assertEqual(f['rotation'],[[1.,0.,0.],[0.,-1.,0.],[0.,0.,-1.]])
 def test_parallel_line_and_plane_rejected(self):
  with self.assertRaises(ValueError):self.api('axis_frame')([0,0,0],[1,0,0],[0,0,0],[0,0,1],[0,1,0])
 def test_parallel_roll_rejected(self):
  with self.assertRaises(ValueError):self.api('axis_frame')([0,0,0],[0,0,1],[0,0,0],[0,0,1],[0,0,2])
 def test_transform_box_90_degree(self):
  r=self.api('transform_bounds')([4,5,6,5,7,9],[[0,-1,0],[1,0,0],[0,0,1]],[40,50,60])
  self.assertEqual(r,[33.,54.,66.,35.,55.,69.])
 def test_bounds_boolean_nan_rejected(self):
  for bad in (True,float('nan')):
   with self.assertRaises(ValueError):self.api('transform_bounds')([bad,0,0,2,2,2],I,[0,0,0])
 def test_overlap_not_called_collision(self):
  r=self.api('screen_pair')([0,0,0,10,10,10],[5,5,5,15,15,15],.5)
  self.assertEqual(r['status'],'POTENTIAL_CONTACT_OR_INTERFERENCE');self.assertFalse(r['exact_collision_checked'])
 def test_separated_box_distance_bound(self):
  r=self.api('screen_pair')([0,0,0,10,10,10],[12,0,0,15,10,10],1)
  self.assertEqual(r['status'],'AABB_SEPARATION_AT_LEAST_CLEARANCE');self.assertEqual(r['lower_bound_distance_mm'],2)
 def test_touching_not_clear(self):
  self.assertEqual(self.api('screen_pair')([0,0,0,1,1,1],[1,0,0,2,1,1],0)['status'],'POTENTIAL_CONTACT_OR_INTERFERENCE')
 def test_pose_sweep_includes_endpoints(self):
  out=self.api('sweep_bounds')([0,0,0,1,1,1],[1,0,0],0,10,3)
  self.assertEqual(out[0]['bounds_mm'],[0.,0.,0.,1.,1.,1.]);self.assertEqual(out[-1]['bounds_mm'],[10.,0.,0.,11.,1.,1.])
 def test_no_nan_direction(self):
  with self.assertRaises(ValueError):self.api('axis_frame')([0,0,0],[0,float('nan'),1],[0,0,0],[0,0,1],[1,0,0])
if __name__=='__main__':unittest.main()
