import math, unittest
from cnc_nx import core, gates

class TestDimensions(unittest.TestCase):
    def test_source_spacers_not_mixed(self):
        from cnc_nx.spacer_data import SPACERS
        dims={r['id']:(r['outer_d_mm'],r['inner_d_mm'],r['length_mm']) for r in SPACERS}
        self.assertEqual(dims['BF20_NEU_09_X'],(16,10,15))
        self.assertEqual(dims['BF20_ALT_09_X'],(13.4,10,11.3))
        self.assertEqual(dims['BF20_NEU_11_Y'],(16,10,22))
        self.assertEqual(dims['BF20_ALT_11_Y'],(13.4,10,15))
        self.assertEqual(dims['BF20_NEU_14_Z'],(20,10,11.5))
        self.assertEqual(dims['BF20_ALT_14_Z'],(20,17,11.3))
    def test_sleeve_volume(self):
        self.assertAlmostEqual(core.sleeve_volume(16,10,15),math.pi/4*(16**2-10**2)*15)
    def test_invalid_dimensions_rejected(self):
        for dims in [(0,10,15),(10,10,15),(8,10,15),(16,10,-1),(float('nan'),10,15),(16,10,float('inf')),(True,1,2)]:
            with self.subTest(dims=dims),self.assertRaises(ValueError):core.sleeve_volume(*dims)
    def test_ratio_definition(self):
        self.assertEqual(core.steps_per_mm(200,16,2,4),1600)
    def test_direction_normalization(self):
        self.assertEqual(core.unit([0,0,-2]),[0.0,0.0,-1.0])
    def test_zero_vector_rejected(self):
        with self.assertRaises(ValueError):core.unit([0,0,0])
    def test_matrix_identity(self):
        self.assertTrue(core.rotation_quality([[1,0,0],[0,1,0],[0,0,1]])['proper_rotation'])
    def test_mirror_rejected(self):
        self.assertFalse(core.rotation_quality([[-1,0,0],[0,1,0],[0,0,1]])['proper_rotation'])
    def test_bad_matrix_rejected(self):
        with self.assertRaises(ValueError):core.rotation_quality([[1,0,0],[0,1,0]])
    def test_empty_axis_not_approved(self):
        r=gates.axis_readiness('X',{})
        self.assertEqual(r['status'],'BLOCKED');self.assertTrue(r['missing'])
    def test_photo_axis_not_approved(self):
        data={'direction':{'value':[1,0,0],'status':'FOTO_ANNAHME'}}
        self.assertEqual(gates.axis_readiness('X',data)['status'],'BLOCKED')
    def test_no_final_release_from_all_fields(self):
        data={k:{'value':1,'status':'CONFIRMED','evidence':'test'} for k in gates.REQUIRED}
        r=gates.axis_readiness('X',data)
        self.assertFalse(r['manufacturing_released'])
    def test_z_requires_holding_evidence(self):
        self.assertIn('gravity_hold_concept',gates.axis_readiness('Z',{})['missing'])
    def test_invalid_axis(self):
        with self.assertRaises(ValueError):gates.axis_readiness('A',{})

if __name__=='__main__':unittest.main()
