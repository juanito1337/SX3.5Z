"""Contracts of the catalogue-based reference, not tests of NX solids."""
import copy
import importlib
import math
import unittest


def m():
    return importlib.import_module('engineering.ballscrew09')


class Catalogue09Tests(unittest.TestCase):
    def test_three_catalogue_nuts_have_exact_codes_and_external_nominals(self):
        reg=m().load_registry()
        expected={'213514':(16,4,28,50),'213505':(16,5,28,50),'213420 0005':(20,5,33,50)}
        self.assertEqual(set(reg['nuts']),set(expected))
        for code,values in expected.items():
            n=reg['nuts'][code]
            self.assertEqual(tuple(n[k] for k in ('screw_diameter_mm','lead_mm','outer_diameter_mm','length_mm')),values)
    def test_catalogue_not_claimed_original_cad_or_locally_observed_pdf(self):
        reg=m().load_registry()
        self.assertFalse(reg['evidence']['original_cad_obtained'])
        self.assertFalse(reg['evidence']['pdf_bytes_obtained'])
        self.assertFalse(reg['evidence']['drawing_visually_verified'])
    def test_all_default_cases_match_real_catalogue_combinations(self):
        reg=m().load_registry();cases=m().load_cases()
        self.assertEqual(len(cases),3)
        for case in cases:
            result=m().resolve_pair(case,reg)
            self.assertEqual(result['status'],'CATALOGUE_ENVELOPE_STUDY_ONLY')
            self.assertFalse(result['machine_fit_verified'])
            self.assertFalse(result['order_released'])
            self.assertIsNone(result['screw_order_code'])
    def test_nut_code_is_not_interchanged_for_equal_outer_geometry(self):
        case=m().load_cases()[0];case['screw_lead_mm']=5
        with self.assertRaisesRegex(ValueError,'pitch|lead|Steigung'):m().resolve_pair(case,m().load_registry())
    def test_wrong_screw_diameter_is_rejected(self):
        case=m().load_cases()[0];case['screw_diameter_mm']=20
        with self.assertRaises(ValueError):m().resolve_pair(case,m().load_registry())
    def test_unknown_nut_is_not_guessed(self):
        case=m().load_cases()[0];case['nut_article']='213505-SUPER'
        with self.assertRaises(ValueError):m().resolve_pair(case,m().load_registry())
    def test_source_dimensions_cannot_silently_change(self):
        reg=m().load_registry();reg['nuts']['213505']['outer_diameter_mm']=29
        with self.assertRaises(ValueError):m().validate_registry(reg)
    def test_no_blank_stock_length_between_catalogue_increments(self):
        case=m().load_cases()[0];case['stock_length_mm']=400
        with self.assertRaises(ValueError):m().resolve_pair(case,m().load_registry())
    def test_maximum_catalogue_stock_length(self):
        case=m().load_cases()[0];case['stock_length_mm']=3052;case['nut_center_mm']=1526
        self.assertEqual(m().resolve_pair(case,m().load_registry())['stock_length_mm'],3052)
    def test_beyond_catalogue_stock_requires_separate_specification(self):
        case=m().load_cases()[0];case['stock_length_mm']=3152
        with self.assertRaises(ValueError):m().resolve_pair(case,m().load_registry())
    def test_nut_outside_allowed_span_rejected(self):
        case=m().load_cases()[0];case['nut_center_mm']=30
        with self.assertRaises(ValueError):m().resolve_pair(case,m().load_registry())
    def test_never_mutates_source_case_or_registry(self):
        case=m().load_cases()[0];reg=m().load_registry();before=copy.deepcopy((case,reg))
        m().resolve_pair(case,reg)
        self.assertEqual((case,reg),before)
    def test_duplicate_case_ids_rejected(self):
        cases=m().load_cases();cases[1]['id']=cases[0]['id']
        with self.assertRaises(ValueError):m().validate_cases(cases,m().load_registry())
    def test_file_path_traversal_in_case_id_rejected(self):
        case=m().load_cases()[0];case['id']='../outside'
        with self.assertRaises(ValueError):m().resolve_pair(case,m().load_registry())
    def test_unknown_case_key_is_not_silently_ignored(self):
        case=m().load_cases()[0];case['stock_lenght_mm']=400
        with self.assertRaises(ValueError):m().resolve_pair(case,m().load_registry())


class AxialPlanning09Tests(unittest.TestCase):
    def test_raw_352_with_nut50_and_reserve10_each(self):
        w=m().axial_window(352,50,0,0,10,10,176)
        self.assertEqual(w['center_min_mm'],35)
        self.assertEqual(w['center_max_mm'],317)
        self.assertEqual(w['span_mm'],282)
        self.assertEqual(w['negative_from_reference_mm'],141)
        self.assertEqual(w['positive_from_reference_mm'],141)
        self.assertEqual(w['nut_start_mm'],151)
    def test_asymmetric_end_losses_and_reference_are_not_halved(self):
        w=m().axial_window(800,50,52,28,10,15,200)
        self.assertEqual(w['center_min_mm'],87)
        self.assertEqual(w['center_max_mm'],732)
        self.assertEqual(w['span_mm'],645)
        self.assertEqual(w['negative_from_reference_mm'],113)
    def test_length_requirement_roundtrip(self):
        length=m().minimum_length(500,50,52,28,10,15)
        self.assertEqual(length,655)
        self.assertEqual(m().axial_window(length,50,52,28,10,15)['span_mm'],500)
    def test_unconfirmed_end_losses_cannot_be_treated_as_zero(self):
        with self.assertRaises(ValueError):m().minimum_length(500,50,None,28,10,10)
    def test_zero_available_motion_is_not_positive_motion(self):
        w=m().axial_window(70,50,0,0,10,10)
        self.assertEqual(w['span_mm'],0)
    def test_too_short_shaft_is_rejected(self):
        with self.assertRaises(ValueError):m().axial_window(69,50,0,0,10,10)
    def test_required_stroke_larger_than_window_is_not_passed(self):
        w=m().axial_window(352,50,0,0,10,10,176,500)
        self.assertFalse(w['requested_stroke_fits_axially'])
        self.assertEqual(w['missing_length_mm'],218)
    def test_required_span_exact_boundary(self):
        w=m().axial_window(352,50,0,0,10,10,None,282)
        self.assertTrue(w['requested_stroke_fits_axially'])
    def test_no_requested_stroke_means_not_evaluated(self):
        w=m().axial_window(352,50,0,0,10,10)
        self.assertIsNone(w['requested_stroke_fits_axially'])
    def test_nonfinite_boolean_and_negative_dimensions(self):
        for bad in (float('nan'),float('inf'),True,-1,'352'):
            with self.subTest(bad=bad),self.assertRaises(ValueError):m().axial_window(bad,50,0,0,10,10)
    def test_negative_reserve_is_not_allowed(self):
        with self.assertRaises(ValueError):m().axial_window(352,50,0,0,-1,10)
    def test_nonfinite_center_rejected(self):
        with self.assertRaises(ValueError):m().axial_window(352,50,0,0,10,10,float('nan'))
    def test_invalid_requested_stroke_rejected(self):
        for bad in (True,-1,float('inf')):
            with self.subTest(bad=bad),self.assertRaises(ValueError):m().axial_window(352,50,0,0,10,10,None,bad)
    def test_pure_geometric_result_never_claims_machine_travel(self):
        w=m().axial_window(352,50,0,0,10,10)
        self.assertFalse(w['machine_travel_verified'])
        self.assertFalse(w['bearing_support_verified'])
    def test_five_mm_and_four_mm_leads_require_different_turn_counts(self):
        self.assertEqual(m().turns_for_distance(20,4),5)
        self.assertEqual(m().turns_for_distance(-20,5),-4)
    def test_zero_or_negative_lead_rejected(self):
        for lead in (0,-5):
            with self.assertRaises(ValueError):m().turns_for_distance(20,lead)

if __name__=='__main__':unittest.main()
