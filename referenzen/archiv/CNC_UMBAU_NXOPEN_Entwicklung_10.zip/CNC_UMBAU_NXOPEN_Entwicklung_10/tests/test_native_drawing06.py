"""Tests of adapter contracts, NOT native NX execution."""
import importlib,importlib.util,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from construction.library04 import reference_library
from exports.drawing06 import drawing_spec

class NativeDrawing06Tests(unittest.TestCase):
 def m(self):
  self.assertIsNotNone(importlib.util.find_spec('cnc_nx.drawings06'),'NX drafting adapter missing')
  return importlib.import_module('cnc_nx.drawings06')
 def test_expected_views_and_bounding_sizes(self):
  m=self.m();s=drawing_spec(reference_library()['parts'][1]);rows=m.view_plan(s)
  self.assertEqual([x['id'] for x in rows],['rear','front','side'])
  self.assertEqual([x['size_mm'] for x in rows],[[80.,60.],[80.,60.],[24.,60.]])
 def test_orientation_is_right_handed_and_opposite_for_faces(self):
  rows=self.m().view_plan(drawing_spec(reference_library()['parts'][1]))
  for v in rows:
   r=v['matrix'];cross=[r[0][1]*r[1][2]-r[0][2]*r[1][1],r[0][2]*r[1][0]-r[0][0]*r[1][2],r[0][0]*r[1][1]-r[0][1]*r[1][0]]
   self.assertEqual(cross,r[2])
  self.assertEqual(rows[0]['matrix'][2],[0,0,1]);self.assertEqual(rows[1]['matrix'][2],[0,0,-1])
 def test_bad_borders_rejected(self):
  with self.assertRaises(ValueError):self.m().validate_view_borders([5,0,3,20],[10,20],[10,10])
 def test_wrong_scale_rejected(self):
  with self.assertRaises(ValueError):self.m().validate_view_borders([0,0,20,40],[10,20],[10,20])
 def test_valid_view_extents(self):
  m=self.m();m.validate_view_borders([10,20,90,80],[80,60],[50,50])
 def test_wrong_centre_rejected(self):
  with self.assertRaises(ValueError):self.m().validate_view_borders([10,20,90,80],[80,60],[70,50])
 def test_declared_python_arity_required(self):
  def f(a,b):pass
  f.__doc__='Signature ``ImportView(a, b)``'
  with self.assertRaises(RuntimeError):self.m().require_declared(f,'UF.Draw.ImportView',4)
 def test_known_declared_arity_accepted(self):
  def f(a,b,c,d):pass
  f.__doc__='Signature ``ImportView(drawing, view, point, info)``'
  self.assertIs(self.m().require_declared(f,'UF.Draw.ImportView',4),f)
 def test_native_module_does_not_use_preview_as_fallback(self):
  m=self.m();src=Path(m.__file__).read_text()
  self.assertNotIn('write_preview_pdf(',src);self.assertNotIn('reportlab',src)
 def test_expression_snapshot_check(self):
  m=self.m();r=reference_library()['parts'][1];values={k:SimpleNamespace(Value=v) for k,v in r['parameters'].items()}
  m.check_expression_snapshot(values,r);values['thickness'].Value+=.01
  with self.assertRaises(RuntimeError):m.check_expression_snapshot(values,r)
 def test_unknown_config_part_rejected(self):
  with self.assertRaises(ValueError):self.m().select_specs({'schema':'SX35Z_DRAWING_JOB_06','part_ids':['imaginary'],'export_pdf':True})
 def test_duplicate_config_part_rejected(self):
  with self.assertRaises(ValueError):self.m().select_specs({'schema':'SX35Z_DRAWING_JOB_06','part_ids':['D04_LAGERDECKEL']*2,'export_pdf':True})
 def test_native_pdf_failure_not_success(self):
  m=self.m()
  with tempfile.TemporaryDirectory() as td:
   b=SimpleNamespace(Filename='',Append=True,SourceBuilder=SimpleNamespace(SetSheets=lambda _:None),Commit=lambda:None,Destroy=lambda:None)
   p=SimpleNamespace(PlotManager=SimpleNamespace(CreatePrintPdfbuilder=lambda:b))
   ev=SimpleNamespace(require=lambda n,f:f)
   with self.assertRaises(FileNotFoundError):m.export_native_pdf(p,object(),Path(td)/'new.pdf',ev)
 def test_no_overwrite_pdf(self):
  with tempfile.TemporaryDirectory() as td:
   f=Path(td)/'old.pdf';f.write_bytes(b'old')
   with self.assertRaises(FileExistsError):self.m().export_native_pdf(None,None,f,None)
   self.assertEqual(f.read_bytes(),b'old')
 def test_print_builder_disposed_after_commit_error(self):
  m=self.m();calls=[]
  def bad():raise RuntimeError('translator failed')
  b=SimpleNamespace(Filename='',Append=True,SourceBuilder=SimpleNamespace(SetSheets=lambda _:None),Commit=bad,Destroy=lambda:calls.append('destroy'))
  p=SimpleNamespace(PlotManager=SimpleNamespace(CreatePrintPdfbuilder=lambda:b));ev=SimpleNamespace(require=lambda n,f:f)
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(RuntimeError):m.export_native_pdf(p,object(),Path(td)/'new.pdf',ev)
  self.assertEqual(calls,['destroy'])
 def test_sheet_layout_requires_size_admission(self):
  s=drawing_spec(reference_library()['parts'][1]);s['width']=300
  with self.assertRaises(ValueError):self.m().view_plan(s)

if __name__=='__main__':unittest.main()
