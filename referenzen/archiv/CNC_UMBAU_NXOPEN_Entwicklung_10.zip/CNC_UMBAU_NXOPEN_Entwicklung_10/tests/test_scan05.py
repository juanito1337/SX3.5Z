import importlib,unittest
from test_motion05 import fixture
class Scan05Tests(unittest.TestCase):
 def m(self):
  try:return importlib.import_module('validation.scan05')
  except ImportError:self.fail('scan05 not implemented')
 def bodies(self):return [dict(component='TABLE',body_index=0,bounds_mm=[0,0,0,1,1,1]),dict(component='SADDLE',body_index=0,bounds_mm=[9,0,0,10,1,1])]
 def test_between_samples_not_certified(self):
  c=fixture();c['axes']={'X':dict(c['axes']['X'],samples=2)}
  c['components'][0]['moving_axes']=['X'];c['components'][1]['moving_axes']=[]
  p=self.m().plan(c,self.bodies());res=[]
  for q in p['poses']:res.append(self.m().evaluate(c,p,q,lambda *a:'SEPARATE',{}))
  final=self.m().finish(p,res)
  self.assertFalse(final['continuous_collision_free']);self.assertEqual(final['unsampled_variable_pairs'],1)
 def test_no_query_for_continuously_separated_bodies(self):
  c=fixture();b=self.bodies();b[1]['bounds_mm']=[100,0,0,110,10,10];p=self.m().plan(c,b)
  def unexpected(*a):raise AssertionError('must not query kernel')
  rows=[self.m().evaluate(c,p,q,unexpected,{}) for q in p['poses']]
  self.assertTrue(self.m().finish(p,rows)['continuous_collision_free'])
 def test_query_detects_sample_penetration(self):
  c=fixture();c['components'][1]['moving_axes']=['X','Y'];b=self.bodies();b[1]['bounds_mm']=[.5,0,0,1.5,1,1]
  p=self.m().plan(c,b);r=self.m().evaluate(c,p,p['poses'][0],lambda *a:'INTERSECT',{})
  self.assertEqual(r['checks'][0]['status'],'INTERFERENCE')
 def test_reuse_relative_motion_only(self):
  c=fixture();c['components'][1]['moving_axes']=['X','Y'];b=self.bodies();b[1]['bounds_mm']=[0,0,0,1,1,1];p=self.m().plan(c,b);calls=[];cache={}
  for q in p['poses']:self.m().evaluate(c,p,q,lambda *a:calls.append(a) or 'SEPARATE',cache)
  self.assertEqual(len(calls),1)
 def test_missing_solid_inventory_rejected(self):
  with self.assertRaises(ValueError):self.m().plan(fixture(),self.bodies()[:1])
 def test_duplicate_body_inventory_rejected(self):
  b=self.bodies();b.append(b[0])
  with self.assertRaises(ValueError):self.m().plan(fixture(),b)
 def test_budget_before_queries(self):
  c=fixture();c['max_pair_evaluations']=1
  with self.assertRaises(ValueError):self.m().plan(c,self.bodies())
 def test_missing_poses_not_reported_complete(self):
  c=fixture();p=self.m().plan(c,self.bodies())
  with self.assertRaises(ValueError):self.m().finish(p,[])
 def test_unsupported_kernel_result_raises(self):
  c=fixture();p=self.m().plan(c,self.bodies())
  with self.assertRaises(ValueError):self.m().evaluate(c,p,{'X':10,'Y':0},lambda *a:'UNKNOWN',{})
 def test_no_clearance_claim_from_hole_separation(self):
  c=fixture();b=self.bodies();b[1]['bounds_mm']=[0,0,0,1,1,1];p=self.m().plan(c,b)
  r=self.m().evaluate(c,p,{'X':0,'Y':0},lambda *a:'SEPARATE',{})
  self.assertEqual(r['checks'][0]['status'],'SEPARATE_GAP_UNVERIFIED')
if __name__=='__main__':unittest.main()
