"""Offline tests of fixture specification/orchestration, NOT NX execution."""
import importlib, math, unittest
from unittest.mock import patch
from types import SimpleNamespace as N
from cnc_nx.runtime import ApiEvidence
from validation.geometry03 import transform_bounds

class Collision05Tests(unittest.TestCase):
 def m(self):
  try:return importlib.import_module('cnc_nx.collision05')
  except ImportError:self.fail('native calibration runner not implemented')
 def test_exactly_nine_cases_and_known_expectations(self):
  from cnc_nx.interference05 import EXPECTED_CASES
  cases=self.m().fixture_cases()
  self.assertEqual({c['case']:c['expected'] for c in cases},EXPECTED_CASES)
  self.assertEqual(len(cases),9)
 def test_hole_case_has_overlapping_bounding_boxes(self):
  from validation.motion05 import aabb_distance
  m=self.m();c=next(c for c in m.fixture_cases() if c['case']=='hole_clear')
  a=m.fixture_contracts()[c['a']]['bounds_mm'];b=m.fixture_contracts()[c['b']]['bounds_mm']
  self.assertEqual(aabb_distance(a,transform_bounds(b,c['rotation'],c['origin_mm'])),0)
  self.assertEqual(c['expected'],'SEPARATE')
 def test_rotation_cases_have_correct_bound_gap(self):
  from validation.motion05 import aabb_distance
  m=self.m();bb=m.fixture_contracts()['cube']['bounds_mm']
  c=next(c for c in m.fixture_cases() if c['case']=='rotated_gap')
  self.assertEqual(aabb_distance(bb,transform_bounds(bb,c['rotation'],c['origin_mm'])),2)
 def test_fixture_volumes_are_analytical(self):
  r=self.m().fixture_contracts()
  self.assertEqual(r['cube']['volume_mm3'],1000)
  self.assertAlmostEqual(r['hole']['volume_mm3'],8000-500*math.pi)
  self.assertAlmostEqual(r['rod']['volume_mm3'],80*math.pi)
 def test_wrong_observed_bounds_rejected(self):
  with self.assertRaises(RuntimeError):self.m().assert_bounds([0,0,0,1,1,1],[0,0,0,2,1,1])
 def test_nonfinite_bounds_rejected(self):
  with self.assertRaises((RuntimeError,ValueError)):self.m().assert_bounds([0,0,0,float('nan'),1,1],[0,0,0,1,1,1])
 def test_missing_occurrence_is_fatal(self):
  m=self.m();p=N();b=N()
  with patch.object(m,'add_component',return_value=N(FindOccurrence=lambda body:None)):
   with self.assertRaises(RuntimeError):m.insert_body(p,N(),ApiEvidence(),'a.prt','A',b,m.I,[0,0,0],'ROWS',[0,0,0,1,1,1])
 def test_occurrence_bounds_checked_before_query(self):
  m=self.m();occ=N(Tag=1)
  with patch.object(m,'add_component',return_value=N(FindOccurrence=lambda body:occ)),patch.object(m,'exact_bounds',return_value=[0,0,0,1,1,1]):
   with self.assertRaises(RuntimeError):m.insert_body(N(),N(),ApiEvidence(),'a.prt','A',N(),m.I,[10,0,0],'ROWS',[0,0,0,1,1,1])
 def test_insert_returns_measured_occurrence(self):
  m=self.m();occ=N(Tag=1)
  with patch.object(m,'add_component',return_value=N(FindOccurrence=lambda body:occ)),patch.object(m,'exact_bounds',return_value=[10,0,0,11,1,1]):
   body,bb=m.insert_body(N(),N(),ApiEvidence(),'a.prt','A',N(),m.I,[10,0,0],'ROWS',[0,0,0,1,1,1])
   self.assertIs(body,occ);self.assertEqual(bb,[10,0,0,11,1,1])
if __name__=='__main__':unittest.main()
