import importlib, unittest
from types import SimpleNamespace as N
from cnc_nx.runtime import ApiEvidence

def documented(targ,num_tools,tools):
 """CheckInterference(targ, num_tools, tools)\n:returns: interference results\n:rtype: list[int]"""
 return [17]

class Interference05Tests(unittest.TestCase):
 def m(self):
  try:return importlib.import_module('cnc_nx.interference05')
  except ImportError:self.fail('interference05 not implemented')
 def rows(self):
  kinds={'gap':'SEPARATE','touch':'TOUCH','overlap':'INTERSECT','coincident':'INTERSECT','hole_clear':'SEPARATE','hole_hit':'INTERSECT','rotated_gap':'SEPARATE','rotated_touch':'TOUCH','rotated_overlap':'INTERSECT'}
  codes={'SEPARATE':17,'TOUCH':33,'INTERSECT':91}
  return [dict(case=k,expected=v,raw_code=codes[v],reverse_raw_code=codes[v]) for k,v in kinds.items()]
 def test_requires_live_documented_signature(self):
  b=self.m().KernelBinding(N(Modl=N(CheckInterference=documented)),ApiEvidence())
  self.assertEqual(b.raw(1,2),17)
 def test_missing_method_rejected(self):
  with self.assertRaises(RuntimeError):self.m().KernelBinding(N(),ApiEvidence())
 def test_missing_docstring_rejected_before_call(self):
  calls=[]
  def f(*a):calls.append(a);return [1]
  with self.assertRaises(RuntimeError):self.m().KernelBinding(N(Modl=N(CheckInterference=f)),ApiEvidence())
  self.assertEqual(calls,[])
 def test_wrong_signature_rejected(self):
  def f(a,b):return [1]
  f.__doc__='CheckInterference(object1, object2)'
  with self.assertRaises(RuntimeError):self.m().KernelBinding(N(Modl=N(CheckInterference=f)),ApiEvidence())
 def test_supported_live_camelcase_signature(self):
  self.assertTrue(self.m().declaration_compatible('Signature ``CheckInterference(targ, numTools, tools)``'))
 def test_results_must_have_exactly_one_integer(self):
  for bad in [True,1,[True],[1.0],[1,2],None,[]]:
   with self.subTest(bad=bad),self.assertRaises(RuntimeError):self.m().single_code(bad)
 def test_scalar_not_assumed_array(self):
  with self.assertRaises(RuntimeError):self.m().single_code(1)
 def test_unobserved_status_never_free(self):
  b=self.m().KernelBinding(N(Modl=N(CheckInterference=documented)),ApiEvidence());b.complete(self.rows())
  with self.assertRaises(RuntimeError):b.classify_code(999)
 def test_no_hardcoded_return_meaning(self):
  b=self.m().KernelBinding(N(Modl=N(CheckInterference=documented)),ApiEvidence());b.complete(self.rows())
  self.assertEqual(b.classify_code(17),'SEPARATE');self.assertEqual(b.classify_code(91),'INTERSECT')
 def test_uncompleted_calibration_rejected(self):
  b=self.m().KernelBinding(N(Modl=N(CheckInterference=documented)),ApiEvidence())
  with self.assertRaises(RuntimeError):b.classify_code(17)
 def test_touch_and_overlap_same_code_rejected(self):
  rows=self.rows();rows[1]['raw_code']=91;rows[1]['reverse_raw_code']=91
  with self.assertRaises(RuntimeError):self.m().calibration_map(rows)
 def test_hole_must_be_separate_despite_overlapping_aabb(self):
  rows=self.rows();next(x for x in rows if x['case']=='hole_clear')['raw_code']=91
  with self.assertRaises(RuntimeError):self.m().calibration_map(rows)
 def test_missed_case_rejected(self):
  with self.assertRaises(RuntimeError):self.m().calibration_map(self.rows()[:-1])
 def test_reverse_query_mismatch_rejected(self):
  rows=self.rows();rows[0]['reverse_raw_code']=99
  with self.assertRaises(RuntimeError):self.m().calibration_map(rows)
 def test_zero_tag_rejected(self):
  b=self.m().KernelBinding(N(Modl=N(CheckInterference=documented)),ApiEvidence())
  with self.assertRaises(ValueError):b.raw(0,2)
 def setup_undo(self,fail=False):
  children=[];events=[];root=N(Tag=6,ComponentAssembly=N(RootComponent=N(GetChildren=lambda:list(children))))
  def undo(*a):
   events.append('undo')
   if fail:raise RuntimeError('undo failed')
   children.clear()
  s=N(SetUndoMark=lambda *a:events.append('mark') or 1,UndoToMark=undo,DeleteUndoMark=lambda *a:events.append('delete'))
  nx=N(Session=N(MarkVisibility=N(Invisible=0)));owner=N(records={6:{'part':root}})
  return children,events,root,s,nx,owner
 def test_temporary_pose_is_removed_on_success(self):
  c,e,p,s,n,o=self.setup_undo()
  with self.m().temporary_occurrences(s,n,p,o,ApiEvidence()):c.append(1)
  self.assertEqual(c,[]);self.assertEqual(e,['mark','undo','delete'])
 def test_temporary_pose_is_removed_on_query_error(self):
  c,e,p,s,n,o=self.setup_undo()
  with self.assertRaisesRegex(ValueError,'query failed'):
   with self.m().temporary_occurrences(s,n,p,o,ApiEvidence()):c.append(1);raise ValueError('query failed')
  self.assertEqual(c,[])
 def test_undo_failure_is_fatal(self):
  c,e,p,s,n,o=self.setup_undo(True)
  with self.assertRaisesRegex(RuntimeError,'undo failed'):
   with self.m().temporary_occurrences(s,n,p,o,ApiEvidence()):c.append(1)
 def test_preexisting_components_cannot_be_rolled_back(self):
  c,e,p,s,n,o=self.setup_undo();c.append('original')
  with self.assertRaises(RuntimeError):
   with self.m().temporary_occurrences(s,n,p,o,ApiEvidence()):pass
  self.assertEqual(e,[]);self.assertEqual(c,['original'])
 def test_original_part_rejected_before_undo_mark(self):
  c,e,p,s,n,o=self.setup_undo();o.records={}
  with self.assertRaises(RuntimeError):
   with self.m().temporary_occurrences(s,n,p,o,ApiEvidence()):pass
  self.assertEqual(e,[])
if __name__=='__main__':unittest.main()
