import copy,hashlib,json,tempfile,unittest
from pathlib import Path
from assembly import manifest03
from construction.recipes03 import reference_carrier
I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
class Manifest03Tests(unittest.TestCase):
 def api(self,n):
  f=getattr(manifest03,n,None);self.assertTrue(callable(f),'Missing '+n);return f
 def cfg(self,p):
  return dict(schema='SX35Z_ASSEMBLY_3',review={'status':'MODEL_LAYOUT_REVIEWED','evidence':'test fixture, NOT actual machine'},groups=['X'],
    source_inventory=None,components=[dict(id='A',group='X',kind='PURCHASE',path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),origin_mm=[1.,2.,3.],rotation=I,source='fixture manufacturer reference',dimensions_status='CATALOGUE_REFERENCE')])
 def test_valid_reviewed_manifest(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'fixture');r=self.api('validate_manifest')(self.cfg(p));self.assertEqual(len(r['components']),1)
 def test_default_empty_not_misrepresented_as_built(self):
  with self.assertRaises(ValueError):self.api('validate_manifest')({'schema':'SX35Z_ASSEMBLY_3','components':[]})
 def test_bad_hash_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['components'][0]['sha256']='0'*64
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
 def test_unknown_group_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['groups']=[]
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
 def test_review_required(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['review']['status']='ASSUMED'
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
 def test_nonfinite_translation(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['components'][0]['origin_mm'][0]=float('nan')
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
 def test_reflection_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['components'][0]['rotation']=[[-1.,0,0],[0,1.,0],[0,0,1.]]
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
 def test_duplicate_occurrence_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['components'].append(copy.deepcopy(c['components'][0]))
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
 def test_original_requires_inventory(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['components'][0]['kind']='ORIGINAL'
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
 def test_manufacturing_release_never_implicit(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');r=self.api('validate_manifest')(self.cfg(p));self.assertFalse(r['manufacturing_released'])
 def test_axis_placement_composition(self):
  frame=dict(origin_mm=[100.,0.,0.],rotation=[[0.,0.,1.],[0.,1.,0.],[-1.,0.,0.]])
  r=self.api('place_axis_component')(frame,dict(origin_mm=[0,0,20],rotation=I))
  self.assertEqual(r['origin_mm'],[120.,0.,0.]);self.assertEqual(r['rotation'],frame['rotation'])
 def test_generated_parts_manifest_needs_source_trace(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'a.prt';p.write_bytes(b'x');c=self.cfg(p);c['components'][0]['kind']='GENERATED';c['components'][0]['source']=''
   with self.assertRaises(ValueError):self.api('validate_manifest')(c)
if __name__=='__main__':unittest.main()
