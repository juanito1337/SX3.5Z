"""Exercise the REAL coordinator with simulated NX objects; no NX/CAD execution."""
import contextlib
import copy
import sys
import tempfile
import types
import unittest
from collections import Counter
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch

from cnc_nx import ballscrew09 as native
from cnc_nx.runtime import sha256_file
from construction.ballscrew09 import reference_set
from validation.geometry03 import transform_bounds


class Registry09Tests(unittest.TestCase):
    def rows(self,d):
        data=reference_set(); rows=[]
        for r in data['parts']:
            p=Path(d)/(r['id']+'.prt');p.write_bytes(b'SIMULATED_TEST_FILE_NOT_NATIVE_NX')
            rows.append(dict(id=r['id'],path=str(p),sha256=sha256_file(p),source=r['source']))
        return data,rows
    def test_six_model_identities_preserve_three_real_nut_codes(self):
        with tempfile.TemporaryDirectory() as d:
            data,rows=self.rows(d);reg=native.source_registry(data,rows)
            self.assertEqual(len(reg['entries']),6)
            self.assertEqual([e['order_number'] for e in reg['entries'] if e['order_number']],['213514','213505','213420 0005'])
            self.assertTrue(all(not e['order_released'] for e in reg['entries']))
    def test_changed_native_bytes_reject_registry(self):
        with tempfile.TemporaryDirectory() as d:
            data,rows=self.rows(d);Path(rows[0]['path']).write_bytes(b'changed')
            with self.assertRaises(ValueError):native.source_registry(data,rows)
    def test_wrong_source_reject_registry(self):
        with tempfile.TemporaryDirectory() as d:
            data,rows=self.rows(d);rows[0]['source']='different'
            with self.assertRaises(ValueError):native.source_registry(data,rows)
    def test_missing_prototype_reject_registry(self):
        with tempfile.TemporaryDirectory() as d:
            data,rows=self.rows(d)
            with self.assertRaises(ValueError):native.source_registry(data,rows[:-1])


class Pipeline09Tests(unittest.TestCase):
    def exercise(self,d,bad_bom=False,change_model=False):
        session=N(Parts=N(Display=None));objects={};events=[]
        class Owner:
            def __init__(self,s,n,root,log,evidence):self.root=Path(root);self.records={}
            def create(self,name):
                p=N(name=name,children=[],Tag=len(objects)+1);objects[p.Tag]=p
                self.records[p.Tag]={'part':p};session.Parts.Display=p;events.append(('create',name));return p
            def save(self,p):
                target=self.root/(p.name+'.prt');target.write_bytes(('SIMULATED_NX_TEST_FILE '+p.name).encode())
                p.path=str(target);events.append(('save',p.name));return str(target)
        class Builder:
            def __init__(self,*a):pass
            def build_recipe(self,r):
                body=N(recipe=r);self.r=r;self.final=N(GetBodies=lambda:[body]);return self.final,body,{'offline_seam':True}
            def test_parameter(self,*a):return {'probes':[{},{}],'status':'SIMULATED_ONLY'}
        def add(asm,nx,evidence,path,name,R,t,mode):
            parent=next(p for p in objects.values() if getattr(p,'path',None)==path)
            comp=N(path=path,prototype=parent,rotation=R,translation=t)
            comp.FindOccurrence=lambda body:N(body=body,rotation=R,translation=t)
            asm.children.append(comp);return comp
        @contextlib.contextmanager
        def poses(s,n,part,owner,evidence):
            # Conservative precondition: no mutation on a non-current scratch part.
            if session.Parts.Display is not part:raise RuntimeError('Scratch part not current during native pose')
            if part.children:raise RuntimeError('Scratch not empty')
            try:yield
            finally:part.children.clear()
        def bbox(part,occ,evidence):return transform_bounds(occ.body.recipe['bounds_mm'],occ.rotation,occ.translation)
        def bom(s,root,log,evidence,registry,expected_quantities):
            tree=session.Parts.Display
            if len(tree.children)!=3:raise RuntimeError('Not three subassemblies')
            counted=Counter()
            for group in tree.children:
                for c in group.prototype.children:
                    counted[Path(c.path).stem]+=1
            if change_model:Path(registry['entries'][0]['prototype_path']).write_bytes(b'changed')
            if bad_bom:counted[next(iter(counted))]+=1
            return dict(inventory_complete=True,source_binding_complete=True,assignment_complete=True,
                        rows=[dict(item_id=k,quantity=v) for k,v in counted.items()])
        evidence=N(require=lambda name,fn:fn)
        fake=types.ModuleType('NXOpen');modules={'NXOpen':fake}
        for key in ('Features','GeometricUtilities','Assemblies'):
            m=types.ModuleType('NXOpen.'+key);setattr(fake,key,m);modules['NXOpen.'+key]=m
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.dict(sys.modules,modules))
            for key,value in [('NewParts',Owner),('RecipeBuilder',Builder),('calibrate',lambda *a:'ROWS'),
                              ('temporary_occurrences',poses),('add_component',add),('exact_bounds',bbox)]:
                stack.enter_context(patch.object(native,key,value))
            stack.enter_context(patch('cnc_nx.bom07.run_report',side_effect=bom))
            result=native.run(session,fake,Path(d),lambda msg:None,evidence,{})
        return result,events
    def test_complete_control_flow_counts_all_samples_and_keeps_scratch_current(self):
        with tempfile.TemporaryDirectory() as d:
            r,events=self.exercise(d)
            self.assertEqual(r['prototype_count'],6);self.assertEqual(r['paired_assembly_count'],3)
            self.assertEqual(r['leaf_occurrence_count'],6);self.assertEqual(r['native_axial_sample_count'],9)
            self.assertEqual(r['native_parameter_tests'],12)
            self.assertFalse(r['machine_fit_verified']);self.assertFalse(r['full_collision_checked'])
            self.assertTrue((Path(d)/'NX_Kugelgewinde_Referenzen_09.json').is_file())
    def test_changed_bom_cannot_publish_completed_report(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(RuntimeError,'BOM differs'):
                self.exercise(d,bad_bom=True)
            self.assertFalse((Path(d)/'NX_Kugelgewinde_Referenzen_09.json').exists())
    def test_changed_saved_part_cannot_publish_completed_report(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(RuntimeError,'part changed'):
                self.exercise(d,change_model=True)
            self.assertFalse((Path(d)/'NX_Kugelgewinde_Referenzen_09.json').exists())

if __name__=='__main__':unittest.main()
