import copy,importlib,importlib.util,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from test_native_bom07 import FakePart,FakeComp
from cnc_nx.runtime import ApiEvidence,sha256_file
from construction.recipes03 import reference_carrier
ROOT=Path(__file__).resolve().parents[1]

class PipelineTests(unittest.TestCase):
    def m(self):
        try:return importlib.import_module('cnc_nx.bom_reference07')
        except ImportError:self.fail('Carrier-to-BOM integration missing')
    def fixture(self,td):
        root=Path(td);data=reference_carrier();parts={r['id']:FakePart(root,r['id'],[True]) for r in data['parts']}
        asm=FakePart(root,'carrier',[]);comp=FakeComp(asm,[FakeComp(parts[c['part_id']]) for c in data['components']]);asm.ComponentAssembly.RootComponent=comp
        built=dict(native_execution=True,status='NATIVE_REFERENCE_ASSEMBLY_CREATED_IN_THIS_RUN',assembly_file=asm.FullPath,
            parts=[dict(id=r['id'],path=parts[r['id']].FullPath,sha256=sha256_file(parts[r['id']].FullPath),source=r['source']) for r in data['parts']],components=data['components'])
        return NS(Parts=NS(Display=asm)),built
    def test_registry_bound_to_current_native_reference_files(self):
        with tempfile.TemporaryDirectory() as td:
            _,built=self.fixture(td);r=self.m().reference_registry(built)
            self.assertEqual(len(r['entries']),4);self.assertTrue(all(e['prototype_sha256'] for e in r['entries']))
    def test_non_native_build_report_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            _,b=self.fixture(td);b['native_execution']=False
            with self.assertRaises(ValueError):self.m().reference_registry(b)
    def test_missing_prototype_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            _,b=self.fixture(td);b['parts'].pop()
            with self.assertRaises(ValueError):self.m().reference_registry(b)
    def test_changed_native_file_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            _,b=self.fixture(td);Path(b['parts'][0]['path']).write_bytes(b'changed')
            with self.assertRaises(ValueError):self.m().reference_registry(b)
    def test_unexpected_source_or_recipe_not_accepted(self):
        with tempfile.TemporaryDirectory() as td:
            _,b=self.fixture(td);b['parts'][0]['source']='not matching recipe'
            with self.assertRaises(ValueError):self.m().reference_registry(b)
    def test_reference_pipeline_real_core_and_fake_native_boundary(self):
        with tempfile.TemporaryDirectory() as td:
            session,b=self.fixture(td);out=Path(td)/'run';out.mkdir()
            with patch('cnc_nx.build03.build_reference',return_value=b):
                r=self.m().run(session,NS(),out,lambda _:None,ApiEvidence(),{})
            self.assertEqual(r['counts']['active_leaf_occurrences'],7)
            self.assertEqual(r['counts']['distinct_part_rows'],4);self.assertTrue(r['assignment_complete'])
            self.assertFalse(r['manufacturing_released']);self.assertFalse(r['order_released'])
            self.assertTrue((out/'BOM'/'Gesamtstueckliste_07.csv').exists())
    def test_displayed_part_mismatch_aborts(self):
        with tempfile.TemporaryDirectory() as td:
            session,b=self.fixture(td);session.Parts.Display.FullPath=str(Path(td)/'other.prt');out=Path(td)/'run';out.mkdir()
            with patch('cnc_nx.build03.build_reference',return_value=b):
                with self.assertRaises(RuntimeError):self.m().run(session,NS(),out,lambda _:None,ApiEvidence(),{})
    def test_routing_and_entrypoints(self):
        for name,action in [('NX_18_Stueckliste.py','bom07'),('NX_19_Motortraeger_mit_Stueckliste.py','bom_reference07')]:
            p=ROOT/name;self.assertTrue(p.is_file(),name)
            self.assertIn("'"+action+"'",p.read_text());self.assertIn("'"+action+"'",(ROOT/'main.py').read_text())
    def test_shipped_mapping_is_not_preapproved(self):
        p=ROOT/'config'/'bom07.json';self.assertTrue(p.exists());self.assertEqual(json.loads(p.read_text())['entries'],[])

class CLITests(unittest.TestCase):
    def tool(self):
        p=ROOT/'Projekt07_Stueckliste.py';self.assertTrue(p.is_file(),'CLI missing')
        spec=importlib.util.spec_from_file_location('bom07_cli',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
    def test_preview_creates_no_prt_files(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'preview';self.tool().main(['--preview','--output',str(out)])
            self.assertEqual(list(out.rglob('*.prt')),[]);r=json.loads((out/'Stueckliste_07.json').read_text())
            self.assertEqual(r['source_origin'],'RECIPE_PREVIEW')
    def test_preview_no_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(FileExistsError):self.tool().main(['--preview','--output',td])
    def test_replay_still_marked_offline(self):
        import cnc_nx.bom07
        with tempfile.TemporaryDirectory() as td:
            pipe=PipelineTests();session,b=pipe.fixture(td);snap=cnc_nx.bom07.capture(session,ApiEvidence(),lambda _:None)
            p=Path(td)/'snapshot.json';p.write_text(json.dumps(snap));out=Path(td)/'out'
            self.tool().main(['--snapshot',str(p),'--output',str(out)])
            r=json.loads((out/'Stueckliste_07.json').read_text());self.assertFalse(r['native_read_in_this_run'])
            self.assertEqual(r['source_origin'],'LIVE_NX_READ')
    def test_replay_integrity_failure_never_exported(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'bad.json';p.write_text(json.dumps(dict(integrity_failure=True)));out=Path(td)/'out'
            with self.assertRaises(ValueError):self.tool().main(['--snapshot',str(p),'--output',str(out)])
            self.assertFalse(out.exists())

class CompletionGateTests(unittest.TestCase):
    def test_wrong_reference_quantity_does_not_publish_complete_bom(self):
        from cnc_nx.bom_reference07 import run
        with tempfile.TemporaryDirectory() as td:
            session,built=PipelineTests().fixture(td)
            session.Parts.Display.ComponentAssembly.RootComponent.children.pop()
            out=Path(td)/'run';out.mkdir()
            with patch('cnc_nx.build03.build_reference',return_value=built):
                with self.assertRaises(RuntimeError):run(session,NS(),out,lambda _:None,ApiEvidence(),{})
            self.assertTrue((out/'NX_Stuecklistenaufnahme_07.json').exists())
            self.assertFalse((out/'NX_Stueckliste_07.json').exists())
            self.assertFalse((out/'BOM'/'Export_SHA256_07.json').exists())
