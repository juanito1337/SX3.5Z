import copy,importlib,importlib.util,math,unittest
from engineering.ballscrew09 import load_cases,load_registry

class NutMount10Tests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('engineering.nutmount10'),'Missing next-step nut-mount implementation')
  self.m=importlib.import_module('engineering.nutmount10')
  self.reg=self.m.load_registry();self.cfg=self.m.load_cases()
 def plan(self,index=0,**changes):
  c=copy.deepcopy(self.cfg[index]);c.update(changes)
  return self.m.resolve(c,load_cases(),load_registry(),self.reg)
 def test_articles(self):
  self.assertEqual(set(self.reg['blocks']),{'213500','213600'})
 def test_nominal_dimensions(self):
  a=self.plan();b=self.plan(2)
  self.assertEqual([a['block'][k] for k in ('bore_d_mm','length_mm','width_mm','height_mm','axis_height_mm')],[28,54,47,33,16.5])
  self.assertEqual([b['block'][k] for k in ('bore_d_mm','length_mm','width_mm','height_mm','axis_height_mm')],[33,61.5,53,40,20])
 def test_sixteen_leads_share_block_not_nut(self):
  a,b=self.plan(),self.plan(1)
  self.assertEqual(a['block_article'],b['block_article']);self.assertNotEqual(a['nut_article'],b['nut_article'])
 def test_wrong_family_rejected(self):
  with self.assertRaises(ValueError):self.plan(block_article='213600')
 def test_unknown_article_rejected(self):
  with self.assertRaises(ValueError):self.plan(block_article='unknown')
 def test_registry_dimension_drift_rejected(self):
  self.reg['blocks']['213500']['length_mm']=55
  with self.assertRaises(ValueError):self.m.validate_registry(self.reg)
 def test_registry_release_escalation_rejected(self):
  self.reg['evidence']['original_cad_obtained']=True
  with self.assertRaises(ValueError):self.m.validate_registry(self.reg)
 def test_source_drift_rejected(self):
  self.reg['source_url']='fake'
  with self.assertRaises(ValueError):self.m.validate_registry(self.reg)
 def test_no_invented_hole_positions(self):
  self.assertFalse(self.reg['evidence']['foot_hole_positions_verified'])
  for b in self.reg['blocks'].values():self.assertIsNone(b['foot_holes'])
 def test_block_not_nut_limits_window(self):
  w=self.plan()['window'];self.assertEqual(w['span_mm'],278);self.assertEqual(w['center_min_mm'],37);self.assertEqual(w['center_max_mm'],315)
 def test_twenty_longer_block(self):
  w=self.plan(2)['window'];self.assertEqual(w['span_mm'],170.5);self.assertEqual(w['center_min_mm'],40.75)
 def test_protruding_nut_positive_offset(self):
  w=self.plan(nut_offset_mm=15)['window'];self.assertEqual(w['relative_low_mm'],-27);self.assertEqual(w['relative_high_mm'],40);self.assertEqual(w['span_mm'],265)
 def test_protruding_nut_negative_offset(self):
  w=self.plan(nut_offset_mm=-15)['window'];self.assertEqual(w['relative_low_mm'],-40);self.assertEqual(w['relative_high_mm'],27)
 def test_reference_outside_rejected(self):
  with self.assertRaises(ValueError):self.plan(reference_block_center_mm=0)
 def test_span_request_failure_visible(self):
  w=self.plan(requested_body_stroke_mm=300)['window'];self.assertFalse(w['requested_stroke_fits']);self.assertEqual(w['missing_length_mm'],22)
 def test_exact_span_request_allowed(self):
  self.assertTrue(self.plan(requested_body_stroke_mm=278)['window']['requested_stroke_fits'])
 def test_missing_values_not_zero_filled(self):
  c=copy.deepcopy(self.cfg[0]);del c['nut_offset_mm']
  with self.assertRaises(ValueError):self.m.resolve(c,load_cases(),load_registry(),self.reg)
 def test_nonfinite_values_rejected(self):
  for val in [True,float('nan'),float('inf'),None,'0']:
   with self.subTest(val=val),self.assertRaises(ValueError):self.plan(nut_offset_mm=val)
 def test_large_offset_rejected(self):
  with self.assertRaises(ValueError):self.plan(nut_offset_mm=500)
 def test_unknown_pair_rejected(self):
  with self.assertRaises(ValueError):self.plan(pair_id='KGT999')
 def test_duplicate_ids_rejected(self):
  with self.assertRaises(ValueError):self.m.resolve_all([self.cfg[0],self.cfg[0]],load_cases(),load_registry(),self.reg)
 def test_zero_missing_reserves_not_assumed(self):
  pairs=load_cases();pairs[0]['reserve_start_mm']=None
  with self.assertRaises(ValueError):self.m.resolve(self.cfg[0],pairs,load_registry(),self.reg)
 def test_unknown_keys_rejected(self):
  with self.assertRaises(ValueError):self.plan(machine_fit_verified=True)
 def test_flags_and_assumption(self):
  p=self.plan();self.assertFalse(p['machine_fit_verified']);self.assertFalse(p['retention_verified']);self.assertFalse(p['contact_verified'])
  self.assertEqual(p['axial_position_basis'],'EXPLICIT_STUDY_OFFSET_NOT_MANUFACTURER_ASSEMBLY_DIMENSION')
 def test_samples_respect_reserves(self):
  for i in range(3):
   p=self.plan(i)
   self.assertEqual([s['name'] for s in p['samples']],['MIN','REFERENCE','MAX'])
   for s in p['samples']:
    self.assertGreaterEqual(s['known_body_start_mm'],10-1e-9);self.assertLessEqual(s['known_body_end_mm'],p['pair']['stock_length_mm']-10+1e-9)
 def test_window_finite_nonnegative(self):
  for i in range(3):self.assertGreaterEqual(self.plan(i)['window']['span_mm'],0)

if __name__=='__main__':unittest.main()
