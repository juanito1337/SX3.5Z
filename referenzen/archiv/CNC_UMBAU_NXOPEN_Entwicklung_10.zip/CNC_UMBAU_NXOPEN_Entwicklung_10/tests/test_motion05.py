import copy, importlib, itertools, math, random, unittest
I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
def fixture():
 return dict(schema='SX35Z_SWEEP_5',review=dict(status='KINEMATICS_REVIEWED',evidence='Artificial unit-test fixture'),
  axes={'X':dict(min_mm=0.,max_mm=20.,reference_mm=0.,direction=[1,0,0],samples=5,evidence='test'),
        'Y':dict(min_mm=-5.,max_mm=5.,reference_mm=0.,direction=[0,1,0],samples=3,evidence='test')},
  components=[dict(id='TABLE',path='table.prt',sha256='1'*64,rotation=copy.deepcopy(I),origin_mm=[0,0,0],moving_axes=['X','Y']),
              dict(id='SADDLE',path='saddle.prt',sha256='2'*64,rotation=copy.deepcopy(I),origin_mm=[0,0,0],moving_axes=['Y'])],
  clearance_mm=0.1,tolerance_mm=0.005,max_poses=200,max_pair_evaluations=10000,expected_contacts=[])
class Motion05Tests(unittest.TestCase):
 def m(self):
  try:return importlib.import_module('validation.motion05')
  except ImportError:self.fail('motion05 not implemented')
 def test_schema_accepts_reviewed_translations(self):self.assertEqual(self.m().validate(fixture())['pose_count'],15)
 def test_shared_axis_motion_is_preserved(self):
  c=fixture();self.assertEqual(self.m().translation(c,c['components'][0],{'X':10,'Y':4}),[10.,4.,0.])
 def test_reference_offsets_subtracted(self):
  c=fixture();c['axes']['X']['reference_mm']=5;self.assertEqual(self.m().translation(c,c['components'][0],{'X':5,'Y':0}),[0.,0.,0.])
 def test_samples_include_endpoints(self):
  poses=self.m().poses(fixture());self.assertEqual(len(poses),15);self.assertEqual(poses[0],{'X':0.,'Y':-5.});self.assertEqual(poses[-1],{'X':20.,'Y':5.})
 def test_reference_pose_is_included_even_with_even_samples(self):
  c=fixture();c['axes']['Y']['samples']=2
  self.assertIn({'X':0.,'Y':0.},self.m().poses(c))
 def test_unreviewed_input_blocked(self):
  c=fixture();c['review']['status']='TEMPLATE'
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_unknown_moving_axis_blocked(self):
  c=fixture();c['components'][0]['moving_axes'].append('A')
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_duplicate_axis_membership_blocked(self):
  c=fixture();c['components'][0]['moving_axes'].append('X')
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_unknown_motion_membership_not_fixed(self):
  c=fixture();c['components'][0]['moving_axes']=None
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_duplicate_component_ids_blocked(self):
  c=fixture();c['components'][1]['id']='TABLE'
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_reflection_blocked(self):
  c=fixture();c['components'][0]['rotation'][0][0]=-1
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_non_unit_direction_not_silently_normalized(self):
  c=fixture();c['axes']['X']['direction']=[2,0,0]
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_reference_outside_limits_blocked(self):
  c=fixture();c['axes']['X']['reference_mm']=21
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_nan_and_bool_not_numeric(self):
  for value in [True,float('nan'),float('inf')]:
   c=fixture();c['axes']['X']['max_mm']=value
   with self.subTest(value=value),self.assertRaises(ValueError):self.m().validate(c)
 def test_samples_must_be_integer(self):
  c=fixture();c['axes']['X']['samples']=2.5
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_pose_budget_blocked(self):
  c=fixture();c['max_poses']=2
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_negative_clearance_blocked(self):
  c=fixture();c['clearance_mm']=-1
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_common_motion_cancels_for_full_travel_proof(self):
  c=fixture();a=c['components'][0];b=c['components'][1];b['moving_axes']=['X','Y']
  r=self.m().swept_pair(c,a,[0,0,0,10,10,10],b,[12,0,0,22,10,10])
  self.assertTrue(r['continuous_separation_proved']);self.assertTrue(r['relative_motion_fixed']);self.assertAlmostEqual(r['lower_bound_mm'],2.)
 def test_crossing_between_samples_is_not_free(self):
  c=fixture();a=c['components'][0];b=c['components'][1];b['moving_axes']=[]
  r=self.m().swept_pair(c,a,[0,0,0,1,1,1],b,[9,0,0,10,1,1])
  self.assertFalse(r['continuous_separation_proved'])
 def test_reversed_axis_direction(self):
  c=fixture();c['axes']['X']['direction']=[-1,0,0];a,b=c['components']
  r=self.m().swept_pair(c,a,[0,0,0,1,1,1],b,[9,0,0,10,1,1]);self.assertTrue(r['continuous_separation_proved'])
 def test_requested_gap_not_proved_by_topological_separation(self):
  r=self.m().classify_sample('SEPARATE',0.,0.1,0.005,False)
  self.assertEqual(r,'SEPARATE_GAP_UNVERIFIED')
 def test_unknown_kernel_code_not_pass(self):
  with self.assertRaises(ValueError):self.m().classify_sample('UNKNOWN',0.,0.,0.005,False)
 def test_penetration_never_whitelisted_as_contact(self):self.assertEqual(self.m().classify_sample('INTERSECT',0.,0.,0.005,True),'INTERFERENCE')
 def test_expected_contact_requires_zero_clearance(self):self.assertEqual(self.m().classify_sample('TOUCH',0.,0.2,0.005,True),'CONTACT_VIOLATES_CLEARANCE')
 def test_expected_contact_zero_gap_allowed_but_labeled(self):self.assertEqual(self.m().classify_sample('TOUCH',0.,0.,0.005,True),'EXPECTED_CONTACT')
 def test_unexpected_contact_is_issue(self):self.assertEqual(self.m().classify_sample('TOUCH',0.,0.,0.005,False),'UNREVIEWED_CONTACT')
 def test_policy_unknown_component_blocked(self):
  c=fixture();c['expected_contacts']=[dict(a='TABLE',b='OTHER',evidence='test')]
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_policy_requires_evidence(self):
  c=fixture();c['expected_contacts']=[dict(a='TABLE',b='SADDLE',evidence='')]
  with self.assertRaises(ValueError):self.m().validate(c)
 def test_whole_box_proof_conservative_random_points(self):
  rng=random.Random(2805);c=fixture();a,b=c['components']
  for _ in range(60):
   bb=[rng.uniform(-40,40) for k in range(3)];bb+= [bb[k]+2 for k in range(3)]
   r=self.m().swept_pair(c,a,[0,0,0,1,1,1],b,bb)
   if r['continuous_separation_proved']:
    for j in range(15):
     q={'X':rng.uniform(0,20),'Y':rng.uniform(-5,5)}
     aa=self.m().shift_bounds([0,0,0,1,1,1],self.m().translation(c,a,q));bt=self.m().shift_bounds(bb,self.m().translation(c,b,q))
     self.assertGreater(self.m().aabb_distance(aa,bt),c['clearance_mm'])
 def test_no_unconditional_pass_from_clean_samples(self):
  r=self.m().summarize([dict(status='SEPARATE')],continuous_complete=False)
  self.assertFalse(r['continuous_collision_free']);self.assertFalse(r['manufacturing_released'])
if __name__=='__main__':unittest.main()
