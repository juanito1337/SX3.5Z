import copy,json,math,unittest
from pathlib import Path
from construction import recipes03
ROOT=Path(__file__).resolve().parents[1]
class Recipes03Tests(unittest.TestCase):
    def api(self,name):
        fn=getattr(recipes03,name,None);self.assertTrue(callable(fn),'Missing implementation: '+name);return fn
    def test_manufacturer_revision_not_silently_mixed(self):
        r=self.api('motor_recipe')();self.assertEqual(r['parameters']['motor_length'],103)
        self.assertIn('104',r['limitations']);self.assertEqual(r['manufacturer_model'],'CS-M22326')
        self.assertFalse(r['order_released'])
    def test_motor_recipe_dimensions_and_volume(self):
        r=self.api('motor_recipe')();v=self.api('validate_recipe')(r)
        self.assertGreater(v['expected_volume_mm3'],320000)
        self.assertEqual(v['bounds_mm'],[-28.2,-28.2,-21.0,28.2,28.2,103.0])
        self.assertEqual(r['parameters']['hole_pitch'],47.14)
    def test_carrier_four_unique_spacers_shared_prototype(self):
        s=self.api('reference_carrier')();self.assertEqual(len(s['parts']),4)
        ids=[x['id'] for x in s['components']];self.assertEqual(len(set(ids)),7)
        spacers=[x for x in s['components'] if x['part_id']=='D03_SPACER']
        self.assertEqual(len(spacers),4)
        self.assertEqual({tuple(x['origin_mm']) for x in spacers},{(x,y,-50) for x in (-35,35) for y in (-35,35)})
    def test_all_reference_recipes_validate(self):
        s=self.api('reference_carrier')()
        for r in s['parts']:self.assertGreater(self.api('validate_recipe')(r)['expected_volume_mm3'],0)
    def test_motor_plate_uses_catalogue_pattern_and_clearance(self):
        s=self.api('reference_carrier')();r=next(x for x in s['parts'] if x['id']=='D03_MOTOR_PLATE')
        self.assertEqual(r['parameters']['motor_pitch'],47.14)
        self.assertGreater(r['parameters']['pilot_clearance'],38.1)
        self.assertFalse(s['machine_fit_verified'])
    def test_recipe_nonfinite_rejected(self):
        r=self.api('motor_recipe')();r['parameters']['shaft_d']=float('nan')
        with self.assertRaises(ValueError):self.api('validate_recipe')(r)
    def test_recipe_boolean_dimension_rejected(self):
        r=self.api('motor_recipe')();r['parameters']['shaft_d']=True
        with self.assertRaises(ValueError):self.api('validate_recipe')(r)
    def test_recipe_file_name_cannot_escape(self):
        r=self.api('motor_recipe')();r['id']='../../lost'
        with self.assertRaises(ValueError):self.api('validate_recipe')(r)
    def test_arbitrary_python_formula_rejected(self):
        r=self.api('motor_recipe')();r['ops'][0]['size'][0]='__import__("os").getcwd()'
        with self.assertRaises(ValueError):self.api('validate_recipe')(r)
    def test_unknown_operation_rejected(self):
        r=self.api('motor_recipe')();r['ops'][0]['kind']='magic'
        with self.assertRaises(ValueError):self.api('validate_recipe')(r)
    def test_no_mutation_between_calls(self):
        a=self.api('reference_carrier')();a['parts'][0]['parameters']['motor_length']=200
        b=self.api('reference_carrier')();self.assertEqual(b['parts'][0]['parameters']['motor_length'],103)
    def test_standoff_rod_mount_math(self):
        r=self.api('sleeve_recipe')('T',14,6.6,50,'design')
        v=self.api('validate_recipe')(r)
        self.assertAlmostEqual(v['expected_volume_mm3'],math.pi*(14**2-6.6**2)/4*50)
    def test_nut_flange_holder_requires_real_interface(self):
        with self.assertRaises(ValueError):self.api('flange_holder_recipe')('N',90,90,12,None,[], 'missing')
    def test_holder_rejects_overlapping_holes(self):
        holes=[dict(x=10,y=10,d=8),dict(x=10.1,y=10,d=8)]
        with self.assertRaises(ValueError):self.api('flange_holder_recipe')('N',90,90,12,10,holes,'design')
    def test_nut_and_bearing_holder_generic_native_recipe(self):
        r=self.api('flange_holder_recipe')('N',100,90,15,32,[dict(x=x,y=y,d=6.6) for x in (-35,35) for y in (-30,30)],'reviewed interface')
        self.assertEqual(r['kind'],'flange_holder');self.assertGreater(self.api('validate_recipe')(r)['expected_volume_mm3'],0)
if __name__=='__main__':unittest.main()
