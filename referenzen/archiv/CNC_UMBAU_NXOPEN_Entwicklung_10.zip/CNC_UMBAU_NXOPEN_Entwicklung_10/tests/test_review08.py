"""Review regressions: evidence binding is not just a success flag."""
import importlib,importlib.util,copy,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from cnc_nx.runtime import ApiEvidence,sha256_file
from test_native_inspection08 import fixture,FAKENX
from test_interfaces08 import synthetic_measurements
from validation.dossier08 import digest,subject_from_snapshot,inspect_artifact,build_dossier
from validation.interfaces08 import reference_checks,evaluate_reference
from cnc_nx.inspection08 import capture_with_positions


class Review08Tests(unittest.TestCase):
    def test_interface_measurements_cannot_have_different_global_placement(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,built,raw,bb=fixture(d)
            sub=subject_from_snapshot(capture_with_positions(session,FAKENX,ApiEvidence(),lambda _:None))
            measurements=synthetic_measurements();pm={p['id']:p for p in built['parts']};cm={c['id']:c for c in built['components']}
            for row in measurements:
                p=pm[cm[row['id']]['part_id']];row.update(prototype_path=p['path'],prototype_sha256=p['sha256'])
                row['translation_mm'][2]+=100.  # relative interfaces still all pass
            payload=dict(schema='SX35Z_NATIVE_INTERFACES_8',native_execution=True,subject_fingerprint=sub['fingerprint'],
                         scope='REFERENCE_CARRIER_ONLY',contract_sha256=digest(reference_checks()),measurements=measurements)
            self.assertTrue(evaluate_reference(measurements)['all_within_limits'])
            self.assertEqual(inspect_artifact('interfaces',payload,sub)['status'],'STALE_OR_OTHER_MODEL')
    def test_subject_checks_include_named_occurrence_not_just_part_hash(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,built,raw,bb=fixture(d)
            sub=subject_from_snapshot(capture_with_positions(session,FAKENX,ApiEvidence(),lambda _:None))
            measurements=synthetic_measurements();pm={p['id']:p for p in built['parts']};cm={c['id']:c for c in built['components']}
            for row in measurements:
                p=pm[cm[row['id']]['part_id']];row.update(prototype_path=p['path'],prototype_sha256=p['sha256'])
            sub['occurrences'][1]['name']='RENAMED'
            payload=dict(schema='SX35Z_NATIVE_INTERFACES_8',native_execution=True,subject_fingerprint=sub['fingerprint'],
                         scope='REFERENCE_CARRIER_ONLY',contract_sha256=digest(reference_checks()),measurements=measurements)
            self.assertEqual(inspect_artifact('interfaces',payload,sub)['status'],'STALE_OR_OTHER_MODEL')
    def test_guard_after_export_blocks_late_memory_change(self):
        from cnc_nx.dossier08 import run_for_current
        import exports.dossier08
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,built,raw,bb=fixture(d);out=d/'out';out.mkdir()
            real=exports.dossier08.export_dossier
            def mutate(*args):
                result=real(*args);session.Parts.Display.IsModified=True;return result
            with patch('cnc_nx.dossier08.export_dossier',side_effect=mutate):
                with self.assertRaises((RuntimeError,ValueError)):
                    run_for_current(session,FAKENX,out,lambda _:None,ApiEvidence(),[],dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=[]))
            self.assertFalse((out/'NX_Pruefdossier_08.json').exists())
    def test_suppressed_reference_part_is_not_inspected(self):
        from cnc_nx.inspection08 import read_reference_faces
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,built,raw,bb=fixture(d)
            session.Parts.Display.ComponentAssembly.RootComponent.children[0].IsSuppressed=True
            with patch('cnc_nx.inspection08._face_method',return_value=lambda t:raw[t]),patch('cnc_nx.inspection08.exact_bounds',side_effect=lambda p,b,e:bb[b.Tag]):
                with self.assertRaises((RuntimeError,ValueError)):
                    read_reference_faces(session,FAKENX,built,ApiEvidence(),lambda _:None)


class CLI08Tests(unittest.TestCase):
    def cli(self):
        p=Path(__file__).resolve().parents[1]/'Projekt08_Pruefdossier.py';self.assertTrue(p.exists(),'Offline CLI missing')
        spec=importlib.util.spec_from_file_location('cli08',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
    def test_preview_creates_no_native_geometry(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'preview';self.cli().main(['--preview','--output',str(out)])
            r=json.loads((out/'Pruefdossier_08.json').read_text());self.assertFalse(r['native_read_in_this_run'])
            self.assertEqual(r['status'],'PREVIEW_CHECK_PLAN_ONLY');self.assertFalse(list(out.rglob('*.prt')))
    def test_existing_output_refused(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(FileExistsError):self.cli().main(['--preview','--output',td])
    def test_replay_not_called_native_run(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);session,*_=fixture(d);snap=capture_with_positions(session,FAKENX,ApiEvidence(),lambda _:None)
            p=d/'snap.json';p.write_text(json.dumps(snap));out=d/'out'
            self.cli().main(['--snapshot',str(p),'--output',str(out)])
            r=json.loads((out/'Pruefdossier_08.json').read_text());self.assertFalse(r['native_read_in_this_run']);self.assertIsNotNone(r['subject'])
    def test_preview_does_not_accept_actual_artifacts(self):
        with tempfile.TemporaryDirectory() as td:
            cfg=Path(td)/'job.json';cfg.write_text('{"schema":"SX35Z_DOSSIER_JOB_8","artifacts":[]}')
            with self.assertRaises(ValueError):self.cli().main(['--preview','--config',str(cfg),'--output',str(Path(td)/'out')])

class EvidenceDocument08Tests(unittest.TestCase):
    def test_changed_linked_document_not_accepted_from_old_bom_flag(self):
        from test_dossier08 import snapshot_fixture
        from analysis.bom07 import summarize
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);snap=snapshot_fixture(d);sub=subject_from_snapshot(snap);r=summarize(snap);r['native_read_in_this_run']=True
            doc=d/'drawing.pdf';doc.write_bytes(b'FAKE_PDF_FIXTURE')
            r['rows'][0]['document_checks']=[dict(role='DRAWING_PDF',path=str(doc),sha256=sha256_file(doc),model_sha256=r['rows'][0]['prototype_sha256'],status='FILE_IDENTITY_CHECKED_NOT_APPROVED')]
            doc.write_bytes(b'CHANGED_PDF_FIXTURE')
            self.assertEqual(inspect_artifact('bom',r,sub)['status'],'STALE_OR_OTHER_MODEL')
    def test_wrong_drawing_model_binding_not_accepted(self):
        from test_dossier08 import snapshot_fixture
        from analysis.bom07 import summarize
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);snap=snapshot_fixture(d);sub=subject_from_snapshot(snap);r=summarize(snap);r['native_read_in_this_run']=True
            doc=d/'drawing.pdf';doc.write_bytes(b'FAKE_PDF_FIXTURE')
            r['rows'][0]['document_checks']=[dict(role='DRAWING_PDF',path=str(doc),sha256=sha256_file(doc),model_sha256='b'*64,status='FILE_IDENTITY_CHECKED_NOT_APPROVED')]
            self.assertEqual(inspect_artifact('bom',r,sub)['status'],'STALE_OR_OTHER_MODEL')
    def test_report_changed_during_evaluation_detected_before_return(self):
        from test_dossier08 import snapshot_fixture
        from analysis.bom07 import summarize
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);snap=snapshot_fixture(d);r=summarize(snap);r['native_read_in_this_run']=True
            p=d/'bom.json';p.write_text(json.dumps(r));spec=dict(role='bom',path=str(p),sha256=sha256_file(p))
            # Package reload tests intentionally purge project modules. Patch the
            # same module instance that is actually executed, not a stale import.
            module=importlib.import_module('validation.dossier08');original=module.inspect_artifact
            def mutate(*args):
                value=original(*args);p.write_text('{}');return value
            with patch.object(module,'inspect_artifact',side_effect=mutate):report=module.build_dossier(snap,[spec])
            self.assertEqual(report['status'],'BLOCKED');self.assertEqual(report['artifacts'][0]['status'],'UNREADABLE_OR_CHANGED')
