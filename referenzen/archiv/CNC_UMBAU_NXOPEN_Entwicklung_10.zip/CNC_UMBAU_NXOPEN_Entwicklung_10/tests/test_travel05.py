"""Offline orchestration tests; injected objects are NOT an NX runtime."""
import importlib,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch
from cnc_nx.runtime import ApiEvidence,sha256_file
from test_motion05 import fixture

def example():
 c=fixture();del c['axes']['Y']
 for component in c['components']:component['moving_axes']=[a for a in component['moving_axes'] if a!='Y']
 return c

class Travel05Tests(unittest.TestCase):
 def m(self):
  try:return importlib.import_module('cnc_nx.travel05')
  except ImportError:self.fail('travel05 not implemented')
 def protect(self,td):
  f=Path(td)/'source.prt';f.write_bytes(b'not-a-cad-file-test-seam')
  return {str(f):dict(part=N(IsModified=False),sha256=sha256_file(f))}
 def test_source_integrity_report_on_success(self):
  with tempfile.TemporaryDirectory() as td:
   state=self.protect(td)
   with self.m().protect_sources(state,Path(td)):pass
   rows=json.loads((Path(td)/'Quellschutz_05.json').read_text())
   self.assertTrue(rows['unchanged']);self.assertFalse(rows['saved_by_this_journal'])
 def test_source_integrity_report_on_exception(self):
  with tempfile.TemporaryDirectory() as td:
   state=self.protect(td)
   with self.assertRaisesRegex(ValueError,'abort'):
    with self.m().protect_sources(state,Path(td)):raise ValueError('abort')
   self.assertTrue((Path(td)/'Quellschutz_05.json').is_file())
 def test_modified_source_is_fatal_never_saved(self):
  with tempfile.TemporaryDirectory() as td:
   state=self.protect(td)
   with self.assertRaisesRegex(RuntimeError,'Source'):
    with self.m().protect_sources(state,Path(td)):next(iter(state.values()))['part'].IsModified=True
 def test_disk_change_is_fatal(self):
  with tempfile.TemporaryDirectory() as td:
   state=self.protect(td)
   with self.assertRaises(RuntimeError):
    with self.m().protect_sources(state,Path(td)):Path(next(iter(state))).write_bytes(b'changed')
 def test_missing_file_is_reported_not_repaired(self):
  with tempfile.TemporaryDirectory() as td:
   state=self.protect(td);f=Path(next(iter(state)))
   with self.assertRaises(RuntimeError):
    with self.m().protect_sources(state,Path(td)):f.unlink()
   self.assertFalse(f.exists());self.assertIn('error',json.loads((Path(td)/'Quellschutz_05.json').read_text())['sources'][0])
 def test_source_without_solid_rejected(self):
  with self.assertRaises(RuntimeError):self.m().solid_inventory(N(Bodies=[]))
 def test_sheet_body_not_silently_skipped(self):
  with self.assertRaises(RuntimeError):self.m().solid_inventory(N(Bodies=[N(IsSolidBody=False)]))
 def test_pose_inventory_checks_each_component(self):
  cfg=example();m=self.m();prototype=N(Bodies=[N(Tag=10,IsSolidBody=True)])
  states={c['path']:dict(part=prototype) for c in cfg['components']}
  occ=N(Tag=50);comp=N(FindOccurrence=lambda b:occ)
  with patch.object(m,'add_component',return_value=comp),patch.object(m,'exact_bounds',return_value=[0,0,0,1,1,1]):
   rows,handles=m.place_pose(cfg,{'X':0},states,N(),N(),ApiEvidence(),'ROWS')
   self.assertEqual(len(rows),len(cfg['components']));self.assertEqual(len(handles),len(cfg['components']))
 def test_missing_occurrence_is_fatal(self):
  cfg=example();m=self.m();states={c['path']:dict(part=N(Bodies=[N(IsSolidBody=True)])) for c in cfg['components']}
  with patch.object(m,'add_component',return_value=N(FindOccurrence=lambda b:None)):
   with self.assertRaises(RuntimeError):m.place_pose(cfg,{'X':0},states,N(),N(),ApiEvidence(),'ROWS')
 def test_measured_pose_bounds_must_match_translation(self):
  m=self.m();cfg=example();cfg['components'][0]['moving_axes']=['X']
  baseline=[dict(component=c['id'],body_index=0,bounds_mm=[0,0,0,1,1,1]) for c in cfg['components']]
  current=[dict(r) for r in baseline]
  with self.assertRaises(RuntimeError):m.check_pose_bounds(cfg,{'X':1},baseline,current)
 def test_missing_body_in_pose_cannot_pass(self):
  m=self.m();cfg=example();base=[dict(component=c['id'],body_index=0,bounds_mm=[0,0,0,1,1,1]) for c in cfg['components']]
  with self.assertRaises(RuntimeError):m.check_pose_bounds(cfg,{'X':0},base,base[:1])
 def test_correct_translation_is_accepted(self):
  m=self.m();cfg=example();cfg['components'][0]['moving_axes']=['X']
  base=[dict(component=c['id'],body_index=0,bounds_mm=[0,0,0,1,1,1]) for c in cfg['components']]
  from validation.motion05 import shift_bounds,translation
  current=[dict(r,bounds_mm=shift_bounds(r['bounds_mm'],translation(cfg,c,{'X':1}))) for r,c in zip(base,cfg['components'])]
  m.check_pose_bounds(cfg,{'X':1},base,current)
if __name__=='__main__':unittest.main()
