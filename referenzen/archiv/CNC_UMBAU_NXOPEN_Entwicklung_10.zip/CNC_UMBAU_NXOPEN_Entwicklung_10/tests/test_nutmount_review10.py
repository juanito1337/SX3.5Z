import copy,tempfile,unittest
from pathlib import Path
from construction.nutmount10 import block_recipe,reference_set
from engineering.nutmount10 import load_registry,load_cases
from cnc_nx.nutmount10 import source_registry
from cnc_nx.runtime import sha256_file

class Review10Tests(unittest.TestCase):
 def test_explicit_empty_registry_is_not_default(self):
  with self.assertRaises(ValueError):block_recipe('213500',{})
 def test_mount_file_tamper_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   data=reference_set();rows=[]
   for r in data['parts']:
    f=Path(d)/(r['id']+'.prt');f.write_bytes(b'SIMULATED_TEST_NOT_NX')
    rows.append(dict(id=r['id'],path=str(f),sha256=sha256_file(f),source=r['source']))
   reg=source_registry(data,rows);self.assertEqual(len(reg['entries']),8)
   self.assertEqual([e['order_number'] for e in reg['entries'] if e['item_id'].startswith('K10_')],['213500','213600'])
   mount=next(r for r in rows if r['id'].startswith('K10_'));Path(mount['path']).write_bytes(b'changed')
   with self.assertRaises(ValueError):source_registry(data,rows)
 def test_known_body_window_can_show_more_than_nut_length(self):
  c=load_cases();c[0]['nut_offset_mm']=35
  d=reference_set(cases=c);self.assertEqual(d['groups'][0]['resolved']['window']['known_body_length_mm'],87)
 def test_source_must_not_claim_known_foot_holes(self):
  r=load_registry();r['blocks']['213500']['foot_holes']=[dict(x=10,y=10,d=6.6)]
  with self.assertRaises(ValueError):block_recipe('213500',r)

if __name__=='__main__':unittest.main()
