import importlib.util,json,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class Entrypoints06Tests(unittest.TestCase):
 def tool(self):
  p=ROOT/'Projekt06_Zeichnungsvorschau.py';self.assertTrue(p.is_file(),'new preview CLI missing')
  s=importlib.util.spec_from_file_location('preview06_cli',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
 def test_journal_connected_to_router(self):
  p=ROOT/'NX_17_Zeichnungsentwuerfe.py';self.assertTrue(p.is_file())
  self.assertIn("'drawings06'",p.read_text());self.assertIn("'drawings06'",(ROOT/'main.py').read_text())
 def test_preview_cli_no_overwrite(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(FileExistsError):self.tool().main(['--output',td])
 def test_cli_rejects_relative_output(self):
  with self.assertRaises(ValueError):self.tool().main(['--output','relative_preview'])
 def test_native_job_selects_known_four_parts(self):
  from cnc_nx.drawings06 import select_specs
  job=json.loads((ROOT/'config'/'drawings06.json').read_text())
  self.assertEqual(len(select_specs(job)),4);self.assertTrue(job['export_pdf'])
 def test_cli_creates_non_native_report(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'preview';self.tool().main(['--output',str(p)])
   r=json.loads((p/'Vorschau_Bericht_06.json').read_text())
   self.assertFalse(r['native_execution']);self.assertEqual(r['part_count'],4)
if __name__=='__main__':unittest.main()
