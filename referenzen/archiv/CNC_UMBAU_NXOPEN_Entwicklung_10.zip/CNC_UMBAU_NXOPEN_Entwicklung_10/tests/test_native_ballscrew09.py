"""Simulated NX seams only. These tests do NOT execute a CAD kernel."""
import copy
import importlib
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch
from construction.ballscrew09 import reference_set,envelope_metrics
from cnc_nx.build03 import RecipeBuilder


def module():return importlib.import_module('cnc_nx.ballscrew09')

class Probe09Tests(unittest.TestCase):
    def seam(self,role):
        r=next(p for p in reference_set()['parts'] if p['role']==role)
        b=RecipeBuilder.__new__(RecipeBuilder);b.part=N();b.evidence=N()
        b.expressions={k:N(RightHandSide=str(v)) for k,v in r['parameters'].items()}
        b.nx=N(Session=N(MarkVisibility=N(Invisible=0)))
        session=N(SetUndoMark=lambda *a:7,UpdateManager=N(DoUpdate=lambda *a:0))
        final=N(GetBodies=lambda:[object()]);return r,b,session,final
    def metrics(self,r,b):
        return envelope_metrics({k:float(v.RightHandSide) for k,v in b.expressions.items()},r['role'])
    def test_new_type_length_and_diameter_probes_restored(self):
        for role in ('screw','nut'):
            r,b,s,f=self.seam(role);before=copy.deepcopy(r['parameters'])
            with patch('cnc_nx.build03.volume',side_effect=lambda *a:self.metrics(r,b)['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',side_effect=lambda *a:self.metrics(r,b)['bounds_mm']):
                result=b.test_parameter(s,r,f)
            self.assertEqual(len(result['probes']),2)
            self.assertEqual(result['status'],'PASSED_IN_THIS_NX_RUN')
            self.assertTrue(result['restored_to_nominal'])
            self.assertEqual({k:float(v.RightHandSide) for k,v in b.expressions.items()},before)
    def test_stale_volume_fails_and_restores(self):
        r,b,s,f=self.seam('nut')
        with patch('cnc_nx.build03.volume',return_value=r['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',side_effect=lambda *a:self.metrics(r,b)['bounds_mm']):
            with self.assertRaises(RuntimeError):b.test_parameter(s,r,f)
        self.assertEqual(float(b.expressions['length'].RightHandSide),50)
    def test_wrong_bounds_fail_despite_correct_volume(self):
        r,b,s,f=self.seam('nut')
        with patch('cnc_nx.build03.volume',side_effect=lambda *a:self.metrics(r,b)['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',return_value=[0,0,0,1,1,1]):
            with self.assertRaises(RuntimeError):b.test_parameter(s,r,f)
    def test_nx_update_error_fails_and_restores(self):
        r,b,s,f=self.seam('screw');s.UpdateManager.DoUpdate=N(__call__=None)
        calls=[]
        def update(*a):calls.append(1);return 1 if len(calls)==1 else 0
        s.UpdateManager.DoUpdate=update
        with patch('cnc_nx.build03.volume',side_effect=lambda *a:self.metrics(r,b)['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',side_effect=lambda *a:self.metrics(r,b)['bounds_mm']):
            with self.assertRaises(RuntimeError):b.test_parameter(s,r,f)
        self.assertEqual(float(b.expressions['length'].RightHandSide),352)
    def test_native_execution_not_claimed_offline(self):
        self.assertFalse(module().NATIVE_EXECUTED_BY_AUTHOR)

class Sample09Tests(unittest.TestCase):
    def sample(self,name='MIN'):
        p=reference_set()['pairs'][0];s=next(s for s in p['axial_samples'] if s['name']==name)
        return p,s,[-8,-8,0,8,8,352],[-14,-14,s['nut_start_mm'],14,14,s['nut_end_mm']]
    def test_each_endpoint_measured_at_its_true_expected_origin(self):
        for name in ('MIN','REFERENCE','MAX'):
            p,s,sb,nb=self.sample(name);r=module().validate_axial_sample(p,s,sb,nb)
            self.assertEqual(r['status'],'PASSED_NOMINAL_ENVELOPE_POSITION')
            self.assertFalse(r['collision_checked'])
    def test_shifted_nut_is_rejected(self):
        p,s,sb,nb=self.sample();nb[2]+=.1;nb[5]+=.1
        with self.assertRaises(RuntimeError):module().validate_axial_sample(p,s,sb,nb)
    def test_offset_screw_axis_rejected(self):
        p,s,sb,nb=self.sample();sb[0]+=.1;sb[3]+=.1
        with self.assertRaises(RuntimeError):module().validate_axial_sample(p,s,sb,nb)
    def test_changed_actual_nut_length_rejected(self):
        p,s,sb,nb=self.sample();nb[5]-=1
        with self.assertRaises(RuntimeError):module().validate_axial_sample(p,s,sb,nb)
    def test_nan_not_accepted_as_matching_envelope(self):
        p,s,sb,nb=self.sample();nb[2]=float('nan')
        with self.assertRaises((ValueError,RuntimeError)):module().validate_axial_sample(p,s,sb,nb)
    def test_wrong_sample_or_altered_expected_position_rejected(self):
        p,s,sb,nb=self.sample();s=copy.deepcopy(s);s['nut_start_mm']+=1
        with self.assertRaises(ValueError):module().validate_axial_sample(p,s,sb,nb)
    def test_native_report_cannot_be_created_by_pure_inputs(self):
        p,s,sb,nb=self.sample();r=module().validate_axial_sample(p,s,sb,nb)
        self.assertNotIn('native_execution',r)
        self.assertFalse(r['physical_machine_verified'])

class SourceGuard09Tests(unittest.TestCase):
    def test_unchanged_source_files_pass(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'source.json';p.write_text('{}')
            state=module().capture_sources([p]);module().verify_sources(state)
    def test_changed_source_not_silently_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'source.json';p.write_text('{}')
            state=module().capture_sources([p]);p.write_text('{"new":1}')
            with self.assertRaises(RuntimeError):module().verify_sources(state)
    def test_deleted_source_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'source.json';p.write_text('{}')
            state=module().capture_sources([p]);p.unlink()
            with self.assertRaises(RuntimeError):module().verify_sources(state)
    def test_empty_sources_not_accepted(self):
        with self.assertRaises(ValueError):module().capture_sources([])
    def test_original_cad_and_release_flags_stay_false(self):
        from construction.ballscrew09 import reference_set
        data=reference_set()
        for r in data['parts']:
            self.assertFalse(r['manufacturer_original_cad']);self.assertFalse(r['order_released'])

if __name__=='__main__':unittest.main()
