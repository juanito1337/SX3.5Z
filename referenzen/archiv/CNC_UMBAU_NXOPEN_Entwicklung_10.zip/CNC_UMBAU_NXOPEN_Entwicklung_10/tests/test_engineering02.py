import importlib.util, math, unittest

class Engineering02(unittest.TestCase):
    def module(self,name):
        self.assertIsNotNone(importlib.util.find_spec(name),'Missing production module '+name)
        return __import__(name,fromlist=['_'])
    def test_transmission_rpm_and_scale(self):
        e=self.module('engineering.sizing')
        r=e.transmission(5,2,1500,200,16)
        self.assertEqual(r['screw_rpm'],300)
        self.assertEqual(r['motor_rpm'],600)
        self.assertEqual(r['steps_per_mm'],1280)
        self.assertEqual(r['pulse_hz'],32000)
    def test_ratio_rejects_zero_bool_nan(self):
        e=self.module('engineering.sizing')
        for ratio in [0,True,float('nan'),float('inf'),-2]:
            with self.subTest(ratio=ratio),self.assertRaises(ValueError):e.transmission(5,ratio,1500,200,16)
    def test_horizontal_force_and_inertia_not_double_counted(self):
        e=self.module('engineering.sizing')
        r=e.load_case(mass_kg=10,accel_mm_s2=100,cut_force_n=100,friction_n=20,
            lead_mm=5,ratio=1,screw_efficiency=1,transmission_efficiency=1,
            screw_inertia_kg_m2=0,motor_inertia_kg_m2=0,vertical=False)
        self.assertAlmostEqual(r['axial_force_n'],121)
        self.assertAlmostEqual(r['motor_torque_nm'],121*.005/(2*math.pi))
    def test_vertical_load_includes_gravity(self):
        e=self.module('engineering.sizing')
        r=e.load_case(mass_kg=10,accel_mm_s2=0,cut_force_n=0,friction_n=0,
            lead_mm=5,ratio=2,screw_efficiency=1,transmission_efficiency=1,
            screw_inertia_kg_m2=0,motor_inertia_kg_m2=0,vertical=True)
        self.assertAlmostEqual(r['axial_force_n'],98.0665)
        self.assertAlmostEqual(r['motor_torque_nm'],98.0665*.005/(4*math.pi))
    def test_efficiency_out_of_range_rejected(self):
        e=self.module('engineering.sizing')
        with self.assertRaises(ValueError):
            e.load_case(10,10,10,10,5,1,1.1,1,0,0,False)
    def test_curve_no_extrapolation(self):
        e=self.module('engineering.sizing')
        self.assertAlmostEqual(e.curve_torque([[0,3],[500,2]],250),2.5)
        with self.assertRaises(ValueError):e.curve_torque([[0,3],[500,2]],600)
        with self.assertRaises(ValueError):e.curve_torque([[500,2],[0,3]],250)
    def test_stopping_reserve(self):
        e=self.module('engineering.sizing')
        self.assertAlmostEqual(e.stopping_distance(25,200,.02,2),4.0625)
    def test_frames_round_trip_and_mirror_rejection(self):
        f=self.module('assembly.position_components')
        R=[[0,-1,0],[1,0,0],[0,0,1]];p=[3,4,5];t=[10,20,30]
        out=f.transform_point(R,t,p)
        self.assertEqual(out,[6,23,35])
        self.assertEqual(f.inverse_point(R,t,out),p)
        with self.assertRaises(ValueError):f.transform_point([[-1,0,0],[0,1,0],[0,0,1]],t,p)
    def test_coaxiality_signed_axis_and_offset(self):
        f=self.module('validation.check_component_positions')
        r=f.axis_alignment([0,0,0],[0,0,1],[.05,0,20],[0,0,-1])
        self.assertAlmostEqual(r['angle_deg'],0)
        self.assertAlmostEqual(r['offset_mm_at_reference'],.05)
    def test_travel_interval(self):
        t=self.module('validation.check_travel_limits')
        r=t.nut_interval(600,40,10,10)
        self.assertEqual(r,{'min_leading_edge_mm':10.,'max_leading_edge_mm':550.,'usable_travel_mm':540.})
        with self.assertRaises(ValueError):t.nut_interval(50,45,5,5)
    def test_sampling_is_not_collision_pass(self):
        t=self.module('validation.check_travel_limits')
        r=t.sample_grid({'X':[0,10],'Y':[0,2],'Z':[0,5]},3)
        self.assertEqual(len(r['poses']),27)
        self.assertEqual(r['collision_status'],'NOT_RUN')
        self.assertFalse(r['continuous_sweep_proven'])
    def test_absent_torque_curve_does_not_approve_motor(self):
        e=self.module('engineering.sizing')
        self.assertEqual(e.motor_check(.5,600,None,1.5)['status'],'NOT_EVALUATED')

if __name__=='__main__':unittest.main()
