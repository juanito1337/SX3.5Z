import copy
import importlib
import math
import unittest


def m():return importlib.import_module('construction.ballscrew09')

class Recipe09Tests(unittest.TestCase):
    def data(self):return m().reference_set()
    def test_three_pairs_six_unique_leaf_parts(self):
        d=self.data()
        self.assertEqual(len(d['pairs']),3)
        self.assertEqual(len(d['parts']),6)
        self.assertEqual(len({r['id'] for r in d['parts']}),6)
    def test_each_pair_has_nut_and_screw_no_invented_supports(self):
        for pair in self.data()['pairs']:
            self.assertEqual({c['role'] for c in pair['components']},{'screw','nut'})
            self.assertEqual(len(pair['components']),2)
            self.assertFalse(pair['machine_fit_verified'])
    def test_nominal_external_envelopes(self):
        for r in self.data()['parts']:
            c=m().contract(r);p=r['parameters']
            self.assertEqual(c['bounds_mm'],[-p['outer_d']/2,-p['outer_d']/2,0,p['outer_d']/2,p['outer_d']/2,p['length']])
    def test_nut_volume_is_visual_annulus_not_actual_component_mass(self):
        r=next(p for p in self.data()['parts'] if p['role']=='nut' and p['catalogue']['article_number']=='213505')
        self.assertAlmostEqual(m().contract(r)['expected_volume_mm3'],math.pi*(28**2-16**2)*50/4)
        self.assertFalse(r['mass_properties_represent_physical_part'])
        self.assertFalse(r['contact_geometry_verified'])
    def test_nut_inner_diameter_explicitly_unsourced(self):
        r=next(p for p in self.data()['parts'] if p['role']=='nut')
        self.assertEqual(r['parameter_provenance']['visual_bore_d'],'DISPLAY_ONLY_EQUALS_NOMINAL_SCREW_DIAMETER_NOT_ACTUAL_BORE')
    def test_screw_bearing_ends_not_created(self):
        for r in self.data()['parts']:
            if r['role']=='screw':
                self.assertEqual(len(r['ops']),1)
                self.assertEqual(r['end_condition'],'UNMACHINED')
                self.assertIsNone(r['catalogue']['article_number'])
    def test_old_recipe_adapter_accepts_new_known_type(self):
        from construction.recipes03 import validate_recipe
        from cnc_nx.build03 import numeric_operations
        for r in self.data()['parts']:
            self.assertEqual(validate_recipe(r)['id'],r['id'])
            self.assertEqual(len(numeric_operations(r)),len(r['ops']))
    def test_tampered_outer_diameter_not_still_catalogue_verified(self):
        r=self.data()['parts'][0];r['parameters']['outer_d']+=1
        with self.assertRaises(ValueError):m().contract(r)
    def test_injected_extra_cut_rejected(self):
        r=self.data()['parts'][0];r['ops'].append(copy.deepcopy(r['ops'][0]))
        with self.assertRaises(ValueError):m().contract(r)
    def test_change_in_original_cad_claim_rejected(self):
        r=self.data()['parts'][0];r['manufacturer_original_cad']=True
        with self.assertRaises(ValueError):m().contract(r)
    def test_expected_volume_not_trusted_if_tampered(self):
        r=self.data()['parts'][0];r['expected_volume_mm3']+=10
        with self.assertRaises(ValueError):m().contract(r)
    def test_unknown_kind_rejected(self):
        r=self.data()['parts'][0];r['kind']='made_up'
        with self.assertRaises(ValueError):m().contract(r)
    def test_parameters_checked_by_analytic_change_without_mutating_source(self):
        for r in self.data()['parts']:
            before=copy.deepcopy(r);probes=m().parameter_probes(r)
            self.assertGreaterEqual(len(probes),2)
            self.assertTrue(any(x['parameter']=='length' for x in probes))
            self.assertEqual(r,before)
            for p in probes:self.assertGreater(p['changed_volume_mm3'],0)
    def test_longer_body_increases_model_volume(self):
        for r in self.data()['parts']:
            p=next(x for x in m().parameter_probes(r) if x['parameter']=='length')
            self.assertGreater(p['changed_volume_mm3'],r['expected_volume_mm3'])
            self.assertEqual(p['changed_bounds_mm'][-1],r['parameters']['length']+1)
    def test_wider_visual_bore_removes_model_volume(self):
        r=next(p for p in self.data()['parts'] if p['role']=='nut')
        p=next(x for x in m().parameter_probes(r) if x['parameter']=='visual_bore_d')
        self.assertLess(p['changed_volume_mm3'],r['expected_volume_mm3'])
    def test_two_16mm_nuts_remain_separate_articles(self):
        nuts=[p for p in self.data()['parts'] if p['role']=='nut' and p['parameters']['outer_d']==28]
        self.assertEqual({r['catalogue']['article_number'] for r in nuts},{'213514','213505'})
        self.assertNotEqual(nuts[0]['id'],nuts[1]['id'])
    def test_poses_align_nut_and_shaft_axes_without_machine_position(self):
        d=self.data();parts={p['id']:p for p in d['parts']}
        for pair in d['pairs']:
            n=next(c for c in pair['components'] if c['role']=='nut')
            s=next(c for c in pair['components'] if c['role']=='screw')
            self.assertEqual(n['origin_mm'][:2],[0.,0.]);self.assertEqual(s['origin_mm'],[0.,0.,0.])
            length=parts[n['part_id']]['parameters']['length']
            self.assertEqual(n['origin_mm'][2]+length/2,pair['resolved']['window']['reference_center_mm'])
            self.assertEqual(pair['frame'],'STUDY_LOCAL_Z_NOT_MACHINE_COORDINATES')
    def test_three_axial_samples_fit_raw_span(self):
        for pair in self.data()['pairs']:
            samples=pair['axial_samples']
            self.assertEqual(len(samples),3)
            self.assertEqual(samples[0]['name'],'MIN')
            self.assertEqual(samples[-1]['name'],'MAX')
            self.assertTrue(all(p['nut_start_mm']>=0 and p['nut_end_mm']<=pair['resolved']['stock_length_mm'] for p in samples))
    def test_bearing_and_clearance_checks_are_not_claimed(self):
        d=self.data()
        self.assertFalse(d['bearing_support_verified'])
        self.assertFalse(d['full_collision_checked'])
        self.assertFalse(d['manufacturer_original_cad'])
    def test_zero_stock_change_keeps_no_old_tables_mutated(self):
        from construction.recipes03 import reference_carrier
        before=reference_carrier();self.data()
        self.assertEqual(before,reference_carrier())
    def test_case_change_creates_correct_stock_parameters(self):
        from engineering.ballscrew09 import load_cases
        cases=load_cases();cases[0]['stock_length_mm']=452;cases[0]['nut_center_mm']=226
        d=m().reference_set(cases=cases)
        shaft=next(p for p in d['parts'] if p['id']==d['pairs'][0]['components'][0]['part_id'])
        self.assertEqual(shaft['parameters']['length'],452)
        self.assertEqual(d['pairs'][0]['resolved']['window']['span_mm'],382)

if __name__=='__main__':unittest.main()
