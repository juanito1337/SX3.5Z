"""NX boundary fakes exercise program flow only. They do NOT prove NX API compatibility."""
import importlib,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
from cnc_nx.runtime import ApiEvidence
from analysis.bom07 import summarize

class FakePart:
    def __init__(self,folder,name,bodies):
        self.Tag=id(self);self.Name=name;self.FullPath=str(folder/(name+'.prt'))
        Path(self.FullPath).write_bytes(('FAKE_NX_PART_FIXTURE_'+name).encode())
        self.IsFullyLoaded=True;self.IsModified=False;self.Bodies=[NS(IsSolidBody=s) for s in bodies]
        self.ComponentAssembly=NS(RootComponent=None)
    def Save(self,*a):raise AssertionError('Saving originals is forbidden')

class FakeComp:
    def __init__(self,part,children=(),suppressed=False):
        self.Tag=id(self);self.Prototype=part;self.Name=part.Name;self.IsSuppressed=suppressed
        self.ReferenceSet='Entire Part';self.children=list(children)
    def GetChildren(self):return self.children

class NativeBOMTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.d=Path(self.tmp.name)
        self.root=FakePart(self.d,'root',[]);self.leaf=FakePart(self.d,'leaf',[True])
        self.a=FakeComp(self.leaf);self.b=FakeComp(self.leaf)
        self.component=FakeComp(self.root,[self.a,self.b]);self.root.ComponentAssembly.RootComponent=self.component
        self.session=NS(Parts=NS(Display=self.root));self.evidence=ApiEvidence()
    def m(self):
        try:return importlib.import_module('cnc_nx.bom07')
        except ImportError:self.fail('Read-only native BOM capture is missing')
    def capture(self):return self.m().capture(self.session,self.evidence,lambda _:None)
    def test_capture_two_occurrences_one_prototype(self):
        s=self.capture();r=summarize(s);self.assertEqual(r['counts']['active_leaf_occurrences'],2)
        self.assertEqual(len(s['prototypes']),2);self.assertEqual(len(s['occurrences']),3)
    def test_no_geometry_api_or_save_needed(self):
        s=self.capture();self.assertFalse(s['integrity_failure']);self.assertEqual(len(self.evidence.rows)>0,True)
        self.assertNotIn('BasePart.Save',self.evidence.rows)
    def test_files_unchanged(self):
        before={p.name:p.read_bytes() for p in self.d.iterdir()};self.capture()
        self.assertEqual(before,{p.name:p.read_bytes() for p in self.d.iterdir()})
    def test_modified_before_stays_unbound_and_is_not_saved(self):
        self.leaf.IsModified=True;s=self.capture();self.assertTrue(self.leaf.IsModified)
        self.assertFalse(summarize(s)['source_binding_complete'])
    def test_file_mutation_during_read_is_integrity_failure(self):
        def change():
            Path(self.root.FullPath).write_bytes(b'external change');return self.component.children
        self.component.GetChildren=change
        self.assertTrue(self.capture()['integrity_failure'])
    def test_new_dirty_flag_during_read_is_integrity_failure(self):
        def change():self.root.IsModified=True;return self.component.children
        self.component.GetChildren=change
        self.assertTrue(self.capture()['integrity_failure'])
    def test_unloaded_branch_not_read_or_loaded(self):
        self.root.IsFullyLoaded=False
        def bad():self.fail('GetChildren on unloaded source')
        self.component.GetChildren=bad;s=self.capture();r=summarize(s)
        self.assertFalse(r['inventory_complete']);self.assertEqual(r['rows'],[])
    def test_suppressed_branch_does_not_access_bad_prototype(self):
        class Suppressed:
            Tag=999;Name='suppressed';IsSuppressed=True;ReferenceSet='Empty'
            @property
            def Prototype(self):raise AssertionError('Suppressed prototype must not be touched')
            def GetChildren(self):raise AssertionError('Suppressed children must not be touched')
        self.component.children=[Suppressed(),self.b]
        r=summarize(self.capture());self.assertEqual(r['counts']['active_leaf_occurrences'],1)
        self.assertTrue(r['inventory_complete'])
    def test_unknown_suppression_is_partial(self):
        self.a.IsSuppressed=None;r=summarize(self.capture());self.assertFalse(r['inventory_complete'])
    def test_getchildren_failure_is_not_leaf(self):
        def bad():raise RuntimeError('loading problem')
        self.a.GetChildren=bad;r=summarize(self.capture())
        self.assertFalse(r['inventory_complete']);self.assertEqual(r['counts']['active_leaf_occurrences'],1)
    def test_body_read_failure_is_not_empty_success(self):
        self.leaf.Bodies=None;r=summarize(self.capture());self.assertFalse(r['inventory_complete'])
    def test_non_boolean_solid_flag_not_coerced(self):
        self.leaf.Bodies=[NS(IsSolidBody='False')];r=summarize(self.capture())
        self.assertFalse(r['inventory_complete'])
    def test_unknown_modified_flag_not_coerced(self):
        self.leaf.IsModified=None;r=summarize(self.capture());self.assertFalse(r['source_binding_complete'])
    def test_missing_native_file_not_guessed(self):
        Path(self.leaf.FullPath).unlink();r=summarize(self.capture());self.assertFalse(r['source_binding_complete'])
    def test_cycle_is_diagnostic_no_recursion(self):
        self.component.children=[self.component]
        s=self.capture();r=summarize(s);self.assertFalse(r['inventory_complete'])
    def test_repeated_subassembly_occurrences_are_counted(self):
        sub=FakePart(self.d,'sub',[]);branch=FakeComp(sub,[self.a,self.b]);self.component.children=[branch,branch]
        r=summarize(self.capture());self.assertEqual(r['rows'][0]['quantity'],4)
    def test_single_part_without_root_is_supported(self):
        self.session.Parts.Display=self.leaf
        r=summarize(self.capture());self.assertEqual(r['counts']['active_leaf_occurrences'],1)
    def test_no_displayed_part_clear_error(self):
        self.session.Parts.Display=None
        with self.assertRaises(RuntimeError):self.capture()
    def test_reference_set_not_used_as_visibility_filter(self):
        self.a.ReferenceSet='Empty';r=summarize(self.capture());self.assertEqual(r['rows'][0]['quantity'],2)
    def test_two_files_same_display_name_remain_separate(self):
        other=FakePart(self.d,'other',[True]);other.Name='leaf';self.component.children=[self.a,FakeComp(other)]
        r=summarize(self.capture());self.assertEqual(len(r['rows']),2)
    def test_non_solid_body_counted_without_assuming_sheet_topology(self):
        self.leaf.Bodies=[NS(IsSolidBody=False)];r=summarize(self.capture())
        self.assertEqual(r['rows'][0]['non_solid_body_count'],1);self.assertEqual(r['rows'][0]['quantity'],2)
    def test_root_scan_bounds_limit(self):
        with self.assertRaises(ValueError):self.m().capture(self.session,self.evidence,lambda _:None,max_occurrences=0)
    def test_depth_limit_reports_partial(self):
        s=self.m().capture(self.session,self.evidence,lambda _:None,max_depth=0)
        self.assertFalse(summarize(s)['inventory_complete'])
    def test_changed_loaded_part_path_is_integrity_failure(self):
        other=self.d/'renamed.prt';other.write_bytes(Path(self.root.FullPath).read_bytes())
        def change():self.root.FullPath=str(other);return self.component.children
        self.component.GetChildren=change
        self.assertTrue(self.capture()['integrity_failure'])
