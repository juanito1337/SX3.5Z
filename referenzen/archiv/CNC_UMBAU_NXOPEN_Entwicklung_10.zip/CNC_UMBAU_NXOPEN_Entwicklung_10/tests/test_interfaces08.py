"""Synthetic analytic surfaces, not NX execution or generated CAD."""
import copy, importlib, math, unittest
from construction.recipes03 import reference_carrier


def cylinder(x=0.,y=0.,r=5.,z0=0.,z1=10.,direction=(0.,0.,1.),name='c'):
    return dict(journal_id=name,uf_type_code=16,point_raw=[x,y,z0],direction_raw=list(direction),
                radius_part_units=r,bounds_raw=[x-r,y-r,z0,x+r,y+r,z1])


def plane(z=0.,name='p'):
    return dict(journal_id=name,uf_type_code=22,point_raw=[0.,0.,z],direction_raw=[0.,0.,1.],
                radius_part_units=0.,bounds_raw=[-45.,-45.,z,45.,45.,z])


def synthetic_measurements():
    """Test fixture only: faces analytically reconstructed from existing recipes."""
    data=reference_carrier();recipes={r['id']:r for r in data['parts']};out=[]
    for c in data['components']:
        r=recipes[c['part_id']];p=r['parameters'];faces=[]
        if r['kind']=='motor_envelope':
            faces=[cylinder(r=p['pilot_d']/2,z0=-p['pilot_h'],z1=0.,name='pilot'),
                   cylinder(r=p['shaft_d']/2,z0=-p['shaft_l'],z1=-p['pilot_h'],name='shaft'),plane(0.,'mount')]
            for i,(x,y) in enumerate(( (x,y) for x in (-p['hole_pitch']/2,p['hole_pitch']/2) for y in (-p['hole_pitch']/2,p['hole_pitch']/2) )):
                faces.append(cylinder(x,y,p['hole_d']/2,0.,p['flange_t'],name='hole'+str(i)))
        elif r['kind']=='flange_holder':
            faces=[plane(0.,'front'),plane(p['thickness'],'rear'),cylinder(r=p['center_bore']/2,z1=p['thickness'],name='center')]
            for k in sorted(p):
                if k.startswith('hole_') and k.endswith('_d'):
                    stem=k[:-2];faces.append(cylinder(p[stem+'_x'],p[stem+'_y'],p[k]/2,0.,p['thickness'],name=stem))
        else:
            faces=[cylinder(r=p['inner_d']/2,z1=p['length'],name='bore'),
                   cylinder(r=p['outer_d']/2,z1=p['length'],name='outside'),plane(0.,'bottom'),plane(p['length'],'top')]
        out.append(dict(id=c['id'],translation_mm=copy.deepcopy(c['origin_mm']),rotation=copy.deepcopy(c['rotation']),faces=faces))
    return out


class Interfaces08Tests(unittest.TestCase):
    def m(self):
        try:return importlib.import_module('validation.interfaces08')
        except ImportError:self.fail('Missing interface inspection implementation')
    def test_parallel_axes_offset_measured(self):
        r=self.m().axis_metrics([0,0,0],[0,0,1],[.2,0,8],[0,0,1]);self.assertAlmostEqual(r['offset_mm'],.2)
    def test_antiparallel_is_same_axis(self):
        r=self.m().axis_metrics([0,0,0],[0,0,1],[0,0,8],[0,0,-1]);self.assertAlmostEqual(r['angle_deg'],0);self.assertEqual(r['offset_mm'],0)
    def test_tilt_is_detected(self):
        r=self.m().axis_metrics([0,0,0],[0,0,1],[0,0,0],[.1,0,1]);self.assertGreater(r['angle_deg'],5.)
    def test_zero_direction_rejected(self):
        with self.assertRaises(ValueError):self.m().axis_metrics([0,0,0],[0,0,0],[0,0,0],[0,0,1])
    def test_nonfinite_and_boolean_rejected(self):
        for x in (math.nan,math.inf,True):
            with self.subTest(x=x),self.assertRaises(ValueError):self.m().axis_metrics([x,0,0],[0,0,1],[0,0,0],[0,0,1])
    def test_select_by_axis_and_station_not_first_face(self):
        fs=[cylinder(r=5.,z0=11,z1=20,name='upper'),cylinder(name='wanted')]
        x=self.m().select_cylinder(fs,dict(center_xy=[0,0],radius_mm=5.,station_z_mm=5.))
        self.assertEqual(x['journal_id'],'wanted')
    def test_ambiguous_surface_rejected(self):
        with self.assertRaises(ValueError):self.m().select_cylinder([cylinder(),cylinder(name='other')],dict(center_xy=[0,0],radius_mm=5.,station_z_mm=5.))
    def test_missing_surface_rejected(self):
        with self.assertRaises(ValueError):self.m().select_cylinder([],dict(center_xy=[0,0],radius_mm=5.,station_z_mm=5.))
    def test_non_cylinder_not_accepted(self):
        x=cylinder();x['uf_type_code']=17
        with self.assertRaises(ValueError):self.m().select_cylinder([x],dict(center_xy=[0,0],radius_mm=5.,station_z_mm=5.))
    def test_select_plane(self):
        self.assertEqual(self.m().select_plane([plane(0),plane(12,'back')],12)['journal_id'],'back')
    def test_plane_ambiguity_rejected(self):
        with self.assertRaises(ValueError):self.m().select_plane([plane(),plane(name='duplicate')],0)
    def test_reference_contract_is_nonempty_unique(self):
        rows=self.m().reference_checks();self.assertGreaterEqual(len(rows),20);self.assertEqual(len(rows),len({r['id'] for r in rows}))
    def test_nominal_synthetic_measurements_within_limits(self):
        r=self.m().evaluate_reference(synthetic_measurements());self.assertTrue(r['all_within_limits'])
        self.assertTrue(all(c['status']=='WITHIN_MODEL_CHECK_LIMIT' for c in r['checks']))
        self.assertFalse(r['manufacturing_released']);self.assertFalse(r['physical_measurement'])
    def test_expected_diameter_clearance_is_point_two(self):
        r=self.m().evaluate_reference(synthetic_measurements());c=next(x for x in r['checks'] if x['id']=='PILOT_DIAMETER_CLEARANCE')
        self.assertAlmostEqual(c['measured']['diametral_clearance_mm'],.2)
    def test_shifted_motor_fails_axis_and_mount_holes(self):
        rows=synthetic_measurements();rows[0]['translation_mm'][0]=.1
        r=self.m().evaluate_reference(rows);self.assertFalse(r['all_within_limits'])
        failures=[x for x in r['checks'] if x['status']=='OUTSIDE_MODEL_CHECK_LIMIT'];self.assertGreaterEqual(len(failures),5)
    def test_wrong_spacer_length_fails_axial_contact(self):
        rows=synthetic_measurements();row=next(x for x in rows if x['id']=='spacer_0')
        next(f for f in row['faces'] if f['journal_id']=='top')['point_raw'][2]=49.9
        r=self.m().evaluate_reference(rows);self.assertFalse(r['all_within_limits'])
        self.assertTrue(any(x['kind']=='plane_gap' and x['status']=='OUTSIDE_MODEL_CHECK_LIMIT' for x in r['checks']))
    def test_missing_spacer_is_not_pass(self):
        rows=synthetic_measurements();rows.pop()
        r=self.m().evaluate_reference(rows);self.assertFalse(r['all_within_limits']);self.assertGreater(r['error_count'],0)
    def test_duplicate_component_rejected(self):
        rows=synthetic_measurements();rows.append(copy.deepcopy(rows[0]))
        with self.assertRaises(ValueError):self.m().evaluate_reference(rows)
    def test_extra_component_rejected(self):
        rows=synthetic_measurements();x=copy.deepcopy(rows[0]);x['id']='extra';rows.append(x)
        with self.assertRaises(ValueError):self.m().evaluate_reference(rows)
    def test_absent_face_records_error_not_skip(self):
        rows=synthetic_measurements();rows[0]['faces']=[]
        r=self.m().evaluate_reference(rows);self.assertFalse(r['all_within_limits']);self.assertGreater(r['error_count'],0)
    def test_whole_rigid_transform_preserves_metrics(self):
        rows=synthetic_measurements();R=[[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]]
        for row in rows:
            x,y,z=row['translation_mm'];row['rotation']=R;row['translation_mm']=[-y+100.,x+200.,z+300.]
        self.assertTrue(self.m().evaluate_reference(rows)['all_within_limits'])
    def test_positive_gap_reported_not_contact(self):
        rows=synthetic_measurements();rows[0]['translation_mm'][2]+=.1
        r=self.m().evaluate_reference(rows);c=next(x for x in r['checks'] if x['id']=='MOTOR_FLANGE_CONTACT')
        self.assertEqual(c['status'],'OUTSIDE_MODEL_CHECK_LIMIT');self.assertAlmostEqual(abs(c['measured']['gap_mm']),.1)
    def test_bad_rotation_not_interpreted_as_valid(self):
        rows=synthetic_measurements();rows[0]['rotation']=[[2,0,0],[0,1,0],[0,0,1]]
        with self.assertRaises(ValueError):self.m().evaluate_reference(rows)
    def test_inputs_not_mutated(self):
        rows=synthetic_measurements();before=copy.deepcopy(rows);self.m().evaluate_reference(rows);self.assertEqual(rows,before)
