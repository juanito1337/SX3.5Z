"""Adversarial regression cases found in author self-review."""
import unittest
from types import SimpleNamespace as N
from cnc_nx.runtime import ApiEvidence
from cnc_nx.interference05 import KernelBinding,temporary_occurrences
from validation.motion05 import summarize

class Review05Tests(unittest.TestCase):
 def test_unknown_status_cannot_be_summarized_as_pass(self):
  for status in ['SKIPPED','NOT_EXECUTED','TYPO']:
   with self.subTest(status=status),self.assertRaises(ValueError):summarize([dict(status=status)],True)
 def test_tag_must_be_integer_before_native_call(self):
  calls=[]
  def fn(targ,num_tools,tools):calls.append((targ,num_tools,tools));return [17]
  fn.__doc__='CheckInterference(targ, num_tools, tools)'
  b=KernelBinding(N(Modl=N(CheckInterference=fn)),ApiEvidence())
  for target in [1.2,'1',True]:
   with self.subTest(target=target),self.assertRaises(ValueError):b.raw(target,2)
  self.assertEqual(calls,[])
 def test_delete_undo_method_checked_before_any_modification(self):
  events=[];children=[];p=N(Tag=5,ComponentAssembly=N(RootComponent=N(GetChildren=lambda:children)))
  session=N(SetUndoMark=lambda *a:events.append('mark') or 1,UndoToMark=lambda *a:children.clear())
  nx=N(Session=N(MarkVisibility=N(Invisible=0)));owner=N(records={5:dict(part=p)})
  with self.assertRaises(Exception):
   with temporary_occurrences(session,nx,p,owner,ApiEvidence()):events.append('body');children.append(1)
  self.assertEqual(events,[])
if __name__=='__main__':unittest.main()
