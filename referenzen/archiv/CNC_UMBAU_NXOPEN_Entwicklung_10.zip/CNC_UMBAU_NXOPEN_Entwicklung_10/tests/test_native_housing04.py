import copy, importlib, math, unittest
from types import SimpleNamespace as N
from unittest.mock import patch
from construction.housing04 import make_recipe, contract
from construction.recipes03 import validate_recipe
from cnc_nx.build03 import RecipeBuilder, numeric_operations


def example():
    return make_recipe(dict(id='SEATED',width=80,height=60,thickness=24,minimum_wall=1,
             source='Self-designed analytical test',holes=[dict(id='seat',x=0,y=0,through_d=22,front_d=32,front_depth=16,rear_d=26,rear_depth=3)]))

class NativeHousing04Tests(unittest.TestCase):
    def test_new_kind_accepted_by_common_axis_recipe_validator(self):
        r=example();self.assertAlmostEqual(validate_recipe(r)['expected_volume_mm3'],contract(r)['expected_volume_mm3'])
    def test_current_geometry_recomputed_by_dispatcher(self):
        r=example();r['parameters']['thickness']=26
        self.assertAlmostEqual(validate_recipe(r)['expected_volume_mm3'],contract(r)['expected_volume_mm3'])
    def test_numeric_compiler_can_evaluate_both_face_recesses(self):
        ops=numeric_operations(example());self.assertEqual(len(ops),4)
        self.assertEqual(ops[-1]['origin'],[0.,0.,21.]);self.assertEqual(ops[-1]['height'],4.)
    def test_axis_design_accepts_new_native_family(self):
        from construction.axis_native03 import validate_axis_design
        r=example();I=[[1,0,0],[0,1,0],[0,0,1]]
        d=dict(axis='X',review=dict(status='MODEL_LAYOUT_REVIEWED',evidence='test'),
               frame=dict(origin_mm=[0,0,0],rotation=I,evidence='test'),custom_parts=[r],
               components=[dict(id='a',part_id='SEATED',origin_mm=[0,0,0],rotation=I)])
        self.assertEqual(validate_axis_design(d)['custom_parts'],1)
    def setup_native_seam(self):
        r=example();b=RecipeBuilder.__new__(RecipeBuilder)
        b.part=N();b.expressions={k:N(RightHandSide=str(v)) for k,v in r['parameters'].items()}
        b.nx=N(Session=N(MarkVisibility=N(Invisible=0)))
        b.evidence=N();session=N(SetUndoMark=lambda *a:7,UpdateManager=N(DoUpdate=lambda *a:0))
        final=N(GetBodies=lambda:[object()]);return r,b,session,final
    def measurement(self,r,b):
        p={k:float(v.RightHandSide) for k,v in b.expressions.items()}
        return contract(r,p)
    def test_native_probe_checks_depth_then_restores(self):
        r,b,s,f=self.setup_native_seam();seen=[]
        def vol(*args):
            c=self.measurement(r,b);seen.append(c['expected_volume_mm3']);return c['expected_volume_mm3']
        with patch('cnc_nx.build03.volume',side_effect=vol),patch('cnc_nx.build03.exact_bounds',side_effect=lambda *a:self.measurement(r,b)['bounds_mm']):
            report=b.test_parameter(s,r,f)
        self.assertEqual(report['status'],'PASSED_IN_THIS_NX_RUN')
        self.assertEqual(len(report['probes']),2)
        self.assertTrue(any(abs(v-(contract(r)['expected_volume_mm3']-math.pi/4*(32**2-22**2)*.5))<1e-6 for v in seen))
        self.assertEqual(float(b.expressions['hole_seat_front_depth'].RightHandSide),16)
        self.assertEqual(float(b.expressions['thickness'].RightHandSide),24)
    def test_native_probe_failure_still_restores_original(self):
        r,b,s,f=self.setup_native_seam()
        with patch('cnc_nx.build03.volume',side_effect=lambda *a:contract(r)['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',return_value=contract(r)['bounds_mm']):
            with self.assertRaises(RuntimeError):b.test_parameter(s,r,f)
        self.assertEqual(float(b.expressions['thickness'].RightHandSide),24)
    def test_native_probe_checks_bounds_not_only_volume(self):
        r,b,s,f=self.setup_native_seam()
        with patch('cnc_nx.build03.volume',side_effect=lambda *a:self.measurement(r,b)['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',return_value=[1,2,3,4,5,6]):
            with self.assertRaises(RuntimeError):b.test_parameter(s,r,f)
    def test_no_native_runtime_import_needed_offline(self):
        import cnc_nx.build03 as m
        self.assertFalse(m.NATIVE_EXECUTED_BY_AUTHOR)

if __name__=='__main__':unittest.main()
