"""NX runtime seams simulated. No native geometry is made by these tests."""
import contextlib,copy,importlib,importlib.util,sys,tempfile,types,unittest
from collections import Counter
from pathlib import Path
from types import SimpleNamespace as N
from unittest.mock import patch
from construction.nutmount10 import reference_set,metrics
from validation.geometry03 import transform_bounds
from cnc_nx.build03 import RecipeBuilder
from cnc_nx.runtime import sha256_file
from test_nutmount_interfaces10 import fake_faces

class Probe10Tests(unittest.TestCase):
 def setup_probe(self):
  r=next(p for p in reference_set()['parts'] if p['kind']=='supplier_mount10')
  b=RecipeBuilder.__new__(RecipeBuilder);b.part=N();b.evidence=N();b.expressions={k:N(RightHandSide=str(v)) for k,v in r['parameters'].items()}
  b.nx=N(Session=N(MarkVisibility=N(Invisible=0)))
  s=N(SetUndoMark=lambda *a:0,UpdateManager=N(DoUpdate=lambda *a:0));f=N(GetBodies=lambda:[object()])
  return r,b,s,f
 def data(self,b):return metrics({k:float(v.RightHandSide) for k,v in b.expressions.items()})
 def test_all_three_probes_restore(self):
  r,b,s,f=self.setup_probe()
  with patch('cnc_nx.build03.volume',side_effect=lambda *a:self.data(b)['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',side_effect=lambda *a:self.data(b)['bounds_mm']):
   result=b.test_parameter(s,r,f)
  self.assertEqual(len(result['probes']),3);self.assertEqual({k:float(v.RightHandSide) for k,v in b.expressions.items()},r['parameters'])
 def test_stale_volume_rejected_and_restored(self):
  r,b,s,f=self.setup_probe()
  with patch('cnc_nx.build03.volume',return_value=r['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',side_effect=lambda *a:self.data(b)['bounds_mm']):
   with self.assertRaises(RuntimeError):b.test_parameter(s,r,f)
  self.assertEqual(float(b.expressions['length'].RightHandSide),54)
 def test_stale_axis_height_bounds_rejected(self):
  r,b,s,f=self.setup_probe()
  def box(*a):
   out=self.data(b)['bounds_mm'];out[1]=-16.5;out[4]=16.5;return out
  with patch('cnc_nx.build03.volume',side_effect=lambda *a:self.data(b)['expected_volume_mm3']),patch('cnc_nx.build03.exact_bounds',side_effect=box):
   with self.assertRaises(RuntimeError):b.test_parameter(s,r,f)
  self.assertEqual(float(b.expressions['axis_height'].RightHandSide),16.5)

class MountPipeline10Tests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('cnc_nx.nutmount10'),'Missing native mount coordinator')
  self.native=importlib.import_module('cnc_nx.nutmount10')
 def exercise(self,d,failure=None):
  session=N(Parts=N(Display=None));objects={};events=[]
  class Owner:
   def __init__(self,s,n,root,log,e):self.root=Path(root);self.records={}
   def create(self,name):
    p=N(name=name,children=[],Tag=len(objects)+1);objects[p.Tag]=p;self.records[p.Tag]={'part':p};session.Parts.Display=p;events.append(('create',name));return p
   def save(self,p):
    target=self.root/(p.name+'.prt');target.write_bytes(('SIMULATED_TEST_BYTES_NOT_NX '+p.name).encode());p.path=str(target);return p.path
  class Builder:
   def __init__(self,*args):pass
   def build_recipe(self,r):
    self.r=r;self.body=N(recipe=r);self.final=N(GetBodies=lambda:[self.body]);return self.final,self.body,{'simulation_only':True}
   def test_parameter(self,*args):return {'probes':[{}]*(3 if self.r['role']=='block' else 2),'status':'SIMULATED_ONLY'}
  def add(asm,nx,e,path,name,R,t,mode):
   proto=next(p for p in objects.values() if getattr(p,'path',None)==path)
   xyz=list(t)
   if failure=='shift' and name=='block':xyz[0]+=.1
   c=N(path=path,prototype=proto,rotation=R,translation=xyz)
   c.FindOccurrence=lambda body:N(body=body,rotation=R,translation=xyz)
   c.GetPosition=lambda:(N(X=xyz[0],Y=xyz[1],Z=xyz[2]),N(**dict(zip(('Xx','Xy','Xz','Yx','Yy','Yz','Zx','Zy','Zz'),sum(R,[])))))
   asm.children.append(c);return c
  @contextlib.contextmanager
  def temporary(s,n,part,owner,e):
   if session.Parts.Display is not part or part.children:raise RuntimeError('Scratch pose lifecycle broken')
   try:yield
   finally:part.children.clear()
  def bbox(part,occ,e):return transform_bounds(occ.body.recipe['bounds_mm'],occ.rotation,occ.translation)
  def face_read(body,e):
   f=fake_faces(body.recipe)
   if failure=='face' and body.recipe['role']=='block':f[0]['radius_part_units']+=.01
   return f
  def bom(s,root,log,e,reg,expected_quantities):
   tree=session.Parts.Display;c=Counter()
   for g in tree.children:
    for part in g.prototype.children:c[Path(part.path).stem]+=1
   if failure=='bom':c[next(iter(c))]+=1
   if failure=='file':Path(reg['entries'][0]['prototype_path']).write_bytes(b'changed')
   return dict(inventory_complete=True,source_binding_complete=True,assignment_complete=True,rows=[dict(item_id=k,quantity=v) for k,v in c.items()])
  fake=types.ModuleType('NXOpen');mods={'NXOpen':fake}
  for k in ('Features','GeometricUtilities','Assemblies'):
   obj=types.ModuleType('NXOpen.'+k);setattr(fake,k,obj);mods['NXOpen.'+k]=obj
  with contextlib.ExitStack() as stack:
   stack.enter_context(patch.dict(sys.modules,mods))
   for key,val in [('NewParts',Owner),('RecipeBuilder',Builder),('calibrate',lambda *a:'ROWS'),('add_component',add),('temporary_occurrences',temporary),('exact_bounds',bbox),('read_faces',face_read)]:
    stack.enter_context(patch.object(self.native,key,val))
   stack.enter_context(patch('cnc_nx.bom07.run_report',side_effect=bom))
   result=self.native.run(session,fake,Path(d),lambda s:None,N(require=lambda k,v:v),{})
  return result,events
 def test_full_flow_and_counts(self):
  with tempfile.TemporaryDirectory() as d:
   r,ev=self.exercise(d)
   self.assertEqual(r['prototype_count'],8);self.assertEqual(r['leaf_occurrence_count'],9)
   self.assertEqual(r['native_parameter_tests'],18);self.assertEqual(r['native_axial_sample_count'],9)
   self.assertEqual(r['model_interface_check_count'],12)
   self.assertEqual(r['bom_quantities']['K10_BLOCK_ISEL_213500'],2)
   self.assertFalse(r['retention_verified']);self.assertFalse(r['machine_fit_verified'])
   self.assertTrue((Path(d)/'NX_Rundmutter_Aufnahmen_10.json').is_file())
 def no_success(self,failure):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises((RuntimeError,ValueError)):self.exercise(d,failure)
   self.assertFalse((Path(d)/'NX_Rundmutter_Aufnahmen_10.json').exists())
 def test_wrong_bom_blocks_publication(self):self.no_success('bom')
 def test_wrong_position_blocks_publication(self):self.no_success('shift')
 def test_changed_file_blocks_publication(self):self.no_success('file')
 def test_wrong_face_blocks_publication(self):self.no_success('face')
 def test_offline_does_not_claim_native_author_execution(self):self.assertFalse(self.native.NATIVE_EXECUTED_BY_AUTHOR)

if __name__=='__main__':unittest.main()
