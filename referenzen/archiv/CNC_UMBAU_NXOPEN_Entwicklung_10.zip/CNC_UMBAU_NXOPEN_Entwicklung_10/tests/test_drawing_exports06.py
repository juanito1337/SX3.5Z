import importlib,importlib.util,json,tempfile,unittest
from pathlib import Path
from construction.library04 import reference_library
from exports.drawing06 import drawing_spec

class DrawingExports06Tests(unittest.TestCase):
 def m(self):
  self.assertIsNotNone(importlib.util.find_spec('exports.drawing_outputs06'),'drawing outputs missing')
  return importlib.import_module('exports.drawing_outputs06')
 def s(self):return drawing_spec(reference_library()['parts'][1])
 def test_dxf_records_include_explicit_units_and_warning(self):
  t=self.m().dxf_text(self.s());self.assertIn('$INSUNITS\n70\n4\n',t);self.assertIn('NICHT ZUR FERTIGUNG',t);self.assertTrue(t.endswith('0\nEOF\n'))
 def test_rear_step_circle_has_true_nominal_radius(self):
  t=self.m().dxf_text(self.s());self.assertIn('8\nREAR_RECESS\n',t);self.assertIn('40\n13\n',t)
 def test_dxf_is_part_coordinates_not_paper_scaled(self):
  t=self.m().dxf_text(self.s());self.assertIn('10\n-40\n20\n-30\n',t);self.assertNotIn('420',t)
 def test_dxf_is_not_announced_as_sheet_flattening(self):
  t=self.m().dxf_text(self.s());self.assertIn('KEINE_ABWICKLUNG',t);self.assertIn('KEIN_CAM',t)
 def test_dxf_existing_not_overwritten(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'a.dxf';p.write_text('source')
   with self.assertRaises(FileExistsError):self.m().write_dxf(p,self.s())
   self.assertEqual(p.read_text(),'source')
 def test_bundle_source_provenance_and_no_native_claim(self):
  with tempfile.TemporaryDirectory() as td:
   out=Path(td)/'drawings';r=self.m().write_bundle(out)
   self.assertEqual(r['part_count'],4);self.assertFalse(r['native_execution']);self.assertFalse(r['manufacturing_released'])
   self.assertEqual(len(list(out.glob('*.dxf'))),4);self.assertTrue((out/'Nennmassblaetter_KEIN_NX_EXPORT.pdf').read_bytes().startswith(b'%PDF-'))
 def test_no_bundle_overwrite(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(FileExistsError):self.m().write_bundle(Path(td))
 def test_pdf_page_count_and_status_text(self):
  import fitz
  with tempfile.TemporaryDirectory() as td:
   out=Path(td)/'drawings';self.m().write_bundle(out)
   with fitz.open(out/'Nennmassblaetter_KEIN_NX_EXPORT.pdf') as doc:
    self.assertEqual(len(doc),4)
    for page in doc:
     self.assertIn('NICHT ZUR FERTIGUNG',page.get_text());self.assertIn('KEIN NX-EXPORT',page.get_text());self.assertAlmostEqual(page.rect.width,420*72/25.4,places=2)
 def test_snapshot_has_all_original_hole_sizes(self):
  with tempfile.TemporaryDirectory() as td:
   out=Path(td)/'drawings';self.m().write_bundle(out)
   r=json.loads((out/'D04_LAGERAUFNAHME_Spezifikation.json').read_text())
   self.assertEqual(r['holes'][0]['front_depth'],16.)
 def test_bounds_checker_rejects_truncated_pdf(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'a.pdf';p.write_bytes(b'%PDF-1.4\npartial')
   with self.assertRaises(ValueError):self.m().validate_pdf_file(p)
 def test_invalid_catalogue_does_not_create_output(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'output'
   with self.assertRaises(ValueError):self.m().write_bundle(p, {'schema':'bad'})
   self.assertFalse(p.exists())

if __name__=='__main__':unittest.main()

class DxfParser06Tests(unittest.TestCase):
 def test_independent_dxf_reader_has_no_repairs(self):
  import ezdxf
  from exports.drawing_outputs06 import write_dxf
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'review.dxf';write_dxf(p,drawing_spec(reference_library()['parts'][1]))
   d=ezdxf.readfile(p);a=d.audit()
   self.assertEqual(a.errors,[]);self.assertEqual([f.message for f in a.fixes],[])
   self.assertEqual(d.units,4)
   circles=list(d.modelspace().query('CIRCLE'))
   self.assertEqual(len(circles),11)
