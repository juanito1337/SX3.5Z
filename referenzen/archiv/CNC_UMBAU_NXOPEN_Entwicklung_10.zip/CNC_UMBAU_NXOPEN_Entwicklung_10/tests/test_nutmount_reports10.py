import importlib,importlib.util,json,tempfile,unittest
from pathlib import Path
from engineering.nutmount10 import load_cases
ROOT=Path(__file__).absolute().parents[1]

class Report10Tests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('exports.nutmount10'),'Missing main-body report export')
  self.m=importlib.import_module('exports.nutmount10')
 def test_counts(self):
  d=self.m.report_data();self.assertEqual(d['prototype_count'],8);self.assertEqual(d['occurrence_count'],9)
 def test_shared_qty(self):
  d=self.m.report_data();r=next(r for r in d['parts'] if r['part_id']=='K10_BLOCK_ISEL_213500');self.assertEqual(r['quantity'],2)
 def test_window_regression(self):
  d=self.m.report_data();self.assertEqual([r['known_body_span_mm'] for r in d['axial_rows']],[278,278,170.5])
 def test_no_native_claim(self):
  d=self.m.report_data();self.assertFalse(d['native_execution']);self.assertFalse(d['manufacturing_released'])
 def test_export_files(self):
  with tempfile.TemporaryDirectory() as t:
   out=Path(t)/'new';self.m.export_report(out)
   for name in ['Rundmutterbericht_10.json','Bauteile_10.csv','Axialraum_10.csv','Rundmutteraufnahmen_10.html']:
    self.assertTrue((out/name).is_file())
 def test_no_overwrite(self):
  with tempfile.TemporaryDirectory() as t:
   out=Path(t)/'new';self.m.export_report(out)
   before={p.name:p.read_bytes() for p in out.iterdir()}
   with self.assertRaises(FileExistsError):self.m.export_report(out)
   self.assertEqual(before,{p.name:p.read_bytes() for p in out.iterdir()})
 def test_invalid_config_leaves_no_target(self):
  with tempfile.TemporaryDirectory() as t:
   cases=load_cases();cases[0]['block_article']='wrong';out=Path(t)/'new'
   with self.assertRaises(ValueError):self.m.export_report(out,cases=cases)
   self.assertFalse(out.exists())
 def test_readable_scope_disclosure(self):
  h=self.m.html_report(self.m.report_data())
  self.assertIn('NICHT ZUR FERTIGUNG',h);self.assertIn('H1',h);self.assertIn('Fußbohrungen',h)
 def test_html_escape(self):
  d=self.m.report_data();d['parts'][0]['part_id']='<script>alert(1)</script>'
  h=self.m.html_report(d);self.assertNotIn('<script>',h);self.assertIn('&lt;script&gt;',h)
 def test_no_missing_unknowns_zeroed(self):
  d=self.m.report_data();self.assertTrue(all(r['requested_body_stroke_mm'] is None for r in d['axial_rows']))

class Entry10Tests(unittest.TestCase):
 def test_journal_present(self):self.assertTrue((ROOT/'NX_23_Rundmutter_Aufnahmen.py').is_file())
 def test_mode_present(self):self.assertIn("'nutmount10':'nutmount10'",(ROOT/'main.py').read_text())
 def test_offline_entry_present(self):self.assertTrue((ROOT/'Projekt10_Aufnahmebericht.py').is_file())

if __name__=='__main__':unittest.main()
