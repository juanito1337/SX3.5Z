"""File evidence tests use clearly synthetic files, not a NX geometry simulation."""
import copy, importlib, tempfile, unittest
from pathlib import Path
from cnc_nx.runtime import sha256_file
from test_bom07 import snapshot
from analysis.bom07 import summarize

class RegistryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.folder=Path(self.temp.name);self.file=self.folder/'sleeve.prt';self.file.write_bytes(b'FAKE_PRT_TEST_FIXTURE')
        self.h=sha256_file(self.file);s=snapshot()
        self.rootfile=self.folder/'root.prt';self.rootfile.write_bytes(b'FAKE_ROOT_TEST_FIXTURE')
        rh=sha256_file(self.rootfile);s['prototypes'][0].update(path=str(self.rootfile),sha256_before=rh,sha256_after=rh)
        s['prototypes'][1].update(path=str(self.file),sha256_before=self.h,sha256_after=self.h)
        self.report=summarize(s)
        self.entry=dict(prototype_path=str(self.file),prototype_sha256=self.h,item_id='D07_TEST',
                        revision='A',kind='MANUFACTURED',description='Testhuelse',source_refs=['Eigener Entwurf'],
                        material=None,documents=[],dimension_status='DESIGN_NOMINAL')
        self.registry=dict(schema='SX35Z_BOM_ASSIGNMENTS_7',entries=[self.entry])
    def module(self):
        try:return importlib.import_module('analysis.bom_registry07')
        except ImportError:self.fail('Hash-bound BOM registry is missing')
    def apply(self,registry=None,**kw):return self.module().apply_registry(self.report,registry or self.registry,**kw)
    def document(self,role='DRAWING_PDF'):
        p=self.folder/'drawing.pdf';p.write_bytes(b'%PDF-1.4 synthetic fixture')
        return dict(role=role,path=str(p),sha256=sha256_file(p),model_sha256=self.h,status='DRAFT')
    def test_exact_model_binding_and_quantity_preserved(self):
        r=self.apply();self.assertEqual(r['rows'][0]['item_id'],'D07_TEST');self.assertEqual(r['rows'][0]['quantity'],2)
        self.assertTrue(r['assignment_complete'])
    def test_no_auto_order_or_manufacturing_approval(self):
        self.entry.update(order_released=True,manufacturing_released=True)
        r=self.apply();self.assertFalse(r['order_released']);self.assertFalse(r['rows'][0]['manufacturing_released'])
    def test_missing_material_and_drawing_remain_open(self):
        row=self.apply()['rows'][0]
        self.assertIn('MATERIAL_NOT_SPECIFIED',row['blockers']);self.assertIn('DRAWING_NOT_LINKED',row['blockers'])
    def test_same_filename_does_not_match_different_path(self):
        self.entry['prototype_path']=str(self.folder/'other'/'sleeve.prt')
        r=self.apply();self.assertIsNone(r['rows'][0]['item_id']);self.assertFalse(r['assignment_complete'])
    def test_stale_assignment_detected(self):
        self.entry['prototype_sha256']='b'*64;r=self.apply()
        self.assertIn('STALE_ASSIGNMENT',r['rows'][0]['blockers'])
    def test_changed_model_on_disk_invalidates_binding(self):
        self.file.write_bytes(b'changed');r=self.apply()
        self.assertFalse(r['source_binding_complete']);self.assertIn('MODEL_FILE_CHANGED',r['rows'][0]['blockers'])
    def test_missing_model_file_invalidates_binding(self):
        self.file.unlink();r=self.apply();self.assertFalse(r['source_binding_complete'])
    def test_dirty_source_cannot_match_registry(self):
        self.report['rows'][0]['source_bound']=False
        self.assertFalse(self.apply()['assignment_complete'])
    def test_document_hash_and_model_link_validated(self):
        self.entry['documents']=[self.document()];r=self.apply();check=r['rows'][0]['document_checks'][0]
        self.assertEqual(check['status'],'FILE_IDENTITY_CHECKED_NOT_APPROVED')
        self.assertFalse(r['rows'][0]['manufacturing_released'])
    def test_stale_drawing_binding_rejected(self):
        d=self.document();d['model_sha256']='c'*64;self.entry['documents']=[d]
        self.assertEqual(self.apply()['rows'][0]['document_checks'][0]['status'],'STALE_MODEL_BINDING')
    def test_missing_document_reported(self):
        d=self.document();Path(d['path']).unlink();self.entry['documents']=[d]
        self.assertEqual(self.apply()['rows'][0]['document_checks'][0]['status'],'MISSING_OR_INVALID_FILE')
    def test_document_content_change_reported(self):
        d=self.document();Path(d['path']).write_bytes(b'%PDF changed');self.entry['documents']=[d]
        self.assertEqual(self.apply()['rows'][0]['document_checks'][0]['status'],'CONTENT_CHANGED')
    def test_document_relative_path_rejected(self):
        d=self.document();d['path']='relative.pdf';self.entry['documents']=[d]
        with self.assertRaises(ValueError):self.apply()
    def test_unsupported_kind_rejected(self):
        self.entry['kind']='AUTOMATICALLY_APPROVED'
        with self.assertRaises(ValueError):self.apply()
    def test_duplicate_binding_rejected(self):
        self.registry['entries'].append(copy.deepcopy(self.entry))
        with self.assertRaises(ValueError):self.apply()
    def test_same_part_number_revision_different_model_rejected(self):
        e=copy.deepcopy(self.entry);e['prototype_path']=str(self.folder/'second.prt');self.registry['entries'].append(e)
        with self.assertRaises(ValueError):self.apply()
    def test_different_revision_allowed_in_library_but_not_counted(self):
        e=copy.deepcopy(self.entry);e['revision']='B';e['prototype_sha256']='c'*64;self.registry['entries'].append(e)
        r=self.apply();self.assertEqual(len(r['unused_assignments']),1);self.assertEqual(r['counts']['active_leaf_occurrences'],2)
    def test_registry_and_report_not_modified(self):
        before=copy.deepcopy((self.report,self.registry));self.apply();self.assertEqual((self.report,self.registry),before)
    def test_purchase_requires_actual_order_identifier(self):
        self.entry.update(kind='PURCHASE',manufacturer='Leadshine',model='CS-M22326',order_number=None)
        r=self.apply();self.assertIn('ORDER_IDENTIFIER_NOT_SPECIFIED',r['rows'][0]['blockers'])
        self.assertIn('MACHINE_FIT_NOT_CONFIRMED',r['rows'][0]['blockers'])
    def test_original_not_sent_to_buy_list(self):
        self.entry['kind']='ORIGINAL';r=self.apply();self.assertEqual(r['views']['purchase'],[])
        self.assertEqual(r['views']['original'],['B0001'])
    def test_unbound_template_is_allowed_but_not_assigned(self):
        self.entry.update(kind='UNASSIGNED',item_id=None,revision=None)
        r=self.apply();self.assertFalse(r['assignment_complete'])
    def test_explicit_skip_file_checks_is_not_success(self):
        r=self.apply(verify_files=False);self.assertEqual(r['file_check_mode'],'NOT_RECHECKED')
        self.assertFalse(r['document_link_complete']);self.assertEqual(r['status'],'PROVENANCE_NOT_RECHECKED')
    def test_bom_quantity_override_is_not_accepted(self):
        self.entry['quantity']=99;r=self.apply();self.assertEqual(r['rows'][0]['quantity'],2)
    def test_missing_sources_recorded(self):
        self.entry['source_refs']=[];self.assertIn('SOURCE_REFERENCE_MISSING',self.apply()['rows'][0]['blockers'])
    def test_reference_only_is_separate_view(self):
        self.entry['kind']='REFERENCE';r=self.apply();self.assertEqual(r['views']['reference'],['B0001'])
    def test_symlink_model_not_rechecked_as_owned_identity(self):
        alt=self.folder/'target';self.file.rename(alt);self.file.symlink_to(alt)
        r=self.apply();self.assertFalse(r['source_binding_complete'])
    def test_windows_case_normalization(self):
        from analysis.bom07 import path_key
        self.assertEqual(path_key(r'C:\Parts\Motor.PRT'),path_key(r'c:\parts\motor.prt'))

    def test_changed_root_assembly_invalidates_snapshot_provenance(self):
        self.rootfile.write_bytes(b'root assembly changed')
        r=self.apply();self.assertFalse(r['source_binding_complete'])
        self.assertEqual(r['status'],'INCOMPLETE_INVENTORY')
