import ast, tempfile, unittest, json
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).absolute().parents[1]
class ReportTests(unittest.TestCase):
    def test_report_works_without_realpath_resolution(self):
        from cnc_nx.concept02 import reports
        with tempfile.TemporaryDirectory() as temp:
            with patch.object(Path,'resolve',side_effect=OSError(1005,'Mapped path cannot be resolved')):
                result=reports(temp)
            self.assertFalse(result['manufacturing_released'])
            self.assertEqual(result['calculations'],6)
            self.assertEqual(result['sample_poses'],125)
    def test_report_does_not_overwrite_existing(self):
        from cnc_nx.concept02 import reports
        with tempfile.TemporaryDirectory() as temp:
            reports(temp)
            with self.assertRaises(FileExistsError):reports(temp)
    def test_every_scenario_is_assumption_not_motor_approval(self):
        from engineering.scenarios import evaluate
        data=json.loads((ROOT/'config/design_scenarios.json').read_text())
        result=evaluate(data)
        for s in result['scenarios']:
            self.assertEqual(s['motor_check']['status'],'NOT_EVALUATED')
            self.assertFalse(s['motor_check']['motor_selected'])
    def test_formula_parser_blocks_code_execution(self):
        from cnc_nx.parts02 import arithmetic
        self.assertEqual(arithmetic('-a/2+3',{'a':10}),-2.)
        with self.assertRaises(ValueError):arithmetic('__import__("os").getcwd()',{})
    def test_native_loader_has_no_resolve(self):
        tree=ast.parse((ROOT/'cnc_nx/parts02.py').read_text())
        calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='resolve']
        self.assertFalse(calls,'Native journal must not require mapped-drive realpath resolution')

if __name__=='__main__':unittest.main()

class IOAndPackageTests(unittest.TestCase):
    def test_io_capacity_and_unique_channels(self):
        data=json.loads((ROOT/'linuxcnc/io_allocation.json').read_text())
        for kind,count in [('input',24),('output',6),('stepdir',3)]:
            rows=[r for r in data['functions'] if r['kind']==kind]
            self.assertEqual(len(rows),count)
            self.assertEqual(len({r['channel'] for r in rows}),count)
        self.assertTrue(all(r.get('safety_function',False) is False for r in data['functions']))
    def test_documented_mesa_connector_positions(self):
        rows=json.loads((ROOT/'linuxcnc/io_allocation.json').read_text())['functions']
        find=lambda kind,ch:next(r for r in rows if r['kind']==kind and r['channel']==ch)
        self.assertEqual((find('input',0)['terminal'],find('input',0)['pin'],find('input',0)['common_pin']),('TB6',1,3))
        self.assertEqual((find('input',15)['pin'],find('input',15)['common_pin']),(23,24))
        self.assertEqual((find('input',16)['terminal'],find('input',16)['pin']),('TB5',1))
        self.assertEqual((find('output',5)['minus_pin'],find('output',5)['plus_pin']),(23,24))
        self.assertEqual(find('stepdir',2)['step_plus_pin'],15)
    def test_no_bom_line_is_released_or_without_source(self):
        ids={r['id'] for r in json.loads((ROOT/'reference/Quellen_02.json').read_text())}
        rows=json.loads((ROOT/'config/bom_concept.json').read_text())['items']
        self.assertEqual(len({r['id'] for r in rows}),len(rows))
        for r in rows:
            self.assertFalse(r['order_released'])
            self.assertTrue(r['source_ids'],'missing source '+r['id'])
            self.assertTrue(set(r['source_ids'])<=ids)
    def test_module_reload_keeps_other_projects(self):
        import main,types,sys
        f=getattr(main,'invalidate_project_modules',None)
        self.assertTrue(callable(f),'scoped module invalidation missing')
        a=types.ModuleType('construction.other_user_project');a.__file__='/some/other/project/a.py'
        b=types.ModuleType('cnc_nx._unit_test');b.__file__=str(ROOT/'cnc_nx/_unit_test.py')
        sys.modules[a.__name__]=a;sys.modules[b.__name__]=b
        try:
            f();self.assertIn(a.__name__,sys.modules);self.assertNotIn(b.__name__,sys.modules)
        finally:sys.modules.pop(a.__name__,None);sys.modules.pop(b.__name__,None)
