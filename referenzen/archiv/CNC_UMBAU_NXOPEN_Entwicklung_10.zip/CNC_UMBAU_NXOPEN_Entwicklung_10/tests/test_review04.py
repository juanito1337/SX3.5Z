import copy,math,unittest
from construction.housing04 import make_recipe,contract,parameter_probes
from construction.library04 import reference_library,check_cover_pair

class Review04Tests(unittest.TestCase):
    def test_mutating_one_pose_cannot_change_others_or_next_call(self):
        a=reference_library();before=copy.deepcopy(a['components'][1]['rotation'])
        saved=copy.deepcopy(a['components'][0]['rotation'])
        try:
            a['components'][0]['rotation'][0][0]=0.125
            self.assertEqual(a['components'][1]['rotation'],before)
            b=reference_library();self.assertEqual(b['components'][0]['rotation'],saved)
        finally:
            # Restore a shared global from the RED implementation so other tests are independent.
            from construction import library04
            library04.I[:]=copy.deepcopy(saved)
    def test_all_probe_shapes_valid_even_at_limit_shoulders(self):
        r=make_recipe(dict(id='EDGE',width=60,height=60,thickness=17,minimum_wall=1,source='test',
               holes=[dict(id='seat',x=0,y=0,through_d=10,front_d=20,front_depth=16)]))
        p=parameter_probes(r)[1]
        self.assertLess(p['changed_value'],p['original_value'])
        changed=dict(r['parameters']);changed[p['parameter']]=p['changed_value']
        self.assertGreater(contract(r,changed)['expected_volume_mm3'],0)
    def test_recess_volume_is_not_double_subtracted(self):
        r=make_recipe(dict(id='T',width=60,height=60,thickness=30,minimum_wall=1,source='test',
               holes=[dict(id='seat',x=0,y=0,through_d=10,front_d=20,front_depth=5,rear_d=30,rear_depth=7)]))
        # independent integral of disjoint axial slices
        expected=(3600-math.pi*20**2/4)*5+(3600-math.pi*10**2/4)*18+(3600-math.pi*30**2/4)*7
        self.assertAlmostEqual(contract(r)['expected_volume_mm3'],expected)
    def test_radius_edit_rechecks_interhole_web(self):
        r=reference_library()['parts'][0];p=dict(r['parameters']);p['hole_pilot_front_d']=50
        with self.assertRaises(ValueError):contract(r,p)
    def test_cover_does_not_accept_rotation(self):
        d=reference_library();c=next(c for c in d['components'] if c['id']=='cover')
        c['rotation']=[[0,-1,0],[1,0,0],[0,0,1]]
        with self.assertRaises(ValueError):check_cover_pair(d['parts'],d['components'])
    def test_large_nonfinite_geometry_does_not_get_positive_report(self):
        s=dict(id='T',width=1e308,height=1e308,thickness=10,minimum_wall=1,source='test',holes=[dict(id='a',x=0,y=0,through_d=2)])
        with self.assertRaises((ValueError,OverflowError)):make_recipe(s)

if __name__=='__main__':unittest.main()
