import ast,importlib.util,json,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).absolute().parents[1]
class Package03Tests(unittest.TestCase):
 def test_new_native_entrypoints_exist(self):
  for n in ['NX_07_Motortraeger_Referenz.py','NX_08_Achsbezuege_auslesen.py','NX_09_Achsmodule_erzeugen.py','NX_10_Montagebaugruppe_erzeugen.py','NX_11_Kaufteile_STEP_importieren.py','NX_12_STEP_exportieren.py','NX_13_AABB_Vorpruefung.py']:
   self.assertTrue((ROOT/n).is_file(),n)
 def test_no_new_mapped_drive_realpath_dependency(self):
  from cnc_nx.assembly03 import project_root
  with patch.object(Path,'resolve',side_effect=OSError(1005,'not available')):
   self.assertEqual(project_root(),ROOT)
 def test_default_machine_layout_not_approved(self):
  p=ROOT/'config/assembly03.json';self.assertTrue(p.is_file())
  c=json.loads(p.read_text());self.assertNotEqual(c['review']['status'],'MODEL_LAYOUT_REVIEWED');self.assertEqual(c['components'],[])
 def test_module_cache_old_own_project_removed(self):
  import main
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);(d/'reference').mkdir();(d/'reference/NUTZERANFORDERUNGEN.txt').write_text('owned project sentinel')
   (d/'config').mkdir();(d/'config/project.json').write_text('{}')
   mod=types.ModuleType('cnc_nx._old03');mod.__file__=str(d/'cnc_nx/_old03.py');sys.modules[mod.__name__]=mod
   try:main.invalidate_project_modules();self.assertNotIn(mod.__name__,sys.modules)
   finally:sys.modules.pop(mod.__name__,None)
 def test_boolean_matrix_rejected(self):
  from cnc_nx.build03 import matrix_fields
  with self.assertRaises(ValueError):matrix_fields([[True,0,0],[0,1,0],[0,0,1]],'ROWS')
if __name__=='__main__':unittest.main()
