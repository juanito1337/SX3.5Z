"""Synthetic face records, explicitly NOT NX geometry measurements."""
import copy,importlib,importlib.util,unittest
from construction.nutmount10 import reference_set

def fake_faces(r):
 p=r['parameters'];role=r['role'];L=p['length']
 def cyl(radius):return dict(uf_type_code=16,point_raw=[0.,0.,0.],direction_raw=[0.,0.,1.],radius_part_units=radius,bounds_raw=[-radius,-radius,0.,radius,radius,L])
 if role=='screw':return [cyl(p['outer_d']/2)]
 if role=='nut':return [cyl(p['outer_d']/2),cyl(p['visual_bore_d']/2)]
 return [cyl(p['bore_d']/2),dict(uf_type_code=22,point_raw=[0.,-p['axis_height'],0.],direction_raw=[0.,-1.,0.],radius_part_units=0.,bounds_raw=[-p['width']/2,-p['axis_height'],0,p['width']/2,-p['axis_height'],L])]

class Interface10Tests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('validation.nutmount10'),'Missing interface evaluator')
  self.m=importlib.import_module('validation.nutmount10');data=reference_set();self.g=data['groups'][0]
  recipes={r['id']:r for r in data['parts']}
  self.measure={c['role']:dict(faces=fake_faces(recipes[c['part_id']]),translation_mm=c['origin_mm']) for c in self.g['components']}
 def test_four_checks(self):self.assertEqual(len(self.m.verify_interfaces(self.g,self.measure)),4)
 def test_shifted_nut_rejected(self):
  self.measure['nut']['translation_mm'][0]=.05
  with self.assertRaises(RuntimeError):self.m.verify_interfaces(self.g,self.measure)
 def test_shifted_block_rejected(self):
  self.measure['block']['translation_mm'][1]=.1
  with self.assertRaises(RuntimeError):self.m.verify_interfaces(self.g,self.measure)
 def test_wrong_bore_diameter_rejected(self):
  self.measure['block']['faces'][0]['radius_part_units']+=.01
  with self.assertRaises(RuntimeError):self.m.verify_interfaces(self.g,self.measure)
 def test_ambiguous_cylinder_rejected(self):
  self.measure['block']['faces'].append(copy.deepcopy(self.measure['block']['faces'][0]))
  with self.assertRaises(ValueError):self.m.verify_interfaces(self.g,self.measure)
 def test_missing_cylinder_rejected(self):
  self.measure['screw']['faces']=[]
  with self.assertRaises(ValueError):self.m.verify_interfaces(self.g,self.measure)
 def test_missing_foot_rejected(self):
  self.measure['block']['faces'].pop()
  with self.assertRaises(ValueError):self.m.verify_interfaces(self.g,self.measure)
 def test_wrong_foot_distance_rejected(self):
  self.measure['block']['faces'][1]['point_raw'][1]+=.05
  with self.assertRaises(RuntimeError):self.m.verify_interfaces(self.g,self.measure)
 def test_nonfinite_measurement_rejected(self):
  self.measure['nut']['faces'][0]['radius_part_units']=float('nan')
  with self.assertRaises(ValueError):self.m.verify_interfaces(self.g,self.measure)
 def test_missing_component_rejected(self):
  del self.measure['block']
  with self.assertRaises(ValueError):self.m.verify_interfaces(self.g,self.measure)
 def test_extra_component_rejected(self):
  self.measure['unknown']={}
  with self.assertRaises(ValueError):self.m.verify_interfaces(self.g,self.measure)
 def test_report_not_retention_approval(self):
  for row in self.m.verify_interfaces(self.g,self.measure):
   self.assertFalse(row['physical_fit_verified']);self.assertNotIn('native_execution',row)
 def test_reversed_axis_same_geometry(self):
  self.measure['nut']['faces'][0]['direction_raw']=[0,0,-1]
  self.assertEqual(len(self.m.verify_interfaces(self.g,self.measure)),4)
 def test_tilted_axis_rejected(self):
  self.measure['block']['faces'][0]['direction_raw']=[0,.001,1]
  with self.assertRaises(RuntimeError):self.m.verify_interfaces(self.g,self.measure)

if __name__=='__main__':unittest.main()
