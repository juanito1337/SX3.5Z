import copy,importlib,importlib.util,math,unittest
from collections import Counter
from construction.recipes03 import validate_recipe
from cnc_nx.build03 import numeric_operations
from cnc_nx.parts02 import arithmetic

class MountRecipe10Tests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('construction.nutmount10'),'Missing nut-mount recipes')
  self.m=importlib.import_module('construction.nutmount10');self.data=self.m.reference_set()
 def block(self):return next(r for r in self.data['parts'] if r['kind']=='supplier_mount10')
 def test_eight_prototypes(self):self.assertEqual(len(self.data['parts']),8)
 def test_three_groups_nine_occurrences(self):
  self.assertEqual(len(self.data['groups']),3);self.assertEqual(sum(len(p['components']) for p in self.data['groups']),9)
 def test_shared_block_quantity(self):
  c=Counter(x['part_id'] for g in self.data['groups'] for x in g['components'])
  self.assertEqual(c['K10_BLOCK_ISEL_213500'],2);self.assertEqual(c['K10_BLOCK_ISEL_213600'],1)
 def test_all_recipes_accepted_by_existing_dispatch(self):
  for r in self.data['parts']:
   validate_recipe(r);self.assertGreater(len(numeric_operations(r)),0)
 def test_catalogue_block_volume(self):
  r=self.block();self.assertAlmostEqual(r['expected_volume_mm3'],(47*33-math.pi*14**2)*54)
 def test_bounds_and_foot(self):
  self.assertEqual(self.block()['bounds_mm'],[-23.5,-16.5,0,23.5,16.5,54])
 def test_no_invented_screw_holes(self):
  r=self.block();self.assertEqual(len(r['ops']),2);self.assertFalse(r['foot_holes_modelled'])
 def test_operation_volume_decreases(self):
  v=self.m.operation_volumes(self.block());self.assertEqual(len(v),2);self.assertGreater(v[0]['volume_after_mm3'],v[1]['volume_after_mm3'])
 def test_tampered_source_rejected(self):
  r=self.block();r['source']='fake'
  with self.assertRaises(ValueError):self.m.contract(r)
 def test_tampered_dimension_rejected(self):
  r=self.block();r['parameters']['bore_d']=29
  with self.assertRaises(ValueError):self.m.contract(r)
 def test_tampered_origin_rejected(self):
  r=self.block();r['ops'][1]['origin'][0]='1'
  with self.assertRaises(ValueError):self.m.contract(r)
 def test_three_independent_parameter_probes(self):
  p=self.m.parameter_probes(self.block());self.assertEqual({x['parameter'] for x in p},{'length','bore_d','axis_height'})
 def test_length_probe_exact(self):
  r=self.block();p=self.m.parameter_probes(r)[0];self.assertAlmostEqual(p['changed_volume_mm3'],r['expected_volume_mm3']/54*55)
 def test_axis_height_probe_moves_foot_not_bore(self):
  r=self.block();p=next(x for x in self.m.parameter_probes(r) if x['parameter']=='axis_height')
  self.assertAlmostEqual(p['changed_volume_mm3'],r['expected_volume_mm3']);self.assertNotEqual(p['changed_bounds_mm'],r['bounds_mm'])
 def test_invalid_probe_breakthrough_rejected(self):
  p=self.block()['parameters'];p['axis_height']=13
  with self.assertRaises(ValueError):self.m.metrics(p)
 def test_samples_centre_align(self):
  for g in self.data['groups']:
   s=g['resolved']['samples'][1];items={x['role']:x for x in g['components']}
   self.assertEqual(items['nut']['origin_mm'],[0,0,s['nut_start_mm']])
   self.assertEqual(items['block']['origin_mm'],[0,0,s['block_start_mm']])
 def test_scope_flags(self):
  r=self.block();self.assertFalse(r['manufacturer_original_cad']);self.assertFalse(r['full_envelope_verified']);self.assertFalse(self.data['machine_fit_verified'])
 def test_report_never_native(self):self.assertFalse(self.data['native_execution'])
 def test_recipe_parameter_references_resolve(self):
  for r in self.data['parts']:
   for op in r['ops']:
    for val in op['origin']:arithmetic(val,r['parameters'])
 def test_no_measurement_overrides(self):
  r=self.block();r['foot_holes_modelled']=True
  with self.assertRaises(ValueError):self.m.contract(r)

if __name__=='__main__':unittest.main()
