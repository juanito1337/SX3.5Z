import copy,importlib,json,tempfile,unittest
from pathlib import Path
from cnc_nx.runtime import sha256_file
from test_motion05 import fixture

class MotionInput05Tests(unittest.TestCase):
 def m(self):
  try:return importlib.import_module('validation.motion_input05')
  except ImportError:self.fail('motion_input05 not implemented')
 def setup(self,t):
  c=fixture();root=Path(t)
  for i,x in enumerate(c['components']):
   p=root/f'p{i}.prt';p.write_bytes(b'fake-test-native-file');x['path']=str(p);x['sha256']=sha256_file(p)
  report=dict(status='NATIVE_REVIEWED_LAYOUT_CREATED_NOT_RELEASED',native_execution=True,components=copy.deepcopy(c['components']))
  p=root/'NX_Montageentwurf.json';p.write_text(json.dumps(report))
  c['input_layout']={'path':str(p),'sha256':sha256_file(p)}
  return c,p,report
 def test_valid_hash_bound_inventory(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);self.assertEqual(len(self.m().load_reviewed(c)['components']),2)
 def test_changed_layout_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);p.write_text('{}')
   with self.assertRaises(ValueError):self.m().load_reviewed(c)
 def test_missing_component_rejected_even_with_two_left(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);r['components'].append(dict(r['components'][0],id='THIRD'));p.write_text(json.dumps(r));c['input_layout']['sha256']=sha256_file(p)
   with self.assertRaises(ValueError):self.m().load_reviewed(c)
 def test_extra_component_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);c['components'].append(dict(c['components'][0],id='THIRD'))
   with self.assertRaises(ValueError):self.m().load_reviewed(c)
 def test_changed_prototype_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);Path(c['components'][0]['path']).write_bytes(b'changed')
   with self.assertRaises(ValueError):self.m().load_reviewed(c)
 def test_changed_origin_not_allowed_in_motion_assignment(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);c['components'][0]['origin_mm'][0]=1
   with self.assertRaises(ValueError):self.m().load_reviewed(c)
 def test_unexecuted_layout_not_native(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);r['native_execution']=False;p.write_text(json.dumps(r));c['input_layout']['sha256']=sha256_file(p)
   with self.assertRaises(ValueError):self.m().load_reviewed(c)
 def test_prepared_template_does_not_assign_motion_by_name(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);tpl=self.m().prepare(p)
   self.assertIsNone(tpl['components'][0]['moving_axes']);self.assertIsNone(tpl['axes']['X']['min_mm'])
   self.assertNotEqual(tpl['review']['status'],'KINEMATICS_REVIEWED')
 def test_prepared_template_cannot_execute(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);tpl=self.m().prepare(p)
   with self.assertRaises(ValueError):self.m().load_reviewed(tpl)
 def test_does_not_write_source_json(self):
  with tempfile.TemporaryDirectory() as t:
   c,p,r=self.setup(t);before=p.read_bytes();self.m().prepare(p);self.m().load_reviewed(c);self.assertEqual(before,p.read_bytes())
if __name__=='__main__':unittest.main()
