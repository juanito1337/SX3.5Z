import copy, importlib, json, math, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class Library04Tests(unittest.TestCase):
    def api(self):
        try:return importlib.import_module('construction.library04')
        except ImportError:self.fail('Missing native housing catalogue')
    def test_four_unique_parts_and_four_presentations(self):
        d=self.api().reference_library();self.assertEqual(len(d['parts']),4);self.assertEqual(len(d['components']),4)
        self.assertEqual(len({p['id'] for p in d['parts']}),4)
        self.assertFalse(d['machine_fit_verified']);self.assertFalse(d['manufacturing_released'])
    def test_actual_bf20_reference_dimensions_not_guessed_sx_values(self):
        d=self.api().reference_library();r=next(p for p in d['parts'] if p['id']=='R04_BF20_17_Y')
        p=r['parameters'];self.assertEqual((p['width'],p['height'],p['thickness']),(43,20,19.5))
        self.assertEqual(p['hole_left_through_d'],6.6);self.assertEqual(p['hole_left_front_d'],11)
        self.assertEqual(p['hole_left_front_depth'],6.4)
        self.assertEqual(p['hole_right_x']-p['hole_left_x'],30)
        self.assertIn('Eckfasen',r['limitations']);self.assertIn('BF20',r['source'])
    def test_bearing_cover_matches_housing_bolt_pattern(self):
        m=self.api();r=m.reference_library();m.check_cover_pair(r['parts'],r['components'])
    def test_wrong_cover_position_rejected(self):
        m=self.api();r=m.reference_library();next(c for c in r['components'] if c['id']=='cover')['origin_mm'][2]+=2
        with self.assertRaises(ValueError):m.check_cover_pair(r['parts'],r['components'])
    def test_wrong_cover_holes_rejected(self):
        m=self.api();r=m.reference_library();next(p for p in r['parts'] if p['id']=='D04_LAGERDECKEL')['parameters']['hole_bolt1_x']+=1
        with self.assertRaises(ValueError):m.check_cover_pair(r['parts'],r['components'])
    def test_display_positions_not_machine_positions(self):
        d=self.api().reference_library();self.assertEqual(d['position_semantics'],'LIBRARY_DISPLAY_LAYOUT_NOT_MACHINE')
    def test_new_recipe_library_integrates_with_all_axis_wrappers(self):
        d=self.api().reference_library();from construction.recipes03 import validate_recipe
        for r in d['parts']:self.assertGreater(validate_recipe(r)['expected_volume_mm3'],0)
    def test_reference_data_cannot_release_purchase_or_machine(self):
        d=self.api().reference_library();self.assertFalse(d['contains_purchase_models'])
        for r in d['parts']:self.assertFalse(r['order_released'])
    def test_catalogue_parameter_change_regenerates_volume(self):
        m=self.api();c=m.load_catalogue();c['parts'][0]['thickness']+=1
        changed=m.reference_library(c);normal=m.reference_library()
        self.assertGreater(changed['parts'][0]['expected_volume_mm3'],normal['parts'][0]['expected_volume_mm3'])
    def test_json_duplicate_part_identity_rejected(self):
        m=self.api();c=m.load_catalogue();c['parts'][1]['id']=c['parts'][0]['id']
        with self.assertRaises(ValueError):m.reference_library(c)
    def test_reports_created_without_nx_and_do_not_overwrite(self):
        import tempfile
        m=self.api()
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'report';m.write_reports(out)
            self.assertTrue((out/'Bohrungstabelle_04.csv').is_file())
            summary=json.loads((out/'Halterbibliothek_04.json').read_text())
            self.assertFalse(summary['native_execution']);self.assertFalse(summary['manufacturing_released'])
            with self.assertRaises(FileExistsError):m.write_reports(out)
    def test_new_journal_and_source_module_exist(self):
        for name in ['NX_14_Mutterhalter_Lageraufnahmen.py','Projekt04_Halterbericht.py','cnc_nx/housings04.py']:
            self.assertTrue((ROOT/name).is_file(),name)
if __name__=='__main__':unittest.main()
