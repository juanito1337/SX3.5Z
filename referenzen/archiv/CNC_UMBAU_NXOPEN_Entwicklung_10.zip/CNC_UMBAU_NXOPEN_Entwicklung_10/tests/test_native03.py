import copy, unittest
from construction.recipes03 import motor_recipe,reference_carrier
from cnc_nx import build03
class Native03Tests(unittest.TestCase):
 def api(self,n):
  f=getattr(build03,n,None);self.assertTrue(callable(f),'Missing '+n);return f
 def test_motor_operations_are_contiguous_nominal_geometry(self):
  rows=self.api('numeric_operations')(motor_recipe())
  self.assertEqual(rows[0]['size'],[56.4,56.4,103.]);self.assertEqual(rows[1]['origin'],[0.,0.,-1.6])
  self.assertEqual(rows[2]['height'],21.)
 def test_hole_pitch_depends_on_parameter(self):
  r=reference_carrier()['parts'][1];r['parameters']['motor_pitch']=50
  rows=self.api('numeric_operations')(r)
  self.assertEqual(rows[2]['origin'][:2],[-25.,-25.]);self.assertEqual(rows[5]['origin'][:2],[25.,25.])
 def test_matrix_pack_transpose(self):
  R=[[0,-1,0],[1,0,0],[0,0,1]]
  self.assertEqual(self.api('matrix_fields')(R,'ROWS'),[0.,-1.,0.,1.,0.,0.,0.,0.,1.])
  self.assertEqual(self.api('matrix_fields')(R,'TRANSPOSE'),[0.,1.,0.,-1.,0.,0.,0.,0.,1.])
 def test_invalid_convention_rejected(self):
  with self.assertRaises(ValueError):self.api('matrix_fields')([[1,0,0],[0,1,0],[0,0,1]],'AUTO_GUESS')
 def test_new_native_runtime_import_is_lazy(self):
  # Author offline checks must never load NXOpen or claim a native run.
  self.assertFalse(getattr(build03,'NATIVE_EXECUTED_BY_AUTHOR',True))
 def test_record_counts_are_not_kernel_success(self):
  rows=self.api('numeric_operations')(motor_recipe());self.assertEqual(len(rows),8)
 def test_fake_factory_not_needed_for_numeric_contract(self):
  r=motor_recipe();r['parameters']['hole_pitch']=float('inf')
  with self.assertRaises(ValueError):self.api('numeric_operations')(r)
if __name__=='__main__':unittest.main()
