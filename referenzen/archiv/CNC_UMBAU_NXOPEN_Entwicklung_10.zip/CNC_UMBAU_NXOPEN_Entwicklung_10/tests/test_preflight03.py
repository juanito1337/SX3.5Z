import copy,unittest
from construction.recipes03 import sleeve_recipe,validate_recipe
from construction.axis_native03 import validate_axis_design
I=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]]
class Preflight03Tests(unittest.TestCase):
 def recipe(self):return sleeve_recipe('TEST03',14,6.6,50,'Design nominal fixture')
 def axis(self):
  return dict(axis='X',review=dict(status='MODEL_LAYOUT_REVIEWED',evidence='TEST ONLY'),frame=dict(origin_mm=[0,0,0],rotation=I,evidence='TEST ONLY'),custom_parts=[],components=[dict(id='p',path='C:/test.prt',sha256='a'*64,source='fixture',kind='PURCHASE',dimensions_status='CATALOGUE_REFERENCE',rotation=I,origin_mm=[0,0,0])])
 def test_unknown_recipe_kind_refused_before_nx(self):
  r=self.recipe();r['kind']='invented'
  with self.assertRaises(ValueError):validate_recipe(r)
 def test_recipe_parameter_probe_key_required(self):
  r=self.recipe();r['kind']='flange_holder'
  with self.assertRaises(ValueError):validate_recipe(r)
 def test_axis_missing_purchase_dimension_status_refused(self):
  a=self.axis();a['components'][0].pop('dimensions_status')
  with self.assertRaises(ValueError):validate_axis_design(a)
 def test_axis_original_not_silently_used_as_purchase(self):
  a=self.axis();a['components'][0]['kind']='ORIGINAL'
  with self.assertRaises(ValueError):validate_axis_design(a)
 def test_axis_bad_id_rejected_before_nx(self):
  a=self.axis();a['components'][0]['id']='../bad'
  with self.assertRaises(ValueError):validate_axis_design(a)
 def test_valid_axis_does_not_grant_release(self):
  r=validate_axis_design(self.axis());self.assertFalse(r['manufacturing_released'])
if __name__=='__main__':unittest.main()
