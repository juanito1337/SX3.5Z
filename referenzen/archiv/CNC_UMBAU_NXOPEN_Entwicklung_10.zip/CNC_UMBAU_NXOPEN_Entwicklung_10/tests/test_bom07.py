"""Pure data tests. Files/parts are fixtures, not actual NX geometry."""
import copy
import importlib
import unittest

H='a'*64

def prototype(pid, solids=1, **changes):
    p=dict(id=pid,name=pid,path='/fixture/'+pid+'.prt',sha256_before=H,sha256_after=H,
           modified_before=False,modified_after=False,fully_loaded=True,body_count=solids,
           solid_body_count=solids,non_solid_body_count=0)
    p.update(changes);return p

def node(path,pid,parent=None,children=0,**changes):
    n=dict(path=path,parent=parent,name=path,prototype_id=pid,suppressed=False,children_count=children,
           reference_set='Entire Part')
    n.update(changes);return n

def snapshot():
    return dict(schema='SX35Z_BOM_SNAPSHOT_7',origin='TEST_FIXTURE_NOT_NX',
                root='0000',prototypes=[prototype('root',0),prototype('sleeve')],
                occurrences=[node('0000','root',children=2),node('0000/0','sleeve','0000'),
                             node('0000/1','sleeve','0000')],issues=[])

class BomTests(unittest.TestCase):
    def module(self):
        try:return importlib.import_module('analysis.bom07')
        except ImportError:self.fail('Occurrence-derived BOM is not implemented')
    def summarize(self,data=None):return self.module().summarize(data or snapshot())
    def test_repeated_prototype_counts_occurrences(self):
        r=self.summarize();self.assertEqual(r['rows'][0]['quantity'],2)
        self.assertEqual(r['counts']['active_leaf_occurrences'],2)
        self.assertEqual(r['counts']['assembly_occurrences'],1)
    def test_not_fabricated_order_release(self):
        r=self.summarize();self.assertFalse(r['order_released']);self.assertFalse(r['manufacturing_released'])
        self.assertFalse(r['native_read_in_this_run'])
    def test_no_registry_reports_unassigned(self):
        r=self.summarize();self.assertEqual(r['status'],'UNASSIGNED_ITEMS')
        self.assertEqual(r['rows'][0]['kind'],'UNASSIGNED')
    def test_nested_repeated_subassembly_doubles_leaf_quantity(self):
        s=snapshot();s['prototypes'].append(prototype('sub',0));s['occurrences']=[node('0000','root',children=2)]
        for a in ('a','b'):
            s['occurrences'].append(node('0000/'+a,'sub','0000',2))
            for b in ('x','y'):s['occurrences'].append(node('0000/'+a+'/'+b,'sleeve','0000/'+a))
        r=self.summarize(s);self.assertEqual(r['rows'][0]['quantity'],4);self.assertEqual(r['counts']['assembly_occurrences'],3)
    def test_suppressed_subtree_excluded_even_if_child_claims_active(self):
        s=snapshot();s['occurrences'][1].update(suppressed=True,children_count=1)
        s['occurrences'].append(node('0000/0/a','sleeve','0000/0'))
        r=self.summarize(s);self.assertEqual(r['rows'][0]['quantity'],1)
        self.assertEqual(r['counts']['suppressed_branches'],1)
    def test_suppressed_branch_can_be_unread(self):
        s=snapshot();s['occurrences'][1].update(suppressed=True,children_count=None,prototype_id=None)
        r=self.summarize(s);self.assertTrue(r['inventory_complete']);self.assertEqual(r['rows'][0]['quantity'],1)
    def test_unknown_suppression_not_counted(self):
        s=snapshot();s['occurrences'][1]['suppressed']=None
        r=self.summarize(s);self.assertFalse(r['inventory_complete']);self.assertEqual(r['rows'][0]['quantity'],1)
    def test_unloaded_parent_not_treated_as_empty_leaf(self):
        s=snapshot();s['prototypes'][0]['fully_loaded']=False;s['occurrences']=s['occurrences'][:1];s['occurrences'][0]['children_count']=0
        r=self.summarize(s);self.assertEqual(r['rows'],[]);self.assertFalse(r['inventory_complete'])
    def test_unknown_child_count_is_not_zero(self):
        s=snapshot();s['occurrences'][1]['children_count']=None
        r=self.summarize(s);self.assertEqual(r['counts']['active_leaf_occurrences'],1);self.assertFalse(r['inventory_complete'])
    def test_missing_child_is_incomplete(self):
        s=snapshot();s['occurrences'][0]['children_count']=3
        r=self.summarize(s);self.assertFalse(r['inventory_complete'])
    def test_missing_prototype_remains_in_occurrence_report(self):
        s=snapshot();s['occurrences'][1]['prototype_id']='absent';r=self.summarize(s)
        self.assertFalse(r['inventory_complete']);self.assertEqual(len(r['occurrences']),3)
    def test_multi_solid_part_counts_one_piece(self):
        s=snapshot();s['prototypes'][1].update(body_count=3,solid_body_count=3)
        r=self.summarize(s);self.assertEqual(r['rows'][0]['quantity'],2);self.assertEqual(r['rows'][0]['solid_body_count'],3)
    def test_sheet_part_is_not_dropped(self):
        s=snapshot();s['prototypes'][1].update(body_count=1,solid_body_count=0,non_solid_body_count=1)
        r=self.summarize(s);self.assertEqual(r['rows'][0]['quantity'],2)
    def test_mixed_body_subassembly_is_not_guessed(self):
        s=snapshot();s['prototypes'][0].update(body_count=1,solid_body_count=1)
        r=self.summarize(s);self.assertFalse(r['inventory_complete']);self.assertTrue(any(x['code']=='MIXED_BODY_ASSEMBLY' for x in r['issues']))
    def test_empty_leaf_needs_explicit_handling(self):
        s=snapshot();s['prototypes'][1].update(body_count=0,solid_body_count=0)
        r=self.summarize(s);self.assertFalse(r['inventory_complete']);self.assertEqual(r['rows'],[])
    def test_unknown_body_count_blocks_leaf(self):
        s=snapshot();s['prototypes'][1]['body_count']=None
        r=self.summarize(s);self.assertFalse(r['inventory_complete']);self.assertEqual(r['rows'],[])
    def test_duplicate_occurrence_id_rejected(self):
        s=snapshot();s['occurrences'].append(copy.deepcopy(s['occurrences'][1]))
        with self.assertRaises(ValueError):self.summarize(s)
    def test_duplicate_prototype_id_rejected(self):
        s=snapshot();s['prototypes'].append(copy.deepcopy(s['prototypes'][1]))
        with self.assertRaises(ValueError):self.summarize(s)
    def test_orphan_rejected(self):
        s=snapshot();s['occurrences'][1]['parent']='nonexistent'
        with self.assertRaises(ValueError):self.summarize(s)
    def test_cycle_rejected(self):
        s=snapshot();s['occurrences'][0]['parent']='0000/0'
        with self.assertRaises(ValueError):self.summarize(s)
    def test_disconnected_cycle_rejected(self):
        s=snapshot();s['occurrences'] += [node('a','sleeve','b'),node('b','sleeve','a')]
        with self.assertRaises(ValueError):self.summarize(s)
    def test_bool_child_count_not_valid_integer(self):
        s=snapshot();s['occurrences'][1]['children_count']=False
        r=self.summarize(s);self.assertFalse(r['inventory_complete'])
    def test_bad_schema_rejected(self):
        s=snapshot();s['schema']='other'
        with self.assertRaises(ValueError):self.summarize(s)
    def test_input_is_not_modified(self):
        s=snapshot();before=copy.deepcopy(s);self.summarize(s);self.assertEqual(s,before)
    def test_hidden_reference_set_is_not_suppression(self):
        s=snapshot();s['occurrences'][1]['reference_set']='Empty'
        r=self.summarize(s);self.assertEqual(r['rows'][0]['quantity'],2)
    def test_dirty_part_not_bound_to_disk_revision(self):
        s=snapshot();s['prototypes'][1]['modified_before']=True
        r=self.summarize(s);self.assertFalse(r['source_binding_complete']);self.assertEqual(r['status'],'INCOMPLETE_INVENTORY')
    def test_changed_source_hash_is_not_complete(self):
        s=snapshot();s['prototypes'][1]['sha256_after']='b'*64
        r=self.summarize(s);self.assertFalse(r['source_binding_complete'])
    def test_equal_basename_in_different_directories_not_merged(self):
        s=snapshot();s['prototypes'].append(prototype('other',path='/different/sleeve.prt'))
        s['occurrences'][2]['prototype_id']='other';r=self.summarize(s);self.assertEqual(len(r['rows']),2)
    def test_single_displayed_part_counts_one(self):
        s=snapshot();s['occurrences']=[node('0000','sleeve')];r=self.summarize(s)
        self.assertEqual(r['rows'][0]['quantity'],1)
    def test_order_independence(self):
        s=snapshot();r=self.summarize(s);s['occurrences'].reverse();s['prototypes'].reverse()
        self.assertEqual(r['rows'],self.summarize(s)['rows'])
    def test_recipe_preview_never_claims_native_read(self):
        s=snapshot();s['origin']='RECIPE_PREVIEW';r=self.summarize(s)
        self.assertEqual(r['source_origin'],'RECIPE_PREVIEW');self.assertFalse(r['native_read_in_this_run'])
