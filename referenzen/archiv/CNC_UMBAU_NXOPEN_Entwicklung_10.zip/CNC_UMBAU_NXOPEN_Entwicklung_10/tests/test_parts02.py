import importlib.util, unittest, math, copy

class Parts02(unittest.TestCase):
    def module(self):
        self.assertIsNotNone(importlib.util.find_spec('construction.part_contracts'),'part_contracts missing')
        from construction import part_contracts
        return part_contracts
    def sample(self):
        return dict(id='D_X_PLATTE',kind='plate',status='DESIGN_PROPOSAL',source='Designer proposal',
            material_proposal='EN AW-6082 T6',width_mm=90,height_mm=90,thickness_mm=12,
            center_bore_mm=38.5,holes=[dict(x_mm=x,y_mm=y,diameter_mm=5.5) for x in [-30,30] for y in [-30,30]])
    def test_plate_volume(self):
        m=self.module();s=self.sample();r=m.validate_part(s)
        self.assertAlmostEqual(r['volume_mm3'],90*90*12-math.pi/4*(38.5**2+4*5.5**2)*12)
        self.assertFalse(r['manufacturing_released'])
    def test_hole_overlap_rejected(self):
        m=self.module();s=self.sample();s['holes'].append(s['holes'][0].copy())
        with self.assertRaises(ValueError):m.validate_part(s)
    def test_hole_outside_blank_rejected(self):
        m=self.module();s=self.sample();s['holes'][0]['x_mm']=45
        with self.assertRaises(ValueError):m.validate_part(s)
    def test_hole_intersects_center_rejected(self):
        m=self.module();s=self.sample();s['holes'][0]['x_mm']=0;s['holes'][0]['y_mm']=0
        with self.assertRaises(ValueError):m.validate_part(s)
    def test_bad_id_and_nan_rejected(self):
        m=self.module()
        for key,value in [('id','../existing'),('width_mm',float('nan')),('thickness_mm',True)]:
            s=self.sample();s[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):m.validate_part(s)
    def test_no_manufacturer_claim_from_design_dimensions(self):
        m=self.module();s=self.sample();s['status']='MANUFACTURER_VERIFIED'
        with self.assertRaises(ValueError):m.validate_part(s)
    def test_ring_volume_and_separate_sources(self):
        m=self.module();s=dict(id='D_DISTANZ',kind='sleeve',status='DESIGN_PROPOSAL',source='Designer',
             outer_mm=16,inner_mm=6.6,length_mm=45)
        self.assertAlmostEqual(m.validate_part(s)['volume_mm3'],math.pi/4*(16**2-6.6**2)*45)
    def test_axis_gate_does_not_accept_just_confirmed_string(self):
        self.assertIsNotNone(importlib.util.find_spec('construction.axis_plan'))
        from construction.axis_plan import compile_axis
        with self.assertRaises(ValueError):compile_axis('X',{'status':'CONFIRMED'})

if __name__=='__main__':unittest.main()

class JournalGuards02(unittest.TestCase):
    def test_invalid_spec_stops_before_creating_part(self):
        import importlib.util
        self.assertIsNotNone(importlib.util.find_spec('cnc_nx.parts02'))
        from cnc_nx.parts02 import validate_batch
        with self.assertRaises(ValueError):validate_batch([{'id':'bad','status':'DESIGN_PROPOSAL'}])
    def test_duplicate_file_id_rejected_before_nx(self):
        import importlib.util
        self.assertIsNotNone(importlib.util.find_spec('cnc_nx.parts02'))
        from cnc_nx.parts02 import validate_batch
        s=Parts02().sample()
        with self.assertRaises(ValueError):validate_batch([s,s])
