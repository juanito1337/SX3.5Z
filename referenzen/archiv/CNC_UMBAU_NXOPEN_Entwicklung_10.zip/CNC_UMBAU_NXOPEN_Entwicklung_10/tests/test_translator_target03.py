import tempfile,unittest
from pathlib import Path
from types import SimpleNamespace as N
from cnc_nx import exchange03
class TranslatorTargetTests(unittest.TestCase):
 def setup_case(self,t):
  part=N(Tag=7,FullPath=str(Path(t)/'new_owned.prt'));record={'part':part,'path':Path(part.FullPath),'disk_hash':None}
  return part,N(records={7:record}),N(Parts=N(Work=part)),N(Step214Importer=N(ImportToOption=N(WorkPart='WORK')))
 def api(self):
  f=getattr(exchange03,'configure_owned_import',None);self.assertTrue(callable(f),'No owned-target translator configuration');return f
 def test_exact_owned_output_is_set(self):
  with tempfile.TemporaryDirectory() as t:
   part,owned,session,nx=self.setup_case(t);imp=N(ObjectTypes=N())
   self.api()(imp,nx,session,part,owned,str(Path(t)/'supplier.step'),'')
   self.assertEqual(imp.OutputFile,part.FullPath);self.assertFalse(imp.FileOpenFlag);self.assertEqual(imp.ImportTo,'WORK')
 def test_original_part_not_allowed_as_target(self):
  with tempfile.TemporaryDirectory() as t:
   part,owned,session,nx=self.setup_case(t);owned.records={}
   with self.assertRaises(RuntimeError):self.api()(N(),nx,session,part,owned,'supplier.step','')
 def test_wrong_workpart_is_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   part,owned,session,nx=self.setup_case(t);session.Parts.Work=N(Tag=99)
   with self.assertRaises(RuntimeError):self.api()(N(),nx,session,part,owned,'supplier.step','')
 def test_changed_native_path_is_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   part,owned,session,nx=self.setup_case(t);part.FullPath=str(Path(t)/'original.prt')
   with self.assertRaises(RuntimeError):self.api()(N(),nx,session,part,owned,'supplier.step','')
if __name__=='__main__':unittest.main()

class TranslatorCommitTests(TranslatorTargetTests):
 def accept(self):
  f=getattr(exchange03,'acknowledge_owned_import_output',None);self.assertTrue(callable(f),'Missing owned-output completion guard');return f
 def test_missing_file_remains_unsaved(self):
  with tempfile.TemporaryDirectory() as t:
   part,owned,session,nx=self.setup_case(t)
   self.accept()(part,owned)
   self.assertIsNone(owned.records[7]['disk_hash'])
 def test_owned_translator_output_is_tracked(self):
  import hashlib
  with tempfile.TemporaryDirectory() as t:
   part,owned,session,nx=self.setup_case(t);Path(part.FullPath).write_bytes(b'NX fixture')
   self.accept()(part,owned)
   self.assertEqual(owned.records[7]['disk_hash'],hashlib.sha256(b'NX fixture').hexdigest())
 def test_renamed_target_not_adopted(self):
  with tempfile.TemporaryDirectory() as t:
   part,owned,session,nx=self.setup_case(t);part.FullPath=str(Path(t)/'other.prt');Path(part.FullPath).write_bytes(b'other')
   with self.assertRaises(RuntimeError):self.accept()(part,owned)
