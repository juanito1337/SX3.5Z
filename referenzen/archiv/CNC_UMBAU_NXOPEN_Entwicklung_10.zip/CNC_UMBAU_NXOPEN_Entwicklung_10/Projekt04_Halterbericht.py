"""Offline parameter/bores report. Does not create CAD, drawings or NX files."""
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from construction.library04 import write_reports


def main():
    root=Path(__file__).absolute().parent
    out=root/'output'/('Halterbericht04_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:8])
    write_reports(out)
    print('Nur analytische Berichte, keine NX-Dateien / Fertigungsfreigabe: '+str(out))

if __name__=='__main__':main()
