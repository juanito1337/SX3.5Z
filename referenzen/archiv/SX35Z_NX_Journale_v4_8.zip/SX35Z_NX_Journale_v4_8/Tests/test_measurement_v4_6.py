# -*- coding: utf-8 -*-
"""Regression for the uploaded v4.5 failure. Simulated NX bindings, NOT NX.

Crucially, most test UF sessions DO NOT expose AskMassProps3d. This covers the
missing API that the old CAD-backed doubles incorrectly assumed available.
"""
import ast
import math
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import nx_geometry as geom

class Unit:
    def __init__(self, name, sequence):
        self.name = name; self.sequence = sequence

class Units:
    def __init__(self):
        self.calls = []; self.sequence = 0
    def FindObject(self, name):
        if name not in geom.BodyInspector.UNIT_NAMES:
            raise ValueError(name)
        self.sequence += 1
        self.calls.append(name)
        return Unit(name, self.sequence)

class Result:
    def __init__(self, value):
        self.value = value; self.disposed = False
    @property
    def Volume(self):
        if isinstance(self.value, Exception):
            raise self.value
        return self.value
    def Dispose(self):
        if self.disposed:
            raise AssertionError('double dispose')
        self.disposed = True

class Collector:
    def __init__(self):
        self.destroyed = False; self.rules = None
    def ReplaceRules(self, rules, append):
        assert append is False
        self.rules = rules
    def Destroy(self):
        assert not self.destroyed
        self.destroyed = True

class Manager:
    """Can expose just ONE of the documented overloads, like an NX binding."""
    def __init__(self, accepted='manager_bodies_accuracy', value=6000.0):
        self.accepted = accepted; self.value = value
        self.calls = []; self.results = []; self.fail = None
    def NewMassProperties(self, *args):
        """Fake NewMassProperties(units, accuracy_or_tolerances, [createGeometry], objects)."""
        assert len(args) in (3, 4)
        units, accuracy = args[:2]
        objects = args[-1]
        assert [u.name for u in units] == list(geom.BodyInspector.UNIT_NAMES)
        assert len({u.sequence for u in units}) == 5
        mode = 'manager_' + ('bodies' if isinstance(objects, list) else 'collector')
        mode += '_tolerances' if isinstance(accuracy, list) else '_accuracy'
        if len(args) == 4:
            assert args[2] is False
            mode += '_no_geometry'
        self.calls.append((mode, args))
        if self.fail:
            raise self.fail
        if mode != self.accepted:
            raise TypeError('simulated unsupported overload ' + mode)
        if isinstance(accuracy, list):
            assert len(accuracy) == 11 and all(0 < x < 1e-5 for x in accuracy)
        else:
            assert 0.99999 < accuracy < 1.0
        if isinstance(objects, list):
            assert len(objects) == 1 and objects[0].Tag == 17
        else:
            assert len(objects.rules) == 1 and objects.rules[0][0].Tag == 17
        result = Result(self.value)
        self.results.append(result)
        return result

class Part:
    def __init__(self, manager):
        self.UnitCollection = Units()
        self.MeasureManager = manager
        self.WCS = types.SimpleNamespace(CoordinateSystem=types.SimpleNamespace(Tag=9))
        self.collectors = []
        def create():
            c = Collector(); self.collectors.append(c); return c
        self.ScCollectors = types.SimpleNamespace(CreateCollector=create)
        self.ScRuleFactory = types.SimpleNamespace(CreateRuleBodyDumb=lambda bodies: tuple(bodies))

class UFWithoutMass:
    def __init__(self):
        self.ModlGeneral = types.SimpleNamespace(AskBoundingBoxExact=self.box)
        self.answer = ([2, 3, 4], [[1, 0, 0], [0, 1, 0], [0, 0, 1]], [10, 20, 30])
    def box(self, tag, csys):
        assert tag == 17 and csys == 9
        return self.answer

class UFWithMass(UFWithoutMass):
    def __init__(self, group='ModlGeneral', spelling='AskMassProps3d'):
        super().__init__()
        self.calls = 0
        g = getattr(self, group, None)
        if g is None:
            g = types.SimpleNamespace(); setattr(self, group, g)
        setattr(g, spelling, self.mass)
    def mass(self, tags, count, kind, units, density, accuracy, values):
        self.calls += 1
        assert tags == [17] and count == 1 and kind == 1 and units == 4
        assert density == 1.0 and accuracy == 1 and len(values) == 11
        values = [0.] * 47; values[1] = 6000. / 1e9
        return values, [0.] * 13

class MeasurementTests(unittest.TestCase):
    def make(self, manager=True, uf=None):
        uf = uf or UFWithoutMass()
        if manager is True: manager = Manager()
        nx = types.ModuleType('NXOpen'); sub = types.ModuleType('NXOpen.UF')
        sub.UFSession = types.SimpleNamespace(GetUFSession=lambda: uf); nx.UF = sub
        p = patch.dict(sys.modules, {'NXOpen': nx, 'NXOpen.UF': sub})
        p.start(); self.addCleanup(p.stop)
        self.part = Part(manager); self.logs = []; self.uf = uf
        self.body = types.SimpleNamespace(Tag=17)
        return geom.BodyInspector(self.part, self.logs.append)
    def test_uploaded_failure_no_uf_mass_is_now_supported(self):
        i = self.make()
        self.assertIsNone(i.mass)
        got = i.measure(self.body)
        self.assertEqual(got['volume_mm3'], 6000.)
        self.assertEqual(got['bounds_mm'], [2, 3, 4, 12, 23, 34])
        self.assertEqual(i.mode, 'manager_bodies_accuracy')
    def test_high_level_does_not_apply_m3_multiplier(self):
        i = self.make()
        self.assertEqual(i.measure(self.body)['volume_mm3'], 6000.)
    def test_high_level_preferred_even_if_uf_present(self):
        uf = UFWithMass(); i = self.make(uf=uf)
        i.measure(self.body); self.assertEqual(uf.calls, 0)
    def test_five_units_in_correct_order(self):
        i = self.make(); i.measure(self.body)
        self.assertEqual(self.part.UnitCollection.calls, list(i.UNIT_NAMES))
    def test_fresh_units_every_measurement(self):
        i = self.make(); i.measure(self.body); i.measure(self.body)
        calls = self.part.MeasureManager.calls
        self.assertTrue(all(a.sequence != b.sequence for a, b in zip(calls[0][1][0], calls[1][1][0])))
    def test_transient_measurement_disposed(self):
        i = self.make(); i.measure(self.body)
        self.assertTrue(self.part.MeasureManager.results[0].disposed)
    def test_collector_accuracy_overload(self):
        i = self.make(Manager('manager_collector_accuracy')); i.measure(self.body)
        self.assertEqual(i.mode, 'manager_collector_accuracy')
        self.assertTrue(all(c.destroyed for c in self.part.collectors))
    def test_bodies_tolerances_overload(self):
        i = self.make(Manager('manager_bodies_tolerances')); i.measure(self.body)
        self.assertEqual(i.mode, 'manager_bodies_tolerances')
        self.assertTrue(all(c.destroyed for c in self.part.collectors))
    def test_collector_tolerances_overload(self):
        i = self.make(Manager('manager_collector_tolerances')); i.measure(self.body)
        self.assertEqual(i.mode, 'manager_collector_tolerances')
        self.assertTrue(all(c.destroyed for c in self.part.collectors))
    def test_collector_explicit_no_geometry_overload(self):
        i = self.make(Manager('manager_collector_accuracy_no_geometry')); i.measure(self.body)
        self.assertEqual(i.mode, 'manager_collector_accuracy_no_geometry')
    def test_collector_tolerances_explicit_no_geometry(self):
        i = self.make(Manager('manager_collector_tolerances_no_geometry')); i.measure(self.body)
        self.assertEqual(i.mode, 'manager_collector_tolerances_no_geometry')
    def test_uf_fallback_only_when_available(self):
        i = self.make(manager=None, uf=UFWithMass()); got = i.measure(self.body)
        self.assertAlmostEqual(got['volume_mm3'], 6000.); self.assertEqual(i.mode, 'uf_mass')
    def test_uf_modeling_group_supported(self):
        i = self.make(manager=None, uf=UFWithMass(group='Modeling')); i.measure(self.body)
        self.assertEqual(i.mass_name, 'UF.Modeling.AskMassProps3d')
    def test_uf_capital_D_alias_supported(self):
        i = self.make(manager=None, uf=UFWithMass(spelling='AskMassProps3D')); i.measure(self.body)
        self.assertEqual(i.mass_name, 'UF.ModlGeneral.AskMassProps3D')
    def test_no_available_measurement_aborts_instead_of_disabling(self):
        with self.assertRaisesRegex(RuntimeError, 'Keine ausfuehrbare NX-Volumenmessung'):
            self.make(manager=None)
    def test_all_overloads_rejected_no_fake_result(self):
        i = self.make(Manager('none'))
        with self.assertRaisesRegex(RuntimeError, 'NICHT abgeschaltet'): i.measure(self.body)
        self.assertEqual(len(i.attempts), 6)
    def test_failed_manager_can_select_real_uf(self):
        i = self.make(Manager('none'), UFWithMass())
        self.assertAlmostEqual(i.measure(self.body)['volume_mm3'], 6000.)
        self.assertEqual(i.mode, 'uf_mass')
    def test_selected_backend_never_silently_switches(self):
        uf = UFWithMass(); i = self.make(uf=uf); i.measure(self.body)
        self.part.MeasureManager.fail = RuntimeError('later real measurement failed')
        with self.assertRaisesRegex(RuntimeError, 'later real'): i.measure(self.body)
        self.assertEqual(uf.calls, 0)
    def test_zero_volume_rejected_and_disposed(self):
        i = self.make(Manager(value=0.))
        with self.assertRaises(geom.MeasurementValueError): i.measure(self.body)
        self.assertTrue(self.part.MeasureManager.results[0].disposed)
    def test_negative_volume_rejected(self):
        i = self.make(Manager(value=-1.))
        with self.assertRaises(geom.MeasurementValueError): i.measure(self.body)
    def test_nan_volume_rejected(self):
        i = self.make(Manager(value=float('nan')))
        with self.assertRaises(geom.MeasurementValueError): i.measure(self.body)
    def test_infinite_volume_rejected(self):
        i = self.make(Manager(value=float('inf')))
        with self.assertRaises(geom.MeasurementValueError): i.measure(self.body)
    def test_bad_value_does_not_use_uf_fallback(self):
        uf = UFWithMass(); i = self.make(Manager(value=0.), uf)
        with self.assertRaises(geom.MeasurementValueError): i.measure(self.body)
        self.assertEqual(uf.calls, 0)
    def test_wrong_positive_scale_rejected_by_contract(self):
        i = self.make(Manager(value=6000e9)); got = i.measure(self.body)
        expected = dict(bounds_mm=got['bounds_mm'], volume_mm3=6000.)
        with self.assertRaisesRegex(RuntimeError, 'Volumen IST'): geom.assert_contract(got, expected, 'probe')
    def test_flat_direction_matrix_supported(self):
        uf = UFWithoutMass(); uf.answer = ([0, 0, 0], [1, 0, 0, 0, 1, 0, 0, 0, 1], [10, 20, 30])
        i = self.make(uf=uf); self.assertEqual(i.measure(self.body)['bounds_mm'], [0, 0, 0, 10, 20, 30])
    def test_rotated_bbox_reconstructed(self):
        uf = UFWithoutMass(); uf.answer = ([2, 3, 4], [[0, 1, 0], [-1, 0, 0], [0, 0, 1]], [10, 20, 30])
        i = self.make(uf=uf); self.assertEqual(i.measure(self.body)['bounds_mm'], [-18, 3, 4, 2, 13, 34])
    def test_nonfinite_bbox_rejected(self):
        uf = UFWithoutMass(); uf.answer = ([float('nan'), 0, 0], [[1, 0, 0], [0, 1, 0], [0, 0, 1]], [10, 20, 30])
        i = self.make(uf=uf)
        with self.assertRaisesRegex(RuntimeError, 'endliche'): i.measure(self.body)
    def test_negative_bbox_extent_rejected(self):
        uf = UFWithoutMass(); uf.answer = ([0, 0, 0], [[1, 0, 0], [0, 1, 0], [0, 0, 1]], [-10, 20, 30])
        i = self.make(uf=uf)
        with self.assertRaisesRegex(RuntimeError, 'Begrenzungen'): i.measure(self.body)
    def test_bbox_missing_fails_explicitly(self):
        uf = UFWithoutMass(); uf.ModlGeneral = types.SimpleNamespace()
        with self.assertRaisesRegex(RuntimeError, 'AskBoundingBoxExact fehlt'): self.make(uf=uf)
    def test_diagnostics_include_real_available_methods(self):
        i = self.make(); i.diagnostics()
        text = '\n'.join(self.logs)
        self.assertIn('AskBoundingBoxExact', text); self.assertIn('NewMassProperties', text)
    def test_geometry_tolerances_unchanged(self):
        self.assertEqual(geom.BOUND_TOL_MM, .005)
        self.assertEqual(geom.REL_VOLUME_TOL, 1e-5)
        self.assertEqual(geom.ABS_VOLUME_TOL, .002)
    def test_all_production_files_have_python310_syntax(self):
        for f in ROOT.glob('*.py'): ast.parse(f.read_text(), feature_version=(3, 10))

if __name__ == '__main__': unittest.main(verbosity=2)
