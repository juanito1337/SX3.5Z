# -*- coding: utf-8 -*-
"""Mock-based regression tests. NOT a Siemens NX execution or geometric test.

Two suspected mechanisms (unit-handle invalidation and update/metadata ordering)
are deliberately simulated. Passing these tests does NOT prove either mechanism
caused the user's NX2406 exception. Run outside NX using Python 3.10+.
"""
import ast
import copy
import math
from pathlib import Path
import types
import unittest
from unittest.mock import patch
import nx_test_bootstrap as bootstrap

nx=bootstrap.nx
native=bootstrap.native
driver=bootstrap.driver
model=driver.model
nx.SmartObject=types.SimpleNamespace(UpdateOption=types.SimpleNamespace(WithinModeling=1))
nx.Scalar=types.SimpleNamespace(DimensionalityType=types.SimpleNamespace(Length=1))
nx.Update=types.SimpleNamespace(Option=types.SimpleNamespace(Now=1))
nx.Session=types.SimpleNamespace(MarkVisibility=types.SimpleNamespace(Invisible=0,Visible=1))

class SimulatedNXError(RuntimeError):
    ErrorCode=999001

class Unit:
    def __init__(self, part):self.part=part;self.generation=part.generation;self.Tag=1000+part.generation
    def assert_valid(self,part):
        if self.part is not part or self.generation!=part.generation:
            raise SimulatedNXError('SIMULATED stale Unit; not proof of real NX cause')

class Units:
    def __init__(self,part):self.part=part;self.get_calls=0;self.find_calls=0;self.fail_get=False
    def GetBase(self,name):
        self.get_calls+=1
        if self.fail_get:raise LookupError('SIMULATED GetBase failure')
        if name!='Length':raise ValueError(name)
        return Unit(self.part)
    def FindObject(self,name):
        self.find_calls+=1
        if name!='MilliMeter':raise ValueError(name)
        return Unit(self.part)
    def Convert(self,base,mm,value):
        base.assert_valid(self.part);mm.assert_valid(self.part)
        return float(value)

class Expressions:
    def __init__(self,part):self.part=part;self.items={};self.calls=[]
    def FindObject(self,name):return self.items[name]
    def __iter__(self):return iter(self.items.values())
    def _create(self,mode,*args):
        self.calls.append((mode,args))
        if mode not in self.part.allowed:raise TypeError('SIMULATED unsupported overload '+mode)
        if mode=='Number_mm':
            kind,equation=args
            if kind!='Number':raise TypeError('Number expected')
            name,formula=map(str.strip,equation.split('=',1))
        elif mode.endswith('4'):
            name,formula,locked,unit=args
            if not isinstance(name,str) or not isinstance(formula,str) or locked is not False:raise TypeError('wrong overload arguments')
            unit.assert_valid(self.part)
        else:
            equation,unit=args
            unit.assert_valid(self.part)
            name,formula=map(str.strip,equation.split('=',1))
        if name in self.items:raise SimulatedNXError('SIMULATED duplicate '+name)
        if self.part.fail_name==name and (not self.part.fail_modes or mode in self.part.fail_modes):
            # Sometimes a native failure can leave partial objects behind.
            if self.part.partial_on_failure:self.items[name]=Expression(self,name,formula,mode)
            raise SimulatedNXError('SIMULATED sx_table_y error after successful tiny probe')
        self.items[name]=result=Expression(self,name,formula,mode)
        # Also simulate unit wrapper expiration after successful calls.
        if self.part.invalidate_every_create:self.part.generation+=1
        return result
    def CreateNumberExpression(self,*args):return self._create('CreateNumberExpression4' if len(args)==4 else 'CreateNumberExpression',*args)
    def CreateWithUnits(self,*args):return self._create('CreateWithUnits4' if len(args)==4 else 'CreateWithUnits',*args)
    def CreateExpression(self,*args):return self._create('Number_mm',*args)
    def value(self,name,stack=None):
        stack=set() if stack is None else set(stack)
        if name in stack:raise ValueError('Cycle')
        stack.add(name)
        def visit(n):
            if isinstance(n,ast.Expression):return visit(n.body)
            if isinstance(n,ast.Constant):return float(n.value)
            if isinstance(n,ast.Name):return self.value(n.id,stack)
            if isinstance(n,ast.UnaryOp):return (-1 if isinstance(n.op,ast.USub) else 1)*visit(n.operand)
            if isinstance(n,ast.BinOp):
                a,b=visit(n.left),visit(n.right)
                if isinstance(n.op,ast.Add):return a+b
                if isinstance(n.op,ast.Sub):return a-b
                if isinstance(n.op,ast.Mult):return a*b
                if isinstance(n.op,ast.Div):return a/b
            raise ValueError(ast.dump(n))
        return visit(ast.parse(self.items[name].RightHandSide,mode='eval'))

class Expression:
    def __init__(self,collection,name,formula,mode):self.collection=collection;self.Name=name;self.RightHandSide=formula;self.mode=mode
    @property
    def Value(self):return self.collection.value(self.Name)
    def SetUserAttribute(self,*args):
        p=self.collection.part
        p.attr_calls.append((self.Name,args,len(p.Expressions.items)))
        p.generation+=1
        if p.attribute_error:raise SimulatedNXError('SIMULATED optional attribute error')

class Point:
    def __init__(self,x,y,z,update):self.scalars=(x,y,z)
    def Evaluate(self):pass
    def Blank(self):pass
    @property
    def Coordinates(self):return types.SimpleNamespace(**dict(zip(('X','Y','Z'),(s.Value for s in self.scalars))))

class Part:
    def __init__(self,allowed=None):
        self.allowed=set(allowed or ['CreateNumberExpression4','CreateNumberExpression','CreateWithUnits4','CreateWithUnits','Number_mm'])
        self.Name='SIMULATED_PART';self.PartUnits=bootstrap.StoredUnits.Millimeters
        self.generation=0;self.UnitCollection=Units(self);self.Expressions=Expressions(self)
        self.Scalars=types.SimpleNamespace(CreateScalarExpression=lambda e,d,u:e)
        self.Points=types.SimpleNamespace(CreatePoint=lambda *args:Point(*args))
        self.fail_name=None;self.fail_modes=set();self.partial_on_failure=False
        self.invalidate_every_create=False;self.attribute_error=False;self.attr_calls=[]
    def SetUserAttribute(self,*args):self.attr_calls.append(('PART',args,len(self.Expressions.items)))
    def CreateReferenceSet(self):return types.SimpleNamespace(SetName=lambda n:None,AddObjectsToReferenceSet=lambda objs:None)

class Session:
    def __init__(self,part):
        self.part=part;self.marks={};self.counter=0;self.undo_count=0;self.fail_undo=False
        self.update_errors=0
        self.UpdateManager=types.SimpleNamespace(DoUpdate=self.update)
    def update(self,mark):self.part.generation+=1;return self.update_errors
    def SetUndoMark(self,*args):
        self.counter+=1
        self.marks[self.counter]={n:(e.RightHandSide,e.mode) for n,e in self.part.Expressions.items.items()}
        return self.counter
    def UndoToMark(self,mark,*args):
        self.undo_count+=1
        if self.fail_undo:raise RuntimeError('SIMULATED rollback failure')
        self.part.Expressions.items={n:Expression(self.part.Expressions,n,r,m) for n,(r,m) in self.marks[mark].items()}
        self.part.generation+=1
    def DeleteUndoMark(self,mark,*args):del self.marks[mark]

class ExpressionRegression(unittest.TestCase):
    def setup_model(self,allowed=None):
        p=Part(allowed);s=Session(p);lines=[]
        params=model.load_parameters(str(bootstrap.ROOT/'Parameter.json'))
        b=native.NativeModelBuilder(s,p,params,lines.append)
        return p,s,b,lines

    def test_four_argument_overload_preferred_and_actual_str_types(self):
        p,s,b,lines=self.setup_model();f=b.expression_factory
        f.select(validate_model=b.create_expressions)
        self.assertEqual(f.mode,'CreateNumberExpression4')
        mode,args=p.Expressions.calls[0]
        self.assertEqual(args[:3],('sxprobe_a','10.25',False));self.assertIsInstance(args[3],Unit)
    def test_all_264_expressions_created_and_checked_then_rebuilt(self):
        p,s,b,lines=self.setup_model();b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(p.Expressions.items,{})
        b.create_expressions()
        self.assertEqual(len(p.Expressions.items),264)
        for n in b.expression_names:self.assertAlmostEqual(p.Expressions.FindObject('sx_'+n).Value,b.values[n])
    def test_simulated_invalid_handles_after_every_create_do_not_break_new_factory(self):
        p,s,b,lines=self.setup_model();p.invalidate_every_create=True
        b.expression_factory.select(validate_model=b.create_expressions);b.create_expressions()
        self.assertEqual(len(p.Expressions.items),264)
    def test_unit_resolved_on_each_call_not_reused(self):
        p,s,b,lines=self.setup_model();f=b.expression_factory;f.mode='CreateNumberExpression4'
        f.create('a = 1');p.generation+=1;f.create('b = 2')
        self.assertEqual(p.UnitCollection.get_calls,2)
    def test_unit_objects_are_local_to_part(self):
        p,s,b,lines=self.setup_model();q=Part();b.expression_factory.unit=Unit(q)
        b.expression_factory.mode='CreateNumberExpression4';b.expression_factory.create('a = 1')
        self.assertIs(p.Expressions.calls[-1][1][-1].part,p)
    def test_unit_getbase_failure_uses_documented_findobject(self):
        p,s,b,lines=self.setup_model();p.UnitCollection.fail_get=True
        b.expression_factory.mode='CreateNumberExpression4';b.expression_factory.create('a = 1')
        self.assertEqual(p.UnitCollection.find_calls,1)
    def test_two_argument_modern_fallback_if_four_unavailable(self):
        p,s,b,lines=self.setup_model(['CreateNumberExpression'])
        b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(b.expression_factory.mode,'CreateNumberExpression')
    def test_legacy_four_argument_fallback(self):
        p,s,b,lines=self.setup_model(['CreateWithUnits4'])
        b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(b.expression_factory.mode,'CreateWithUnits4')
    def test_legacy_two_argument_fallback(self):
        p,s,b,lines=self.setup_model(['CreateWithUnits'])
        b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(b.expression_factory.mode,'CreateWithUnits')
    def test_unitless_whole_mode_fallback_is_explicit_and_parametric(self):
        p,s,b,lines=self.setup_model(['Number_mm'])
        b.expression_factory.select(validate_model=b.create_expressions);b.create_expressions()
        self.assertEqual(b.expression_factory.mode,'Number_mm')
        self.assertIn('KOMPATIBILITAETSMODUS','\n'.join(lines))
        p.Expressions.FindObject('sx_head_down').RightHandSide='70'
        self.assertAlmostEqual(p.Expressions.FindObject('sx_head_bottom_z').Value,b.values['head_bottom_z']-10)
    def test_inch_part_stops_before_any_create(self):
        p,s,b,lines=self.setup_model();p.PartUnits=bootstrap.StoredUnits.Inches
        with self.assertRaisesRegex(RuntimeError,'Zollteil'):b.expression_factory.select(validate_model=b.create_expressions)
        self.assertFalse(p.Expressions.calls)
    def test_parameter_failure_after_tiny_probe_selects_next_complete_mode(self):
        p,s,b,lines=self.setup_model();p.fail_name='sx_table_y';p.fail_modes={'CreateNumberExpression4'}
        b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(b.expression_factory.mode,'CreateNumberExpression')
        self.assertTrue(any('sx_table_y' in text for text in lines))
        self.assertEqual(p.Expressions.items,{})
        b.create_expressions();self.assertEqual(len(p.Expressions.items),264)
    def test_failure_partial_objects_are_removed_before_next_mode(self):
        p,s,b,lines=self.setup_model();p.fail_name='sx_table_y';p.fail_modes={'CreateNumberExpression4'};p.partial_on_failure=True
        b.expression_factory.select(validate_model=b.create_expressions);b.create_expressions()
        self.assertEqual(len(p.Expressions.items),264)
        self.assertEqual({e.mode for e in p.Expressions.items.values()},{'CreateNumberExpression'})
    def test_failure_for_all_modes_leaves_no_half_model(self):
        p,s,b,lines=self.setup_model();p.fail_name='sx_table_y';p.partial_on_failure=True
        with self.assertRaisesRegex(RuntimeError,'Kein Ausdrucks'):b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(p.Expressions.items,{})
        self.assertIsNone(b.expression_factory.mode)
    def test_no_switch_during_real_create(self):
        p,s,b,lines=self.setup_model();f=b.expression_factory;f.mode='CreateNumberExpression4';p.fail_name='bad'
        with self.assertRaises(SimulatedNXError):f.create('bad = 1')
        self.assertEqual(f.mode,'CreateNumberExpression4');self.assertEqual(len(p.Expressions.calls),1)
    def test_bad_rollback_aborts_no_next_candidate(self):
        p,s,b,lines=self.setup_model(['Number_mm']);s.fail_undo=True
        with self.assertRaisesRegex(RuntimeError,'rollback failure'):b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(len(p.Expressions.calls),1)
    def test_existing_expressions_survive_all_test_rollbacks(self):
        p,s,b,lines=self.setup_model();p.Expressions.CreateExpression('Number','unrelated = 42')
        b.expression_factory.select(validate_model=b.create_expressions)
        self.assertEqual(list(p.Expressions.items),['unrelated']);self.assertEqual(p.Expressions.FindObject('unrelated').Value,42)
    def test_no_attributes_interleaved_with_model_expressions(self):
        p,s,b,lines=self.setup_model();b.expression_factory.mode='CreateNumberExpression4'
        b.create_expressions();self.assertFalse(p.attr_calls)
        b.write_expression_metadata()
        self.assertEqual(len(p.attr_calls),4*215)
        self.assertTrue(all(c[2]==264 for c in p.attr_calls))
    def test_metadata_uses_reacquired_names_not_undone_objects(self):
        p,s,b,lines=self.setup_model();b.expression_factory.select(validate_model=b.create_expressions);b.create_expressions()
        b.write_expression_metadata();self.assertEqual(len(p.attr_calls),860)
        self.assertEqual(b._expression_metadata,[])
    def test_metadata_errors_are_reported_not_ignored(self):
        p,s,b,lines=self.setup_model();b.expression_factory.mode='CreateNumberExpression4';b.create_expressions();p.attribute_error=True
        b.write_expression_metadata();self.assertEqual(len(b.warnings),860)
    def test_expression_creation_still_works_after_metadata_unit_invalidation(self):
        p,s,b,lines=self.setup_model();b.expression_factory.mode='CreateNumberExpression4';b.create_expressions();b.write_expression_metadata()
        b.expression_factory.create('extra = sx_table_x+1')
        self.assertEqual(p.Expressions.FindObject('extra').Value,741)
    def test_semantic_value_verification_catches_wrong_expression(self):
        p,s,b,lines=self.setup_model();b.expression_factory.mode='CreateNumberExpression4';b.create_expressions()
        p.Expressions.FindObject('sx_table_y').RightHandSide='181'
        with self.assertRaisesRegex(RuntimeError,'sx_table_y'):b.verify_expression_values()
    def test_part_dependency_subset_has_no_missing_names(self):
        params=model.load_parameters(str(bootstrap.ROOT/'Parameter.json'))
        for definition in model.recipe():
            with self.subTest(part=definition['id']):
                p=Part();s=Session(p);b=driver.PartBuilder(s,p,params,definition,lambda text:None)
                b.expression_factory.mode='CreateNumberExpression4';b.create_expressions()
                self.assertEqual(set(b.expression_names),b.needed)
                self.assertFalse(p.attr_calls)
    def test_solid_operations_finish_before_expression_attributes(self):
        params=model.load_parameters(str(bootstrap.ROOT/'Parameter.json'));definition=model.recipe()[0]
        p=Part();s=Session(p);b=driver.PartBuilder(s,p,params,definition,lambda text:None)
        count=[];body=object()
        def primitive(op,target,name):
            self.assertFalse(p.attr_calls);count.append(name);return object(),body
        b.primitive=primitive;b.style=lambda *args:None
        self.assertIs(b.build_one('CreateNumberExpression4'),body)
        self.assertEqual(len(count),len(b.definition['ops']));self.assertTrue(p.attr_calls)
    def test_invalid_equation_types_and_names_rejected(self):
        p,s,b,lines=self.setup_model();f=b.expression_factory;f.mode='CreateNumberExpression4'
        for equation in (123,'broken',' = 1','1bad = 1','a = '):
            with self.subTest(eq=equation),self.assertRaises((TypeError,ValueError)):f.create(equation)
        self.assertFalse(p.Expressions.calls)
    def test_rhs_equality_is_not_resplit(self):
        self.assertEqual(native.ExpressionFactory._split_equation('a = if (1=1) (2) else (3)'),('a','if (1=1) (2) else (3)'))
    def test_nan_and_infinite_actual_values_rejected(self):
        for v in (float('nan'),float('inf'),-float('inf')):
            with self.subTest(v=v),self.assertRaises(RuntimeError):native.ExpressionFactory._close(v,1,'test')
    def test_error_code_logged_for_failed_parameter(self):
        p,s,b,lines=self.setup_model();b.expression_factory.mode='CreateNumberExpression4';p.fail_name='sx_table_y'
        with self.assertRaises(SimulatedNXError):b.create_expressions()
        self.assertIn('NX-Fehlercode: 999001','\n'.join(lines))
    def test_no_unknown_mode_accepted(self):
        p,s,b,lines=self.setup_model();b.expression_factory.mode='UNKNOWN'
        with self.assertRaisesRegex(RuntimeError,'Unbekannter'):b.expression_factory.create('x = 1')
    def test_full_test_runs_after_basic_probe_undo(self):
        p,s,b,lines=self.setup_model();checks=[]
        def validate():
            checks.append(s.undo_count);self.assertFalse(p.Expressions.items);b.create_expressions()
        b.expression_factory.select(validate_model=validate)
        self.assertEqual(checks,[1]);self.assertEqual(s.undo_count,2)
    def test_update_failure_rejects_modes_and_leaves_no_objects(self):
        p,s,b,lines=self.setup_model();s.update_errors=1
        with self.assertRaisesRegex(RuntimeError,'Kein Ausdrucks'):b.expression_factory.select(validate_model=b.create_expressions)
        self.assertFalse(p.Expressions.items)
    def test_repeated_selection_and_rebuild_on_separate_parts(self):
        for i in range(3):
            p,s,b,lines=self.setup_model();b.expression_factory.select(validate_model=b.create_expressions);b.create_expressions()
            self.assertEqual(len(p.Expressions.items),264)

if __name__=='__main__':unittest.main(verbosity=2)
