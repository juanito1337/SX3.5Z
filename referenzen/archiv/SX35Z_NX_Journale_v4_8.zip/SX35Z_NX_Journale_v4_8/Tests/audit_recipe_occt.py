import sys, json, time, math
from pathlib import Path
import cadquery as cq
BASE=str(Path(__file__).resolve().parents[1])
sys.path.insert(0,BASE)
import modell_v4 as model

def tool(op,v):
    ev=lambda x:model.evaluate(x,v)
    orig=[ev(x) for x in op['origin']]
    if op['kind']=='box':return cq.Solid.makeBox(*[ev(x) for x in op['size']],pnt=cq.Vector(*orig))
    d=cq.Vector(*op['direction']);h=ev(op['height'])
    if op['kind']=='cylinder':return cq.Solid.makeCylinder(ev(op['diameter'])/2,h,cq.Vector(*orig),d)
    if op['kind']=='cone':return cq.Solid.makeCone(ev(op['diameter'])/2,ev(op['top_diameter'])/2,h,cq.Vector(*orig),d)
    pts=[cq.Vector(*[ev(x) for x in p]) for p in op['points']]
    wire=cq.Wire.makePolygon(pts+[pts[0]])
    return cq.Solid.extrudeLinear(wire,[],d.multiply(h))

def audit(ids=None):
    params=model.load_parameters(BASE+'/Parameter.json');v=model.all_values(params)
    report=[]
    for item in model.recipe():
        if ids and item['id'] not in ids:continue
        d=model.local_definition(item);body=None;rows=[]
        for i,op in enumerate(d['ops'],1):
            t0=time.monotonic();s=tool(op,v);before=body.Volume() if body else 0
            if body is None:body=s
            elif op['op']=='add':body=body.fuse(s).clean()
            else:body=body.cut(s).clean()
            after=body.Volume();delta=after-before
            row=dict(n=i,kind=op['kind'],operation=op['op'],label=op['label'],before=before,after=after,delta=delta,solids=len(body.Solids()),valid=body.isValid(),seconds=time.monotonic()-t0)
            rows.append(row)
            if abs(delta)<1e-5 or not row['valid'] or row['solids']!=1:print('CHECK',d['id'],row,flush=True)
            if d['id']=='P001':print('P001',i,op['label'],round(delta,6),flush=True)
        report.append(dict(id=d['id'],name=d['name'],rows=rows))
        (Path(BASE)/'Tests'/'Geometry_Recheck.json').write_text(json.dumps(report,indent=2))
        print('DONE',d['id'],d['name'],len(rows),round(body.Volume(),4),flush=True)
    return report
if __name__=='__main__':audit(sys.argv[1:] or None)
