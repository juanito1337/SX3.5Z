# -*- coding: utf-8 -*-
"""Strict API-contract regressions WITHOUT Siemens NX or a solid-modeling kernel.

The stubs deliberately distinguish Cone.Null, Feature.Null and
AssociativeLine.Null. This reproduces the reported Python type error.
Full recipe dispatch checks argument/formula plumbing only, NOT solid validity,
NX associativity, NX licenses, saving PRT files or assembly insertion.
Run outside NX: python Tests/test_nx_features_v4_4.py
"""
import ast
import collections
import copy
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
import test_expressions_v4_5 as expr

nx=expr.nx
native=expr.native
model=expr.model
ROOT=expr.bootstrap.ROOT

class Body:
    def __init__(self):self.Tag=id(self)

class Feature:
    def __init__(self,body=None,entities=None):
        self.body=body;self.entities=[] if entities is None else entities;self.name=None
    def SetName(self,name):self.name=name
    def GetBodies(self):return [] if self.body is None else [self.body]
    def GetEntities(self):return self.entities
class Cone(Feature):pass
class AssociativeLine(Feature):pass
Feature.Null=Feature()
Cone.Null=Cone()
AssociativeLine.Null=AssociativeLine()
for t in (Feature,Cone,AssociativeLine):
    t.__module__='NXOpen.Features'
    setattr(nx.Features,t.__name__,t)

class Line:
    def __init__(self):self.Layer=None;self.blanked=False
    def Blank(self):self.blanked=True
nx.Line=Line
nx.NXObject=types.SimpleNamespace(Null=object())
nx.Point3d=lambda x,y,z:types.SimpleNamespace(X=x,Y=y,Z=z)
nx.Vector3d=lambda x,y,z:types.SimpleNamespace(X=x,Y=y,Z=z)
nx.Section=types.SimpleNamespace(AllowTypes=types.SimpleNamespace(OnlyCurves='OnlyCurves'),
                               Mode=types.SimpleNamespace(Create='Create'))
bo_types=types.SimpleNamespace(Create='Create',Subtract='Subtract',Unite='Unite')
nx.GeometricUtilities.BooleanOperation=types.SimpleNamespace(BooleanType=bo_types)

class BoolOption:
    def __init__(self):self.Type=None;self.targets=[]
    def SetTargetBodies(self,targets):self.targets=list(targets)
class Formula:
    def __init__(self):self.RightHandSide=None
class Axis:
    def __init__(self):self.Point=None;self.Direction=None;self.evaluated=False
    def Evaluate(self):self.evaluated=True

class BuilderBase:
    __slots__=('destroyed','fail_commit','Type')
    def __init__(self):self.destroyed=False;self.fail_commit=False;self.Type=None
    def CommitFeature(self):
        if self.fail_commit:raise RuntimeError('SIMULATED commit failure')
        opt=self.BooleanOperation if isinstance(self,ExtrudeBuilder) else self.BooleanOption
        if opt.Type=='Create':body=Body()
        elif opt.Type in ('Subtract','Unite') and len(opt.targets)==1:body=opt.targets[0]
        else:raise ValueError('SIMULATED invalid boolean arguments')
        return Feature(body)
    def Destroy(self):self.destroyed=True

class BlockFeatureBuilder(BuilderBase):
    __slots__=('BooleanOption','OriginPoint','ParentAssociativity','lengths','orientation','numeric_origin')
    Types=types.SimpleNamespace(OriginAndEdgeLengths='OriginAndEdgeLengths')
    def __init__(self):
        super().__init__();self.BooleanOption=BoolOption();self.OriginPoint=None;self.ParentAssociativity=False
    def SetOriginAndLengths(self,origin,*lengths):self.numeric_origin=origin;self.lengths=lengths
    def SetOrientation(self,*v):self.orientation=v

class CylinderBuilder(BuilderBase):
    __slots__=('BooleanOption','Diameter','Height','Axis','ParentAssociativity')
    Types=types.SimpleNamespace(AxisDiameterAndHeight='AxisDiameterAndHeight')
    def __init__(self):
        super().__init__();self.BooleanOption=BoolOption();self.Diameter=Formula();self.Height=Formula()
        self.Axis=Axis();self.ParentAssociativity=False

class ConeBuilder(BuilderBase):
    __slots__=('BooleanOption','BaseDiameter','TopDiameter','Height','Axis','ParentAssociativity')
    Types=types.SimpleNamespace(DiametersAndHeight='DiametersAndHeight')
    def __init__(self):
        super().__init__();self.BooleanOption=BoolOption();self.BaseDiameter=Formula();self.TopDiameter=Formula()
        self.Height=Formula();self.Axis=Axis();self.ParentAssociativity=False

class ExtrudeBuilder(BuilderBase):
    __slots__=('BooleanOperation','Section','Direction','Limits')
    def __init__(self):
        super().__init__();self.BooleanOperation=BoolOption();self.Section=None;self.Direction=None
        self.Limits=types.SimpleNamespace(StartExtend=types.SimpleNamespace(Value=Formula()),
                                         EndExtend=types.SimpleNamespace(Value=Formula()))

class AssociativeLineBuilder:
    __slots__=('Associative','StartPointOptions','EndPointOptions','StartPoint','EndPoint',
               'destroyed','fail_commit','entities')
    StartOption=types.SimpleNamespace(Point='Point')
    EndOption=types.SimpleNamespace(Point='Point')
    def __init__(self):
        self.Associative=False;self.StartPointOptions=None;self.EndPointOptions=None
        self.StartPoint=types.SimpleNamespace(Value=None);self.EndPoint=types.SimpleNamespace(Value=None)
        self.destroyed=False;self.fail_commit=False;self.entities=[Line()]
    def CommitFeature(self):
        if self.fail_commit:raise RuntimeError('SIMULATED line commit failure')
        return Feature(entities=self.entities)
    def Destroy(self):self.destroyed=True

for t in (BlockFeatureBuilder,CylinderBuilder,ConeBuilder,ExtrudeBuilder,AssociativeLineBuilder):
    setattr(nx.Features,t.__name__,t)

class FeatureCollection:
    def __init__(self):self.calls=[];self.builders=[];self.fail_next=False;self.return_none=False
    def make(self,name,arg,expected,builder_class):
        self.calls.append((name,arg))
        if type(arg) is not expected or arg is not expected.Null:
            raise TypeError('SIMULATED: expected '+expected.__name__+'; got '+type(arg).__name__)
        if self.return_none:return None
        b=builder_class();b.fail_commit=self.fail_next;self.fail_next=False;self.builders.append(b);return b
    def CreateBlockFeatureBuilder(self,arg):return self.make('block',arg,Feature,BlockFeatureBuilder)
    def CreateCylinderBuilder(self,arg):return self.make('cylinder',arg,Feature,CylinderBuilder)
    def CreateConeBuilder(self,arg):
        """SIMULATED documented signature: CreateConeBuilder(cone: Cone)."""
        return self.make('cone',arg,Cone,ConeBuilder)
    def CreateExtrudeBuilder(self,arg):return self.make('extrude',arg,Feature,ExtrudeBuilder)
    def CreateAssociativeLineBuilder(self,arg):return self.make('line',arg,AssociativeLine,AssociativeLineBuilder)

class Section:
    def __init__(self):self.allowed=None;self.args=None
    def SetAllowedEntityTypes(self,allowed):self.allowed=allowed
    def AddToSection(self,*args):
        if args[2] is not nx.NXObject.Null or args[3] is not nx.NXObject.Null:
            raise TypeError('SIMULATED NXObject.Null required')
        self.args=args

