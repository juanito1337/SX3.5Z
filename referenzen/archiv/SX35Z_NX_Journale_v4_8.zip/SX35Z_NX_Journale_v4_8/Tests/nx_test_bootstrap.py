# -*- coding: utf-8 -*-
"""Regression tests WITHOUT Siemens NX. All NX calls are test doubles.
Support module for the v4.5 tests; not a production NX module.
Never run this mock suite inside a Siemens NX session.
"""
import enum
import importlib.util
import math
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

if 'NXOpen' in sys.modules or importlib.util.find_spec('NXOpen') is not None:
    raise RuntimeError('These mock tests must run OUTSIDE Siemens NX.')
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

# Same integer values, distinct enum types: this reproduces the faulty
# cross-enum comparison without assuming NX's actual underlying integers.
class CreationUnits(enum.Enum):
    Inches=0
    Millimeters=1
class StoredUnits(enum.Enum):
    Inches=0
    Millimeters=1

nx=types.ModuleType('NXOpen')
nx.__path__=[]
nx.Part=types.SimpleNamespace(Units=CreationUnits)
nx.BasePart=types.SimpleNamespace(Units=StoredUnits)
nx.__file__='TEST_DOUBLE_ONLY_NOT_REAL_NXOpen'
sys.modules['NXOpen']=nx
for name in ('Features','GeometricUtilities','Assemblies'):
    mod=types.ModuleType('NXOpen.'+name)
    sys.modules[mod.__name__]=mod
    setattr(nx,name,mod)

spec=importlib.util.spec_from_file_location('_sx35z_driver_test',ROOT/'NX_Detailbaugruppe_erzeugen.py')
driver=importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
native=sys.modules['nx_native']

class FakeUnits:
    def __init__(self, factor=1.0, failed=None):
        self.base=object()
        self.mm=object()
        self.factor=factor
        self.failed=failed
        self.calls=[]
    def GetBase(self, measure):
        assert measure=='Length'
        if self.failed=='GetBase':raise AttributeError('Unavailable in test binding')
        return self.base
    def FindObject(self, name):
        assert name=='MilliMeter'
        if self.failed=='FindObject':raise LookupError('Unavailable in test binding')
        return self.mm
    def Convert(self, initial, target, value):
        assert initial is self.base and target is self.mm and value==1.0
        self.calls.append((initial,target,value))
        if self.failed=='Convert':raise TypeError('Unavailable in test binding')
        return self.factor

class FakePart:
    def __init__(self, units=StoredUnits.Millimeters, factor=1.0, history=True, failed=None):
        self.PartUnits=units
        self.UnitCollection=FakeUnits(factor,failed)
        self.Preferences=types.SimpleNamespace(Modeling=types.SimpleNamespace(GetHistoryMode=lambda:history))
        self.Name='TEST_PART'
        self.Expressions=types.SimpleNamespace(CreateExpression=lambda *args:object())

