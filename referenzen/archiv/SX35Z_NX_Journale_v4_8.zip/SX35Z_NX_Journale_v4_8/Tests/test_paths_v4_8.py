"""Path/IO regression: fake NX objects, real temporary files. NOT an NX run."""
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch
import nx_test_bootstrap as boot

nx, driver, native = boot.nx, boot.driver, boot.native
import nx_files as files


def volume_error():
    exc = OSError('Auf dem Datentraeger befindet sich kein erkanntes Dateisystem')
    exc.winerror = 1005
    return exc


class Listing:
    def __init__(self): self.lines = []
    def Open(self): pass
    def WriteLine(self, text): self.lines.append(str(text))


class PathTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.journal = self.base / 'W_like_journal'
        self.journal.mkdir()
        self.local = self.base / 'LocalAppData'
        self.local.mkdir()
        self.session = types.SimpleNamespace(ListingWindow=Listing(), Parts=[])
        self.logs = []
        self.addCleanup(patch.stopall)
        patch.dict(os.environ, {'LOCALAPPDATA': str(self.local)}).start()
        patch.object(native, 'HERE', str(self.journal)).start()

    def config(self, data):
        (self.journal/'NX_Ausgabe.json').write_text(json.dumps(data), encoding='utf8')

    def test_main_can_start_from_realpath_failing_script_volume(self):
        """Regression for supplied trace, not merely a unit test of a new helper."""
        real = os.path.realpath
        def resolve(path, *args, **kwargs):
            if str(path).startswith(str(self.journal)):
                raise volume_error()
            return real(path, *args, **kwargs)
        patch.object(driver, 'HERE', str(self.journal)).start()
        patch.object(native, 'HERE', str(self.journal)).start()
        patch.object(nx, 'Session', types.SimpleNamespace(GetSession=lambda: self.session), create=True).start()
        patch.object(driver, 'log_environment', lambda log: None).start()
        probe = patch.object(driver, 'probe', return_value='CreateNumberExpression').start()
        # Reference file is needed, parameters default when omitted.
        (self.journal/'Geometrie_Referenz_v4.json').write_bytes((boot.ROOT/'Geometrie_Referenz_v4.json').read_bytes())
        with patch.object(os.path, 'realpath', side_effect=resolve):
            try:
                driver.main(probe_only=True)
            except OSError as exc:
                self.fail('WinError %s propagated because output is still tied to the script volume' % exc.winerror)
        self.assertEqual(probe.call_count, 1)
        output = Path(probe.call_args.args[3]).parent
        self.assertTrue(output.is_relative_to(self.local))
        self.assertFalse((self.journal/'NX_Output').exists())
        self.assertTrue(list(output.glob('NX_Laufprotokoll_*.txt')))

    def test_default_root_is_independent_of_journal(self):
        root = files.select_output_root(str(self.journal), self.logs.append)
        self.assertEqual(Path(root), self.local/'SX35Z'/'NX_Output')

    def test_explicit_absolute_root(self):
        other = self.base/'Mein_Output'
        self.config({'output_root':str(other)})
        self.assertEqual(Path(files.select_output_root(str(self.journal))), other)

    def test_empty_config_uses_default(self):
        self.config({'output_root':''})
        self.assertEqual(Path(files.select_output_root(str(self.journal))), self.local/'SX35Z'/'NX_Output')

    def test_relative_destination_rejected(self):
        self.config({'output_root':'relative/parts'})
        with self.assertRaisesRegex(ValueError, 'absolut'):
            files.select_output_root(str(self.journal))

    def test_bad_config_type_rejected(self):
        for data in [[], {'output_root':5}, {'output_root':None}, {'typo':'x'}]:
            with self.subTest(data=data):
                self.config(data)
                with self.assertRaises(ValueError): files.select_output_root(str(self.journal))

    def test_invalid_json_rejected(self):
        (self.journal/'NX_Ausgabe.json').write_text('{oops')
        with self.assertRaises(ValueError): files.select_output_root(str(self.journal))

    def test_bom_json(self):
        (self.journal/'NX_Ausgabe.json').write_text('{"output_root":""}', encoding='utf-8-sig')
        self.assertEqual(Path(files.select_output_root(str(self.journal))), self.local/'SX35Z'/'NX_Output')

    def test_io_probe_and_manifest_only_create_run_owned_files(self):
        out = Path(files.prepare_output_directory(str(self.journal), 'TEST_001', self.logs.append))
        self.assertTrue(out.is_dir())
        self.assertTrue((out/'NX_Pfadpruefung.json').is_file())
        data = json.loads((out/'NX_Pfadpruefung.json').read_text())
        self.assertTrue(data['io_probe_passed'])
        self.assertFalse(list(out.glob('*.tmp')))

    def test_repeated_run_name_does_not_overwrite(self):
        out = Path(files.prepare_output_directory(str(self.journal), 'TEST_001', self.logs.append))
        (out/'keep.txt').write_text('untouched')
        with self.assertRaises(FileExistsError):
            files.prepare_output_directory(str(self.journal), 'TEST_001', self.logs.append)
        self.assertEqual((out/'keep.txt').read_text(),'untouched')

    def test_run_name_traversal_rejected(self):
        for name in ('../escape','x/y','', '..'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                files.prepare_output_directory(str(self.journal), name, self.logs.append)

    def test_explicit_failing_volume_not_silently_replaced(self):
        bad = self.base/'bad_volume'; self.config({'output_root':str(bad)})
        real = os.path.realpath
        def resolve(path, *a, **kw):
            if str(path).startswith(str(bad)): raise volume_error()
            return real(path,*a,**kw)
        with patch.object(os.path, 'realpath', side_effect=resolve):
            with self.assertRaisesRegex(RuntimeError,'1005'):
                files.prepare_output_directory(str(self.journal),'BAD_01',self.logs.append)
        self.assertFalse((self.local/'SX35Z').exists())

    def test_permission_error_not_silently_replaced(self):
        with patch.object(os, 'makedirs', side_effect=PermissionError('denied')):
            with self.assertRaisesRegex(RuntimeError,'denied'):
                files.prepare_output_directory(str(self.journal),'BAD_01',self.logs.append)

    def test_canonical_still_resolves_symlinks(self):
        actual = self.base/'actual';actual.mkdir()
        alias = self.base/'alias';alias.symlink_to(actual,target_is_directory=True)
        self.assertEqual(files.canonical(alias/'x.prt'),str(actual/'x.prt'))

    def test_canonical_does_not_hide_io_errors(self):
        with patch.object(os.path,'realpath',side_effect=volume_error()):
            with self.assertRaises(OSError): files.canonical(self.base/'x.prt')

    def test_target_outside_run_still_rejected(self):
        run = self.base/'run'
        fm = files.NativePartFiles(self.session,str(run),'unique',self.logs.append)
        with self.assertRaises(ValueError): fm.filename(str(self.base/'elsewhere'),'x')

    def test_link_escaping_run_still_rejected(self):
        run = self.base/'run';run.mkdir()
        external = self.base/'external';external.mkdir()
        (run/'link').symlink_to(external,target_is_directory=True)
        fm = files.NativePartFiles(self.session,str(run),'unique',self.logs.append)
        with self.assertRaises(ValueError): fm.filename(str(run/'link'),'x')

    def test_log_stored_in_selected_output(self):
        out = self.base/'logs';out.mkdir()
        log = native.RunLog(self.session)
        log.set_output_directory(str(out))
        log('original failure text');log.save(failed=True)
        self.assertTrue((out/'NX_Fehlerprotokoll.txt').is_file())
        self.assertIn('original failure text',(out/'NX_Fehlerprotokoll.txt').read_text())

    def test_error_mirror_failure_does_not_destroy_local_log(self):
        out = self.base/'logs';out.mkdir()
        impossible = self.base/'not_a_directory';impossible.write_text('keep')
        patch.object(native,'HERE',str(impossible)).start()
        log = native.RunLog(self.session);log.set_output_directory(str(out))
        log('original failure text');log.save(failed=True)
        self.assertIn('original failure text',(out/'NX_Fehlerprotokoll.txt').read_text())
        self.assertEqual(impossible.read_text(),'keep')

    def test_mixed_model_version_rejected_before_output(self):
        patch.object(driver,'HERE',str(self.journal)).start()
        patch.object(native,'HERE',str(self.journal)).start()
        patch.object(nx,'Session',types.SimpleNamespace(GetSession=lambda:self.session),create=True).start()
        patch.object(driver,'log_environment',lambda log:None).start()
        patch.object(driver.model,'VERSION','4.7').start()
        with self.assertRaisesRegex(RuntimeError,'Gemischte Journalversionen'):
            driver.main(paths_only=True)

    def test_path_only_does_not_call_nx_probe(self):
        patch.object(driver,'HERE',str(self.journal)).start()
        patch.object(nx,'Session',types.SimpleNamespace(GetSession=lambda:self.session),create=True).start()
        patch.object(driver,'log_environment',lambda log:None).start()
        probe=patch.object(driver,'probe',side_effect=AssertionError('must not run')).start()
        driver.main(paths_only=True)
        probe.assert_not_called()
        self.assertTrue(any('Pfadtest bestanden' in x for x in self.session.ListingWindow.lines))

if __name__=='__main__':unittest.main(verbosity=2)
