# -*- coding: utf-8 -*-
"""Independent numerical tests, outside NX only; no Siemens execution.
Optional CadQuery is needed for the real OpenCascade cross-kernel tests.
The production journals do NOT depend on CadQuery.
"""
import ast, copy, json, math, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import modell_v4 as model
import nx_geometry as geom

class GeometryTests(unittest.TestCase):
    def setUp(self):self.params=model.load_parameters(str(ROOT/'Parameter.json'));self.v=model.all_values(self.params)
    def contract(self,op):return geom.primitive_contract(op,self.v,model.evaluate)
    def test_box(self):
        a=self.contract(dict(kind='box',origin=['-2','3','-4'],size=['5','6','7']))
        self.assertEqual(a,dict(bounds_mm=[-2.,3.,-4.,3.,9.,3.],volume_mm3=210.))
    def test_cylinder_negative_y(self):
        a=self.contract(dict(kind='cylinder',origin=['3','10','5'],diameter='4',height='6',direction=(0,-1,0)))
        self.assertEqual(a['bounds_mm'],[1,4,3,5,10,7]);self.assertAlmostEqual(a['volume_mm3'],24*math.pi)
    def test_cone_negative_x(self):
        a=self.contract(dict(kind='cone',origin=['10','0','0'],diameter='4',top_diameter='8',height='6',direction=(-1,0,0)))
        self.assertEqual(a['bounds_mm'],[4,-4,-4,10,4,4]);self.assertAlmostEqual(a['volume_mm3'],56*math.pi)
    def test_prism(self):
        op=dict(kind='prism',origin=['0','0','0'],points=[['0','0','0'],['3','0','0'],['0','4','0']],height='5',direction=(0,0,1))
        self.assertEqual(self.contract(op)['volume_mm3'],30)
    def test_bad_vector_rejected(self):
        with self.assertRaises(ValueError):geom.unit_vector([0,0,0])
    def test_displaced_tool_rejected(self):
        a=dict(bounds_mm=[0,0,0,10,10,10],volume_mm3=1000)
        b=copy.deepcopy(a);b['bounds_mm'][0]=1
        with self.assertRaisesRegex(RuntimeError,'VOR boolescher'):geom.assert_contract(b,a,'T')
    def test_wrong_scale_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'Volumen IST'):geom.assert_volume(1,1000,'T')
    def test_noop_cut_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'kein messbares'):geom.assert_boolean_change('cut',1000,1000,100,'T')
    def test_noop_union_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'kein messbares'):geom.assert_boolean_change('add',1000,1000,100,'T')
    def test_cut_wrong_direction_rejected(self):
        with self.assertRaises(RuntimeError):geom.assert_boolean_change('cut',1000,1100,100,'T')
    def test_valid_cut_and_union(self):
        geom.assert_boolean_change('cut',1000,950,100,'T');geom.assert_boolean_change('add',1000,1050,100,'T')
    def test_impossible_cut_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'Abtragsvolumen'):geom.assert_boolean_change('cut',1000,100,10,'T')
    def test_exact_reference_selection(self):
        logs=[];r=geom.ReferenceCheck(str(ROOT/'Geometrie_Referenz_v4.json'),self.params,model.recipe(),logs.append)
        self.assertEqual(len(r.data),179)
    def test_custom_parameters_not_compared_to_defaults(self):
        p=dict(self.params);p['base_h']+=2
        r=geom.ReferenceCheck(str(ROOT/'Geometrie_Referenz_v4.json'),p,model.recipe(),lambda x:None)
        self.assertEqual(r.data,{})
    def test_recipe_edit_disables_default_reference(self):
        d=model.recipe();d[0]['ops'][0]['label']='changed'
        r=geom.ReferenceCheck(str(ROOT/'Geometrie_Referenz_v4.json'),self.params,d,lambda x:None)
        self.assertEqual(r.data,{})
    def test_reference_catches_earlier_wrong_base(self):
        r=geom.ReferenceCheck(str(ROOT/'Geometrie_Referenz_v4.json'),self.params,model.recipe(),lambda x:None)
        with self.assertRaises(RuntimeError):r.check('P001',1,dict(volume_mm3=1000))
    def test_reported_hole_is_not_air_in_reference(self):
        rows=json.loads((ROOT/'Geometrie_Referenz_v4.json').read_text())['parts'][0]['rows']
        self.assertEqual(rows[30]['label'],'Aufstellbohrung_ANNAHME')
        self.assertAlmostEqual(rows[30]['delta'],-5021.032919787802,places=4)
    def test_source_python310(self):
        for p in ROOT.glob('*.py'):ast.parse(p.read_text(encoding='utf8'),feature_version=(3,10))
    def test_journal_standard_library_only(self):
        for name in ('nx_native.py','nx_geometry.py','NX_Detailbaugruppe_erzeugen.py'):
            tree=ast.parse((ROOT/name).read_text())
            imports=[n.names[0].name for n in ast.walk(tree) if isinstance(n,ast.Import)]
            self.assertFalse(set(imports)&{'cadquery','OCP','numpy','scipy'})
    def test_reference_all_ops_have_effect_and_valid_single_solids(self):
        d=json.loads((ROOT/'Geometrie_Referenz_v4.json').read_text())
        rows=[r for p in d['parts'] for r in p['rows']]
        self.assertEqual(len(rows),887)
        self.assertTrue(all(r['valid'] and r['solids']==1 and abs(r['delta'])>1e-5 for r in rows))

if __name__=='__main__':unittest.main(verbosity=2)
