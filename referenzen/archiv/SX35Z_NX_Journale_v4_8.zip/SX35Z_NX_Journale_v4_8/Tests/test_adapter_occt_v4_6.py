# -*- coding: utf-8 -*-
"""CAD-backed test double for NX bindings. THIS IS NOT SIEMENS NX.

Runs the production nx_native adapter through simulated NX API objects; actual
solid operations/volumes use CadQuery/OpenCascade, not Parasolid. This can detect
adapter routing/coordinate errors, but cannot verify Siemens binding behavior,
licenses, native history, file saves, or actual NX parametric update semantics.
Requires cadquery only when running this TEST outside NX.
The simulated UF binding intentionally has NO AskMassProps3d. Actual volumes
flow through a simulated MeasureManager using real OpenCascade solids.
"""
import json, math, re, sys, types, unittest
from pathlib import Path
import cadquery as cq
import nx_test_features as old
expr=old.expr;nx=old.nx;native=old.native;model=old.model
ROOT=old.ROOT
from nx_geometry import ReferenceCheck, primitive_contract, assert_contract, BodyInspector
REGISTRY={}


def xyz(p):return [p.X,p.Y,p.Z]
def vec(p):return cq.Vector(*xyz(p))
def bbox(shape):
    b=shape.BoundingBox()
    return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]

class Body(old.Body):
    def __init__(self,part,make):
        super().__init__();self.part=part;self.make=make;self.cache=None;self.generation=None
        self.Layer=1;REGISTRY[self.Tag]=self
    @property
    def shape(self):
        if self.cache is None or self.generation!=self.part.generation:
            self.cache=self.make();self.generation=self.part.generation
        return self.cache
    def SetName(self,name):self.name=name
    def SetUserAttribute(self,*args):pass

class BooleanFeature(old.Feature):pass
BooleanFeature.Null=BooleanFeature()
BooleanFeature.__module__='NXOpen.Features'
nx.Features.BooleanFeature=BooleanFeature
nx.Features.Feature.BooleanType=types.SimpleNamespace(Unite='Unite',Subtract='Subtract')

class Axis:
    def __init__(self,p,d):self.Point=p;self.Direction=d;self.evaluated=False
    def Evaluate(self):self.evaluated=True
class Line:
    def __init__(self,a,b):self.a=a;self.b=b;self.Layer=1
    def Blank(self):pass
nx.Line=Line

class MeasurementUnits(expr.Units):
    def FindObject(self,name):
        if name not in BodyInspector.UNIT_NAMES: raise ValueError(name)
        u=expr.Unit(self.part);u.measurement_name=name
        return u

class MeasureResult:
    def __init__(self,body):self.body=body;self.disposed=False
    @property
    def Volume(self):return self.body.shape.Volume()
    def Dispose(self):self.disposed=True

class MeasureManager:
    def __init__(self,part):self.part=part;self.results=[]
    def NewMassProperties(self,units,accuracy,objects):
        assert [u.measurement_name for u in units]==list(BodyInspector.UNIT_NAMES)
        for u in units:u.assert_valid(self.part)
        assert isinstance(accuracy,float) and .99999 < accuracy < 1
        assert len(objects)==1
        r=MeasureResult(objects[0]);self.results.append(r);return r

class Part(expr.Part):
    def __init__(self):
        super().__init__(['CreateNumberExpression'])
        self.UnitCollection=MeasurementUnits(self)
        self.MeasureManager=MeasureManager(self)
        self.Features=Collection(self);self.BaseFeatures=Collection(self)
        self.Sections=types.SimpleNamespace(CreateSection=lambda *args:old.Section())
        self.ScRuleFactory=types.SimpleNamespace(CreateRuleCurveDumb=lambda curves:tuple(curves))
        self.Directions=types.SimpleNamespace(CreateDirection=lambda p,v,u:v)
        self.Axes=types.SimpleNamespace(CreateAxis=lambda p,d,u:Axis(p,d))
        self.Bodies=[]
        self.WCS=types.SimpleNamespace(CoordinateSystem=types.SimpleNamespace(Tag=0),SetOriginAndMatrix=lambda *args:None)
    def ev(self,rhs):
        names=set(re.findall(r'\b[A-Za-z_]\w*',rhs))
        return model.evaluate(rhs,{n:self.Expressions.value(n) for n in names})
    def body(self,fn,remove=()):
        body=Body(self,fn)
        # The geometry kernel checks are part of the test, not a real NX call.
        if not body.shape.isValid() or len(body.shape.Solids())!=1:raise RuntimeError('OpenCascade: invalid/multiple solids')
        self.Bodies[:]=[b for b in self.Bodies if b not in remove]+[body]
        return body

class Block(old.BlockFeatureBuilder):
    def CommitFeature(self):
        assert self.BooleanOption.Type=='Create' and not self.BooleanOption.targets
        p=self.part
        return old.Feature(p.body(lambda:cq.Solid.makeBox(*[p.ev(x) for x in self.lengths],pnt=vec(self.OriginPoint.Coordinates))))

class Cylinder(old.CylinderBuilder):
    def CommitFeature(self):
        assert self.BooleanOption.Type=='Create' and not self.BooleanOption.targets
        assert self.ParentAssociativity and self.ReverseDirection is False
        assert self.Axis.evaluated
        p=self.part
        return old.Feature(p.body(lambda:cq.Solid.makeCylinder(p.ev(self.Diameter.RightHandSide)/2,p.ev(self.Height.RightHandSide),vec(self.Axis.Point.Coordinates),vec(self.Axis.Direction))))

class Cone(old.ConeBuilder):
    def CommitFeature(self):
        assert self.BooleanOption.Type=='Create' and not self.BooleanOption.targets
        assert self.ParentAssociativity and self.Axis.evaluated
        p=self.part
        return old.Feature(p.body(lambda:cq.Solid.makeCone(p.ev(self.BaseDiameter.RightHandSide)/2,p.ev(self.TopDiameter.RightHandSide)/2,p.ev(self.Height.RightHandSide),vec(self.Axis.Point.Coordinates),vec(self.Axis.Direction))))

class Extrude(old.ExtrudeBuilder):
    def CommitFeature(self):
        assert self.BooleanOperation.Type=='Create' and not self.BooleanOperation.targets
        p=self.part
        def make():
            curves=self.Section.args[0][0]
            pts=[vec(c.a.Coordinates) for c in curves]
            wire=cq.Wire.makePolygon(pts+[pts[0]])
            return cq.Solid.extrudeLinear(wire,[],vec(self.Direction).normalized().multiply(p.ev(self.Limits.EndExtend.Value.RightHandSide)))
        return old.Feature(p.body(make))

class AssocLine(old.AssociativeLineBuilder):
    def CommitFeature(self):return old.Feature(entities=[Line(self.StartPoint.Value,self.EndPoint.Value)])

class Selection:
    def __init__(self):self.items=[]
    def Add(self,body):
        if not isinstance(body,Body):raise TypeError('Test expects single Body Tools.Add overload')
        self.items.append(body);return True

class Boolean:
    def __init__(self,part):self.part=part;self.Tools=Selection();self.destroyed=False
    def CommitFeature(self):
        assert len(self.Tools.items)==1 and self.Target is not self.Tools.items[0]
        assert not any((self.RetainTool,self.RetainTarget,self.CopyTools,self.CopyTargets))
        assert self.Tolerance==.001
        a=self.Target;b=self.Tools.items[0]
        if self.Operation=='Subtract':make=lambda:a.shape.cut(b.shape).clean()
        elif self.Operation=='Unite':make=lambda:a.shape.fuse(b.shape).clean()
        else:raise ValueError('Bad Boolean Operation')
        return BooleanFeature(self.part.body(make,(a,b)))
    def Destroy(self):self.destroyed=True

class Collection:
    def __init__(self,part):self.part=part;self.calls=[];self.builders=[]
    def make(self,name,arg,expected,cls):
        if type(arg) is not expected or arg is not expected.Null:raise TypeError('Expected '+expected.__name__+'.Null')
        self.calls.append((name,arg));b=cls(self.part) if cls is Boolean else cls();b.part=self.part;self.builders.append(b);return b
    def CreateBlockFeatureBuilder(self,arg):return self.make('box',arg,old.Feature,Block)
    def CreateCylinderBuilder(self,arg):return self.make('cylinder',arg,old.Feature,Cylinder)
    def CreateConeBuilder(self,arg):return self.make('cone',arg,old.Cone,Cone)
    def CreateExtrudeBuilder(self,arg):return self.make('prism',arg,old.Feature,Extrude)
    def CreateAssociativeLineBuilder(self,arg):return self.make('line',arg,old.AssociativeLine,AssocLine)
    def CreateBooleanBuilder(self,arg):return self.make('boolean',arg,BooleanFeature,Boolean)

class UF:
    def __init__(self):self.Modl=self;self.ModlGeneral=self
    def AskBoundingBoxExact(self,tag,csys):
        b=bbox(REGISTRY[tag].shape)
        return b[:3],[[1,0,0],[0,1,0],[0,0,1]],[b[i+3]-b[i] for i in range(3)]
    def AskBoundingBox(self,tag):return bbox(REGISTRY[tag].shape)

uf=UF();module=types.ModuleType('NXOpen.UF');module.UFSession=types.SimpleNamespace(GetUFSession=lambda:uf)
nx.UF=module;sys.modules['NXOpen.UF']=module

class AdapterTests(unittest.TestCase):
    def setup_builder(self,params=None):
        p=Part();s=expr.Session(p);logs=[]
        params=params or model.load_parameters(str(ROOT/'Parameter.json'))
        b=native.NativeModelBuilder(s,p,params,logs.append)
        b.expression_factory.mode='CreateNumberExpression';b.create_expressions()
        return p,s,b,logs
    def test_typed_boolean_null(self):
        p=Part()
        with self.assertRaises(TypeError):p.Features.CreateBooleanBuilder(old.Feature.Null)
        p.Features.CreateBooleanBuilder(BooleanFeature.Null)
    def test_all_179_parts_through_new_adapter_using_real_occt(self):
        params=model.load_parameters(str(ROOT/'Parameter.json'))
        reference=ReferenceCheck(str(ROOT/'Geometrie_Referenz_v4.json'),params,model.recipe(),lambda x:None)
        report=[];total=0;boolean_count=0
        for d in model.recipe():
            p,s,b,logs=self.setup_builder(params)
            target=None
            for i,op in enumerate(model.local_definition(d)['ops'],1):
                _,target=b.primitive(op,target,'%03d_%s'%(i,op['label']))
                reference.check(d['id'],i,b.last_measurement)
                self.assertEqual(len(p.Bodies),1);self.assertTrue(target.shape.isValid())
                total+=1
            boolean_count+=sum(1 for name,arg in p.Features.calls if name=='boolean')
            self.assertTrue(all(x.destroyed for x in p.Features.builders+p.BaseFeatures.builders))
            self.assertEqual(len(b.geometry_trace),len(d['ops']))
            self.assertEqual(b.inspector.mode,'manager_bodies_accuracy')
            self.assertTrue(all(r.disposed for r in p.MeasureManager.results))
            report.append(dict(id=d['id'],operations=len(d['ops']),volume_mm3=target.shape.Volume(),valid=True,
                               measurement_backend=b.inspector.mode,measurements=len(p.MeasureManager.results)))
            print('OCCT adapter',d['id'],len(d['ops']),flush=True)
        self.assertEqual(total,887);self.assertEqual(boolean_count,708)
        (ROOT/'Tests'/'Adapter_OCCT_Result_v4_8.json').write_text(json.dumps(dict(NX_execution=False,backend='simulated NX bindings WITHOUT UF mass; simulated MeasureManager + actual CadQuery/OpenCascade',parts=report,operations=total,booleans=boolean_count),indent=2))
    def test_wrong_tool_location_stops_before_boolean(self):
        p,s,b,logs=self.setup_builder()
        real=b._raw_primitive
        def wrong(op,target,name):
            import copy
            moved=copy.deepcopy(op);moved['origin']=['900','900','900']
            return real(moved,target,name)
        b._raw_primitive=wrong
        with self.assertRaisesRegex(RuntimeError,'VOR boolescher'):
            b.primitive(dict(kind='box',op='add',origin=['0','0','0'],size=['10','10','10']),None,'bad')
        self.assertFalse(any(n=='boolean' for n,_ in p.Features.calls))
    def test_outside_tool_is_not_silently_skipped(self):
        p,s,b,logs=self.setup_builder()
        _,body=b.primitive(dict(kind='box',op='add',origin=['0','0','0'],size=['10','10','10']),None,'stock')
        with self.assertRaisesRegex(RuntimeError,'kein messbares Material'):
            b.primitive(dict(kind='cylinder',op='cut',origin=['30','30','-1'],diameter='2',height='12',direction=(0,0,1)),body,'outside')
    def test_actual_basis_changed_parameters(self):
        params=model.load_parameters(str(ROOT/'Parameter.json'));params['base_h']+=2;params['mount_hole_d']=12
        p,s,b,logs=self.setup_builder(params);body=None
        for i,op in enumerate(model.local_definition(model.recipe()[0])['ops'],1):_,body=b.primitive(op,body,str(i))
        self.assertEqual(len(p.Bodies),1);self.assertTrue(body.shape.isValid());self.assertEqual(len(b.geometry_trace),38)
    def test_actual_partbuilder_subset_and_metadata(self):
        p=Part();s=expr.Session(p);params=model.load_parameters(str(ROOT/'Parameter.json'))
        d=model.recipe()[0]
        reference=ReferenceCheck(str(ROOT/'Geometrie_Referenz_v4.json'),params,model.recipe(),lambda x:None)
        b=expr.bootstrap.driver.PartBuilder(s,p,params,d,lambda x:None,reference)
        body=b.build_one('CreateNumberExpression')
        self.assertEqual(len(p.Bodies),1);self.assertTrue(body.shape.isValid())
        self.assertEqual(len(b.geometry_trace),38);self.assertEqual(len(b.expression_names),37)
    def test_native_probe_with_cad_backed_bindings(self):
        p,s,b,logs=self.setup_builder()
        b.native_probe()
        self.assertTrue(any('API-Probe bestanden' in l for l in logs))
        self.assertTrue(any('SXPROBE_Zylinder_minusY' in l for l in logs))
        self.assertTrue(any('SXPROBE_Vereinigung' in l for l in logs))

if __name__=='__main__':unittest.main(verbosity=2)
