"""Head-specific geometry regressions using OpenCascade, not Siemens NX."""
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import modell_v4 as model
from audit_recipe_occt import tool

class HeadTests(unittest.TestCase):
    def setUp(self):
        self.params=model.load_parameters(str(ROOT/'Parameter.json'))
        self.parts={d['name']:d for d in model.recipe()}
    def test_driver_dog_pockets_belong_to_spindle_nose_not_pinion(self):
        labels=lambda name:[op['label'] for op in self.parts[name]['ops']]
        self.assertEqual(labels('Spindelnase_SK30_Normreferenz').count('Mitnehmer_Tasche'),2)
        self.assertNotIn('Mitnehmer_Tasche',labels('Pinolenvorschub_Ritzel'))
    def test_all_twelve_pinion_teeth_extend_the_body(self):
        v=model.all_values(self.params)
        d=model.local_definition(self.parts['Pinolenvorschub_Ritzel'])
        body=None;count=0
        for op in d['ops']:
            if op['op']=='cut':continue # target correctness checked separately
            shape=tool(op,v);before=body.Volume() if body else 0
            body=shape if body is None else body.fuse(shape).clean()
            self.assertTrue(body.isValid());self.assertEqual(len(body.Solids()),1)
            self.assertGreater(body.Volume()-before,1e-5,op['label']+' is a no-op')
            if op['label']=='Ritzelzahn_SYMBOLISCH':count+=1
        self.assertEqual(count,12)
    def test_pinion_width_parameter_controls_every_tooth(self):
        self.params['quill_pinion_w']=22
        v=model.all_values(self.params)
        d=model.local_definition(self.parts['Pinolenvorschub_Ritzel'])
        for op in d['ops']:
            if op['label']!='Ritzelzahn_SYMBOLISCH':continue
            b=tool(op,v).BoundingBox()
            self.assertAlmostEqual(b.xmax-b.xmin,22,places=6)
    def test_head_changed_parts_remain_single_valid_effective_solids(self):
        names=('Pinolenvorschub_Ritzel','Spindelnase_SK30_Normreferenz','Pinole_Huelse_Detail',
               'Werkzeugspindel_Durchgehende_Huelle','Pinolenvorschub_Welle_innen')
        for name in names:
            with self.subTest(name=name):
                v=model.all_values(self.params);body=None
                for op in model.local_definition(self.parts[name])['ops']:
                    s=tool(op,v);before=body.Volume() if body else 0
                    body=s if body is None else (body.cut(s).clean() if op['op']=='cut' else body.fuse(s).clean())
                    self.assertTrue(body.isValid());self.assertEqual(len(body.Solids()),1)
                    delta=body.Volume()-before
                    if op['op']=='cut':self.assertLess(delta,-1e-5,op['label'])
                    else:self.assertGreater(delta,1e-5,op['label'])

if __name__=='__main__':unittest.main(verbosity=2)
