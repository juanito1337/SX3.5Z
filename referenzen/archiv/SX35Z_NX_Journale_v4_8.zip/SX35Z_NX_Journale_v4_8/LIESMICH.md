# SX3.5Z – vollständiges NX-Journalpaket v4.8

Für Siemens NX 2406 / Python 3.10. Modellstand 4.8, aufbauend auf 4.7.
Foto-Rekonstruktion; Anschlussmaße unbestätigt. Kein Fertigungsdatensatz.

## Anlass: WinError 1005 beim Ausgabeordner auf W:

Das gelieferte `NX_Fehlerprotokoll(6).txt` bricht in `nx_files.canonical()` ab:
`os.path.realpath()` kann den Ausgabeordner auf W: nicht auflösen. Noch kein
NX-Testteil und kein Maschinenbauteil wird in diesem Lauf aufgebaut.

Die konkrete Ursache der Laufwerkseinbindung ist nicht aus dem Protokoll
bestimmbar. Der Fehler allein beweist keinen beschädigten Datenträger.
Keine Formatierung oder Änderung von Dateisystemtreibern ist Teil dieses Patches.

## Installation – vollständiges Paket empfohlen

Das ZIP vollständig in einen neuen, beschreibbaren Journalordner entpacken.
Alle Python-Dateien und `Parameter.json` bleiben zusammen. Der Journalordner
darf weiterhin auf W: liegen, sofern NX die Skripte und Eingabedateien dort lesen
kann. Die Ausgabe wird nicht mehr an dieses Laufwerk gebunden.

Eigene Maßänderungen: Vorhandene `Parameter.json` separat sichern und in den neuen
Ordner übernehmen. Das vollständige ZIP enthält die unveränderten Standardwerte.

## Neuer Standard-Ausgabeort

Ohne abweichende Einstellung werden die Ausgaben unter

```text
%LOCALAPPDATA%\SX35Z\NX_Output\SX35Z_v4_8_<Zeitstempel>_<Laufkennung>\
```

angelegt. `%LOCALAPPDATA%` lässt sich im Windows-Explorer in die Adresszeile
kopieren. Ist diese Umgebungsvariable nicht gesetzt, wird der Benutzerordner mit
`SX35Z\NX_Output` als Basis verwendet. Der tatsächlich verwendete Pfad wird im
NX-Listing Window ausgegeben.

Ein alternativer, absoluter Speicherort wird in `NX_Ausgabe.json` eingetragen:

```json
{
  "output_root": "C:\\NX_Daten\\SX35Z_Output"
}
```

Leerer Wert oder fehlende Datei bedeutet Standardausgabe. Relative Pfade,
falsche Datentypen und unbekannte JSON-Felder werden abgewiesen. Ein explizit
gewählter, nicht verwendbarer Ordner wird **nicht stillschweigend ersetzt**.

## Start in NX

1. Über „Journal wiedergeben / Play Journal“ zunächst `NX_Pfad_Pruefen.py` starten.
   Dieses Journal prüft ausschließlich Pfadauflösung und tatsächliches Schreiben,
   Lesen, Umbenennen und Entfernen einer eigenen Testdatei. Es erzeugt keine `.prt`.
   Die Meldung `Pfadtest bestanden` bestätigt nur diese Dateisystemprüfung.
2. Danach `NX_Detailbaugruppe_erzeugen.py` ausführen. Die Versionszeile muss
   `Journal-Version: 4.8` zeigen. Die bekannten NX-Ausdrucks-, Feature-, Speicher-
   und Baugruppen-Vortests werden automatisch vor dem Maschinenaufbau ausgeführt.
3. Nach vollständigem Erfolg enthält `HAUPTBAUGRUPPE.txt` im neuen Ausgabeordner den
   tatsächlichen Namen der Hauptbaugruppe. Den kompletten Ausgabeordner mit
   `Teile` und `Unterbaugruppen` zusammenhalten.

`NX_API_Pruefen.py`, `NX_Basis_Pruefen.py` und `NX_Einzelteile_erzeugen.py` bleiben
für Einzelprüfungen verfügbar. Vorhandene Ausgabedateien müssen nicht gelöscht
werden; jeder Lauf erzeugt einen neuen Ordner und eindeutige Teilenamen.

## Was verändert wurde

### Dateiverwaltung

Journal-/Eingabeordner und Ausgabeort sind getrennt. Bevor das erste NX-Teil
angelegt wird, prüft der Code den Zielordner einschließlich realer Dateioperationen.
`NX_Pfadpruefung.json` protokolliert das Ergebnis. Die bestehende strenge Auflösung
von Links und Pfadidentitäten wird **nicht durch ein pauschales Abfangen von
WinError 1005 abgeschaltet**. Auch der Schutz vor Überschreiben fremder Dateien,
Teilenamenskonflikten und Speichern außerhalb des Laufordners bleibt aktiv.

Lauf- und Fehlerprotokolle liegen beim gewählten Ausgabeordner. Eine zusätzliche
Fehlerprotokollkopie neben dem Journal wird nur noch bestmöglich geschrieben.
Scheitert diese Kopie auf W:, bleibt das lokale Protokoll erhalten. Scheitert bereits
die Ausgabeinitialisierung, wird für die Diagnose der lokale Standard-Protokollordner
`%LOCALAPPDATA%\SX35Z\NX_Output\_Protokolle` verwendet; es werden keine Teile an
einen stillschweigend anderen Ort geschrieben.

### Zwei unabhängig vom hochgeladenen Log lokal nachgewiesene v4.7-Modellfehler

Beim ergänzenden Geometrietest waren einzelne achsparallele Zahnblöcke des neuen
Pinolenvorschubritzels vollständig im Radkörper eingeschlossen. Die Vereinigung
fügte dann kein Material hinzu. Die zwölf symbolischen Zähne sind jetzt radial
orientierte Profile; ihre Breite folgt `quill_pinion_w`.

Außerdem waren die zwei Mitnehmertaschen durch eine wiederverwendete Variable dem
Ritzel statt der Spindelnase zugeordnet. Sie werden nun ausdrücklich am Körper
`Spindelnase_SK30_Normreferenz` abgezogen.

Das sind Programm-/Geometriekorrekturen, **keine neu vermessenen Maschinendaten**.
Zahnzahl, Verzahnungsprofil, Lagerungen und Anschlussmaße bleiben Annahmen. Keine
Kinematiksimulation oder Kollisionsfreigabe wird daraus abgeleitet. Die übrigen
Bauteilrezepte und die v4.7-Farbzuordnungen sind unverändert. Der Farbaufbau in NX
wurde mit diesem Patch nicht separat bestätigt.

### Aktualisierte Geometriereferenz

Die Datei `Geometrie_Referenz_v4.json` ist neu aus dem vollständigen Modellstand 4.8
berechnet. Bei mitgelieferten Standardparametern müssen Parameter- und Rezept-Hashes
passen; der frühere erwartete v4.7-Hash-Mismatch ist dann nicht mehr vorgesehen.
Eigene Parameteränderungen deaktivieren nur den Standard-Volumenvergleich,
nicht die laufenden Körper- und Wirkungsprüfungen. Keine Bohrung oder Operation
wird auf Fehler hin übersprungen.

## Nur den Patch über ein vollständiges v4.7-Paket installieren

Diese vorhandenen Dateien ersetzen:

```text
NX_Detailbaugruppe_erzeugen.py
nx_native.py
nx_files.py
modell_v4.py
Geometrie_Referenz_v4.json
```

Diese Dateien hinzufügen:

```text
NX_Pfad_Pruefen.py
NX_Ausgabe.json
```

`NX_Ausgabe.json` enthält nur die neue Ausgabeort-Einstellung; sie ist keine
Maßparameterdatei. `Parameter.json` nicht ersetzen. Die vorhandenen Dateien
`nx_geometry.py` (Messroutine v4.6), `v3_geometriebasis.py` und die übrigen
Startjournale bleiben erforderlich. Das kleine Patch-ZIP ist nicht allein lauffähig.

## Prüfstand und Grenzen

Die konkrete WinError-1005-Abbruchfolge wurde im Test gezielt durch eine Ausnahme
bei Pfadauflösung im simulierten Journal-Laufwerk nachgestellt. Derselbe
Treiberablauf mit getrennter lokaler Ausgabe besteht anschließend. Die Dateisystem-
Tests verwenden echte temporäre Dateien, aber keine echte Windows-W:-Einbindung.
NX-Objekte sind in den automatischen Tests ausdrücklich nachgebildet.

Eine zusätzliche Prüfung baut sämtliche 179 Einzelkörper mit 887 Modelloperationen
in OpenCascade auf und prüft jede Zwischengeometrie und Materialänderung. Die
NX-Adaptertests verwenden ebenfalls OpenCascade für die Körper, nicht Siemens
Parasolid. Zahlen und Testausgaben stehen in `Pruefbericht_v4_8.json` und
`Tests/Testergebnis_v4_8.txt`.

**Kein tatsächlicher Siemens-NX-Lauf wurde hier ausgeführt.** Eine erzeugte `.prt`,
STEP-Dateien oder neu gerenderte Vorschauen sind nicht Bestandteil dieses
Journalpakets. Die nativen Dateien entstehen erst bei erfolgreichem Lauf in NX.

## Bei einem weiteren Abbruch

Die neue `NX_Fehlerprotokoll.txt` aus dem tatsächlichen Ausgabeordner verwenden.
Bei Geometriefehlern zusätzlich die dort erzeugte `NX_Geometriediagnose.json`.
Die Pfadprüfdatei unterscheidet Dateisystemzugriff von noch nicht bestätigtem
NX-Speichern. Bitte nicht alte Logs aus einem vorherigen Ausgabeordner verwenden.

## Externe Referenzen zur Einordnung des Pfadfehlers

- Python `os.path`: https://docs.python.org/3.10/library/os.path.html
- Microsoft, ERROR_UNRECOGNIZED_VOLUME (1005):
  https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes--1000-1299-

Diese Dokumentation erläutert die Funktionen/Fehlernummer, identifiziert aber
nicht die konkrete Ursache der W:-Einbindung auf dem Benutzerrechner.
