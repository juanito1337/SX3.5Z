# -*- coding: utf-8 -*-
"""Only parts, without assembly. Optional filter: identifiers/names, or None for all."""
import os,sys,importlib.util
TEILE_FILTER=None # Example: ['Basis_Guss_Foto','Spindelkopf_Guss_Detail']
h=os.path.dirname(os.path.abspath(__file__))
s=importlib.util.spec_from_file_location('_v4_start',os.path.join(h,'NX_Detailbaugruppe_erzeugen.py'))
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
if __name__=='__main__':m.main(parts_only=True,part_filter=TEILE_FILTER)
