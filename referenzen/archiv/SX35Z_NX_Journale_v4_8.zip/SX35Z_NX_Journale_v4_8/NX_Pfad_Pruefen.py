# -*- coding: utf-8 -*-
"""Only path and real file IO check. Creates no NX solid or .prt file."""
import os, runpy
HERE = os.path.dirname(os.path.abspath(__file__))
ns = runpy.run_path(os.path.join(HERE, 'NX_Detailbaugruppe_erzeugen.py'), run_name='sx35z_path_runner')
if __name__ == '__main__':
    ns['main'](paths_only=True)
