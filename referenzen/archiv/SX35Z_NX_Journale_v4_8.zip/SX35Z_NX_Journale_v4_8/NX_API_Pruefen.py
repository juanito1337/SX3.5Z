# -*- coding: utf-8 -*-
import os,sys,importlib.util
h=os.path.dirname(os.path.abspath(__file__))
s=importlib.util.spec_from_file_location('_v4_start',os.path.join(h,'NX_Detailbaugruppe_erzeugen.py'))
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
if __name__=='__main__':m.main(probe_only=True)
