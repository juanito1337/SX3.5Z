# -*- coding: utf-8 -*-
"""Run only the real 38-step P001 basis, after the generic NX API tests."""
import os, sys, runpy
HERE=os.path.dirname(os.path.abspath(__file__))
if HERE in sys.path:sys.path.remove(HERE)
sys.path.insert(0,HERE)
ns=runpy.run_path(os.path.join(HERE,'NX_Detailbaugruppe_erzeugen.py'),run_name='sx35z_basis_runner')
ns['main'](parts_only=True,part_filter=('P001',))
