# Aktueller Journalstand: 4.3 – Modellstand unverändert 4.0

**Zuerst `LIESMICH_FIX_v4_3.md` lesen.** Der aktuelle Patch korrigiert den
Cone-Nullparameter; frühere Einheiten- und Ausdruckskorrekturen bleiben erhalten.
Die Geometrie und die Standardparameter sind unverändert.

**Kein hier ausgeführter NX-Lauf.** 75 lokale Tests mit simulierten NX-Objekten
prüfen Typübergaben und Programmablauf, nicht reale NX-Volumenkörper.
Details: `Tests/Patch_Pruefbericht_v4_3.json`.

Dieses kleine Paket enthält KEINE STEP-Dateien, Bilder oder fertigen nativen
PRT-Dateien. Die betreffenden Abschnitte der ursprünglichen Modellbeschreibung
unten beziehen sich auf das große v4-Gesamtpaket.

---

# SX3.5Z – Detailmodell v4 / native NX-Dateibaugruppe

## Ergebnis und Grenzen

Die Maschine wurde in 176 einzelne geometrische Teile aufgeteilt, geordnet in zehn Unterbaugruppen. Der gemeinsame geometrische Bauplan wird sowohl vom NX-Journal als auch vom mitgelieferten STEP-Generator verwendet. Jeder modellierte Teil wird zuerst separat aufgebaut; anschließend werden die Teile positioniert und zu Unterbaugruppen und einer Hauptbaugruppe zusammengefügt.

**Es liegt keine von Siemens NX erzeugte `.prt` im Paket.** Hier ist keine NX-Laufzeit verfügbar. Der Python-Journallauf in deiner NX-Installation soll die nativen Dateien erzeugen. Eine erfolgreiche Ausführung in NX wurde hier nicht getestet oder behauptet. Geprüft wurden reale Open-CASCADE-Volumenkörper, STEP-Exporte und Parameteränderungen; das ist kein NX-API-Test.

Es handelt sich um eine detailliertere **Foto-Rekonstruktion des Originalzustands**, nicht um die bereits ausgelegte CNC-Konvertierung. Alle 72 bereitgestellten Maschinenfotos sind in der Quellenzuordnung berücksichtigt. Unsichtbare Innengeometrie ist nicht als Herstellerkonstruktion ausgegeben. Aus den Fotos abgeleitete Maße bleiben Annahmen; bestätigte neue numerische Messwerte des Nutzers liegen in diesem Stand nicht vor.

## 1. In Siemens NX erzeugen

1. Das vollständige Paket in einen neuen beschreibbaren lokalen Ordner entpacken. Mit v1/v2/v3 nicht mischen.
2. In NX im **Modeling-/History-Modus** `NX_Detailbaugruppe_erzeugen.py` über **Journal wiedergeben / Play Journal** ausführen. Die mitgelieferten Module müssen im selben Ordner liegen. NX verwendet seine Python-Umgebung; CadQuery ist dafür nicht erforderlich.
3. Das Journal führt zuerst einen lokalen API-Test aus: Ausdrücke, abhängige Punkte, Parameteränderung, Block/Zylinder/Kegel/Profil-Extrusion, Speichern und Einfügen einer Komponente. Wenn dieser Test fehlschlägt, wird nicht einfach mit einem weniger parametrischen STEP-Import weitergemacht.
4. Danach werden alle Einzelteile nacheinander erstellt. Erst wenn sämtliche Teile gespeichert sind, entstehen die zehn Unterbaugruppen und die Hauptbaugruppe.
5. Ausgabe: `NX_Output/SX35Z_v4_3_<Zeitstempel>/SX35Z_GESAMT_v4.prt`. Der Zeitstempel verhindert Überschreiben früherer Ausgaben.

Die Ausgabe enthält `Teile/` mit 176 Modellteilen, `Unterbaugruppen/` mit zehn Baugruppenteilen sowie die Hauptbaugruppe. Hinzu kommen zwei kleine Dateien in `_API_Test/`, die nicht in die Maschine eingebaut werden. Die komplette Modellordnerstruktur zusammenhalten. Nach einem Umzug auf einen anderen Rechner ggf. `Teile` und `Unterbaugruppen` zu den NX-Baugruppen-Suchordnern hinzufügen.

**Nicht vorhandene native Dateien niemals durch Umbenennen einer STEP-Datei in `.prt` ersetzen.**

## 2. Weitere Journale

- `NX_API_Pruefen.py`: nur der Vortest, ohne Maschinenmodell. Dieser Test wird vom Hauptjournal ohnehin ausgeführt.
- `NX_Einzelteile_erzeugen.py`: nur native Einzelteile. Optional oben `TEILE_FILTER` auf eine Liste von Bauteilnamen oder IDs setzen. `None` bedeutet alle Teile. Den Filter nur in einer Kopie bearbeiten.

Falls ein Lauf abbricht: `NX_Fehlerprotokoll.txt` und das Laufprotokoll unter `NX_Output` enthalten Python-/NX-Angaben, das betroffene Teil und das betroffene Feature. Bereits gespeicherte Teile eines abgebrochenen Laufs sind **keine vollständig erzeugte Baugruppe**. Offene vorhandene Benutzerteile werden nicht bearbeitet oder geschlossen.

## 3. Welche Parametrik vorliegt

Jedes Teil besitzt native Block-, Zylinder-, Kegel-, Profil-Extrusions- und boolesche Features sowie die tatsächlich benötigten benannten `sx_...`-Ausdrücke. Profile werden aus assoziativen, expressionsgesteuerten Linien aufgebaut. Es werden weder Dreiecksnetze importiert noch STEP-Körper als native Featurehistorie ausgegeben.

Die Teile erhalten lokale Bezugsursprünge. Ihre Einbaupositionen werden aus `Parameter.json` berechnet und beim Erzeugen als Komponentenpositionen gesetzt. Die Hauptbaugruppe besitzt echte Komponentenreferenzen und Unterbaugruppen, **aber keine Montagezwangsbedingungen, keine WAVE-/Interpart-Verknüpfungen und keine Kinematiksimulation**.

Lokale Formänderungen sind in NX über die Ausdrücke möglich. Für konsistente Änderungen über mehrere Teile, insbesondere Einbauhöhen, Achsstellungen oder Gehäuseabmessungen: `Parameter.json` ändern und das Hauptjournal in einen neuen Ausgabeordner laufen lassen. Das synchronisiert alle benötigten Teile und Einbaupositionen. Eine Änderung an einem einzelnen Teil aktualisiert nicht automatisch alle anderen Teile.

Beispiele für globale Einstellungen: `pos_x`, `pos_y`, `head_down`, `quill_down`. Beispiele für Formparameter: `saddle_x`, `saddle_y`, `head_wall`, `column_wall`, `motor_length`, `cover_width`, `cover_deep`. Einige aus v3 erhaltene Werte dienen lediglich der Prüfung oder als Referenz und steuern keine sichtbare Geometrie; sie sind in `Dokumentation/Parameter_Quellen.json` entsprechend gekennzeichnet.

Die Einheiten sind **Millimeter**. Falls die NX-Installation nur den geprüften Rückfallweg `Number_mm` unterstützt, werden einheitenlose Zahlen-Ausdrücke mit expliziter Millimeterkonvention benutzt; das wird protokolliert. In diesem Modus nicht auf Zoll umstellen.

## 4. STEP, Vorschau und Katalog

- `SX35Z_Detailbaugruppe_v4.step`: farbige Baugruppe mit Unterstruktur und allen Teilen.
- `Einzelteile_STEP/`: alle Einzelteile an ihrem lokalen Teileursprung.
- `Unterbaugruppen_STEP/`: zehn Unterbaugruppen in Maschinenkoordinaten.
- `SX35Z_Detailbaugruppe_v4.glb`: Netzvorschau, nicht für Fertigung und nicht die Quelle des NX-Aufbaus.
- `START_HIER.html`: lokale Übersicht mit Bildern und Links.
- `Bauteilkatalog.html`: durchsuchbare Liste mit Geometriedetails, Quellenfotos und einzelnen STEP-Dateien.
- `Vorschau/`: aus den tatsächlichen Volumenkörpern gerenderte Bilder. Kein KI-Bild als Geometrienachweis.

Die STEP-Dateien haben keine NX-Featurehistorie. Diese entsteht ausschließlich beim nativen Journalaufbau.

## 5. Nachgebildet und bewusst vereinfacht

Detailliert aufgenommen wurden insbesondere: hohle Basis mit Rippen und Durchbruch, offene Gusssäule, Kreuzschlitten mit gerundetem Kanal und Schmiernuten, Tisch mit T-Nuten und Unterseitenprofil, hohler Spindelkopf mit Führungsbereich und Bohrungen, Motor-Kühlrippen, Montageplatten, Riemenscheibenrillen, Bedienpanel, mehrteilige Blechverkleidung, sichtbare Elektrik-Baugruppen und Schutzteile.

Bewusst nicht als exakt rekonstruiert ausgegeben werden: Gewindesteigungen und Gewindegänge der Vorschubspindeln, Lagerinnenleben, Getriebeverzahnung, elektrische Schaltung und Kontaktfunktionen, unsichtbare Halteranschlüsse, Biegeradien/Abwicklungen, Passungen und Sicherheitsabstände. Original-Gleitspindeln sind Hüllkörper, keine nachträglich erfundenen Kugelumlaufspindeln. Riemenzähne und Wellenverzahnung sind nur Konturannäherungen. Kabelschläuche bilden eine angenäherte Neutralstellung ab und simulieren keine Bewegung.

Die Elektrik ist ein Einbaumodell: Platinen, Transformatoren, Kühlkörper und Klemmen als getrennte Körper. Leiterbahnen, interne Verdrahtung und alle nicht erkennbaren Elektronikdetails fehlen bewusst. Die Anordnung ist teilweise für die angenommene Gehäusegeometrie angepasst und kein freigegebener Schaltschrankplan.

**Nicht für Fertigung, Lagerauswahl, Kugelspindelbestellung, statischen Nachweis oder abschließende Kollisionsprüfung verwenden.** Kritische Maße müssen vor diesen Schritten an der zerlegten Maschine geprüft werden.

## 6. Prüfstand

Der tatsächliche Prüfbericht befindet sich in `Pruefbericht.json`. Jede additive/subtraktive CAD-Operation wurde auf gültige, zusammenhängende Volumengeometrie geprüft. Der komplette STEP-Export wurde wieder eingelesen und die Körperzahl sowie Volumensumme abgeglichen. Zusätzliche Parameterkonfigurationen werden in `Tests/Parametertests.json` einzeln aufgeführt.

Das sind Geometrie- und Softwareprüfungen, keine Bestätigung der Übereinstimmung mit allen realen Maschinenmaßen. Die Fotovorlage liefert die Baumerkmale, nicht sämtliche Abmessungen.
