# SX3.5Z – NX-Journalkorrektur 4.4 für den NX-2406-Speicherabbruch

Modellstand: unverändert 4.0. Journalstand: 4.4.

## Was das hochgeladene Protokoll tatsächlich belegt

Im Lauf mit Journal 4.3 in NX 2406 bestehen die Einheitenprüfung, die 259
Modellausdrücke, deren Wiederholung nach Undo und die Featureproben einschließlich
Kegel, Kegelabzug -X und Profil-Extrusion. Der Abbruch erfolgt erst beim Aufruf
`part.SaveAs(...)` für `API_Testteil.prt`: „Datei bereits vorhanden“.
Die Maschinen-Einzelteile wurden in diesem Lauf noch nicht gebaut.

Das bisherige Protokoll enthält weder den `FullPath` des Testteils vor dem
Speichern noch eine Dateisystem-/Sitzungsprüfung am Ziel. Es beweist daher
**nicht**, ob tatsächlich eine Datei auf dem Datenträger existierte, ein
Namenskonflikt mit einem geladenen Teil bestand oder ein anderer interner
NX-Zustand den Fehler auslöste. Auch ein Zusammenhang mit den zuvor gemeldeten
optionalen Ausdrucksattribut-Warnungen ist nicht nachgewiesen.

## Installation: drei Laufzeitdateien

Im vorhandenen v4.x-Journalordner – direkt neben `modell_v4.py` und
`Parameter.json` – diese Dateien ablegen:

- `NX_Detailbaugruppe_erzeugen.py` ersetzen.
- `nx_native.py` ersetzen (nur Versionskennung geändert; Geometrie-/Ausdruckscode gleich).
- **`nx_files.py` neu hinzufügen.**

`Parameter.json`, `modell_v4.py`, `v3_geometriebasis.py`, `NX_API_Pruefen.py` und
`NX_Einzelteile_erzeugen.py` unverändert lassen. Das kleine Patch-ZIP enthält
keine Parameterdatei. Die Ordner `Tests` und die Anleitungen sind nur
Dokumentation/Offline-Tests und nicht für den NX-Lauf erforderlich.

Das vollständige Journal-ZIP alternativ in einen neuen beschreibbaren lokalen
Ordner entpacken, beispielsweise `C:\NX\SX35Z`. Es enthält die ursprünglichen
Standardparameter; eigene Parameteränderungen nicht damit überschreiben.
Kurze Ordnernamen vermeiden unnötig lange Gesamtpfade. Alte .prt-Dateien oder
Ausgabeordner müssen für diesen Patch nicht gelöscht werden.

## In NX ausführen

1. `NX_API_Pruefen.py` über Journal wiedergeben / Play Journal starten.
2. Im Listing Window muss `Journal-Version: 4.4` erscheinen. Die neue Dateilogik
   meldet `Speicherweg: NewDisplay am endgueltigen Pfad, dann Save; kein SaveAs.`
3. Erst die abschließende Meldung bestätigt den vollständigen Vortest:

   `API-Vortest bestanden: Ausdruecke, Parameteraenderung, Features, Save und AddComponent.`

4. Danach `NX_Detailbaugruppe_erzeugen.py` für alle 176 Modellteile und die
   Baugruppen starten. Das Hauptjournal wiederholt den Vortest absichtlich.

Die Dateinamen haben jetzt ALLE eine eigene Laufkennung – auch die Hauptbaugruppe:

```text
NX_Output/
└── SX35Z_v4_4_<Zeitstempel>_<Laufkennung>/
    ├── _API_Test/
    │   ├── API_Testteil__<Laufkennung>.prt
    │   └── API_Testbaugruppe__<Laufkennung>.prt
    ├── Teile/                      176 Teile bei vollständigem Erfolg
    ├── Unterbaugruppen/            10 Unterbaugruppen
    ├── SX35Z_GESAMT_v4__<Laufkennung>.prt
    ├── HAUPTBAUGRUPPE.txt           tatsächlicher Hauptdateiname
    ├── Erzeugte_Teile.json
    └── Parameter_beim_Aufbau.json
```

Die Anzeigenamen der Komponenten bleiben lesbar. Die Baugruppenverweise und das
Manifest verwenden die tatsächlich erzeugten Dateinamen. Keine Kopie ohne
Laufkennung anlegen: Das könnte beim gleichzeitigen Laden alter Läufe wieder
Namenskonflikte erzeugen. Den gesamten Ausgabeordner zusammenhalten.

## Was die Speicherlogik ändert

Alle Teile werden direkt mit ihrem endgültigen absoluten Dateipfad angelegt:

```python
part = session.Parts.NewDisplay(final_path, NXOpen.Part.Units.Millimeters)
# ... Parameter, Features bzw. Komponenten ...
status = part.Save(NXOpen.BasePart.SaveComponents.FalseValue,
                   NXOpen.BasePart.CloseAfterSave.FalseValue)
```

Der Helfer `nx_files.py` prüft zusätzlich den tatsächlichen `part.FullPath`.
`SaveAs` wird in diesem Ablauf nicht mehr aufgerufen. Nicht einfach im alten
Journal `SaveAs` durch `Save` ersetzen: Erst die neue Erzeugung am endgültigen
Pfad macht den Speicheraufruf eindeutig.

Vor der Erzeugung werden existierende Ziele und bereits geladene gleichnamige
Teile geprüft. Gespeichert werden ausschließlich Teile, die diese konkrete
Journalinstanz selbst neu angelegt und registriert hat. Die Speicherroutine
speichert nicht automatisch Komponenten oder andere offene Benutzerteile mit.
Es gibt weder `SaveAll` noch Löschen/Überschreiben fremder Dateien, automatisches
Schließen vorhandener Teile oder einen stillen `SaveAs`-Rückfall.

Nach dem Speichern werden `PartSaveStatus`, der Teilpfad sowie eine nichtleere
Zieldatei geprüft. Eine fehlende Datei oder ein Speicherfehler stoppt den Lauf;
eine Fehlermeldung wird nicht als Erfolg behandelt. Diese Dateiprüfung ist kein
Wiedereinlese-/Geometrievalidierungstest.

Bei Problemen ergänzt das Protokoll den tatsächlichen NX-Teilpfad, Dateiname,
Dateiexistenz, Dateigröße, ermittelte offene Namenskonflikte und – falls von der
Ausnahme geliefert – den NX-Fehlercode.

## Metadatenhinweise aus dem alten Lauf

Die Hinweise `Attribut SX_STATUS ... aktuelle Version von OM ...` betreffen
optionale Zusatzattribute auf Expressions. Der alte Lauf setzte danach bis zum
Speicheraufruf fort; sie sind nicht die im Traceback genannte Abbruchstelle.
Diese Korrektur unterdrückt sie nicht und behauptet auch keine neue Lösung für
sie. Die Quellen-/Annahmenzuordnung bleibt in
`Dokumentation/Parameter_Quellen.json` verfügbar. Ausdrucksformeln und deren
Parametrik bleiben unverändert.

## Prüfumfang dieser Lieferung

**117 lokale Regressionstests bestanden, ausschließlich mit simulierten
NX-Objekten:** 21 Einheiten-, 32 Ausdrucks-, 22 Feature- und 42 Datei-/Ablauftests.
Der Ablauftest führt den gesamten Hauptjournal-Steuerfluss zweimal aus und prüft
dabei 378 eindeutige simulierte Dateien (je 176 Teile + 10 Unterbaugruppen +
1 Hauptbaugruppe + 2 Testdateien). Diese temporären Testdateien enthalten nur
gekennzeichneten Mock-Text; es sind ausdrücklich KEINE NX-PRT-Dateien.

Außerdem: Python-3.10-Syntax geprüft; Geometriemodule, Standardparameter,
Quellenparameterdatei und die zwei Starter byteweise unverändert. Der native
Geometrie-/Ausdrucksadapter unterscheidet sich nur in der Versionskennung.

**Kein Siemens NX wurde hier ausgeführt.** Das Speichern echter nativer Teile,
das Einfügen in NX-Baugruppen und der vollständige Modellaufbau mit v4.4 sind
weiterhin nicht bestätigt. Der Patch ersetzt den problematischen Speicherablauf
und macht Fehler genauer sichtbar; er beweist nicht die interne Ursache des
alten Fehlers. Reale Geometrie wurde für diesen Patch nicht neu erzeugt.

Prüfergebnisse: `Tests/Patch_Pruefbericht_v4_4.json`; Änderungen:
`Tests/Patch_v4_3_nach_v4_4.diff`. Die Tests im Ordner `Tests` nur mit gewöhnlichem
Python außerhalb von NX ausführen, nie über Play Journal.

Bei einem erneuten Abbruch die neu erzeugte `NX_Fehlerprotokoll.txt` hochladen;
die Versionszeile muss 4.4 und die Dateiverwaltung `nx_files.py` ausweisen.

## API-Abgleich und Grenzen der Quellen

Die folgenden öffentlich erreichbaren Spiegel enthalten die von Siemens
generierte NXOpen-API-Referenz; sie sind keine aktuelle NX-2406-Python-Laufzeit:

- `PartCollection.NewDisplay`: https://www.ugapi.com/doc/nxopen/a04487.html
- `BasePart.Save`, `SaveAs`, `FullPath`: https://www.ugapi.com/doc/nxopen/a00638.html
- `PartSaveStatus`: https://www.ugapi.com/doc/nxopen/a04505.html
- .NET-Signaturen: https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.BasePart.html

Die API unterscheidet das Speichern des aktuellen Teils (`Save`) vom Speichern
unter neuem Namen (`SaveAs`). Die konkrete Python-Bindung und der reale
Dateispeichervorgang müssen im beigefügten Vortest auf dem Nutzerrechner bestehen.
Die .NET-/C++-Referenz ersetzt diesen Test nicht.
