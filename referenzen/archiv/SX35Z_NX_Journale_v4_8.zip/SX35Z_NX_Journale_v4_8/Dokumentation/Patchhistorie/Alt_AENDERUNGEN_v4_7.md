# SX3.5Z – NX-Journal 4.7 für NX 2406

Stand dieser Revision: Kopf-Innenleben und Farbzuordnung überarbeitet.

## Änderungen in v4.7

1. **Kopf-Innenleben plausibilisiert**
   - Die **Werkzeugspindel** läuft nun als eigene Hüllgeometrie **durchgehend bis in den oberen Antriebsbereich**.
   - Die **Zahnstange der Pinole** wurde logisch zur Vorschubmechanik neu angeordnet.
   - Ein **inneres Pinolenvorschub-Ritzel** sowie eine **innere Vorschubwelle** zwischen Ritzel und Dreisternhebel wurden ergänzt.

2. **Farben näher an den Fotos**
   - Kopfgehäuse, Riemenabdeckung, Bediengehäuse und Blechsäule sind **maschinenrot**.
   - Tisch, Kreuzschlitten und Basisguss sind **grau / gussähnlich**.
   - Motor, Griffe, Bleche, Schrauben und Anzeige-/Elektrobauteile bleiben materialtypisch dunkel, schwarz, silber oder bronzefarben.

## Wichtige Hinweise

- Diese Revision ist weiterhin ein **fotoabgeglichenes Rekonstruktionsmodell**.
- Maße, Passungen, Zahnzahlen und Zahnprofile im Kopf sind **Funktionsannahmen**, nicht vermessene Fertigungsdaten.
- Die Datei `Geometrie_Referenz_v4.json` wurde **nicht neu mit OpenCascade regeneriert**. Deshalb ist im Listing Window ein Hinweis auf einen **Referenz-/Rezept-Hash-Mismatch** möglich. Das ist **erwartet** und **kein Abbruchkriterium**. Die nativen NX-Körperprüfungen bleiben aktiv.

## Verwendung in NX 2406

1. ZIP entpacken.
2. Ordner in NX als Journalspeicher öffnen.
3. Zuerst optional `NX_Basis_Pruefen.py` ausführen.
4. Danach `NX_Detailbaugruppe_erzeugen.py` ausführen.
5. Im Listing Window sollte `Journal-Version: 4.7` erscheinen.

## Erwartete Ausgabe

Die erzeugten Dateien liegen in einem Ausgabeordner mit dem Muster:

`NX_Output/SX35Z_v4_7_<Zeitstempel>_<Laufkennung>/`

## Wenn du noch ein neues Foto lieferst

Dann kann die innere Kinematik von Pinole / Ritzel / Hebel noch einmal gezielt weiter verfeinert werden.
