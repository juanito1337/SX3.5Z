# SX3.5Z – NX-Journal-Patch 4.2 für den gemeldeten NX-2406-Abbruch

## Installation: vorhandene Parameter behalten

Das kleine Patch-ZIP ist für das vorhandene v4-/v4.1-Modellpaket gedacht.
Die beiden Dateien `nx_native.py` und `NX_Detailbaugruppe_erzeugen.py` im
bisherigen Arbeitsordner ersetzen. Sie müssen direkt neben `modell_v4.py`,
`v3_geometriebasis.py`, `Parameter.json` und `NX_API_Pruefen.py` liegen.
Nicht nur einen zusätzlichen verschachtelten Patchordner daneben anlegen.
Die übrigen mitgelieferten Dateien dokumentieren den Patch und seine Tests.

`Parameter.json` NICHT ersetzen. Der kleine Patch enthält bewusst keine
Parameterdatei. Eigene Maße bleiben dadurch erhalten. Geometriedateien und
bisherige STEP-Dateien ändern sich nicht.

Danach in NX über „Journal wiedergeben / Play Journal“ zuerst
`NX_API_Pruefen.py` starten. Im Listing Window muss `Journal-Version: 4.2`
stehen. Nach dem vollständigen erfolgreichen Vortest kann
`NX_Detailbaugruppe_erzeugen.py` für das gesamte Modell gestartet werden.
Das Hauptjournal führt den Vortest erneut aus; er wird nicht übersprungen.

Die Ausgabe lautet `NX_Output/SX35Z_v4_2_<Zeitstempel>/`.
Die Hauptdatei heißt weiterhin `SX35Z_GESAMT_v4.prt`.
Vorhandene PRT-Dateien werden nicht überschrieben.
Ein reiner API-Test schreibt nur seine Testteile, nicht die Maschine.

Alternativ enthält `SX35Z_NX_Journale_v4_2.zip` alle benötigten Skripte und
unveränderte v4-Standardwerte in `Parameter.json`. Dieses Paket in einen
NEUEN Ordner entpacken. Eigene Maße dann aus der alten Parameterdatei
übernehmen. Keine zusätzlichen Python-Pakete in NX erforderlich.

## Was das neue Protokoll tatsächlich belegt

Quelle: hochgeladene `NX_Fehlerprotokoll(1).txt`, Journal-Version 4.1,
NX-Installationspfad nx2406 und Python 3.10.12.

- Die in 4.1 korrigierte Millimeterprüfung besteht (Zeilen 10–18).
- Die kleine Ausdrucks-/Punktprobe besteht mit CreateNumberExpression
  (Zeilen 19–20).
- Beim anschließenden Modellparameter-Aufbau bricht der Aufruf
  `sx_table_y = 180` ab (Zeilen 21–27, Traceback 191–202).
- Der Abbruch liegt noch vor dem Aufbau der Maschinen-Einzelteile (204–205).
- Die vom lokalen NX-Modul ausgegebene Dokumentation nennt sowohl
  `CreateNumberExpression(expressionString, unitType)` als auch
  `CreateNumberExpression(name, formula, isUserLocked, units)` (36–37).

Die interne NX-Ursache ist damit NICHT eindeutig bewiesen. Insbesondere
lässt der Text „Typ int erwartet, str gefunden“ nicht den Schluss zu, dass
eine Gleichung in eine Ganzzahl umgewandelt werden sollte. Die lokale
Methodendokumentation verlangt eine Zeichenkette für die Gleichung (49–52).

Im alten Quellcode lagen zwischen Mini-Test und Modellaufbau eine Undo-
Rücknahme, und zwischen den ersten Modellparametern Attributschreibvorgänge
mit Update.Now. Das sind Änderungen des API-Zustands, die der kleine Test
nicht abdeckte. Eine ungültig gewordene Objektbindung, eine Wirkung der
Zwischen-Updates oder die Überladungsauflösung sind denkbare Ursachen,
aber keine hier nachgewiesene Diagnose eines NX-Interna-Fehlers.

## Änderungen in 4.2

1. Bevorzugter Aufruf mit explizit getrenntem Namen, Formel und Sperrflag:

   ```python
   units = part.UnitCollection.GetBase("Length")
   expression = part.Expressions.CreateNumberExpression(
       "sx_table_y", "180", False, units
   )
   ```

   Das ist ein Unit-Objekt, kein numerischer Unit-Tag. Gleichung und Formel
   bleiben Text. Das Vorhandensein dieser Überladung wird aus der lokalen
   NX-2406-Dokumentation abgeleitet; ihre Ausführung wurde hier nicht in NX
   getestet. Bei fehlender Unterstützung werden die weiteren dokumentierten
   Wege vollständig geprüft, nicht pro Parameter stillschweigend gemischt.

2. Einheitenobjekt aus dem jeweils aktuellen Teil bei JEDEM Aufruf neu
   beziehen. Ein früheres Unit-Objekt wird weder nach Undo noch zwischen
   Teilen als gültig vorausgesetzt. Die Einheitenprüfung aus 4.1 bleibt erhalten.

3. KEINE Ausdrucksattribute zwischen dem Anlegen einzelner Parameter und
   während der geometrischen Operationen. Quellen-/Statusattribute werden
   erst nach dem vollständigen Körperaufbau geschrieben. Namen werden zur
   späteren Zuordnung gespeichert, keine NX-Objekte aus rückgängig gemachten
   Tests. Attributprobleme bleiben im Protokoll als Metadatenhinweise sichtbar.

4. Jeder Kandidat muss zunächst die assoziative Punktprobe und danach – nach
   deren Undo – ALLE 210 Eingabe- und 49 abgeleiteten Modell-Ausdrücke bestehen.
   Ihre Zahlenwerte werden mit dem gemeinsamen Modellrezept verglichen.
   Nach einem Update wird zusätzlich ein abhängiger Ausdruck erzeugt.
   Der gesamte Kandidat wird zurückgenommen, bevor ein anderer geprüft wird.

5. Mit dem ausgewählten Modus werden die vollständigen Modell-Ausdrücke
   erneut aufgebaut. Anschließend folgen die vorhandenen Feature-, Update-,
   SaveAs- und Baugruppentests. Die nach der Featureprobe erzeugte Testgeometrie
   prüft auch Ausdrucksaufrufe nach deren Undo.

6. Innerhalb eines tatsächlichen Teileaufbaus wird bei einem Fehler NICHT der
   Einheiten-/API-Modus gewechselt. Scheitert die Rücknahme eines Kandidaten,
   wird abgebrochen, statt mit möglicherweise verbliebenen Objekten fortzufahren.

## Einheitenloser Rückfallweg

Nur wenn die anderen Kandidaten die erforderlichen Ausdruckstests nicht
bestehen, kommt `CreateExpression("Number", equation)` zum Einsatz. Dieser
Weg wird ausdrücklich als `Number_mm` / `KOMPATIBILITAETSMODUS` gemeldet.
Auch er muss die Abhängigkeiten und vollständigen Modell-Ausdrücke bestehen.

Die benannten Formeln bleiben dabei parametrisch. Die sx_-Ausdrücke selbst
sind jedoch einheitenlose Zahlen in einer festen Millimeterkonvention. Das
Teil bleibt ein Millimeterteil; nicht nachträglich auf Zoll umstellen. Keine
automatische Konvertierung und kein Rückfall auf einen reinen STEP-Import.

## Was lokal geprüft wurde – und was nicht

- 21 Einheiten-Regressionstests sowie 32 Ausdrucks-/Ablauf-Regressionstests
  mit SIMULIERTEN NX-Objekten: 53 Tests erfolgreich.
- Vollständige Zahlenformeln und benötigte Parameterteilmengen aller
  176 Modelldefinitionen in der Simulation geprüft.
- Reihenfolge Geometrie vor Ausdrucksattributen, Überladungswahl, vollständige
  Rücknahme, sichtbarer Number_mm-Modus und unveränderte Parameter getestet.
- Syntax aller mitgelieferten Python-Dateien gegen Python-3.10-Grammatik geprüft.
- `modell_v4.py`, `v3_geometriebasis.py` und `Parameter.json` sind bytegleich
  zum gelieferten v4.1-Paket; Hashvergleich im separaten Patch-Prüfbericht.

Die Tests simulieren unter anderem ungültig gewordene Unit-Objekte und einen
Fehler bei sx_table_y nach erfolgreicher Mini-Probe. Das prüft die Robustheit
des Patches, beweist aber NICHT, dass einer dieser Mechanismen deinen NX-Fehler
verursacht hat. Hier wurde kein Siemens NX gestartet, keine native .prt erzeugt
und kein vollständiger Maschinenaufbau als erfolgreich bestätigt. Die alten
CAD-Geometrieprüfungen aus v4 wurden für diesen Journalpatch nicht wiederholt.

Die Originale `Pruefbericht.json` und `Dokumentation/API_UND_PRUEFSTAND.md`
beschreiben den v4-Modellstand. Der neue Patch wird ausschließlich in
`Tests/Patch_Pruefbericht_v4_2.json` und den v4.2-Testprotokollen bewertet.
Historische v4.1-Testberichte sind kein Nachweis eines neuen NX-Laufs.

Bei erneutem Abbruch die NEUE `NX_Fehlerprotokoll.txt` aus diesem Arbeitsordner
verwenden. Sie muss Journal-Version 4.2 enthalten. Die NX-Version ist bereits
bekannt; sie muss nicht erneut erfragt werden.
