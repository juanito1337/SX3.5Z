# SX3.5Z – NX-Journalkorrektur 4.3 für den gemeldeten NX-2406-Fehler

**Geometriestand: unverändert 4.0. Journalstand: 4.3.**
Dieser Patch korrigiert den typisierten Nullparameter beim Kegelaufbau.
Er ist kein neues oder vermessenes Maschinenmodell und enthält keine bereits
in NX erzeugte `.prt`-Datei. Ein realer NX-Lauf wurde hier nicht ausgeführt.

## 1. Befund aus deinem neuen Protokoll

`NX_Fehlerprotokoll(2).txt` meldet für Journal 4.2:

- Die Millimeterprüfung besteht.
- Die Punkt-/Ausdrucksprüfung und alle 259 Modell-Ausdrücke bestehen,
  einschließlich erneuter Erzeugung nach Rücknahme.
- Der Abbruch erfolgt in Testphase 3 beim Feature `SXPROBE_Kegel`.
- Der Traceback nennt `CreateConeBuilder(NXOpen.Features.Feature.Null)` und
  `Typ NXOpen.Features.Cone erwartet, NXOpen.Features.Feature gefunden`.
- Es wurden in diesem Lauf noch keine Maschinen-Einzelteile aufgebaut.

Der abgelehnte Vier-Argument-Versuch in der früheren Testphase ist **nicht**
der abschließende Fehler. Der vorhandene Rückfall auf den Zwei-Argument-Aufruf
`CreateNumberExpression` funktioniert laut deinem Protokoll. Die gesamte
Ausdruckslogik aus 4.2 bleibt deshalb unverändert, einschließlich Vortest und
Einheitenbehandlung. Es gibt keinen Anlass, Parameterwerte umzuschreiben.

## 2. Einspielen in deinen vorhandenen Ordner (empfohlen)

1. Das kleine Paket `SX35Z_NX_Fix_v4_3_NX2406.zip` entpacken.
2. **Nur `nx_native.py` und `NX_Detailbaugruppe_erzeugen.py` ersetzen.**
   Beide müssen unmittelbar neben `modell_v4.py`, `v3_geometriebasis.py`
   und deiner `Parameter.json` liegen. Nicht in einen zusätzlichen Unterordner
   kopieren. Die bisherigen Dateien bei Bedarf vorher sichern.
3. **`Parameter.json` nicht ersetzen.** Das kleine Patchpaket enthält bewusst
   keine Parameterdatei und keine neue Geometriedefinition.
4. In NX über „Journal wiedergeben / Play Journal“ die vorhandene Datei
   `NX_API_Pruefen.py` starten. Dieser Einstieg lädt den korrigierten Adapter.
5. Auf `Journal-Version: 4.3` und das vollständige Ende des Vortests achten.
   Die Meldung `259/259` allein ist noch kein erfolgreicher Gesamtvortest.
6. Erst nach bestandenem Vortest `NX_Detailbaugruppe_erzeugen.py` starten.
   Der Hauptlauf führt den Vortest nochmals selbst aus.

Die beiden Einstiegsskripte `NX_API_Pruefen.py` und `NX_Einzelteile_erzeugen.py`
müssen nicht geändert werden. Das Hauptjournal lädt die zugehörigen Module
neu, damit NX keine ältere Adapterversion aus einem vorherigen Lauf benutzt.

## 3. Vollständiges kleines Journalpaket als Alternative

`SX35Z_NX_Journale_v4_3.zip` enthält alle für den nativen Aufbau benötigten
Skripte und **die ursprünglichen Standardparameter**. In einen neuen,
beschreibbaren Ordner entpacken. Bereits selbst geänderte Parameter zuvor
sichern und die eigene v4-Parameterdatei bewusst übernehmen.

Keine STEP-Dateien, Vorschauen oder nativen `.prt`-Dateien enthalten.
Keine zusätzliche CadQuery-Installation nötig. Die alte große v4-Modell-
lieferung muss nicht neu heruntergeladen werden.

## 4. Konkrete Korrektur und abgeglichene Builder-Signaturen

Für einen neuen Kegel ist die entscheidende Übergabe:

```python
builder = part.Features.CreateConeBuilder(NXOpen.Features.Cone.Null)
```

**Nicht pauschal alle `Feature.Null` ersetzen.** Der Adapter verwendet:

| Builder | Nullparameter für Neuanlage |
|---|---|
| `Features.CreateBlockFeatureBuilder` | `NXOpen.Features.Feature.Null` |
| `Features.CreateCylinderBuilder` | `NXOpen.Features.Feature.Null` |
| `Features.CreateConeBuilder` | **`NXOpen.Features.Cone.Null`** |
| `Features.CreateExtrudeBuilder` | `NXOpen.Features.Feature.Null` |
| `BaseFeatures.CreateAssociativeLineBuilder` | `NXOpen.Features.AssociativeLine.Null` |

Die Übergabe erfolgt im Patch über eine gemeinsame, protokollierende
Hilfsfunktion `new_feature_builder`. Sie setzt **keine** Integer-Tags ein,
ändert keine API-Fehler in einen Erfolg und ersetzt den Kegel nicht durch
andere Geometrie. Ein Fehler stoppt weiterhin den Aufbau.

Die Diagnose protokolliert jetzt zusätzlich den zuletzt verwendeten Builder,
den tatsächlich übergebenen Python-Nullobjekttyp, die Geometrieoperation und
soweit verfügbar die Dokumentation des betreffenden NX-Python-Aufrufs.

## 5. Erweiterter Vortest in deiner NX-Installation

Der Vortest kennzeichnet jeden Modellierschritt mit START und OK. Er prüft
weiterhin Block, Zylinderabzug, Kegel, assoziative Linien und Profil-Extrusion.
Hinzugekommen ist ein Kegelabzug entlang der negativen X-Richtung. Damit wird
auch der subtraktive Einsatz des Kegels geprüft, nicht nur ein freier Körper
entlang +Z. Alle Probegeometrien und Probeänderungen werden zurückgenommen.

Nach den Modellierschritten folgen unverändert die Prüfung einer abhängigen
Parameteränderung, das Speichern eines Testteils und dessen Einfügen in eine
Testbaugruppe. Erst folgende Gesamtmeldung bedeutet, dass dieser Vortest in
deiner NX-Installation vollständig durchgelaufen ist:

```text
API-Vortest bestanden: Ausdruecke, Parameteraenderung, Features, SaveAs und AddComponent.
```

Ein Vortest ist noch kein Nachweis, dass sämtliche 176 Maschinen-Einzelteile
oder alle Baugruppenoperationen erfolgreich aufgebaut wurden.

## 6. Ausgabe und vorhandene Dateien

Neue Ausgabe:

```text
NX_Output/
  SX35Z_v4_3_<Zeitstempel>/
    _API_Test/
    Teile/
    Unterbaugruppen/
    SX35Z_GESAMT_v4.prt
```

Die Maschinenordner entstehen erst beim vollständigen Hauptlauf; ein reiner
Vortest erzeugt keine Maschinenbaugruppe. Der Stammname `SX35Z_GESAMT_v4.prt`
bleibt bestehen, weil sich die Modellgeometrie nicht geändert hat.
Ein Zeitstempel verhindert das Überschreiben früherer Ausgaben.

Bei erneutem Abbruch wird `NX_Fehlerprotokoll.txt` im Journalordner neu
beschrieben. Zusätzliche datierte Protokolle stehen unter `NX_Output`.
Das aktuelle Protokoll muss die Versionszeile **4.3** tragen. Der Patch
schließt keine vorhandenen Benutzerteile; angelegte Test-/unvollständige
Teile können nach einem Abbruch noch geöffnet sein.

## 7. Tatsächlich durchgeführte Prüfungen

**75 lokale Tests, alle erfolgreich, mit ausdrücklich simulierten NX-Objekten:**
21 Einheitenregressionen, 32 Ausdrucksregressionen und 22 Feature-/Dispatchtests.
Der ursprüngliche Fehler wird durch strikt getrennte Nullobjekttypen
nachgestellt. Mit `Feature.Null` wird der Kegelaufruf im Test abgelehnt; mit
`Cone.Null` akzeptiert. Auch Rücknahme und Builder-Aufräumen sind abgedeckt.

Die unveränderte Definition enthält 176 Teile mit 871 primitiven Operationen:
220 Blöcke, 581 Zylinder, 64 Profil-Extrusionen und 6 Kegeloperationen. Alle
wurden durch die **simulierte Schnittstelle** geführt. Das ist KEINE Prüfung
von Volumenkörpern und KEIN tatsächlicher NX-Geometrieaufbau. Die Testkörper
besitzen keine echte Geometrie.

Zusätzlich: Syntaxprüfung nach Python-3.10-Grammatik; Byte-/SHA-256-Abgleich
von `modell_v4.py`, `v3_geometriebasis.py` und `Parameter.json`; unveränderter
Quelltext der Klasse `ExpressionFactory` gegenüber Version 4.2.

Berichte und Tests befinden sich unter `Tests/`. Diese Simulationstests nur
mit gewöhnlichem Python außerhalb von NX ausführen. Für den realen Test in
NX ausschließlich `NX_API_Pruefen.py` verwenden.

**Nicht geprüft:** reale Ausführung in Siemens NX 2406, vollständiger nativer
Geometrieaufbau, native PRT-Speicherung und Gesamtbaugruppe. Die älteren
CAD-/STEP-Prüfberichte betreffen die zuvor erzeugte v4-Geometrie und sind
kein NX-Nachweis. Passgenauigkeit und Fertigungsfreigabe bleiben offen.

## 8. Grundlagen der Schnittstellenprüfung

Primärnachweis des aktuellen Fehlers: dein NX-2406-Laufprotokoll,
`NX_Fehlerprotokoll(2).txt`, insbesondere die Testphasen und der Traceback.
Die Datei wird aus Datenschutzgründen nicht nochmals in die Pakete kopiert.

Ergänzender Signaturabgleich mit veröffentlichten NXOpen-API-Referenzen
(ältere Versionen bzw. andere Sprachbindungen, keine pauschale 2406-Freigabe):

- NX Open C++ Reference Guide, FeatureCollection:
  https://www.ugapi.com/doc/nxopen/a02829.html
- NX Open C++ Reference Guide, ConeBuilder:
  https://www.ugapi.com/doc/nxopen/a02745.html
- NXOpen-Referenz NX2022.1, FeatureCollection:
  https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.Features.FeatureCollection.html
- NXOpen-Referenz NX2022.1, BaseFeatureCollection:
  https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.Features.BaseFeatureCollection.html

Maßgeblich für den konkreten Python-Fehler ist die Typanforderung, die deine
NX-Installation selbst meldet. Die älteren Referenzen dienen dem zusätzlichen
Vergleich der weiteren Builder-Aufrufe.
