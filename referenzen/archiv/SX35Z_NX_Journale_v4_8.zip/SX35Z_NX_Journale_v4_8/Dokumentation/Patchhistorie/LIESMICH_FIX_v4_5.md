# SX3.5Z – NX-Journal 4.5 / Geometriestand 4.0

Ziel: Siemens NX 2406, Python 3.10. Native parametrische Einzelteile und
Dateibaugruppen. Keine STEP-Importgeometrie, keine geaenderten Maschinenmasse.
**Fotorekonstruktion; keine Fertigungs- oder Bestellfreigabe.**

## Warum diese Fassung

Das Nutzerprotokoll `NX_Fehlerprotokoll(4).txt` meldet fuer v4.4 einen bestandenen
API-Vortest: Ausdruecke, Parameteraktualisierung, Features, Speichern und
Komponenteneinfuegung. Erst das erste Maschinenbauteil `P001_Basis_Guss_Foto`
bricht bei `031_Aufstellbohrung_ANNAHME` ab:

    Werkzeugkoerper ist ausserhalb des Zielkoerpers

Das ist kein erneuter Einheiten-, Ausdrucks-, Cone.Null- oder Dateinamensfehler.
Die tatsaechlichen NX-Koerperkoordinaten/Volumina und die verwendeten numerischen
Parameter waren im Protokoll an dieser Stelle nicht enthalten.
**Die genaue interne Ursache ist deshalb nicht bewiesen.**

Eine erneute unabhaengige Berechnung mit den mitgelieferten Standardparametern
in CadQuery/OpenCascade zeigt, dass diese Bohrung etwa 5021.03292 mm^3 Material
entfernt. Auch alle anderen 870 Schritte haben dort eine messbare geometrische
Wirkung. Das beweist nicht, dass NX dieselbe Geometrie aufgebaut hat.

## Geaenderter Aufbau

1. Jeder Block, Zylinder, Kegel und jede Profil-Extrusion entsteht zuerst als
   eigenstaendiger nativer Werkzeug-/Grundkoerper, ohne eingebetteten Abzug.
2. NX misst dessen exakte achsparallele Begrenzung und Volumen. Diese werden
   mit den analytischen Sollwerten des Rezepts verglichen.
3. Erst danach verbindet ein **eigenes natives BooleanFeature** Werkzeug und
   Zielkoerper. Die Rohfeatures bleiben assoziative Eltern.
4. Auch die Volumenwirkung des Booleans wird kontrolliert. Ein fehlgeschlagener
   oder wirkungsloser Abzug wird **nicht** uebersprungen. Keine Bohrung wird
   verschoben, kein Gussmaterial erfunden, kein parametrisches Feature durch
   einen importierten Koerper ersetzt.
5. Frische Achsen pro Zylinder/Kegel, explizite Initialisierung von
   Zylinderursprung/-richtung und absolute WCS-Ausrichtung aller **neu erzeugten**
   Teile vermeiden Abhaengigkeit von impliziten Builder-Voreinstellungen.
6. Die tatsaechlichen assoziativen Punktkoordinaten werden vor Verwendung
   kontrolliert. Der Vortest umfasst zusaetzlich einen Zylinder entlang -Y und
   eine explizite Vereinigung.
7. Bei exakt passenden Standardparametern und unveraendertem Rezept werden
   zusaetzlich alle Zwischenvolumina mit der mitgelieferten OpenCascade-Referenz
   verglichen. Bei eigenen Parametern wird nur dieser Standardvergleich
   abgeschaltet; Werkzeugpruefungen und Boolean-Wirkungspruefungen bleiben aktiv.

Werkzeug-Begrenzungstoleranz der numerischen Pruefung: 0.005 mm.
Volumenvergleich: max(0.002 mm^3, 1e-5 * Sollvolumen).
Diese Prueftoleranzen sind **keine Genauigkeitszusage des Fotomodells**.

## Installation

### Vorhandenes v4.4-Paket aktualisieren

Alle sechs Programm-/Datendateien aus dem kleinen Patchordner neben die
vorhandene `Parameter.json` kopieren:

| Datei | Aktion |
|---|---|
| `NX_Detailbaugruppe_erzeugen.py` | ersetzen |
| `nx_native.py` | ersetzen |
| `nx_files.py` | mitgelieferte, inhaltlich unveraenderte v4.4-Dateiverwaltung |
| `nx_geometry.py` | neu |
| `Geometrie_Referenz_v4.json` | neu, erforderlich |
| `NX_Basis_Pruefen.py` | neu |

`modell_v4.py`, `v3_geometriebasis.py` und **die eigene `Parameter.json`
unveraendert lassen**. Das kleine Patchpaket enthaelt keine Parameterdatei.
Alle Dateien muessen im selben Ordner liegen, nicht in mehreren Unterordnern.

### Vollstaendiges Journalpaket

Das vollstaendige ZIP in einen neuen beschreibbaren Ordner entpacken.
Es enthaelt die urspruenglichen Standardwerte. Eigene v4-Parameter koennen durch
Kopieren der vorhandenen `Parameter.json` uebernommen werden. Keine Bibliothek
wie CadQuery, NumPy oder OCP wird fuer den NX-Journallauf benoetigt.

## Ausfuehren

Zuerst ueber NX > Journal wiedergeben / Play Journal:

    NX_Basis_Pruefen.py

Es laeuft erst der allgemeine API-Vortest und danach **das wirkliche
38-Schritte-Basisteil P001**, einschliesslich aller vier Aufstellbohrungen.
Im Ausgabefenster muss `Journal-Version: 4.5` erscheinen.
Ein bestandener allgemeiner API-Test allein genuegt nicht. Erfolg ist erst die
anschliessende Meldung `FERTIG: 1 native Einzelteile.` mit gespeicherter Basis.

Nach erfolgreichem Basistest:

    NX_Detailbaugruppe_erzeugen.py

Dieser Lauf erzeugt erneut seine eigenen Teile in einem neuen Ausgabeordner.
Er verwendet die Diagnose-Basis nicht als Komponente.

Weitere Journale:
- `NX_API_Pruefen.py`: nur die allgemeinen API-Tests, NICHT die ganze Basis.
- `NX_Einzelteile_erzeugen.py`: alle 176 Einzelteile, ohne Baugruppenaufbau.

Ausgabe:

    NX_Output/SX35Z_v4_5_<Zeitstempel>_<Laufkennung>/
        Teile/
        Unterbaugruppen/
        SX35Z_GESAMT_v4__<Laufkennung>.prt
        HAUPTBAUGRUPPE.txt
        Parameter_beim_Aufbau.json

Hauptdatei und Unterordner gemeinsam aufbewahren. Dateiverwaltung, Save statt
SaveAs und eindeutige Laufkennung aus v4.4 bleiben erhalten. Vorhandene Teile
werden nicht geloescht oder ueberschrieben.

## Diagnose

Jedes erfolgreich gespeicherte Teil erhaelt eine zusaetzliche Datei
`<Teilename>.prt.geometrie.json` mit Soll-/Ist-Begrenzungen und Volumina.
Bei Fehlern im Einzelteilaufbau entstehen `NX_Fehlerprotokoll.txt` im
Journalordner und `NX_Geometriediagnose.json` im jeweiligen Ausgabeordner.
Die tatsaechlich geladenen Parameter werden bereits vor dem API-Test gesichert.
Ein weiterer Fehler wird nicht als fertiges Gesamtmodell ausgegeben.

Optionale Metadaten/Provenienzattribute koennen in der NX-Installation weiterhin
abgelehnt werden. Solche Attributfehler werden gesammelt; Geometrie-, Speicher-
und Baugruppenfehler bleiben dagegen fatal. Die Dokumentation im Paket bleibt
auch bei fehlenden NX-Attributen massgeblich.

## Parametrik und Grenzen

176 Teile, 10 Unterbaugruppen; Geometriestand v4.0 unveraendert. Die Einzelteile
verwenden native, durch benannte Ausdruecke gesteuerte Features. Die Zahl der
Features steigt durch die getrennten Grundkoerper und Booleans; die Geometrie
soll identisch bleiben. Keine Montagezwangsbedingungen oder automatische
Interpart-Verknuepfungen. Fuer globale Aenderungen Parameterdatei bearbeiten und
neu erzeugen. Die Dokumentation/Modellbeschreibung der v4 bleibt gueltig.

**Es wurde hier kein Siemens NX gestartet und keine native .prt erzeugt.**
Die Laufzeitkontrollen sind Teil der neuen Fassung, kein bereits bestandener
Test auf dem Rechner des Nutzers. Die lokale CAD-Pruefung verwendet OpenCascade,
nicht den NX-Geometriekern. Die NX-Schnittstellen wurden nur nachgebildet.
Ein erfolgreicher Gesamtaufbau in NX 2406 bleibt zu bestaetigen.

## Pruefnachweise und Quellen

`Pruefbericht_Journal_v4_5.json` trennt die unabhaengige CAD-Pruefung,
die nachgebildete NX-Schnittstelle und die nicht ausgefuehrte NX-Pruefung.
`Tests/` enthaelt aktuelle reproduzierbare Tests fuer Python ausserhalb von NX.
Die CAD-gestuetzten Tests benoetigen CadQuery; die Journale selbst nicht.
Alte Patchdokumente und Tests sind nur als Historie unter
`Dokumentation/Patchhistorie/` enthalten und sind nicht die v4.5-Testsuite.

Hersteller-API-Referenzen (Siemens-Referenztexte, gespiegelt):
- https://www.ugapi.com/doc/nxopen/a02762.html – CylinderBuilder: Ursprung,
  Richtung, Achse, ParentAssociativity.
- https://www.ugapi.com/doc/nxopen/a00635.html – AxisCollection/CreateAxis.
- https://www.ugapi.com/doc/nxopen/a02712.html – BooleanBuilder: Ziel, Werkzeuge,
  Operation und Aufbewahrung der beteiligten Koerper.
- https://www.ugapi.com/doc/nxopen/a02829.html – typisiertes BooleanFeature.Null.
- https://www.ugapi.com/doc/ufun/uf_modl/global.html – AskBoundingBoxExact und
  AskMassProps3d; bei units=4 ist das ausgegebene Volumen in m^3.

Diese Referenzen dokumentieren die verwendeten Schnittstellen; sie beweisen
nicht die Ursache des spezifischen Fehlers aus dem Nutzerprotokoll.
