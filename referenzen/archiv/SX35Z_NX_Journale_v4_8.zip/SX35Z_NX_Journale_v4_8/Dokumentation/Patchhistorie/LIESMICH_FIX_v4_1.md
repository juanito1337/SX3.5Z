# HISTORIE – für aktuelle Installation LIESMICH_FIX_v4_2.md verwenden

# SX3.5Z – NX-Journal-Korrektur 4.1

## Ursache des gemeldeten Abbruchs

Das Fehlerprotokoll nennt NX 2406 (Installationspfad nx2406), Python 3.10.12
und Journal 4.0. Der Abbruch erfolgt im API-Vortest, bevor Maschinen-Einzelteile
gebaut werden. Die Meldung über Millimeterteile stammt aus dem Journal selbst.

Im Journal 4.0 steht irrtümlich:

```python
if self.part.PartUnits != NXOpen.Part.Units.Millimeters:
    raise RuntimeError("Dieses Journal unterstuetzt nur Millimeterteile.")
```

Die Eigenschaft `PartUnits` hat den Enum-Typ `NXOpen.BasePart.Units`.
Der korrekte Vergleich lautet daher:

```python
self.part.PartUnits == NXOpen.BasePart.Units.Millimeters
```

`session.Parts.NewDisplay(name, NXOpen.Part.Units.Millimeters)` verwendet
dagegen weiterhin korrekt `Part.Units`. Diese beiden APIs dürfen nicht durch
globales Ersetzen auf denselben Enum-Typ umgestellt werden.

## Installation des kleinen Korrekturpakets

1. Die beiden Python-Dateien `nx_native.py` und
   `NX_Detailbaugruppe_erzeugen.py` aus dem Patch in denselben bisherigen
   v4-Ordner kopieren, in dem auch `modell_v4.py` und `Parameter.json` liegen.
   Die beiden vorhandenen Dateien ersetzen. Eine Sicherung der alten Dateien
   kann außerhalb des Journalordners aufbewahrt werden.
2. `Parameter.json`, `modell_v4.py` und `v3_geometriebasis.py` unverändert
   lassen. Der Patch enthält bewusst keine Parameterdatei und überschreibt
   daher keine eigenen Maßänderungen.
3. In NX über »Journal wiedergeben / Play Journal« zunächst die bereits im
   v4-Ordner vorhandene Datei `NX_API_Pruefen.py` starten.
4. Im Listing Window muss `Journal-Version: 4.1` erscheinen. Danach sollte
   die Einheitenprüfung `Einheitenpruefung OK: Millimeter ...` melden.
5. Erst wenn der GESAMTE API-Vortest erfolgreich ist, das Hauptjournal
   `NX_Detailbaugruppe_erzeugen.py` starten. Es führt den Vortest ebenfalls aus.

Der Hauptlauf erzeugt einen neuen Ordner `NX_Output/SX35Z_v4_1_<Zeitstempel>`.
Die Geometrieversion bleibt v4.0 und der Name der Hauptbaugruppe bleibt
`SX35Z_GESAMT_v4.prt`. Unterbaugruppen und Teile bleiben zusammen in diesem
Ausgabeordner. Es werden keine alten PRT-Dateien überschrieben oder vorhandene
Teile von Zoll nach Millimeter umgerechnet.

## Alternative: vollständiges kleines Journalpaket

`SX35Z_NX_Journale_v4_1.zip` enthält alle benötigten Skripte und die originalen
v4-Standardparameter. In einen neuen Ordner entpacken. Eigene Parameteränderungen
bei Bedarf aus der bisherigen `Parameter.json` übernehmen. STEP-Dateien,
CadQuery und zusätzliche Python-Pakete sind für den NX-Journallauf nicht nötig.

## Änderungen in 4.1

- Einheitenprüfung mit dem dokumentierten `BasePart.Units`-Enum.
- Zusätzlicher Abgleich von einer nativen Längeneinheit nach mm über
  `UnitCollection.Convert`, soweit vom Binding bereitgestellt. Ein Widerspruch
  führt zum Abbruch. Ist dieser zusätzliche Aufruf nicht verfügbar, bleibt der
  bestätigte BasePart-Enum-Vergleich maßgeblich und wird protokolliert.
- Prüfung aller neu angelegten Teile, auch der Baugruppen-Container.
- Kein Abschalten der Prüfung und keine fest codierten numerischen Enum-Werte.
- Einheitenwerte und Python-Typen, geladene Modulpfade und Testphasen im Log.
- Der aktuelle Journalordner erhält bei lokalen Modulimporten Vorrang vor
  älteren Paketordnern. Die drei paketlokalen Module werden wie zuvor neu geladen.
- Zusätzliche Diagnose des Probe-Features und seiner Ausdrücke bei Testabbruch.
- Fehlermeldung im frühen Vortest behauptet nicht mehr, dass Maschinen-Einzelteile
  bereits gespeichert wurden.
- Geometrierezept und Standardparameter unverändert; kein STEP-Reexport.

## Prüfumfang und Grenzen

Lokal durchgeführt: Python-3.10-Syntaxprüfung, 21 automatisierte
Regressionstests mit getrennten simulierten NX-Enum-Typen, Prüfung des
unveränderten v4-Rezepts mit 176 Einzelteilen und 10 Unterbaugruppen sowie
Datei-Hashvergleich der Geometrie- und Parameterdateien.

Diese Regressionstests laufen OHNE NX. Die Funktionssignaturen wurden gegen
veröffentlichte NX-API-Referenzen abgeglichen, nicht gegen eine hier installierte
NX-2406-Laufzeit. Hier wurde KEIN Siemens NX gestartet, KEINE PRT gespeichert
und KEIN vollständiger Journalaufbau als erfolgreich bestätigt. Weitere
API-Probleme können beim nun weiterlaufenden lokalen Vortest sichtbar werden.

Bei erneutem Abbruch bitte die NEU erzeugte `NX_Fehlerprotokoll.txt` aus genau
diesem Journalordner verwenden. Es muss Version 4.1 darin stehen. Die frühere
Version 4.0 des Protokolls nicht erneut verwenden.

## Referenzen (öffentlich erreichbare Spiegel der API-Referenz)

- BasePart.PartUnits: https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.BasePart.html
- PartCollection.NewDisplay: https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.PartCollection.html
- UnitCollection.Convert: https://nxopencsdocumentation.thescriptingengineer.com/NX2022_1/NXOpen.UnitCollection.html
- NX Open C++ BasePart: https://www.ugapi.com/doc/nxopen/a00638.html

Dies sind Signaturreferenzen, keine Bestätigung eines ausgeführten Python-Journals
in NX 2406. Die Siemens-Python-Referenz ließ sich hier nicht direkt abrufen.
