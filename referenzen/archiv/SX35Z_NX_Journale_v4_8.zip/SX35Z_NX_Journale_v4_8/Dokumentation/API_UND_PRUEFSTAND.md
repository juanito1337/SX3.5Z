# Aktueller Stand v4.8

Siehe ../LIESMICH.md und ../Pruefbericht_v4_8.json.
Historische Berichte sind keine v4.8-Pruefungen.
Keine echte NX-Ausfuehrung.
