# Modellentscheidungen und offene Genauigkeit

## Quellenhierarchie

1. Nutzerfotos: Form, sichtbare Bauteilaufteilung, Öffnungen, Rippen, Bedienelemente.
2. Bereits bereitgestellte Anleitung: Tisch 740 × 180 mm, T-Nutenöffnung 12 mm, Abstand 53 mm, Verfahrwege und Pinolenhub. Die Achszuordnung von Sockelmaßen ist eine Modellannahme.
3. Fotomaßstäbe: nur grobe Größenorientierung. Parallaxe, nicht sichtbare Nullanschläge und unterschiedliche Höhen verhindern die Verwendung als präzise Zeichnungen.
4. Einpassannahmen: unvermessene Wanddicken, freie Bohrungen, Flansche, Lagerräume und Verbindungen werden explizit als Annahmen bezeichnet.

## Gegenüber v3 gezielt geändert

- Kreuzschlitten neu aus den Fotos 1000047959–1000047963: X-Länge 220 und Y-Breite 180 mm sind vorläufige Fotowerte. Der bisherige 260-mm-Block wurde ersetzt. Die nicht fotografierte Y-Unterseite bleibt angenommen.
- Kopf: Hohlräume, Pinolenboss, Lagerbrücke, Z-Gegenprofil, separate Front- und Unterbleche. Kopfbreite 150 mm und Höhe 220 mm sind Näherungen, keine bestätigten Messwerte.
- Gusssäulenbreite: 138 mm als Einpassannahme innerhalb der vorläufig 150 mm breiten Blechhülle. Die frühere 158-mm-Annahme würde in dieser Kombination kollidieren. Diese Änderung ist ausdrücklich **kein neuer Messwert**.
- Blechhülle: 780 mm Länge, 150 mm Breite, 215/125 mm Tiefe aus grober Fotoablesung; Stufe, Schräge und 1,5 mm Dicke frei angenähert. Dreidimensionale Blechkörper, keine abgewickelten NX-Sheet-Metal-Teile.
- Elektrik: niedriger im tiefen Gehäuseabschnitt positioniert, damit die Einbaukörper nicht durch die angenommene obere Schräge ragen. Diese Lagen müssen mit der echten Montageplatte abgeglichen werden.
- Hauptmotor W92-1000 F und GPG-Z-Motor anhand lesbarer Typenschilder zugeordnet. Die Typenschilder liefern keine vollständigen Gehäusezeichnungen. Ihre Maße bleiben Fotoannahmen.
- Bedienpanel: LCD unten, Not-Halt oben rechts und zwei Taster links gemäß dem realen Panel-Foto, nicht nach der älteren vereinfachten Frontaufteilung.
- Sichtbare Originalspindeln bleiben als Bestands-Gleitspindeln bezeichnet. Keine Kugelrückläufe, Kugelmuttern oder CNC-Motoren erfunden.

## Montage und Genauigkeitsgrenzen

Die Montage ist eine parametergesteuerte Positionierung, keine gelöste Passungsbaugruppe. Einzelne kleine Überschneidungen an angenommenen Anschlussstellen sind nicht ausgeschlossen. Die Volumenprüfung jedes einzelnen Teils ersetzt keine Interferenzprüfung der gesamten Maschine.

Die nominale Außenhülle kann von den Katalog-Gesamtmaßen abweichen. Insbesondere die fotografisch angenommene Säulenlänge und der originale Hubmotor bestimmen die Modellhöhe. Die dokumentierte Kataloghöhe wurde nicht durch stilles Verformen der Teile erzwungen.

Gewinde sind grundsätzlich als glatte Hüllzylinder dargestellt. Muttern und Lager erhalten vereinfachte Bohrungen. Nicht sichtbare Motor- und Getriebeinnereien werden nicht erzeugt. Der Spindelkonus ist eine aus v3 übernommene SK30-Normannäherung, keine vermessene Aufnahme der realen Maschine.

## Kein CNC-Fertigungsstand

Dieser Stand ist die detailliertere Bestandsmaschine. Die spätere CNC-Auslegung benötigt insbesondere Spindel-/Mutteranschlüsse, Lagerbohrungen, bewegte Kopfmasse und den realen freien Bauraum. Dieses Paket enthält keine Bestellfreigaben und keine Sicherheitsfreigabe.
