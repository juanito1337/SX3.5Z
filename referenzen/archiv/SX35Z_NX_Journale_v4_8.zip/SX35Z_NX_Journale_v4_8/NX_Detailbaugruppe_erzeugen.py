# -*- coding: utf-8 -*-
"""SX3.5Z model v4 / NX journal patch v4.8 -- create every native part, then 10 subassemblies and root .prt.
Run with Siemens NX > Journal > Play. No external Python packages required.
Always writes a new timestamped directory; existing parts remain unmodified.
The STEP files are not read by this script.
"""
import os, sys, json, re, traceback, importlib.util
from uuid import uuid4
from datetime import datetime
HERE=os.path.dirname(os.path.abspath(__file__))
if HERE in sys.path:sys.path.remove(HERE)
sys.path.insert(0,HERE)
# NX retains modules between journal runs: explicitly reload this package only.
for _n in ('modell_v4','v3_geometriebasis','nx_native','nx_files','nx_geometry'):
    if _n in sys.modules:del sys.modules[_n]
import modell_v4 as model
import NXOpen, NXOpen.Features, NXOpen.Assemblies
from nx_native import (NativeModelBuilder, ExpressionFactory, RunLog,
                       log_environment, require_millimeter_part, JOURNAL_VERSION)
from nx_files import NativePartFiles, FILES_VERSION, prepare_output_directory
from nx_geometry import ReferenceCheck, GEOMETRY_VERSION


_metadata_warnings=[]
def attr(obj,key,value):
    # Provenance metadata is optional. Geometry/file/assembly errors remain fatal.
    try:obj.SetUserAttribute(key,-1,str(value),NXOpen.Update.Option.Now)
    except Exception as exc:_metadata_warnings.append('%s: %s'%(key,exc))

def ident():
    m=NXOpen.Matrix3x3()
    m.Xx=1.;m.Xy=0.;m.Xz=0.;m.Yx=0.;m.Yy=1.;m.Yz=0.;m.Zx=0.;m.Zy=0.;m.Zz=1.
    return m

def newpart(session,name,log=None):
    # NewDisplay explicitly requires Part.Units (NOT BasePart.Units).
    part=session.Parts.NewDisplay(name,NXOpen.Part.Units.Millimeters)
    # PartUnits, in contrast, returns BasePart.Units. Check every new part,
    # including assembly containers, before creating any features.
    require_millimeter_part(part,log)
    part.WCS.SetOriginAndMatrix(NXOpen.Point3d(0.0,0.0,0.0),ident())
    if not part.Preferences.Modeling.GetHistoryMode():
        raise RuntimeError('NX muss im History-Modus arbeiten. Kein historienfreier Aufbau.')
    return part

def add_component(parent,filename,name,xyz,layer=1):
    result=parent.ComponentAssembly.AddComponent(filename,'Entire Part',name,
                        NXOpen.Point3d(*[float(x) for x in xyz]),ident(),int(layer))
    if isinstance(result,tuple):
        component=result[0]
        for item in result[1:]:
            if hasattr(item,'NumberUnloadedParts') and item.NumberUnloadedParts:
                messages=[]
                for i in range(item.NumberUnloadedParts):
                    try:messages.append(item.GetStatusDescription(i))
                    except Exception:pass
                item.Dispose()
                raise RuntimeError('Komponente nicht voll geladen: '+str(messages))
            if hasattr(item,'Dispose'):item.Dispose()
    else:component=result
    if component is None:raise RuntimeError('AddComponent lieferte keine Komponente: '+name)
    return component

class PartBuilder(NativeModelBuilder):
    def __init__(self,session,part,parameters,definition,log,reference=None):
        super().__init__(session,part,parameters,log)
        self.definition=model.local_definition(definition)
        self.source_definition=definition
        self.reference=reference
        self.needed=model.used_parameters(self.definition)
        self.known=set(parameters)|set(model.DERIVED)
    def create_expressions(self):
        super().create_expressions(needed=self.needed)
    def build_one(self,mode=None):
        # Mode was tested in a separate API part. Unit objects are resolved
        # freshly from this actual part for every expression creation.
        if mode is None:
            self.expression_factory.select()
        else:
            require_millimeter_part(self.part)
            self.expression_factory.mode=mode
            self.expression_factory.unit=None
        self.create_expressions();target=None
        for i,op in enumerate(self.definition['ops'],1):
            self.current_feature='%03d_%s'%(i,op['label'])
            _,target=self.primitive(op,target,self.current_feature)
            if self.reference is not None:self.reference.check(self.definition['id'],i,self.last_measurement)
        # All primitives exist before optional provenance metadata is attached.
        self.verify_expression_values()
        self.write_expression_metadata()
        self.style(target,self.source_definition)
        for key,value in {'SX_VERSION':model.VERSION,'SX_JOURNAL_VERSION':JOURNAL_VERSION,'SX_PART_ID':self.definition['id'],'SX_TEILNAME':self.definition['name'],
                          'SX_GRUPPE':self.definition['group'],'SX_QUELLE':self.definition['source'],
                          'SX_STATUS':self.definition['status'],'SX_GRENZEN':self.definition['note'],
                          'SX_DATUM_FORMEL':json.dumps(self.definition['datum']),
                          'SX_EINHEIT':'mm','SX_NX_TEST':'Lokaler Lauf erforderlich; keine Fertigungsfreigabe'}.items():attr(self.part,key,value)
        # Explicit MODEL reference set avoids exposing construction objects on import.
        try:
            rs=self.part.CreateReferenceSet();rs.SetName('MODEL');rs.AddObjectsToReferenceSet([target])
        except Exception as exc:self.log('Optionales MODEL-Referenzset nicht erzeugt: '+str(exc))
        return target

def probe(session,params,log,out,files):
    """Actual runtime test on user's NX, including file save + component insertion.
    The numeric part shape is checked via the existing associative probe.
    Files are retained in _API_Test for diagnostics and are NOT in final assembly.
    """
    os.makedirs(out,exist_ok=True)
    path=files.filename(out,'API_Testteil')
    p=files.create(path,lambda target:newpart(session,target,log))
    b=NativeModelBuilder(session,p,params,log)
    try:
        log('API-Testphase 1: API-Auswahl mit Punktprobe UND allen Modell-Ausdruecken')
        b.expression_factory.select(validate_model=b.create_expressions)
        log('API-Testphase 2: Alle Modell-Ausdruecke nach Test-Ruecknahme erneut erzeugen')
        b.create_expressions()
        log('API-Testphase 3: Native Featuretypen und Parameteraktualisierung')
        b.native_probe()
    except Exception:
        log('API-Testteil: '+str(getattr(p,'Name','unbekannt')))
        log('API-Testfeature: '+str(b.current_feature))
        b.feature_diagnostics()
        b.expression_factory.diagnostics()
        raise
    log('API-Testphase 4: Speichern und Einfuegen einer Testkomponente')
    # Build and save a small native solid so the actual assembly API is tested too.
    op=dict(kind='box',op='add',origin=['0','0','0'],size=['10','10','10'])
    b.primitive(op,None,'API_Testwuerfel')
    errors=session.UpdateManager.DoUpdate(session.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible,'API update'))
    if errors:raise RuntimeError('API-Test Updatefehler: '+str(errors))
    b.verify_expression_values()
    # The last cube tests expression creation after native_probe's rollback.
    # Optional attributes are not interleaved with geometric operations.
    b.write_expression_metadata()
    for warning in b.warnings[:10]:log('Metadatenhinweis: '+warning)
    files.save(p,path)
    assembly_path=files.filename(out,'API_Testbaugruppe')
    a=files.create(assembly_path,lambda target:newpart(session,target,log))
    c=add_component(a,path,'API_Testkomponente',(13,0,0))
    result=c.GetPosition()
    if not isinstance(result,tuple) or abs(result[0].X-13)>1e-6:raise RuntimeError('AddComponent/GetPosition API-Test nicht bestanden')
    files.save(a,assembly_path)
    log('API-Vortest bestanden: Ausdruecke, Parameteraenderung, Features, Save und AddComponent.')
    return b.expression_factory.mode

def main(probe_only=False,parts_only=False,part_filter=None,paths_only=False):
    session=NXOpen.Session.GetSession();log=RunLog(session)
    current=None;builder=None;out=None;mark=None;files=None
    try:
        log('SX3.5Z Detailmodell v4 -- Native Einzelteile zuerst, danach Baugruppen.')
        log('FOTO-REKONSTRUKTION; Anschlussmasse unbestaetigt. KEIN Fertigungsdatensatz.')
        log_environment(log)
        log('Startjournal: '+os.path.abspath(__file__))
        if JOURNAL_VERSION != '4.8' or FILES_VERSION != '4.8' or GEOMETRY_VERSION != '4.6' or model.VERSION != '4.8':
            raise RuntimeError('Gemischte Journalversionen. Alle Patchdateien im selben Ordner ablegen.')
        params=model.load_parameters(os.path.join(HERE,'Parameter.json'));values=model.check_recipe(params)
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        run_id=uuid4().hex[:12]
        out=prepare_output_directory(HERE,'SX35Z_v4_8_'+stamp+'_'+run_id,log)
        log.set_output_directory(out)
        if paths_only:
            log('Nur Pfadtest: keine NX-Testteile oder Maschinenbauteile erzeugt.')
            log.save();return
        files=NativePartFiles(session,out,run_id,log)
        log('Dateiverwaltung: '+os.path.join(HERE,'nx_files.py'))
        log('Geometriepruefung: '+os.path.join(HERE,'nx_geometry.py')+' / '+GEOMETRY_VERSION)
        log('Laufkennung fuer ALLE Dateinamen: '+run_id)
        log('Speicherweg: NewDisplay am endgueltigen Pfad, dann Save; kein SaveAs.')
        reference=ReferenceCheck(os.path.join(HERE,'Geometrie_Referenz_v4.json'),params,model.recipe(),log)
        with open(os.path.join(out,'Parameter_beim_Aufbau.json'),'w',encoding='utf8') as f:json.dump(params,f,indent=2)
        mode=probe(session,params,log,os.path.join(out,'_API_Test'),files)
        if probe_only:log.save();return
        definitions=model.recipe()
        if part_filter:definitions=[d for d in definitions if d['id'] in part_filter or d['name'] in part_filter]
        if not definitions:raise ValueError('Keine Teile im Filter')
        partsdir=os.path.join(out,'Teile');groupsdir=os.path.join(out,'Unterbaugruppen')
        os.makedirs(partsdir);os.makedirs(groupsdir)
        manifest=[]
        for index,d in enumerate(definitions,1):
            current=d['filename'];log('[%03d/%03d] %s'%(index,len(definitions),current))
            path=files.filename(partsdir,d['filename'])
            p=files.create(path,lambda target:newpart(session,target,log))
            mark=session.SetUndoMark(NXOpen.Session.MarkVisibility.Visible,'V4 '+d['name'])
            builder=PartBuilder(session,p,params,d,log,reference);body=builder.build_one(mode)
            errors=session.UpdateManager.DoUpdate(mark)
            if errors:raise RuntimeError('NX Update meldet %d Fehler'%errors)
            if len(list(p.Bodies))!=1:raise RuntimeError('Einzelteil enthaelt nicht genau einen Koerper: '+current)
            try:p.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Isometric,NXOpen.View.ScaleAdjustment.Fit)
            except Exception:pass
            files.save(p,path)
            with open(path+'.geometrie.json','w',encoding='utf8') as f:json.dump(builder.geometry_trace,f,indent=2)
            item=dict(id=d['id'],name=d['name'],file=os.path.relpath(path,out),group=d['group'],datum=[model.evaluate(x,values) for x in d['datum']],datum_formula=d['datum'],native_feature_count=builder.feature_count,expression_mode=mode,journal_version=JOURNAL_VERSION)
            manifest.append(item)
            with open(os.path.join(out,'Erzeugte_Teile.json'),'w',encoding='utf8') as f:json.dump(manifest,f,indent=2)
            for w in builder.warnings[:2]:log('Darstellungshinweis: '+w)
            # Do not close all parts or modify existing user documents.
            mark=None
        if not parts_only:
            subpaths=[]
            for group in model.GROUPS:
                members=[m for m in manifest if m['group']==group]
                if not members:continue
                current=group
                path=files.filename(groupsdir,group)
                p=files.create(path,lambda target:newpart(session,target,log))
                for m in members:
                    c=add_component(p,os.path.join(out,m['file']),m['id']+'_'+m['name'],m['datum'],model.LAYERS[group])
                    attr(c,'SX_PART_ID',m['id']);attr(c,'SX_PLATZIERUNG','Parameter.json; explizite Lage, keine Montagezwangsbedingungen')
                attr(p,'SX_VERSION',model.VERSION);attr(p,'SX_JOURNAL_VERSION',JOURNAL_VERSION);attr(p,'SX_BAUGRUPPE',model.GROUPS[group])
                files.save(p,path);subpaths.append((group,path))
                log('Unterbaugruppe gespeichert: '+group)
            current='SX35Z_GESAMT_v4'
            rootpath=files.filename(out,current)
            root=files.create(rootpath,lambda target:newpart(session,target,log))
            for g,path in subpaths:add_component(root,path,g,(0,0,0))
            attr(root,'SX_VERSION',model.VERSION);attr(root,'SX_JOURNAL_VERSION',JOURNAL_VERSION);attr(root,'SX_MODELLTYP','Native Dateibaugruppe; parametrisierte Einzelteile, explizite Einbaupositionen')
            attr(root,'SX_GRENZEN','Keine Montagezwangsbedingungen oder Kinematiksimulation. Rekonstruktion, keine Fertigungsdaten.')
            for n in ['pos_x','pos_y','head_down','quill_down']:attr(root,'SX_STELLUNG_'+n,params[n])
            try:root.ModelingViews.WorkView.Orient(NXOpen.View.Canned.Isometric,NXOpen.View.ScaleAdjustment.Fit)
            except Exception:pass
            files.save(root,rootpath)
            with open(os.path.join(out,'HAUPTBAUGRUPPE.txt'),'w',encoding='utf8') as f:
                f.write(os.path.basename(rootpath)+'\n')
            log('HAUPTBAUGRUPPE: '+rootpath)
        with open(os.path.join(out,'Parameter_beim_Aufbau.json'),'w',encoding='utf8') as f:json.dump(params,f,indent=2)
        if _metadata_warnings:log('Optionale Metadatenwarnungen: %d; Geometrie dadurch nicht uebersprungen.'%len(_metadata_warnings))
        log('FERTIG: %d native Einzelteile. Ihre bereits offenen Dateien wurden nicht bearbeitet.'%len(manifest))
        log('Formaenderungen lokal: Ausdruecke sx_. Gesamtmodell/Einbaulagen: Parameter.json aendern und neu aufbauen.')
        log('Ausgabeordner komplett zusammenhalten: Teile + Unterbaugruppen + Hauptbaugruppe.')
        log.save()
    except Exception:
        log(traceback.format_exc());log('Betroffenes Teil: '+str(current))
        if builder is not None:
            if out:
                try:
                    with open(os.path.join(out,'NX_Geometriediagnose.json'),'w',encoding='utf8') as f:
                        json.dump(dict(part=current,parameters=params,completed=builder.geometry_trace,
                                       failed=builder.last_geometry_context),f,indent=2)
                except Exception as e:log('Geometriediagnose nicht geschrieben: '+str(e))
            log('Betroffenes Feature: '+str(builder.current_feature))
            try:
                builder.feature_diagnostics()
                builder.expression_factory.diagnostics()
            except Exception:pass
        if mark is not None:
            try:session.UndoToMark(mark,None)
            except Exception as e:log('Ruecknahme fehlgeschlagen: '+str(e))
        if out:
            if current is None:
                log('Abbruch im Vortest; in diesem Lauf wurden noch keine Maschinen-Einzelteile aufgebaut.')
            log('Ausgabeordner dieses Laufs (ggf. unvollstaendig): '+out)
        log.save(failed=True)
        try:NXOpen.UI.GetUI().NXMessageBox.Show('SX35Z Journal v4.8',NXOpen.NXMessageBox.DialogType.Error,'Abbruch. Details im Listing Window und NX_Fehlerprotokoll.txt. Keine fertige Baugruppe behauptet.')
        except Exception:pass
        raise

def getUnloadOption(dummy):return NXOpen.Session.LibraryUnloadOption.Immediately
if __name__=='__main__':main()
